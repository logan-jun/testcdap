(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ExperimentsDetailedView"],{

/***/ "../../node_modules/clipboard/dist/clipboard.js":
/*!****************************************************************************************************!*\
  !*** delegated ../../../node_modules/clipboard/dist/clipboard.js from dll-reference shared_vendor ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = (__webpack_require__(/*! dll-reference shared_vendor */ "dll-reference shared_vendor"))("./node_modules/clipboard/dist/clipboard.js");

/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/CollapsibleWrapper/CollapsibleWrapper.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/CollapsibleWrapper/CollapsibleWrapper.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.collapsable-wrapper {\n  display: inline-block;\n  max-width: 100%; }\n  .collapsable-wrapper .popper {\n    text-align: left;\n    width: auto;\n    z-index: 1; }\n  .collapsable-wrapper .view-popover-wrapper {\n    display: inline-block;\n    vertical-align: top;\n    margin: 0 3px; }\n  .collapsable-wrapper .view-wrapper {\n    color: #0099ff;\n    cursor: pointer; }\n  .collapsable-wrapper .with-view-link {\n    width: calc(100% - 50px);\n    display: inline-block;\n    overflow: hidden;\n    vertical-align: top;\n    text-overflow: ellipsis; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/CopyableID/CopyableID.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/CopyableID/CopyableID.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.copyable-id {\n  display: inline-block;\n  padding: 0 10px;\n  cursor: pointer; }\n  .copyable-id.hide.popper.tooltip {\n    opacity: 0; }\n  .copyable-id .popper {\n    width: auto;\n    min-width: unset;\n    display: -webkit-inline-box;\n    display: inline-flex;\n    -webkit-box-align: center;\n            align-items: center; }\n    .copyable-id .popper .copied-label {\n      margin: 0 5px;\n      display: -webkit-inline-box;\n      display: inline-flex;\n      -webkit-box-align: center;\n              align-items: center; }\n      .copyable-id .popper .copied-label .icon-check-circle {\n        margin-right: 3px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/AddModelToPipelineBtn/AddModelToPipelineBtn.scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/AddModelToPipelineBtn/AddModelToPipelineBtn.scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.add-model-to-pipeline[disabled] .btn.btn-primary {\n  color: white;\n  cursor: not-allowed; }\n  .add-model-to-pipeline[disabled] .btn.btn-primary:focus {\n    outline: none; }\n\n.add-model-to-pipeline .btn.btn-primary {\n  display: -webkit-box;\n  display: flex;\n  max-width: -webkit-fit-content;\n  max-width: -moz-fit-content;\n  max-width: fit-content; }\n  .add-model-to-pipeline .btn.btn-primary > span:first-child {\n    margin-right: 10px; }\n  .add-model-to-pipeline .btn.btn-primary > span:only-child {\n    margin: 0; }\n\n.add-model-to-pipeline .popper {\n  min-width: -webkit-fit-content;\n  min-width: -moz-fit-content;\n  min-width: fit-content; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/DetailedView.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/DetailedView.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.experiment-detailed-view {\n  height: 100%; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/ExperimentMetricsDropdown/ExperimentMetricsDropdown.scss":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/ExperimentMetricsDropdown/ExperimentMetricsDropdown.scss ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.experiments-metrics-dropdown {\n  width: 450px; }\n  .experiments-metrics-dropdown > div:last-of-type {\n    height: calc(100% - 30px); }\n  .experiments-metrics-dropdown > div.empty-message {\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-pack: center;\n            justify-content: center;\n    -webkit-box-align: center;\n            align-items: center;\n    font-size: 1.5rem;\n    color: #bbbbbb;\n    border: 2px solid #bbbbbb;\n    border-radius: 4px;\n    margin-top: 10px; }\n    .experiments-metrics-dropdown > div.empty-message > span {\n      margin: 0 5px; }\n    .experiments-metrics-dropdown > div.empty-message .icon-svg {\n      color: #0099ff;\n      cursor: pointer;\n      display: block; }\n    .experiments-metrics-dropdown > div.empty-message .popper {\n      font-size: 1rem; }\n  .experiments-metrics-dropdown .styled-select-wrapper {\n    margin-left: 250px; }\n  .experiments-metrics-dropdown .pie-chart-with-legends .pie-chart-legends {\n    margin-left: 20px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/HyperParamsPopover/HyperParamsPopover.scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/HyperParamsPopover/HyperParamsPopover.scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.hyperparameters-popover {\n  cursor: pointer;\n  display: inline-block;\n  margin-right: 5px; }\n  .hyperparameters-popover .popper {\n    width: auto;\n    padding: 10px;\n    text-align: left; }\n    .hyperparameters-popover .popper .table.table-bordered {\n      border: 0;\n      margin: 0; }\n      .hyperparameters-popover .popper .table.table-bordered thead tr th {\n        color: #999999;\n        border-top: 0; }\n        .hyperparameters-popover .popper .table.table-bordered thead tr th:first-of-type {\n          border-left: 0; }\n        .hyperparameters-popover .popper .table.table-bordered thead tr th:last-of-type {\n          border-right: 0; }\n      .hyperparameters-popover .popper .table.table-bordered tbody tr td {\n        text-align: left; }\n      .hyperparameters-popover .popper .table.table-bordered tbody tr td:first-of-type {\n        border-left: 0; }\n      .hyperparameters-popover .popper .table.table-bordered tbody tr td:last-of-type {\n        border-right: 0; }\n      .hyperparameters-popover .popper .table.table-bordered tbody tr:last-of-type td {\n        border-bottom: 0; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/ModelStatusIndicator/ModelStatusIndicator.scss":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/ModelStatusIndicator/ModelStatusIndicator.scss ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.model-status-indicator {\n  display: -webkit-inline-box;\n  display: inline-flex;\n  -webkit-box-align: center;\n          align-items: center;\n  line-height: 1.4; }\n  .model-status-indicator > span {\n    margin-left: 5px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/ModelsTable/DetailedViewModelsTable.scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/ModelsTable/DetailedViewModelsTable.scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2015 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.experiment-models-table {\n  padding: 25px 35px;\n  height: calc(100% - 230px); }\n  .experiment-models-table .experiment-table-header {\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-pack: justify;\n            justify-content: space-between; }\n    .experiment-models-table .experiment-table-header .btn-container {\n      display: -webkit-box;\n      display: flex; }\n      .experiment-models-table .experiment-table-header .btn-container .btn {\n        color: #0099ff; }\n    .experiment-models-table .experiment-table-header .pagination-with-title {\n      margin: 0; }\n  .experiment-models-table .grid-wrapper {\n    height: calc(100% - 32px);\n    overflow: auto; }\n  .experiment-models-table .grid.grid-container {\n    max-height: 100%; }\n    .experiment-models-table .grid.grid-container .grid-header .sortable-header {\n      cursor: pointer;\n      display: -webkit-box;\n      display: flex;\n      -webkit-box-align: center;\n              align-items: center; }\n      .experiment-models-table .grid.grid-container .grid-header .sortable-header:hover {\n        text-decoration: underline; }\n      .experiment-models-table .grid.grid-container .grid-header .sortable-header .icon-svg {\n        font-size: 1.3rem; }\n    .experiment-models-table .grid.grid-container .grid-header .grid-row,\n    .experiment-models-table .grid.grid-container .grid-body .grid-row {\n      grid-template-columns: 20px 1.5fr 1fr 1.5fr 1fr 1fr 1fr 1.5fr 20px;\n      white-space: nowrap; }\n      .experiment-models-table .grid.grid-container .grid-header .grid-row:hover [class*=\"icon-\"],\n      .experiment-models-table .grid.grid-container .grid-body .grid-row:hover [class*=\"icon-\"] {\n        color: #0099ff; }\n    .experiment-models-table .grid.grid-container .grid-body .grid-row.opened {\n      grid-template-columns: 1fr;\n      background: #f5f5f5;\n      border-bottom: 3px solid #bbbbbb;\n      border-top: 0;\n      -webkit-box-align: start;\n              align-items: start;\n      cursor: auto; }\n      .experiment-models-table .grid.grid-container .grid-body .grid-row.opened .content-wrapper {\n        display: grid;\n        grid-template-columns: 20px 1fr 1fr 1fr 1fr 20px;\n        white-space: nowrap;\n        text-overflow: ellipsis;\n        height: 100%;\n        padding: 0; }\n      .experiment-models-table .grid.grid-container .grid-body .grid-row.opened > div:not(.model-action-btns) strong {\n        display: block; }\n      .experiment-models-table .grid.grid-container .grid-body .grid-row.opened > div:not(.model-action-btns) .copyable-id {\n        padding-left: 0; }\n      .experiment-models-table .grid.grid-container .grid-body .grid-row.opened > div:not(.model-action-btns) > div {\n        padding: 5px 0; }\n        .experiment-models-table .grid.grid-container .grid-body .grid-row.opened > div:not(.model-action-btns) > div > div:nth-child(2) {\n          padding-top: 10px; }\n      .experiment-models-table .grid.grid-container .grid-body .grid-row.opened .collapsable-wrapper .grid.grid-container {\n        max-height: 300px;\n        padding: 0 10px; }\n        .experiment-models-table .grid.grid-container .grid-body .grid-row.opened .collapsable-wrapper .grid.grid-container .grid-row {\n          grid-template-columns: 1fr; }\n        .experiment-models-table .grid.grid-container .grid-body .grid-row.opened .collapsable-wrapper .grid.grid-container.directives-list .grid-header .grid-row {\n          grid-template-columns: 1fr auto; }\n          .experiment-models-table .grid.grid-container .grid-body .grid-row.opened .collapsable-wrapper .grid.grid-container.directives-list .grid-header .grid-row:hover {\n            background: transparent; }\n        .experiment-models-table .grid.grid-container .grid-body .grid-row.opened .collapsable-wrapper .grid.grid-container.directives-list .grid-header strong {\n          padding-left: 0;\n          color: #999999; }\n      .experiment-models-table .grid.grid-container .grid-body .grid-row.opened.loading {\n        display: -webkit-box;\n        display: flex;\n        -webkit-box-pack: center;\n                justify-content: center; }\n      .experiment-models-table .grid.grid-container .grid-body .grid-row.opened .model-action-btns {\n        display: -webkit-box;\n        display: flex;\n        -webkit-box-align: center;\n                align-items: center;\n        flex-wrap: wrap;\n        margin-left: 20px;\n        margin-top: 0;\n        padding: 0;\n        padding-left: 0; }\n        .experiment-models-table .grid.grid-container .grid-body .grid-row.opened .model-action-btns .add-model-to-pipeline {\n          margin: 5px 5px 5px 0; }\n    .experiment-models-table .grid.grid-container .grid-body .grid-row.active {\n      border-bottom: 0;\n      border-top: 2px solid #bbbbbb;\n      background: #f5f5f5; }\n    .experiment-models-table .grid.grid-container .grid-body .grid-row.highlight {\n      border-color: #3cc801; }\n    .experiment-models-table .grid.grid-container .grid-body > a {\n      color: inherit; }\n    .experiment-models-table .grid.grid-container .grid-body .algorithm-cell,\n    .experiment-models-table .grid.grid-container .grid-body > div > span {\n      width: 100%;\n      overflow: hidden;\n      text-overflow: ellipsis;\n      white-space: nowrap; }\n    .experiment-models-table .grid.grid-container .grid-body [class*=\"icon-\"] {\n      color: #999999; }\n      .experiment-models-table .grid.grid-container .grid-body [class*=\"icon-\"]:hover {\n        color: #0099ff; }\n    .experiment-models-table .grid.grid-container.classification .grid-header .grid-row,\n    .experiment-models-table .grid.grid-container.classification .grid-body .grid-row {\n      grid-template-columns: 20px 1fr 1fr 2fr 1fr 1fr 1fr 20px; }\n    .experiment-models-table .grid.grid-container.classification .grid-body .grid-row.opened {\n      grid-template-columns: 1fr;\n      cursor: auto; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/PredictionDatasetExploreModal/PredictionDatasetExploreModal.scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/PredictionDatasetExploreModal/PredictionDatasetExploreModal.scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.predictions-dataset-disabled {\n  max-width: 120px; }\n  .predictions-dataset-disabled .btn.btn-secondary {\n    cursor: not-allowed;\n    opacity: 0.6; }\n  .predictions-dataset-disabled .popper {\n    min-width: -webkit-max-content;\n    min-width: -moz-max-content;\n    min-width: max-content; }\n\n.tooltip .fast-action-tooltip {\n  text-align: left; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/TopPanel/DetailedViewTopPanel.scss":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/TopPanel/DetailedViewTopPanel.scss ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.experiments-toppanel.detailed-view {\n  height: 250px;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: start;\n          align-items: flex-start;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n  padding: 25px 35px;\n  margin: 0; }\n  .experiments-toppanel.detailed-view .experiment-toppanel-container {\n    display: -webkit-box;\n    display: flex;\n    height: 100%;\n    width: 100%; }\n  .experiments-toppanel.detailed-view .algorithm-distribution,\n  .experiments-toppanel.detailed-view .experiment-metadata {\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n            flex-direction: column;\n    -webkit-box-pack: justify;\n            justify-content: space-between; }\n  .experiments-toppanel.detailed-view .experiment-metadata {\n    width: calc(100% - 450px);\n    padding-right: 30px; }\n    .experiments-toppanel.detailed-view .experiment-metadata > div {\n      display: -webkit-box;\n      display: flex;\n      -webkit-box-align: start;\n              align-items: flex-start;\n      margin: 20px 0; }\n      .experiments-toppanel.detailed-view .experiment-metadata > div:first-of-type {\n        margin: 0;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n                flex-direction: column;\n        text-overflow: ellipsis;\n        width: 100%; }\n        .experiments-toppanel.detailed-view .experiment-metadata > div:first-of-type h2 {\n          margin: 0;\n          line-height: 1.3; }\n        .experiments-toppanel.detailed-view .experiment-metadata > div:first-of-type > div,\n        .experiments-toppanel.detailed-view .experiment-metadata > div:first-of-type > h2 {\n          width: 100%;\n          white-space: nowrap;\n          overflow: hidden;\n          text-overflow: ellipsis; }\n        .experiments-toppanel.detailed-view .experiment-metadata > div:first-of-type .description {\n          color: #999999; }\n      .experiments-toppanel.detailed-view .experiment-metadata > div:not(:first-of-type) {\n        border-bottom: 1px solid #bbbbbb;\n        margin: 0; }\n        .experiments-toppanel.detailed-view .experiment-metadata > div:not(:first-of-type) div,\n        .experiments-toppanel.detailed-view .experiment-metadata > div:not(:first-of-type) strong {\n          width: 100%;\n          white-space: nowrap;\n          overflow: hidden;\n          text-overflow: ellipsis; }\n      .experiments-toppanel.detailed-view .experiment-metadata > div:last-child {\n        border-bottom: 0; }\n      .experiments-toppanel.detailed-view .experiment-metadata > div > div,\n      .experiments-toppanel.detailed-view .experiment-metadata > div > strong {\n        width: 50%;\n        padding: 0 10px 0 0; }\n  .experiments-toppanel.detailed-view .pie-chart-with-legends {\n    display: -webkit-box;\n    display: flex;\n    width: 450px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/FastAction/ExploreAction/ExploreAction.scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/FastAction/ExploreAction/ExploreAction.scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.fast-action-with-popover.btn.btn-secondary.btn-sm {\n  position: relative;\n  border: 1px solid #7ed321; }\n  .fast-action-with-popover.btn.btn-secondary.btn-sm .fast-action-popover-container {\n    position: absolute;\n    background: #7ed321;\n    padding: 5px;\n    top: -15px;\n    right: -3px;\n    border-radius: 7px;\n    font-size: 11px;\n    color: white; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/FastAction/ExploreAction/ExploreModal.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/FastAction/ExploreAction/ExploreModal.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.explore-modal.modal-dialog {\n  width: 80vw;\n  max-width: 80vw; }\n  .explore-modal.modal-dialog .explore-modal-body {\n    padding: 10px; }\n    .explore-modal.modal-dialog .explore-modal-body textarea {\n      resize: none;\n      margin: 0;\n      margin-bottom: 10px;\n      width: 100%; }\n    .explore-modal.modal-dialog .explore-modal-body .fa.fa-spinner {\n      margin-right: 10px; }\n    .explore-modal.modal-dialog .explore-modal-body .clearfix .text-danger {\n      word-wrap: break-word;\n      word-break: break-all; }\n    .explore-modal.modal-dialog .explore-modal-body .queries-table-wrapper {\n      margin-top: 10px;\n      max-height: calc(80vh - 225px);\n      overflow: auto; }\n    .explore-modal.modal-dialog .explore-modal-body .queries-table {\n      background-color: #f6f6f6;\n      border: 1px solid #bbbbbb; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table th,\n      .explore-modal.modal-dialog .explore-modal-body .queries-table td {\n        border: 0;\n        vertical-align: middle; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table tbody tr,\n      .explore-modal.modal-dialog .explore-modal-body .queries-table thead tr {\n        border-bottom: 1px solid #bbbbbb; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .btn-group .btn.btn-secondary {\n        padding: 7px;\n        border: 0;\n        background: transparent; }\n        .explore-modal.modal-dialog .explore-modal-body .queries-table .btn-group .btn.btn-secondary:first-child {\n          padding-left: 0; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .query-timestamp {\n        width: 185px; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .query-status {\n        width: 115px; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .query-status-value {\n        margin-right: 10px; }\n        .explore-modal.modal-dialog .explore-modal-body .queries-table .query-status-value ~ .fa-spinner {\n          margin: 0; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .query-actions {\n        width: 105px; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .preview-cell .fa.fa-spinner.fa-spin {\n        width: 100%; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .preview-cell > div {\n        width: calc(80vw - 40px);\n        overflow: auto; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PieChartWithLegend/PieChartWithLegend.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PieChartWithLegend/PieChartWithLegend.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.pie-chart-with-legends > div.pie-chart-legends {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap; }\n  .pie-chart-with-legends > div.pie-chart-legends > div {\n    margin: 10px 0;\n    line-height: 1;\n    width: 100%;\n    overflow: hidden;\n    white-space: nowrap;\n    text-overflow: ellipsis; }\n    .pie-chart-with-legends > div.pie-chart-legends > div .pie-legend-color {\n      width: 15px;\n      height: 15px;\n      display: inline-block;\n      margin: 0px 10px;\n      vertical-align: top;\n      border-radius: 50%; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/StyledSelectTag/StyledSelectTag.scss":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/StyledSelectTag/StyledSelectTag.scss ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.styled-select-wrapper {\n  display: inline-block; }\n  .styled-select-wrapper .styled-select-tag {\n    border: 0;\n    background: transparent;\n    border-bottom: 1px solid;\n    border-radius: 0;\n    border-bottom-right-radius: 0;\n    border-bottom-left-radius: 0;\n    -webkit-appearance: none;\n       -moz-appearance: none;\n            appearance: none; }\n    .styled-select-wrapper .styled-select-tag:focus, .styled-select-wrapper .styled-select-tag:active, .styled-select-wrapper .styled-select-tag:hover {\n      outline: none; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/lodash/isNumber.js":
/*!*************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/isNumber.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(/*! ./_baseGetTag */ "../../node_modules/lodash/_baseGetTag.js"),
    isObjectLike = __webpack_require__(/*! ./isObjectLike */ "../../node_modules/lodash/isObjectLike.js");

/** `Object#toString` result references. */
var numberTag = '[object Number]';

/**
 * Checks if `value` is classified as a `Number` primitive or object.
 *
 * **Note:** To exclude `Infinity`, `-Infinity`, and `NaN`, which are
 * classified as numbers, use the `_.isFinite` method.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a number, else `false`.
 * @example
 *
 * _.isNumber(3);
 * // => true
 *
 * _.isNumber(Number.MIN_VALUE);
 * // => true
 *
 * _.isNumber(Infinity);
 * // => true
 *
 * _.isNumber('3');
 * // => false
 */
function isNumber(value) {
  return typeof value == 'number' ||
    (isObjectLike(value) && baseGetTag(value) == numberTag);
}

module.exports = isNumber;


/***/ }),

/***/ "../../node_modules/lodash/isString.js":
/*!*************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/isString.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(/*! ./_baseGetTag */ "../../node_modules/lodash/_baseGetTag.js"),
    isArray = __webpack_require__(/*! ./isArray */ "../../node_modules/lodash/isArray.js"),
    isObjectLike = __webpack_require__(/*! ./isObjectLike */ "../../node_modules/lodash/isObjectLike.js");

/** `Object#toString` result references. */
var stringTag = '[object String]';

/**
 * Checks if `value` is classified as a `String` primitive or object.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a string, else `false`.
 * @example
 *
 * _.isString('abc');
 * // => true
 *
 * _.isString(1);
 * // => false
 */
function isString(value) {
  return typeof value == 'string' ||
    (!isArray(value) && isObjectLike(value) && baseGetTag(value) == stringTag);
}

module.exports = isString;


/***/ }),

/***/ "../../node_modules/redux-thunk/es/index.js":
/*!**********************************************************************************************!*\
  !*** delegated ../../../node_modules/redux-thunk/es/index.js from dll-reference cdap_vendor ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, exports, __webpack_require__) {

module.exports = (__webpack_require__(/*! dll-reference cdap_vendor */ "dll-reference cdap_vendor"))("./node_modules/redux-thunk/es/index.js");

/***/ }),

/***/ "./api/explore.js":
/*!************************!*\
  !*** ./api/explore.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_0__["default"].getInstance();
var basepath = '/namespaces/:namespace/data/explore/tables';
var queriesPath = '/namespaces/:namespace/data/explore/queries';
var queryHandleApi = '/data/explore/queries/:queryHandle';
var myExploreApi = {
  fetchTables: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  fetchQueries: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'POLL', queriesPath),
  submitQuery: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', queriesPath),
  getQuerySchema: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', queryHandleApi + '/schema'),
  getQueryPreview: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', queryHandleApi + '/preview'),
  pollQueryStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'POLL', queryHandleApi + '/status'),
  download: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', queryHandleApi + '/download')
};
/* harmony default export */ __webpack_exports__["default"] = (myExploreApi);

/***/ }),

/***/ "./api/metadata.js":
/*!*************************!*\
  !*** ./api/metadata.js ***!
  \*************************/
/*! exports provided: MyMetadataApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyMetadataApi", function() { return MyMetadataApi; });
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__["default"].getInstance();
var basepath = '/namespaces/:namespace/:entityType/:entityId/metadata';
var lineagePath = '/namespaces/:namespace/datasets/:entityId/lineage/fields';
var fieldLineagePath = '/namespaces/:namespace/datasets/:entityId/lineage/allfieldlineage';
var MyMetadataApi = {
  getMetadata: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  getProperties: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/properties?responseFormat=v6")),
  addProperties: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/properties")),
  deleteProperty: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(basepath, "/properties/:key")),
  getTags: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/tags?responseFormat=v6")),
  addTags: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/tags")),
  deleteTags: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(basepath, "/tags/:key")),
  // Field Level Lineage
  getFields: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', lineagePath),
  getFieldLineage: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(lineagePath, "/:fieldName")),
  getFieldOperations: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(lineagePath, "/:fieldName/operations")),
  getAllFieldLineage: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', fieldLineagePath)
};

/***/ }),

/***/ "./components/CollapsibleWrapper/CollapsibleWrapper.scss":
/*!***************************************************************!*\
  !*** ./components/CollapsibleWrapper/CollapsibleWrapper.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./CollapsibleWrapper.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/CollapsibleWrapper/CollapsibleWrapper.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/CollapsibleWrapper/index.js":
/*!************************************************!*\
  !*** ./components/CollapsibleWrapper/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollapsibleWrapper; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





__webpack_require__(/*! ./CollapsibleWrapper.scss */ "./components/CollapsibleWrapper/CollapsibleWrapper.scss");

var CollapsibleWrapper =
/*#__PURE__*/
function (_Component) {
  _inherits(CollapsibleWrapper, _Component);

  function CollapsibleWrapper() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, CollapsibleWrapper);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(CollapsibleWrapper)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      showViewLink: false
    });

    _defineProperty(_assertThisInitialized(_this), "setViewLink", function () {
      if (_this.contentRef) {
        _this.setState({
          showViewLink: _this.contentRef.offsetWidth >= _this.contentRef.parentElement.offsetWidth
        });
      }
    });

    return _this;
  }

  _createClass(CollapsibleWrapper, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      window.addEventListener('resize', this.setViewLink);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      window.removeEventListener('resize', this.setViewLink);
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      this.setViewLink();
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        ref: function ref(_ref) {
          return _this2.contentRef = _ref;
        },
        className: "collapsable-wrapper"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()({
          'with-view-link': this.state.showViewLink
        })
      }, this.props.content), this.props.alwaysShowViewLink || this.state.showViewLink ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_3__["default"], {
        target: function target() {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
            className: "view-wrapper"
          }, " View ");
        },
        className: "view-popover-wrapper",
        placement: "right",
        bubbleEvent: false,
        enableInteractionInPopover: true
      }, this.props.popoverContent()) : null);
    }
  }]);

  return CollapsibleWrapper;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(CollapsibleWrapper, "propTypes", {
  content: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  popoverContent: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.node, prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func]),
  alwaysShowViewLink: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});

_defineProperty(CollapsibleWrapper, "defaultProps", {
  alwaysShowViewLink: false
});



/***/ }),

/***/ "./components/CopyableID/CopyableID.scss":
/*!***********************************************!*\
  !*** ./components/CopyableID/CopyableID.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./CopyableID.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/CopyableID/CopyableID.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/CopyableID/index.js":
/*!****************************************!*\
  !*** ./components/CopyableID/index.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CopyableID; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var clipboard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! clipboard */ "../../node_modules/clipboard/dist/clipboard.js");
/* harmony import */ var clipboard__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clipboard__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */










__webpack_require__(/*! ./CopyableID.scss */ "./components/CopyableID/CopyableID.scss");

var PREFIX = "features.CopyableID";

var CopyableID =
/*#__PURE__*/
function (_Component) {
  _inherits(CopyableID, _Component);

  function CopyableID() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, CopyableID);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(CopyableID)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      showTooltip: false
    });

    _defineProperty(_assertThisInitialized(_this), "onIDClickHandler", function (e) {
      _this.setState({
        showTooltip: !_this.state.showTooltip
      });

      if (!_this.props.bubbleEvent) {
        Object(services_helpers__WEBPACK_IMPORTED_MODULE_8__["preventPropagation"])(e);
        return false;
      }
    });

    _defineProperty(_assertThisInitialized(_this), "onPopoverClose", function (showPopover) {
      if (!showPopover) {
        _this.setState({
          showTooltip: showPopover
        });
      }
    });

    return _this;
  }

  _createClass(CopyableID, [{
    key: "renderToolTipText",
    value: function renderToolTipText() {
      if (!this.props.tooltipText) {
        return null;
      }

      if (typeof this.props.tooltipText === 'string' && this.props.tooltipText) {
        return this.props.tooltipText;
      }

      if (this.props.id) {
        return this.props.id;
      }

      return i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".notAvailable"));
    }
  }, {
    key: "render",
    value: function render() {
      var idlabel = "A-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_6___default()());

      if (this.props.idprefix) {
        idlabel = "".concat(this.props.idprefix, "-").concat(this.props.id);
      } // FIXME: Not sure how else to do this. Looks adhoc. Need this for copy to clipboard.


      new clipboard__WEBPACK_IMPORTED_MODULE_3___default.a("#".concat(idlabel));

      var _target = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "copyable-id btn-link",
        id: idlabel,
        onClick: this.onIDClickHandler,
        "data-clipboard-text": this.props.id
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.props.label));

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_2__["default"], {
        target: function target() {
          return _target;
        },
        showOn: "Hover",
        bubbleEvent: false,
        placement: "right",
        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()('copyable-id', {
          hide: !this.props.tooltipText && !this.state.showTooltip
        }),
        showPopover: this.state.showTooltip,
        modifiers: {
          shift: {
            order: 800,
            enabled: true
          }
        },
        onTogglePopover: this.onPopoverClose
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.renderToolTipText()), this.state.showTooltip ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "copied-label text-success"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-check-circle"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".copiedLabel")))) : null);
    }
  }]);

  return CopyableID;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(CopyableID, "propTypes", {
  id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
  idprefix: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  label: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  placement: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  tooltipText: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool]),
  bubbleEvent: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});

_defineProperty(CopyableID, "defaultProps", {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".label")),
  tooltipText: true,
  bubbleEvent: false
});



/***/ }),

/***/ "./components/DeleteEntityBtn/index.js":
/*!*********************************************!*\
  !*** ./components/DeleteEntityBtn/index.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return DeleteEntityBtn; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/ConfirmationModal */ "./components/ConfirmationModal/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var DeleteEntityBtn =
/*#__PURE__*/
function (_Component) {
  _inherits(DeleteEntityBtn, _Component);

  function DeleteEntityBtn() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, DeleteEntityBtn);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(DeleteEntityBtn)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "getDefaulState", function () {
      return {
        showModal: false,
        isLoading: true,
        errorMessage: '',
        extendedMessage: ''
      };
    });

    _defineProperty(_assertThisInitialized(_this), "state", _this.getDefaulState());

    _defineProperty(_assertThisInitialized(_this), "toggleModal", function (e) {
      _this.setState(_objectSpread({}, _this.getDefaulState(), {
        isLoading: !_this.state.isLoading,
        showModal: !_this.state.showModal
      }));

      if (e) {
        Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["preventPropagation"])(e);
      }

      return false;
    });

    _defineProperty(_assertThisInitialized(_this), "setError", function (errorMessage, extendedMessage) {
      _this.setState({
        errorMessage: errorMessage,
        extendedMessage: extendedMessage,
        isLoading: false
      });
    });

    _defineProperty(_assertThisInitialized(_this), "confirmFn", function () {
      _this.setState({
        isLoading: true
      });

      _this.props.confirmFn(_this.toggleModal, _this.setError);
    });

    return _this;
  }

  _createClass(DeleteEntityBtn, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: this.props.className,
        onClick: this.toggleModal
      }, this.props.btnLabel ? this.props.btnLabel : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
        name: "icon-trash"
      })), this.state.showModal ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_3__["default"], {
        isOpen: this.state.showModal,
        cancelFn: this.toggleModal,
        confirmFn: this.confirmFn,
        isLoading: this.state.isLoading,
        toggleModal: this.toggleModal,
        headerTitle: this.props.headerTitle,
        errorMessage: this.state.errorMessage,
        extendedMessage: this.state.extendedMessage,
        confirmationElem: this.props.confirmationElem
      }) : null);
    }
  }]);

  return DeleteEntityBtn;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(DeleteEntityBtn, "propTypes", {
  confirmFn: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func.isRequired,
  headerTitle: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  confirmationElem: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.element,
  btnLabel: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.element]),
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
});



/***/ }),

/***/ "./components/Experiments/DetailedView/AddModelToPipelineBtn/AddModelToPipelineBtn.scss":
/*!**********************************************************************************************!*\
  !*** ./components/Experiments/DetailedView/AddModelToPipelineBtn/AddModelToPipelineBtn.scss ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./AddModelToPipelineBtn.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/AddModelToPipelineBtn/AddModelToPipelineBtn.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/DetailedView/AddModelToPipelineBtn/PipelineSkeleton.js":
/*!***************************************************************************************!*\
  !*** ./components/Experiments/DetailedView/AddModelToPipelineBtn/PipelineSkeleton.js ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return getPipelineConfig; });
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
function getPipelineConfig(_ref) {
  var file = _ref.file,
      wrangler = _ref.wrangler,
      mmds = _ref.mmds;
  return {
    artifact: {},
    description: '',
    name: '',
    config: {
      connections: [{
        from: 'File',
        to: 'Wrangler'
      }, {
        from: 'Wrangler',
        to: 'MLPredictor'
      }],
      comments: [],
      postActions: [],
      properties: {},
      processTimingEnabled: true,
      stageLoggingEnabled: true,
      stages: [{
        name: 'File',
        plugin: {
          name: 'File',
          type: 'batchsource',
          label: 'File',
          artifact: file.corepluginsArtifact,
          properties: {
            referenceName: 'file_source',
            path: file.srcPath,
            schema: '{"name":"fileRecord","type":"record","fields":[{"name":"offset","type":"long"},{"name":"body","type":"string"}]}'
          }
        }
      }, {
        name: 'Wrangler',
        plugin: {
          name: 'Wrangler',
          type: 'transform',
          label: 'Wrangler',
          artifact: wrangler.wranglerArtifact,
          properties: {
            field: 'body',
            precondition: 'false',
            threshold: '1',
            directives: wrangler.directives.join('\n'),
            schema: JSON.stringify(wrangler.schema),
            workspaceId: wrangler.workspaceId
          }
        }
      }, {
        name: 'MLPredictor',
        plugin: {
          name: 'MLPredictor',
          type: 'sparkcompute',
          label: 'MLPredictor',
          artifact: mmds.mmdsPluginsArtifact,
          properties: {
            experimentId: mmds.experimentId,
            modelId: mmds.modelId
          }
        }
      }],
      schedule: '0 * * * *',
      engine: 'mapreduce',
      numOfRecordsPreview: 100,
      maxConcurrentRuns: 1
    }
  };
}

/***/ }),

/***/ "./components/Experiments/DetailedView/AddModelToPipelineBtn/index.js":
/*!****************************************************************************!*\
  !*** ./components/Experiments/DetailedView/AddModelToPipelineBtn/index.js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_artifact__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/artifact */ "./api/artifact.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_Experiments_DetailedView_AddModelToPipelineBtn_PipelineSkeleton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Experiments/DetailedView/AddModelToPipelineBtn/PipelineSkeleton */ "./components/Experiments/DetailedView/AddModelToPipelineBtn/PipelineSkeleton.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var api_experiments__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! api/experiments */ "./api/experiments.js");
/* harmony import */ var components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! components/Experiments/store/CreateExperimentActionCreator */ "./components/Experiments/store/CreateExperimentActionCreator.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_13__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */















__webpack_require__(/*! ./AddModelToPipelineBtn.scss */ "./components/Experiments/DetailedView/AddModelToPipelineBtn/AddModelToPipelineBtn.scss");

var MMDS_PLUGINS_ARTIFACT_NAME = 'mmds-plugins';
var ERROR_MSG = 'Unable to find plugins to create a scoring pipeline';

var AddModelToPipelineBtn =
/*#__PURE__*/
function (_Component) {
  _inherits(AddModelToPipelineBtn, _Component);

  function AddModelToPipelineBtn() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, AddModelToPipelineBtn);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(AddModelToPipelineBtn)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      disabled: _this.props.disabled,
      error: null,
      mmdsPluginsArtifact: null,
      datapipelineArtifact: null,
      wranglerArtifact: null,
      corepluginsArtifact: null,
      schema: null
    });

    _defineProperty(_assertThisInitialized(_this), "cloneId", uuid_v4__WEBPACK_IMPORTED_MODULE_10___default()());

    _defineProperty(_assertThisInitialized(_this), "batchPipelineUrl", window.getHydratorUrl({
      stateName: 'hydrator.create',
      stateParams: {
        namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])(),
        cloneId: _this.cloneId,
        artifactType: services_global_constants__WEBPACK_IMPORTED_MODULE_6__["GLOBALS"].etlDataPipeline
      }
    }));

    _defineProperty(_assertThisInitialized(_this), "setWorkspaceId", function () {
      var srcPath = _this.props.srcPath;
      Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["createWorkspace"])(srcPath).subscribe(function (res) {
        var workspaceId;
        var directives = _this.props.directives;
        workspaceId = res.values[0].id;

        _this.setState({
          workspaceId: workspaceId
        });

        Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["applyDirectives"])(workspaceId, directives).subscribe();
      });
    });

    _defineProperty(_assertThisInitialized(_this), "generatePipelineConfig", function () {
      var _this$props = _this.props,
          experimentId = _this$props.experimentId,
          modelId = _this$props.modelId,
          modelName = _this$props.modelName,
          srcPath = _this$props.srcPath,
          directives = _this$props.directives;
      var _this$state = _this.state,
          mmdsPluginsArtifact = _this$state.mmdsPluginsArtifact,
          wranglerArtifact = _this$state.wranglerArtifact,
          datapipelineArtifact = _this$state.datapipelineArtifact,
          corepluginsArtifact = _this$state.corepluginsArtifact,
          workspaceId = _this$state.workspaceId,
          schema = _this$state.schema;
      var pipelineConfig = Object(components_Experiments_DetailedView_AddModelToPipelineBtn_PipelineSkeleton__WEBPACK_IMPORTED_MODULE_5__["default"])({
        mmds: {
          mmdsPluginsArtifact: mmdsPluginsArtifact,
          experimentId: experimentId,
          modelId: modelId
        },
        wrangler: {
          wranglerArtifact: wranglerArtifact,
          directives: directives,
          schema: schema,
          workspaceId: workspaceId
        },
        file: {
          corepluginsArtifact: corepluginsArtifact,
          srcPath: srcPath
        }
      });
      pipelineConfig = _objectSpread({}, pipelineConfig, {
        name: "Scoring_Pipeline_".concat(experimentId, "_").concat(modelName),
        description: "Scoring pipeline for ".concat(modelName, " under experiment ").concat(experimentId, "."),
        artifact: datapipelineArtifact
      });
      window.localStorage.setItem(_this.cloneId, JSON.stringify(pipelineConfig));
    });

    return _this;
  }

  _createClass(AddModelToPipelineBtn, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.setWorkspaceId();
      this.fetchArtifactForPipelines();
    }
  }, {
    key: "fetchArtifactForPipelines",
    value: function fetchArtifactForPipelines() {
      var _this2 = this;

      var _this$props2 = this.props,
          experimentId = _this$props2.experimentId,
          splitId = _this$props2.splitId;
      api_artifact__WEBPACK_IMPORTED_MODULE_2__["MyArtifactApi"].list({
        namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])()
      }).combineLatest([api_experiments__WEBPACK_IMPORTED_MODULE_11__["myExperimentsApi"].getSplitDetails({
        namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])(),
        experimentId: experimentId,
        splitId: splitId
      })]).subscribe(function (_ref) {
        var _ref2 = _slicedToArray(_ref, 2),
            artifacts = _ref2[0],
            splitDetails = _ref2[1];

        var mmdsPluginsArtifact, datapipelineArtifact, wranglerArtifact, corepluginsArtifact;
        artifacts.forEach(function (artifact) {
          switch (artifact.name) {
            case MMDS_PLUGINS_ARTIFACT_NAME:
              mmdsPluginsArtifact = artifact;
              break;

            case services_global_constants__WEBPACK_IMPORTED_MODULE_6__["GLOBALS"].etlDataPipeline:
              datapipelineArtifact = artifact;
              break;

            case services_global_constants__WEBPACK_IMPORTED_MODULE_6__["GLOBALS"].wrangler.pluginArtifactName:
              wranglerArtifact = artifact;
              break;

            case 'core-plugins':
              // FIXME: We need to move this to use some constant.
              corepluginsArtifact = artifact;
              break;
          }
        });
        var schema = splitDetails.schema;

        if (Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["isNilOrEmpty"])(mmdsPluginsArtifact) || Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["isNilOrEmpty"])(datapipelineArtifact) || Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["isNilOrEmpty"])(wranglerArtifact) || Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["isNilOrEmpty"])(corepluginsArtifact) || Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["isNilOrEmpty"])(schema)) {
          _this2.setState({
            error: ERROR_MSG
          });
        } else {
          _this2.setState({
            mmdsPluginsArtifact: mmdsPluginsArtifact,
            datapipelineArtifact: datapipelineArtifact,
            wranglerArtifact: wranglerArtifact,
            corepluginsArtifact: corepluginsArtifact,
            schema: schema,
            disabled: _this2.props.disabled || false
          });
        }
      }, function () {
        _this2.setState({
          error: ERROR_MSG
        });
      });
    }
  }, {
    key: "render",
    value: function render() {
      var AnchorTag = this.state.disabled ? 'button' : 'a';
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("fieldset", {
        className: "add-model-to-pipeline",
        disabled: this.state.disabled
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(AnchorTag, {
        className: classnames__WEBPACK_IMPORTED_MODULE_13___default()('btn btn-primary btn-sm', {
          disabled: this.state.disabled
        }),
        onClick: this.generatePipelineConfig,
        href: this.state.disabled ? null : this.batchPipelineUrl
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, "Create a scoring pipeline"), this.state.error ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_7__["default"], {
        target: function target() {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_8__["default"], {
            name: "icon-exclamation-triangle"
          });
        },
        showOn: "Hover"
      }, this.state.error) : null));
    }
  }]);

  return AddModelToPipelineBtn;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(AddModelToPipelineBtn, "propTypes", {
  experimentId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  modelId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  modelName: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  srcPath: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  directives: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string),
  splitId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  disabled: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});

_defineProperty(AddModelToPipelineBtn, "defaultProps", {
  disabled: false
});

var mapStateToProps = function mapStateToProps(state, ownProps) {
  var modelObj = state.models.find(function (model) {
    return model.id === ownProps.modelId;
  });
  return {
    experimentId: state.name,
    modelId: ownProps.modelId,
    modelName: Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(modelObj, 'name'),
    directives: Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(modelObj, 'directives'),
    srcPath: state.srcpath,
    splitId: Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(modelObj, 'split')
  };
};

var ConnectedAddModelToPipelineBtn = Object(react_redux__WEBPACK_IMPORTED_MODULE_9__["connect"])(mapStateToProps)(AddModelToPipelineBtn);
/* harmony default export */ __webpack_exports__["default"] = (ConnectedAddModelToPipelineBtn);

/***/ }),

/***/ "./components/Experiments/DetailedView/DeleteExperimentBtn/index.js":
/*!**************************************************************************!*\
  !*** ./components/Experiments/DetailedView/DeleteExperimentBtn/index.js ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return DeleteExperimentBtn; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_DeleteEntityBtn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/DeleteEntityBtn */ "./components/DeleteEntityBtn/index.js");
/* harmony import */ var api_experiments__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/experiments */ "./api/experiments.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Experiments/store/ExperimentDetailActionCreator */ "./components/Experiments/store/ExperimentDetailActionCreator.js");
/* harmony import */ var services_history__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/history */ "./services/history.ts");
/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








var deleteExperiment = function deleteExperiment(experimentId, callback, errCallback) {
  var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])();
  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].deleteExperiment({
    namespace: namespace,
    experimentId: experimentId
  }).subscribe(function () {
    return services_history__WEBPACK_IMPORTED_MODULE_6__["default"].push("/ns/".concat(namespace, "/experiments"));
  }, function (err) {
    var error = "Failed to delete the experiment '".concat(experimentId, "' - ").concat(err.response || err);
    errCallback(error);
  });
};

var deleteConfirmElement = function deleteConfirmElement(experimentId) {
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, "Are you sure you want to delete the experiment ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("b", null, experimentId), "?");
};

function DeleteExperimentBtn(_ref) {
  var experimentId = _ref.experimentId;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_DeleteEntityBtn__WEBPACK_IMPORTED_MODULE_2__["default"], {
    confirmFn: deleteExperiment.bind(null, experimentId, null, components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_5__["setExperimentDetailError"]),
    className: "btn btn-link",
    headerTitle: 'Delete Experiment',
    confirmationElem: deleteConfirmElement(experimentId),
    btnLabel: 'Delete Experiment'
  });
}
DeleteExperimentBtn.propTypes = {
  experimentId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/Experiments/DetailedView/DeleteModelBtn/index.js":
/*!*********************************************************************!*\
  !*** ./components/Experiments/DetailedView/DeleteModelBtn/index.js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return DeleteModelBtn; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_DeleteEntityBtn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/DeleteEntityBtn */ "./components/DeleteEntityBtn/index.js");
/* harmony import */ var components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Experiments/store/ExperimentDetailActionCreator */ "./components/Experiments/store/ExperimentDetailActionCreator.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_experiments__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! api/experiments */ "./api/experiments.js");
/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */







var deleteModel = function deleteModel(experimentId, model, callback, errCallback) {
  var _NamespaceStore$getSt = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["default"].getState(),
      namespace = _NamespaceStore$getSt.selectedNamespace;

  api_experiments__WEBPACK_IMPORTED_MODULE_5__["myExperimentsApi"].deleteModelInExperiment({
    namespace: namespace,
    experimentId: experimentId,
    modelId: model.id
  }).subscribe(function () {
    Object(components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_3__["getModelsInExperiment"])(experimentId);
    callback();
  }, function (err) {
    var error = "Failed to delete the model '".concat(model.name, "' - ").concat(err.response || err);
    errCallback(error);
  });
};

var deleteConfirmElement = function deleteConfirmElement(model) {
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, "Are you sure you want to delete the model ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("b", null, model.name), "?");
};

function DeleteModelBtn(_ref) {
  var experimentId = _ref.experimentId,
      model = _ref.model;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_DeleteEntityBtn__WEBPACK_IMPORTED_MODULE_2__["default"], {
    confirmFn: deleteModel.bind(null, experimentId, model, null, components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_3__["setExperimentDetailError"]),
    headerTitle: 'Delete Model',
    confirmationElem: deleteConfirmElement(model)
  });
}
DeleteModelBtn.propTypes = {
  experimentId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  model: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    name: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  })
};

/***/ }),

/***/ "./components/Experiments/DetailedView/DetailedView.scss":
/*!***************************************************************!*\
  !*** ./components/Experiments/DetailedView/DetailedView.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./DetailedView.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/DetailedView.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/DetailedView/ExperimentDetailPageTitle/index.js":
/*!********************************************************************************!*\
  !*** ./components/Experiments/DetailedView/ExperimentDetailPageTitle/index.js ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-helmet */ "../../node_modules/react-helmet/lib/Helmet.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var EXPERIMENTS_I18N_PREFIX = 'features.Experiments.DetailedView';

function ExperimentDetailPageTitle(_ref) {
  var experiment_name = _ref.experiment_name;
  var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_5__["Theme"].featureNames.analytics;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_helmet__WEBPACK_IMPORTED_MODULE_2___default.a, {
    title: i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate("".concat(EXPERIMENTS_I18N_PREFIX, ".pageTitle"), {
      experiment_name: experiment_name,
      productName: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_5__["Theme"].productName,
      featureName: featureName
    })
  });
}

ExperimentDetailPageTitle.propTypes = {
  experiment_name: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    experiment_name: state.name
  };
};

var ConnectedExperimentDetailPageTitle = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["connect"])(mapStateToProps)(ExperimentDetailPageTitle);
/* harmony default export */ __webpack_exports__["default"] = (ConnectedExperimentDetailPageTitle);

/***/ }),

/***/ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/AlgorithmDistribution.js":
/*!************************************************************************************************!*\
  !*** ./components/Experiments/DetailedView/ExperimentMetricsDropdown/AlgorithmDistribution.js ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var d3__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! d3 */ "../../node_modules/d3/index.js");
/* harmony import */ var components_PieChartWithLegend__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/PieChartWithLegend */ "./components/PieChartWithLegend/index.js");
/* harmony import */ var components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/store/SharedActionCreator */ "./components/Experiments/store/SharedActionCreator.js");
/* harmony import */ var components_Experiments_DetailedView_ExperimentMetricsDropdown_EmptyMetricMessage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Experiments/DetailedView/ExperimentMetricsDropdown/EmptyMetricMessage */ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/EmptyMetricMessage.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var HEIGHT_OF_PIE_CHART = 190;
var colorScale = d3__WEBPACK_IMPORTED_MODULE_2__["scaleOrdinal"](d3__WEBPACK_IMPORTED_MODULE_2__["schemeCategory20"]);

var AlgorithmDistribution = function AlgorithmDistribution(_ref) {
  var algorithms = _ref.algorithms;

  if (!algorithms.length) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_ExperimentMetricsDropdown_EmptyMetricMessage__WEBPACK_IMPORTED_MODULE_5__["default"], {
      mainMessage: "Algorithm Distribution Unavailable",
      popoverMessage: "Atleast one model has to be trained to get Algorithms distribution"
    });
  }

  var algos = algorithms.map(function (algo) {
    return _objectSpread({}, algo, {
      value: Object(components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_4__["getAlgorithmLabel"])(algo.bin),
      color: colorScale(algo.bin)
    });
  });
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PieChartWithLegend__WEBPACK_IMPORTED_MODULE_3__["default"], {
    data: algos,
    width: HEIGHT_OF_PIE_CHART,
    height: HEIGHT_OF_PIE_CHART
  });
};

AlgorithmDistribution.propTypes = {
  algorithms: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    bin: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    count: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number
  }))
};
/* harmony default export */ __webpack_exports__["default"] = (AlgorithmDistribution);

/***/ }),

/***/ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/EmptyMetricMessage.js":
/*!*********************************************************************************************!*\
  !*** ./components/Experiments/DetailedView/ExperimentMetricsDropdown/EmptyMetricMessage.js ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EmptyMetricMessage; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var POPOVER_ICON_DIMENSION = 20;
function EmptyMetricMessage(_ref) {
  var mainMessage = _ref.mainMessage,
      popoverMessage = _ref.popoverMessage;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "empty-message"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_2__["default"], {
    target: function target() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
        name: "icon-info-circle"
      });
    },
    targetDimension: {
      width: POPOVER_ICON_DIMENSION,
      height: POPOVER_ICON_DIMENSION
    },
    placement: "bottom"
  }, popoverMessage), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, mainMessage));
}
EmptyMetricMessage.propTypes = {
  mainMessage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  popoverMessage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/ExperimentMetricsDropdown.scss":
/*!******************************************************************************************************!*\
  !*** ./components/Experiments/DetailedView/ExperimentMetricsDropdown/ExperimentMetricsDropdown.scss ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./ExperimentMetricsDropdown.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/ExperimentMetricsDropdown/ExperimentMetricsDropdown.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/ModelStatusesDistribution.js":
/*!****************************************************************************************************!*\
  !*** ./components/Experiments/DetailedView/ExperimentMetricsDropdown/ModelStatusesDistribution.js ***!
  \****************************************************************************************************/
/*! exports provided: MODEL_STATUS_TO_COLOR_MAP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MODEL_STATUS_TO_COLOR_MAP", function() { return MODEL_STATUS_TO_COLOR_MAP; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_PieChartWithLegend__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PieChartWithLegend */ "./components/PieChartWithLegend/index.js");
/* harmony import */ var components_Experiments_DetailedView_ExperimentMetricsDropdown_EmptyMetricMessage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Experiments/DetailedView/ExperimentMetricsDropdown/EmptyMetricMessage */ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/EmptyMetricMessage.js");
/* harmony import */ var components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/store/ModelStatus */ "./components/Experiments/store/ModelStatus.js");
/* harmony import */ var styles_variables_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! styles/variables.scss */ "./styles/variables.scss");
/* harmony import */ var styles_variables_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styles_variables_scss__WEBPACK_IMPORTED_MODULE_5__);
var _MODEL_STATUS_TO_COLO;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var HEIGHT_OF_PIE_CHART = 190;
var MODEL_STATUS_TO_COLOR_MAP = (_MODEL_STATUS_TO_COLO = {}, _defineProperty(_MODEL_STATUS_TO_COLO, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_4__["MODEL_STATUS"].PREPARING, styles_variables_scss__WEBPACK_IMPORTED_MODULE_5___default.a.blue01), _defineProperty(_MODEL_STATUS_TO_COLO, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_4__["MODEL_STATUS"].SPLITTING, styles_variables_scss__WEBPACK_IMPORTED_MODULE_5___default.a.blue03), _defineProperty(_MODEL_STATUS_TO_COLO, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_4__["MODEL_STATUS"].TRAINING, styles_variables_scss__WEBPACK_IMPORTED_MODULE_5___default.a.blue05), _defineProperty(_MODEL_STATUS_TO_COLO, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_4__["MODEL_STATUS"].DEPLOYED, styles_variables_scss__WEBPACK_IMPORTED_MODULE_5___default.a.green02), _defineProperty(_MODEL_STATUS_TO_COLO, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_4__["MODEL_STATUS"].DATA_READY, styles_variables_scss__WEBPACK_IMPORTED_MODULE_5___default.a.green05), _defineProperty(_MODEL_STATUS_TO_COLO, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_4__["MODEL_STATUS"].TRAINED, styles_variables_scss__WEBPACK_IMPORTED_MODULE_5___default.a.green03), _defineProperty(_MODEL_STATUS_TO_COLO, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_4__["MODEL_STATUS"].SPLIT_FAILED, styles_variables_scss__WEBPACK_IMPORTED_MODULE_5___default.a.red01), _defineProperty(_MODEL_STATUS_TO_COLO, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_4__["MODEL_STATUS"].TRAINING_FAILED, styles_variables_scss__WEBPACK_IMPORTED_MODULE_5___default.a.red03), _MODEL_STATUS_TO_COLO);

var ModelStatusesDistribution = function ModelStatusesDistribution(_ref) {
  var modelStatuses = _ref.modelStatuses;

  if (!modelStatuses.length) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_ExperimentMetricsDropdown_EmptyMetricMessage__WEBPACK_IMPORTED_MODULE_3__["default"], {
      mainMessage: "Model Status Distribution Unavailable",
      popoverMessage: "Atleast one model has to be trained to get Model Status distribution"
    });
  }

  var statuses = modelStatuses.map(function (status) {
    return _objectSpread({}, status, {
      value: status.bin,
      color: MODEL_STATUS_TO_COLOR_MAP[status.bin]
    });
  });
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PieChartWithLegend__WEBPACK_IMPORTED_MODULE_2__["default"], {
    data: statuses,
    width: HEIGHT_OF_PIE_CHART,
    height: HEIGHT_OF_PIE_CHART
  });
};

ModelStatusesDistribution.propTypes = {
  modelStatuses: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    bin: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    count: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number
  }))
};
/* harmony default export */ __webpack_exports__["default"] = (ModelStatusesDistribution);

/***/ }),

/***/ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/index.js":
/*!********************************************************************************!*\
  !*** ./components/Experiments/DetailedView/ExperimentMetricsDropdown/index.js ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var components_StyledSelectTag__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/StyledSelectTag */ "./components/StyledSelectTag/index.js");
/* harmony import */ var components_Experiments_DetailedView_ExperimentMetricsDropdown_AlgorithmDistribution__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Experiments/DetailedView/ExperimentMetricsDropdown/AlgorithmDistribution */ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/AlgorithmDistribution.js");
/* harmony import */ var components_Experiments_DetailedView_ExperimentMetricsDropdown_ModelStatusesDistribution__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Experiments/DetailedView/ExperimentMetricsDropdown/ModelStatusesDistribution */ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/ModelStatusesDistribution.js");
/* harmony import */ var components_Experiments_DetailedView_MetricChartWithLegend__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Experiments/DetailedView/MetricChartWithLegend */ "./components/Experiments/DetailedView/MetricChartWithLegend/index.js");
/* harmony import */ var styles_variables_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! styles/variables.scss */ "./styles/variables.scss");
/* harmony import */ var styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(styles_variables_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_9__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */










var PREFIX = 'features.Experiments.DetailedView';

__webpack_require__(/*! ./ExperimentMetricsDropdown.scss */ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/ExperimentMetricsDropdown.scss");

var ExperimentMetricsDropdown =
/*#__PURE__*/
function (_Component) {
  _inherits(ExperimentMetricsDropdown, _Component);

  function ExperimentMetricsDropdown() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ExperimentMetricsDropdown);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ExperimentMetricsDropdown)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      active: 'algorithms'
    });

    _defineProperty(_assertThisInitialized(_this), "onSelectChange", function (e) {
      _this.setState({
        active: e.target.value
      });
    });

    _defineProperty(_assertThisInitialized(_this), "renderMetricBarChart", function (_ref) {
      var metric = _ref.id,
          label = _ref.value,
          colorRange = _ref.colorRange;

      if (metric === 'algorithms') {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_ExperimentMetricsDropdown_AlgorithmDistribution__WEBPACK_IMPORTED_MODULE_5__["default"], {
          algorithms: _this.props.algorithms.histo || []
        });
      }

      if (metric === 'statuses') {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_ExperimentMetricsDropdown_ModelStatusesDistribution__WEBPACK_IMPORTED_MODULE_6__["default"], {
          modelStatuses: _this.props.statuses.histo || []
        });
      }

      var values = _this.props.evaluationMetrics[metric] || {};

      var _this$containerRef$ge = _this.containerRef.getBoundingClientRect(),
          width = _this$containerRef$ge.width,
          height = _this$containerRef$ge.height;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_MetricChartWithLegend__WEBPACK_IMPORTED_MODULE_7__["default"], {
        colorRange: colorRange,
        xAxisTitle: label,
        metric: metric,
        values: values.histo || [],
        width: width,
        height: height
      });
    });

    return _this;
  }

  _createClass(ExperimentMetricsDropdown, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var keys = _toConsumableArray(ExperimentMetricsDropdown.commonKeys);

      keys = services_global_constants__WEBPACK_IMPORTED_MODULE_3__["NUMBER_TYPES"].indexOf(this.props.outcomeType) !== -1 ? keys.concat(ExperimentMetricsDropdown.regressionKeys) : keys.concat(ExperimentMetricsDropdown.categoricalKeys);
      var matchingKey = keys.find(function (key) {
        return key.id === _this2.state.active;
      });
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "experiments-metrics-dropdown clearfix",
        ref: function ref(_ref2) {
          return _this2.containerRef = _ref2;
        }
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_StyledSelectTag__WEBPACK_IMPORTED_MODULE_4__["default"], {
        keys: keys,
        onChange: this.onSelectChange
      }), this.renderMetricBarChart(matchingKey));
    }
  }]);

  return ExperimentMetricsDropdown;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(ExperimentMetricsDropdown, "propTypes", {
  evaluationMetrics: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  algorithms: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  statuses: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  outcomeType: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
});

_defineProperty(ExperimentMetricsDropdown, "commonKeys", [{
  id: 'algorithms',
  value: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".algoTypes"))
}, {
  id: 'statuses',
  value: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".modelStatus"))
}]);

_defineProperty(ExperimentMetricsDropdown, "regressionKeys", [{
  id: 'rmse',
  value: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".rmse")),
  colorRange: [styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.bluegrey01, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.bluegrey02, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.bluegrey03, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.bluegrey04, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.bluegrey05]
}, {
  id: 'mae',
  value: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".mae")),
  colorRange: [styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.green01, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.green02, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.green03, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.green04, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.green05]
}, {
  id: 'r2',
  value: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".r2")),
  colorRange: [styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.blue01, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.blue02, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.blue03, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.blue04, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.blue05]
}, {
  id: 'evariance',
  value: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".evariance")),
  colorRange: [styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.orange01, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.orange02, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.orange03, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.orange04, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.orange05]
}]);

_defineProperty(ExperimentMetricsDropdown, "categoricalKeys", [{
  id: 'precision',
  value: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".precision")),
  colorRange: [styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.blue01, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.blue02, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.blue03, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.blue04, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.blue05]
}, {
  id: 'recall',
  value: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".recall")),
  colorRange: [styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.orange01, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.orange02, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.orange03, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.orange04, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.orange05]
}, {
  id: 'f1',
  value: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".f1")),
  colorRange: [styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.green01, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.green02, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.green03, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.green04, styles_variables_scss__WEBPACK_IMPORTED_MODULE_8___default.a.green05]
}]);

var mapStateToExperimentMetricsDropdownProps = function mapStateToExperimentMetricsDropdownProps(state) {
  return {
    outcomeType: state.outcomeType,
    evaluationMetrics: state.evaluationMetrics,
    algorithms: state.algorithms,
    statuses: state.statuses
  };
};

var ConnectedExperimentsDropdown = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToExperimentMetricsDropdownProps)(ExperimentMetricsDropdown);
/* harmony default export */ __webpack_exports__["default"] = (ConnectedExperimentsDropdown);

/***/ }),

/***/ "./components/Experiments/DetailedView/HyperParamsPopover/HyperParamsPopover.scss":
/*!****************************************************************************************!*\
  !*** ./components/Experiments/DetailedView/HyperParamsPopover/HyperParamsPopover.scss ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./HyperParamsPopover.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/HyperParamsPopover/HyperParamsPopover.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/DetailedView/HyperParamsPopover/index.js":
/*!*************************************************************************!*\
  !*** ./components/Experiments/DetailedView/HyperParamsPopover/index.js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HyperParamsPopover; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/store/SharedActionCreator */ "./components/Experiments/store/SharedActionCreator.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./HyperParamsPopover.scss */ "./components/Experiments/DetailedView/HyperParamsPopover/HyperParamsPopover.scss");

function HyperParamsPopover(_ref) {
  var algorithm = _ref.algorithm,
      hyperparameters = _ref.hyperparameters;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_3__["default"], {
    target: function target() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
        name: "icon-cogs"
      });
    },
    className: "hyperparameters-popover",
    placement: "right",
    bubbleEvent: false,
    enableInteractionInPopover: true
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("table", {
    className: "table table-bordered"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("thead", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", null, "Hyperparameter"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", null, "Value"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tbody", null, Object.keys(hyperparameters).map(function (param, i) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
      key: i
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, Object(components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_4__["getHyperParamLabel"])(algorithm, param)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, hyperparameters[param], " "));
  }))));
}
HyperParamsPopover.propTypes = {
  hyperparameters: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  algorithm: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/Experiments/DetailedView/MetricChartWithLegend/index.js":
/*!****************************************************************************!*\
  !*** ./components/Experiments/DetailedView/MetricChartWithLegend/index.js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MetricChartWithLegend; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_VegaLiteChart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/VegaLiteChart */ "./components/VegaLiteChart/index.js");
/* harmony import */ var components_Experiments_DetailedView_ExperimentMetricsDropdown_EmptyMetricMessage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Experiments/DetailedView/ExperimentMetricsDropdown/EmptyMetricMessage */ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/EmptyMetricMessage.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var chartSpec = {
  data: {
    values: []
  },
  mark: 'bar',
  encoding: {
    x: {
      field: 'bin',
      type: 'nominal',
      axis: {
        title: null,
        values: []
      }
    },
    y: {
      field: 'count',
      type: 'quantitative',
      axis: {
        title: '#Of Models'
      }
    },
    color: {
      field: 'bin',
      type: 'ordinal',
      legend: {
        title: null
      }
    }
  },
  config: {
    legend: {
      labelFontSize: 13
    }
  }
};
function MetricChartWithLegend(_ref) {
  var xAxisTitle = _ref.xAxisTitle,
      values = _ref.values,
      height = _ref.height,
      width = _ref.width,
      colorRange = _ref.colorRange;
  var newChartSpec = {};

  if (Array.isArray(colorRange) && colorRange.length) {
    newChartSpec = _objectSpread({}, chartSpec, {
      config: _objectSpread({}, chartSpec.config, {
        range: {
          ordinal: colorRange
        }
      })
    });
  } else {
    newChartSpec = chartSpec;
  }

  var spec = _objectSpread({}, newChartSpec, {
    height: height,
    width: width
  });

  xAxisTitle ? spec.encoding.x.axis.title = xAxisTitle : delete spec.encoding.x.axis.title;

  if (!values.length) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_ExperimentMetricsDropdown_EmptyMetricMessage__WEBPACK_IMPORTED_MODULE_3__["default"], {
      mainMessage: "".concat(xAxisTitle, " Distribution Unavailable"),
      popoverMessage: "Atleast one model has to be trained to get ".concat(xAxisTitle, " distribution")
    });
  }

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_VegaLiteChart__WEBPACK_IMPORTED_MODULE_2__["default"], {
    spec: spec,
    data: values,
    widthOffset: 280,
    heightOffset: 30,
    className: "metric-chart-with-legend"
  });
}
MetricChartWithLegend.propTypes = {
  colorRange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string),
  xAxisTitle: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  values: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object),
  height: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  width: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number
};

/***/ }),

/***/ "./components/Experiments/DetailedView/ModelStatusIndicator/ModelStatusIndicator.scss":
/*!********************************************************************************************!*\
  !*** ./components/Experiments/DetailedView/ModelStatusIndicator/ModelStatusIndicator.scss ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./ModelStatusIndicator.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/ModelStatusIndicator/ModelStatusIndicator.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/DetailedView/ModelStatusIndicator/index.js":
/*!***************************************************************************!*\
  !*** ./components/Experiments/DetailedView/ModelStatusIndicator/index.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ModelStatusIndicator; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var lodash_capitalize__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/capitalize */ "../../node_modules/lodash/capitalize.js");
/* harmony import */ var lodash_capitalize__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_capitalize__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/UncontrolledComponents */ "./components/UncontrolledComponents/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Experiments/store/ModelStatus */ "./components/Experiments/store/ModelStatus.js");
/* harmony import */ var components_Experiments_DetailedView_ExperimentMetricsDropdown_ModelStatusesDistribution__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Experiments/DetailedView/ExperimentMetricsDropdown/ModelStatusesDistribution */ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/ModelStatusesDistribution.js");
var _STATUS_ICON_MAP;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









__webpack_require__(/*! ./ModelStatusIndicator.scss */ "./components/Experiments/DetailedView/ModelStatusIndicator/ModelStatusIndicator.scss");

var DEFAULT_STATUS_MAP = {
  className: 'text-info',
  icon: 'icon-circle-o'
};
var STATUS_ICON_MAP = (_STATUS_ICON_MAP = {}, _defineProperty(_STATUS_ICON_MAP, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].SPLITTING, {
  className: 'fa-spin ',
  icon: 'icon-spinner',
  color: components_Experiments_DetailedView_ExperimentMetricsDropdown_ModelStatusesDistribution__WEBPACK_IMPORTED_MODULE_7__["MODEL_STATUS_TO_COLOR_MAP"][components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].SPLITTING]
}), _defineProperty(_STATUS_ICON_MAP, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].SPLIT_FAILED, {
  className: '',
  icon: 'icon-circle-o',
  color: components_Experiments_DetailedView_ExperimentMetricsDropdown_ModelStatusesDistribution__WEBPACK_IMPORTED_MODULE_7__["MODEL_STATUS_TO_COLOR_MAP"][components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].SPLIT_FAILED]
}), _defineProperty(_STATUS_ICON_MAP, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].DATA_READY, {
  className: '',
  icon: 'icon-circle-o',
  color: components_Experiments_DetailedView_ExperimentMetricsDropdown_ModelStatusesDistribution__WEBPACK_IMPORTED_MODULE_7__["MODEL_STATUS_TO_COLOR_MAP"][components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].DATA_READY]
}), _defineProperty(_STATUS_ICON_MAP, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].TRAINING, {
  className: 'fa-spin',
  icon: 'icon-spinner',
  color: components_Experiments_DetailedView_ExperimentMetricsDropdown_ModelStatusesDistribution__WEBPACK_IMPORTED_MODULE_7__["MODEL_STATUS_TO_COLOR_MAP"][components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].TRAINING]
}), _defineProperty(_STATUS_ICON_MAP, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].TRAINED, {
  className: '',
  icon: 'icon-circle-o',
  color: components_Experiments_DetailedView_ExperimentMetricsDropdown_ModelStatusesDistribution__WEBPACK_IMPORTED_MODULE_7__["MODEL_STATUS_TO_COLOR_MAP"][components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].TRAINED]
}), _defineProperty(_STATUS_ICON_MAP, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].TRAINING_FAILED, {
  className: '',
  icon: 'icon-circle-o',
  color: components_Experiments_DetailedView_ExperimentMetricsDropdown_ModelStatusesDistribution__WEBPACK_IMPORTED_MODULE_7__["MODEL_STATUS_TO_COLOR_MAP"][components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].TRAINING_FAILED]
}), _defineProperty(_STATUS_ICON_MAP, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].PREPARING, {
  className: 'fa-spin',
  icon: 'icon-spinner',
  color: components_Experiments_DetailedView_ExperimentMetricsDropdown_ModelStatusesDistribution__WEBPACK_IMPORTED_MODULE_7__["MODEL_STATUS_TO_COLOR_MAP"][components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_6__["MODEL_STATUS"].PREPARING]
}), _STATUS_ICON_MAP);

var getIconMap = function getIconMap(status) {
  return status in STATUS_ICON_MAP ? STATUS_ICON_MAP[status] : DEFAULT_STATUS_MAP;
};

function ModelStatusIndicator(_ref) {
  var status = _ref.status,
      loading = _ref.loading,
      error = _ref.error,
      model = _ref.model,
      getModelStatus = _ref.getModelStatus;

  if (loading) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
      name: "icon-spinner",
      className: "fa-spin"
    });
  }

  if (error) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
      className: "model-status-error model-status-indicator text-danger",
      id: "error-".concat(model.id),
      onClick: function onClick(e) {
        Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["preventPropagation"])(e);
        getModelStatus();
      }
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
      className: "text-danger",
      name: "icon-exclamation-circle"
    }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, "Error")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_4__["UncontrolledTooltip"], {
      placement: "right",
      delay: 0,
      target: "error-".concat(model.id)
    }, "Failed to get the status of the model '".concat(model.name, "'. Click to try loading the status again")));
  }

  var iconMap = getIconMap(status);
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
    className: "model-status-indicator",
    title: status
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
    name: iconMap.icon,
    className: iconMap.className,
    style: {
      color: iconMap.color
    }
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, lodash_capitalize__WEBPACK_IMPORTED_MODULE_3___default()(status)));
}
ModelStatusIndicator.propTypes = {
  status: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
  loading: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  error: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  model: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  getModelStatus: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/***/ }),

/***/ "./components/Experiments/DetailedView/ModelsTable/DetailedViewModelsTable.scss":
/*!**************************************************************************************!*\
  !*** ./components/Experiments/DetailedView/ModelsTable/DetailedViewModelsTable.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./DetailedViewModelsTable.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/ModelsTable/DetailedViewModelsTable.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/DetailedView/ModelsTable/index.js":
/*!******************************************************************!*\
  !*** ./components/Experiments/DetailedView/ModelsTable/index.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_PaginationWithTitle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PaginationWithTitle */ "./components/PaginationWithTitle/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Experiments/store/ExperimentDetailActionCreator */ "./components/Experiments/store/ExperimentDetailActionCreator.js");
/* harmony import */ var components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Experiments/store/SharedActionCreator */ "./components/Experiments/store/SharedActionCreator.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/LoadingSVGCentered */ "./components/LoadingSVGCentered/index.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! lodash/isEmpty */ "../../node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var components_Experiments_DetailedView_ModelStatusIndicator__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! components/Experiments/DetailedView/ModelStatusIndicator */ "./components/Experiments/DetailedView/ModelStatusIndicator/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var components_Experiments_DetailedView_DeleteModelBtn__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! components/Experiments/DetailedView/DeleteModelBtn */ "./components/Experiments/DetailedView/DeleteModelBtn/index.js");
/* harmony import */ var components_Experiments_DetailedView_DeleteExperimentBtn__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! components/Experiments/DetailedView/DeleteExperimentBtn */ "./components/Experiments/DetailedView/DeleteExperimentBtn/index.js");
/* harmony import */ var components_Experiments_DetailedView_HyperParamsPopover__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! components/Experiments/DetailedView/HyperParamsPopover */ "./components/Experiments/DetailedView/HyperParamsPopover/index.js");
/* harmony import */ var lodash_isNumber__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! lodash/isNumber */ "../../node_modules/lodash/isNumber.js");
/* harmony import */ var lodash_isNumber__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(lodash_isNumber__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var lodash_isString__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! lodash/isString */ "../../node_modules/lodash/isString.js");
/* harmony import */ var lodash_isString__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(lodash_isString__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var components_CopyableID__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! components/CopyableID */ "./components/CopyableID/index.js");
/* harmony import */ var components_CollapsibleWrapper__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! components/CollapsibleWrapper */ "./components/CollapsibleWrapper/index.js");
/* harmony import */ var components_LoadingSVG__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! components/LoadingSVG */ "./components/LoadingSVG/index.js");
/* harmony import */ var components_Alert__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! components/Alert */ "./components/Alert/index.js");
/* harmony import */ var components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! components/Experiments/store/ModelStatus */ "./components/Experiments/store/ModelStatus.js");
/* harmony import */ var components_Experiments_DetailedView_PredictionDatasetExploreModal__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! components/Experiments/DetailedView/PredictionDatasetExploreModal */ "./components/Experiments/DetailedView/PredictionDatasetExploreModal/index.js");
/* harmony import */ var components_Experiments_DetailedView_AddModelToPipelineBtn__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! components/Experiments/DetailedView/AddModelToPipelineBtn */ "./components/Experiments/DetailedView/AddModelToPipelineBtn/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_28__);
var _this = undefined;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






























var PREFIX = 'features.Experiments.DetailedView';

__webpack_require__(/*! ./DetailedViewModelsTable.scss */ "./components/Experiments/DetailedView/ModelsTable/DetailedViewModelsTable.scss");

var MODELSTATES = [components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_25__["MODEL_STATUS"].PREPARING, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_25__["MODEL_STATUS"].SPLITTING, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_25__["MODEL_STATUS"].DATA_READY, components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_25__["MODEL_STATUS"].SPLIT_FAILED];
var tableHeaders = [{
  label: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".modelName")),
  property: 'name'
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".status")),
  property: 'status'
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".algorithm")),
  property: 'algorithm'
}];
var regressionMetrics = [{
  label: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".rmse")),
  property: 'rmse'
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".r2")),
  property: 'r2'
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".evariance")),
  property: 'evariance'
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".mae")),
  property: 'mae'
}];
var categoricalMetrics = [{
  label: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".precision")),
  property: 'precision'
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".recall")),
  property: 'recall'
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".f1")),
  property: 'f1'
}];

var addMetricsToHeaders = function addMetricsToHeaders(tableHeaders, metrics) {
  return [].concat(_toConsumableArray(tableHeaders.slice(0, tableHeaders.length)), _toConsumableArray(metrics), _toConsumableArray(tableHeaders.slice(tableHeaders.length)));
};

var getNewHeadersBasedOnOutcome = function getNewHeadersBasedOnOutcome(outcomeType) {
  return services_global_constants__WEBPACK_IMPORTED_MODULE_8__["NUMBER_TYPES"].indexOf(outcomeType) !== -1 ? addMetricsToHeaders(tableHeaders, regressionMetrics) : addMetricsToHeaders(tableHeaders, categoricalMetrics);
};

var addDetailedModelObject = function addDetailedModelObject(list) {
  var activeIndex = list.findIndex(function (model) {
    return model.active;
  });

  if (activeIndex !== -1) {
    return [].concat(_toConsumableArray(list.slice(0, activeIndex + 1)), [_objectSpread({}, list[activeIndex], {
      detailedView: true,
      active: false
    })], _toConsumableArray(list.slice(activeIndex + 1)));
  }

  return list;
};

var wrapContentWithTitleAttr = function wrapContentWithTitleAttr(content, key) {
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    title: lodash_isNumber__WEBPACK_IMPORTED_MODULE_18___default()(content) || lodash_isString__WEBPACK_IMPORTED_MODULE_19___default()(content) ? content : '',
    key: key
  }, content);
};

var wrapMetricWithTitleAttr = function wrapMetricWithTitleAttr(content, property) {
  var ROUNDABLE_METRIC = regressionMetrics.map(function (metric) {
    return metric.property;
  });

  if (ROUNDABLE_METRIC.indexOf(property) !== -1) {
    return wrapContentWithTitleAttr(Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["humanReadableNumber"])(Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["roundDecimalToNDigits"])(content, 4), services_helpers__WEBPACK_IMPORTED_MODULE_7__["HUMANREADABLE_DECIMAL"]), property);
  }

  return wrapContentWithTitleAttr(content, property);
};

var renderMetrics = function renderMetrics(newHeaders, model) {
  var commonHeadersLen = tableHeaders.length;
  var len = newHeaders.length;
  var metrics = newHeaders.slice(commonHeadersLen, len);
  return metrics.map(function (t) {
    return wrapMetricWithTitleAttr(model.evaluationMetrics[t.property] || '--', t.property);
  });
};

var renderFeaturesTable = function renderFeaturesTable(features) {
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-wrapper"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid grid-container"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-header"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-row"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, " Features (", features.length, ")"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-body"
  }, features.map(function (feature) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
      key: feature,
      className: "grid-row"
    }, ' ', feature);
  }))));
};

var renderDirectivesTables = function renderDirectivesTables(directives) {
  var copyableDirectives = directives.join('\n');
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-wrapper"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid grid-container directives-list"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-header"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-row"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, " Directives (", directives.length, ")"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_CopyableID__WEBPACK_IMPORTED_MODULE_21__["default"], {
    label: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".copyToClipboard")),
    id: copyableDirectives,
    tooltipText: false
  }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-body"
  }, directives.map(function (directive, i) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
      key: i,
      className: "grid-row"
    }, ' ', directive);
  }))));
};

var constructModelTrainingLogs = function constructModelTrainingLogs(model, experimentId) {
  var splitId = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(model, 'splitDetails', 'id');
  var startTime = Math.floor(model.createtime / 1000);
  var endTime = model.trainedtime === -1 ? model.trainingtime : model.trainedtime;
  endTime = Math.floor(endTime / 1000);

  if (splitId) {
    var baseUrl = "/logviewer/view?namespace=".concat(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_14__["getCurrentNamespace"])(), "&appId=ModelManagementApp&programType=spark&programId=ModelManagerService");
    var queryParams = "&filter=".concat(encodeURIComponent("MDC:experiment=\"".concat(experimentId, "\" AND MDC:model=").concat(model.id)), "&startTime=").concat(startTime, "&endTime=").concat(endTime);
    return "".concat(baseUrl).concat(queryParams);
  }
};

var renderModelDetails = function renderModelDetails(model, newlyTrainingModel, experimentId) {
  var newlyTrainingModelId = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(newlyTrainingModel, 'modelId');
  var props = {
    className: classnames__WEBPACK_IMPORTED_MODULE_9___default()('grid-row', {
      opened: model.detailedView,
      active: model.active,
      highlight: model.id === newlyTrainingModelId,
      loading: !model.splitDetails
    }),
    key: uuid_v4__WEBPACK_IMPORTED_MODULE_20___default()()
  };

  if (!model.splitDetails) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", props, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_LoadingSVG__WEBPACK_IMPORTED_MODULE_23__["default"], null));
  }

  var directives = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(model, 'splitDetails', 'directives') || [];
  var splitId = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(model, 'splitDetails', 'id');
  var modelTrainingLogsUrl;
  var directivesCount = Array.isArray(directives) ? directives.length : 0;
  var featuresCount = Array.isArray(model.features) ? model.features.length : 0;
  modelTrainingLogsUrl = constructModelTrainingLogs(model, experimentId);
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", props, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "content-wrapper"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".modelDescription"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, model.description || '--')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, " Directives (", directivesCount, ") "), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_CollapsibleWrapper__WEBPACK_IMPORTED_MODULE_22__["default"], {
    content: directivesCount ? "".concat(directives[0], "...") : '--',
    popoverContent: renderDirectivesTables.bind(null, directives),
    alwaysShowViewLink: true
  })))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, "Features (", featuresCount, ") "), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_CollapsibleWrapper__WEBPACK_IMPORTED_MODULE_22__["default"], {
    content: featuresCount ? model.features.join(',') : '--',
    popoverContent: renderFeaturesTable.bind(null, model.features)
  })))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, " Created on"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["humanReadableDate"])(model.createtime, true)))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, " Model ID "), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_CopyableID__WEBPACK_IMPORTED_MODULE_21__["default"], {
    id: model.id,
    label: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".copyToClipboard")),
    placement: "left"
  })), splitId ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".modelTrainingLogs"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
    href: modelTrainingLogsUrl,
    target: "_blank",
    rel: "noopener noreferrer"
  }, ' ', "Logs", ' ')) : null)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "model-action-btns"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_AddModelToPipelineBtn__WEBPACK_IMPORTED_MODULE_27__["default"], {
    modelName: model.name,
    modelId: model.id,
    disabled: model.status === components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_25__["MODEL_STATUS"].TRAINING_FAILED
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_PredictionDatasetExploreModal__WEBPACK_IMPORTED_MODULE_26__["default"], {
    predictionDataset: model.predictionsDataset,
    disabled: model.status === components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_25__["MODEL_STATUS"].TRAINING_FAILED
  })));
};

var renderModel = function renderModel(model, outcomeType, experimentId, newlyTrainingModel, statusIsLoading, statusIsError) {
  var newHeaders = getNewHeadersBasedOnOutcome(outcomeType);
  var newlyTrainingModelId = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(newlyTrainingModel, 'modelId');
  var Component = 'div';
  var props = {
    className: classnames__WEBPACK_IMPORTED_MODULE_9___default()('grid-row grid-link', {
      opened: model.detailedView,
      active: model.active,
      highlight: model.id === newlyTrainingModelId
    }),
    key: uuid_v4__WEBPACK_IMPORTED_MODULE_20___default()()
  };
  var inSplitStep = MODELSTATES.indexOf(model.status) !== -1;

  if (inSplitStep) {
    Component = react_router_dom__WEBPACK_IMPORTED_MODULE_13__["Link"];
    props.to = "/ns/".concat(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_14__["getCurrentNamespace"])(), "/experiments/create?experimentId=").concat(experimentId, "&modelId=").concat(model.id);
  }

  var modelStatusComp = function modelStatusComp() {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_ModelStatusIndicator__WEBPACK_IMPORTED_MODULE_12__["default"], {
      status: model.status || '--',
      loading: statusIsLoading,
      error: statusIsError,
      model: model,
      getModelStatus: components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_5__["getModelStatus"].bind(_this, experimentId, model.id)
    });
  };

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Component, _extends({}, props, {
    onClick: components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_5__["setActiveModel"].bind(null, model.id)
  }), wrapContentWithTitleAttr(react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
    name: model.active ? 'icon-caret-down' : 'icon-caret-right'
  })), wrapContentWithTitleAttr(model.name), wrapContentWithTitleAttr(modelStatusComp()), wrapContentWithTitleAttr(!inSplitStep ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
    className: "algorithm-cell",
    title: model.algorithmLabel
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_HyperParamsPopover__WEBPACK_IMPORTED_MODULE_17__["default"], {
    hyperparameters: model.hyperparameters,
    algorithm: model.algorithm
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, model.algorithmLabel)) : '--'), renderMetrics(newHeaders, model, experimentId), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-item-sm"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_DeleteModelBtn__WEBPACK_IMPORTED_MODULE_15__["default"], {
    experimentId: experimentId,
    model: model
  })));
};

function renderGridBody(models, outcomeType, experimentId, newlyTrainingModel, modelsLoading, modelsWithError) {
  var list = addDetailedModelObject(_toConsumableArray(models));
  return list.map(function (model) {
    var _model = model,
        name = _model.name,
        algorithm = _model.algorithm,
        hyperparameters = _model.hyperparameters;
    model = _objectSpread({}, model, {
      name: name,
      algorithmLabel: Object(components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_6__["getAlgorithmLabel"])(algorithm),
      hyperparameters: hyperparameters
    });
    var statusIsLoading = modelsLoading.indexOf(model.id) !== -1;
    var statusIsError = modelsWithError.indexOf(model.id) !== -1;

    if (model.detailedView) {
      return renderModelDetails(model, newlyTrainingModel, experimentId);
    }

    return renderModel(model, outcomeType, experimentId, newlyTrainingModel, statusIsLoading, statusIsError);
  });
}

function renderGrid(models, outcomeType, experimentId, newlyTrainingModel, modelsSortColumn, modelsSortMethod, modelsLoading, modelsWithError) {
  var newHeaders = getNewHeadersBasedOnOutcome(outcomeType);

  var renderSortIcon = function renderSortIcon(sortMethod) {
    return sortMethod === 'asc' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
      name: "icon-caret-down"
    }) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
      name: "icon-caret-up"
    });
  };

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_9___default()('grid grid-container', {
      classification: services_global_constants__WEBPACK_IMPORTED_MODULE_8__["NUMBER_TYPES"].indexOf(outcomeType) === -1
    })
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-header"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-row"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null), newHeaders.map(function (header) {
    if (modelsSortColumn === header.property) {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", {
        onClick: components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_5__["handleModelsSorting"].bind(null, header.property),
        className: "sortable-header",
        key: header.property
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, header.label), renderSortIcon(modelsSortMethod));
    }

    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", {
      key: header.property
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, header.label));
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-body"
  }, renderGridBody(models, outcomeType, experimentId, newlyTrainingModel, modelsLoading, modelsWithError)));
}

function ModelsTableContent(_ref) {
  var experimentId = _ref.experimentId,
      modelsList = _ref.modelsList,
      loading = _ref.loading,
      outcomeType = _ref.outcomeType,
      modelsTotalPages = _ref.modelsTotalPages,
      modelsCurrentPage = _ref.modelsCurrentPage,
      modelsTotalCount = _ref.modelsTotalCount,
      newlyTrainingModel = _ref.newlyTrainingModel,
      modelsSortColumn = _ref.modelsSortColumn,
      modelsSortMethod = _ref.modelsSortMethod,
      modelsLoading = _ref.modelsLoading,
      modelsWithError = _ref.modelsWithError;

  if (loading || lodash_isEmpty__WEBPACK_IMPORTED_MODULE_11___default()(experimentId)) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_10__["default"], null);
  }

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "experiment-models-table"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "experiment-table-header"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "btn-container"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_13__["Link"], {
    className: "btn btn-secondary",
    to: "/ns/".concat(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_14__["getCurrentNamespace"])(), "/experiments/create?experimentId=").concat(experimentId, "&addModel=true")
  }, "Add a Model"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_DeleteExperimentBtn__WEBPACK_IMPORTED_MODULE_16__["default"], {
    experimentId: experimentId
  })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PaginationWithTitle__WEBPACK_IMPORTED_MODULE_2__["default"], {
    handlePageChange: components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_5__["handleModelsPageChange"],
    currentPage: modelsCurrentPage,
    totalPages: modelsTotalPages,
    title: i18n_react__WEBPACK_IMPORTED_MODULE_28___default.a.translate("".concat(PREFIX, ".models"), {
      context: modelsTotalCount
    })
  })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-wrapper"
  }, renderGrid(modelsList, outcomeType, experimentId, newlyTrainingModel, modelsSortColumn, modelsSortMethod, modelsLoading, modelsWithError)));
}

ModelsTableContent.propTypes = {
  modelsList: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.array,
  loading: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  experimentId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  outcomeType: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  modelsTotalPages: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  modelsCurrentPage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  modelsTotalCount: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  modelsSortMethod: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  modelsSortColumn: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  newlyTrainingModel: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  modelsLoading: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.array,
  modelsWithError: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.array
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    modelsList: state.models,
    experimentId: state.name,
    loading: state.loading,
    outcomeType: state.outcomeType,
    modelsTotalPages: state.modelsTotalPages,
    modelsCurrentPage: state.modelsOffset === 0 ? 1 : Math.ceil((state.modelsOffset + 1) / state.modelsLimit),
    modelsTotalCount: state.modelsTotalCount,
    newlyTrainingModel: state.newlyTrainingModel,
    modelsSortMethod: state.modelsSortMethod,
    modelsSortColumn: state.modelsSortColumn,
    modelsLoading: state.modelsLoading,
    modelsWithError: state.modelsWithError,
    error: state.error
  };
};

function ModelsTable(_ref2) {
  var props = _extends({}, _ref2);

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, ModelsTableContent(props), props.error ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Alert__WEBPACK_IMPORTED_MODULE_24__["default"], {
    message: props.error,
    type: "error",
    showAlert: true,
    onClose: components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_5__["setExperimentDetailError"]
  }) : null);
}

ModelsTable.propTypes = {
  error: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.any
};
var ModelsTableWrapper = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["connect"])(mapStateToProps)(ModelsTable);
/* harmony default export */ __webpack_exports__["default"] = (ModelsTableWrapper);

/***/ }),

/***/ "./components/Experiments/DetailedView/PredictionDatasetExploreModal/PredictionDatasetExploreModal.scss":
/*!**************************************************************************************************************!*\
  !*** ./components/Experiments/DetailedView/PredictionDatasetExploreModal/PredictionDatasetExploreModal.scss ***!
  \**************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./PredictionDatasetExploreModal.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/PredictionDatasetExploreModal/PredictionDatasetExploreModal.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/DetailedView/PredictionDatasetExploreModal/index.js":
/*!************************************************************************************!*\
  !*** ./components/Experiments/DetailedView/PredictionDatasetExploreModal/index.js ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PredictionDatasetExploreModal; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_FastAction_ExploreAction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/FastAction/ExploreAction */ "./components/FastAction/ExploreAction/index.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_metadata__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! api/metadata */ "./api/metadata.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_ExploreTables_ExploreTablesStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/ExploreTables/ExploreTablesStore */ "./services/ExploreTables/ExploreTablesStore.js");
/* harmony import */ var services_ExploreTables_ActionCreator__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/ExploreTables/ActionCreator */ "./services/ExploreTables/ActionCreator.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */











__webpack_require__(/*! ./PredictionDatasetExploreModal.scss */ "./components/Experiments/DetailedView/PredictionDatasetExploreModal/PredictionDatasetExploreModal.scss");

var PredictionDatasetExploreModal =
/*#__PURE__*/
function (_Component) {
  _inherits(PredictionDatasetExploreModal, _Component);

  function PredictionDatasetExploreModal() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, PredictionDatasetExploreModal);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(PredictionDatasetExploreModal)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      showModal: false,
      predictionDataset: _this.props.predictionDataset,
      datasetDetails: null
    });

    _defineProperty(_assertThisInitialized(_this), "fetchDatasetDetails", function () {
      api_metadata__WEBPACK_IMPORTED_MODULE_4__["MyMetadataApi"].getProperties({
        namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])(),
        entityType: 'datasets',
        entityId: _this.state.predictionDataset,
        scope: services_global_constants__WEBPACK_IMPORTED_MODULE_9__["SCOPES"].SYSTEM
      }).subscribe(function (datasetDetails) {
        var properties = {};
        datasetDetails.properties.forEach(function (property) {
          properties[property.key] = property.value;
        });

        _this.setState({
          datasetDetails: {
            schema: properties.schema,
            id: _this.state.predictionDataset,
            type: 'dataset',
            uniqueId: uuid_v4__WEBPACK_IMPORTED_MODULE_8___default()(),
            properties: properties
          }
        });
      }, function (err) {
        // FIXME: Handle error state.
        console.log('Error fetching dataset details: ', err);
      });
    });

    _defineProperty(_assertThisInitialized(_this), "toggleModal", function () {
      _this.setState({
        showModal: !_this.state.showModal
      });
    });

    return _this;
  }

  _createClass(PredictionDatasetExploreModal, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (!Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["isNilOrEmpty"])(this.state.predictionDataset)) {
        this.fetchDatasetDetails();
        services_ExploreTables_ExploreTablesStore__WEBPACK_IMPORTED_MODULE_6__["default"].dispatch(Object(services_ExploreTables_ActionCreator__WEBPACK_IMPORTED_MODULE_7__["fetchTables"])(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])()));
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var ActionButton = function ActionButton(tooltipId) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "btn-link",
          onClick: _this2.toggleModal,
          id: tooltipId
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, "Explore Predictions"));
      };

      var disabledTarget = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
        className: "btn btn-secondary btn-sm",
        disabled: true
      }, "Explore Predictions");

      if (Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["isNilOrEmpty"])(this.state.datasetDetails) || this.props.disabled) {
        return disabledTarget;
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_FastAction_ExploreAction__WEBPACK_IMPORTED_MODULE_2__["default"], {
        entity: this.state.datasetDetails,
        opened: this.state.showModal,
        renderActionButton: ActionButton,
        onClose: this.toggleModal,
        customTooltip: "Explore predictions generated by this model"
      });
    }
  }]);

  return PredictionDatasetExploreModal;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(PredictionDatasetExploreModal, "propTypes", {
  predictionDataset: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  disabled: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});

_defineProperty(PredictionDatasetExploreModal, "defaultProps", {
  disabled: false
});



/***/ }),

/***/ "./components/Experiments/DetailedView/TopPanel/DetailedViewTopPanel.scss":
/*!********************************************************************************!*\
  !*** ./components/Experiments/DetailedView/TopPanel/DetailedViewTopPanel.scss ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./DetailedViewTopPanel.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/DetailedView/TopPanel/DetailedViewTopPanel.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/DetailedView/TopPanel/index.js":
/*!***************************************************************!*\
  !*** ./components/Experiments/DetailedView/TopPanel/index.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Experiments_TopPanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Experiments/TopPanel */ "./components/Experiments/TopPanel/index.js");
/* harmony import */ var components_Experiments_DetailedView_ExperimentMetricsDropdown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/DetailedView/ExperimentMetricsDropdown */ "./components/Experiments/DetailedView/ExperimentMetricsDropdown/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PREFIX = 'features.Experiments.DetailedView';

__webpack_require__(/*! ./DetailedViewTopPanel.scss */ "./components/Experiments/DetailedView/TopPanel/DetailedViewTopPanel.scss");

var Metadata = function Metadata(_ref) {
  var name = _ref.name,
      description = _ref.description,
      srcpath = _ref.srcpath,
      total = _ref.total,
      outcome = _ref.outcome;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "experiment-metadata"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h2", {
    title: name
  }, name), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "description",
    title: description
  }, description)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".numModels"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h1", null, total))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", {
    className: "experiment-meta-label"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".data"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, srcpath)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", {
    className: "experiment-meta-label"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".outcome"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, outcome))));
};

Metadata.propTypes = {
  name: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  description: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  srcpath: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  total: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  outcome: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

var mapStateToMetadataProps = function mapStateToMetadataProps(state) {
  return {
    name: state.name,
    description: state.description,
    srcpath: state.srcpath,
    models: state.models,
    total: state.modelsTotalCount,
    outcome: state.outcome
  };
};

var ConnectedMetadata = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToMetadataProps)(Metadata);

var DetailedTopPanel = function DetailedTopPanel() {
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_TopPanel__WEBPACK_IMPORTED_MODULE_3__["default"], {
    className: "detailed-view"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "experiment-toppanel-container"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ConnectedMetadata, null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_ExperimentMetricsDropdown__WEBPACK_IMPORTED_MODULE_4__["default"], null)));
};

/* harmony default export */ __webpack_exports__["default"] = (DetailedTopPanel);

/***/ }),

/***/ "./components/Experiments/DetailedView/index.js":
/*!******************************************************!*\
  !*** ./components/Experiments/DetailedView/index.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ExperimentDetails; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Experiments/store/experimentDetailStore */ "./components/Experiments/store/experimentDetailStore.js");
/* harmony import */ var components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/store/ExperimentDetailActionCreator */ "./components/Experiments/store/ExperimentDetailActionCreator.js");
/* harmony import */ var components_Experiments_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Experiments/store */ "./components/Experiments/store/index.js");
/* harmony import */ var components_Experiments_DetailedView_TopPanel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Experiments/DetailedView/TopPanel */ "./components/Experiments/DetailedView/TopPanel/index.js");
/* harmony import */ var components_Experiments_DetailedView_ModelsTable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Experiments/DetailedView/ModelsTable */ "./components/Experiments/DetailedView/ModelsTable/index.js");
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! mousetrap */ "../../node_modules/mousetrap/mousetrap.js");
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(mousetrap__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash/isNil */ "../../node_modules/lodash/isNil.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_isNil__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! query-string */ "../../node_modules/query-string/index.js");
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(query_string__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var components_Alert__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/Alert */ "./components/Alert/index.js");
/* harmony import */ var components_Experiments_DetailedView_ExperimentDetailPageTitle__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! components/Experiments/DetailedView/ExperimentDetailPageTitle */ "./components/Experiments/DetailedView/ExperimentDetailPageTitle/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */














__webpack_require__(/*! ./DetailedView.scss */ "./components/Experiments/DetailedView/DetailedView.scss");

var ExperimentDetails =
/*#__PURE__*/
function (_Component) {
  _inherits(ExperimentDetails, _Component);

  function ExperimentDetails() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ExperimentDetails);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ExperimentDetails)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "modelStatusObservables", []);

    _defineProperty(_assertThisInitialized(_this), "showNewlyTrainingModel", function () {
      var _experimentDetailStor = components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_3__["default"].getState(),
          newlyTrainingModel = _experimentDetailStor.newlyTrainingModel;

      if (newlyTrainingModel) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Alert__WEBPACK_IMPORTED_MODULE_11__["default"], {
          message: "You have successfully started training the model: ".concat(newlyTrainingModel.name),
          type: "success",
          showAlert: true,
          onClose: components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_4__["resetNewlyTrainingModel"]
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "goToNextPage", function () {
      var _experimentDetailStor2 = components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_3__["default"].getState(),
          modelsOffset = _experimentDetailStor2.modelsOffset,
          modelsLimit = _experimentDetailStor2.modelsLimit,
          modelsTotalPages = _experimentDetailStor2.modelsTotalPages;

      var nextPage = modelsOffset === 0 ? 1 : Math.ceil((modelsOffset + 1) / modelsLimit);

      if (nextPage < modelsTotalPages) {
        Object(components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_4__["handleModelsPageChange"])({
          selected: nextPage
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "goToPreviousPage", function () {
      var _experimentDetailStor3 = components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_3__["default"].getState(),
          modelsOffset = _experimentDetailStor3.modelsOffset,
          modelsLimit = _experimentDetailStor3.modelsLimit;

      var prevPage = modelsOffset === 0 ? 1 : Math.ceil((modelsOffset + 1) / modelsLimit);

      if (prevPage > 1) {
        Object(components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_4__["handleModelsPageChange"])({
          selected: prevPage - 2
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "getQueryObject", function (query) {
      if (lodash_isNil__WEBPACK_IMPORTED_MODULE_9___default()(query)) {
        return {};
      }

      var _query$offset = query.offset,
          offset = _query$offset === void 0 ? components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_3__["DEFAULT_EXPERIMENT_DETAILS"].modelsOffset : _query$offset,
          _query$limit = query.limit,
          limit = _query$limit === void 0 ? components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_3__["DEFAULT_EXPERIMENT_DETAILS"].modelsLimit : _query$limit,
          sort = query.sort;
      var sortMethod, sortColumn;
      offset = parseInt(offset, 10);
      limit = parseInt(limit, 10);

      if (isNaN(offset)) {
        offset = components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_3__["DEFAULT_EXPERIMENT_DETAILS"].modelsOffset;
      }

      if (isNaN(limit)) {
        limit = components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_3__["DEFAULT_EXPERIMENT_DETAILS"].modelsLimit;
      }

      if (!sort) {
        sortMethod = components_Experiments_store__WEBPACK_IMPORTED_MODULE_5__["MMDS_SORT_METHODS"].ASC;
        sortColumn = components_Experiments_store__WEBPACK_IMPORTED_MODULE_5__["MMDS_SORT_COLUMN"];
      } else {
        var sortSplit = sort.split(' ');
        sortColumn = sortSplit[0] || components_Experiments_store__WEBPACK_IMPORTED_MODULE_5__["MMDS_SORT_COLUMN"];
        sortMethod = sortSplit[1] || components_Experiments_store__WEBPACK_IMPORTED_MODULE_5__["MMDS_SORT_METHODS"].ASC;
      }

      return {
        offset: offset,
        limit: limit,
        sortMethod: sortMethod,
        sortColumn: sortColumn
      };
    });

    return _this;
  }

  _createClass(ExperimentDetails, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var _this2 = this;

      mousetrap__WEBPACK_IMPORTED_MODULE_8___default.a.bind('right', this.goToNextPage);
      mousetrap__WEBPACK_IMPORTED_MODULE_8___default.a.bind('left', this.goToPreviousPage);
      Object(components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_4__["setAlgorithmsListForDetailedView"])();
      var experimentId = this.props.match.params.experimentId;

      var _this$getQueryObject = this.getQueryObject(query_string__WEBPACK_IMPORTED_MODULE_10___default.a.parse(this.props.location.search)),
          modelsOffset = _this$getQueryObject.offset,
          modelsLimit = _this$getQueryObject.limit,
          modelsSortMethod = _this$getQueryObject.sortMethod,
          modelsSortColumn = _this$getQueryObject.sortColumn;

      Object(components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_4__["updateQueryParametersForModels"])({
        modelsOffset: modelsOffset,
        modelsLimit: modelsLimit,
        modelsSortMethod: modelsSortMethod,
        modelsSortColumn: modelsSortColumn
      });
      Object(components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_4__["getExperimentDetails"])(experimentId);
      Object(components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_4__["getModelsInExperiment"])(experimentId).subscribe(function (_ref) {
        var models = _ref.models;
        models.forEach(function (model) {
          return _this2.modelStatusObservables.push(Object(components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_4__["pollModelStatus"])(experimentId, model.id));
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_8___default.a.unbind('left');
      mousetrap__WEBPACK_IMPORTED_MODULE_8___default.a.unbind('right');
      Object(components_Experiments_store_ExperimentDetailActionCreator__WEBPACK_IMPORTED_MODULE_4__["resetExperimentDetailStore"])();

      if (this.modelStatusObservables.length) {
        this.modelStatusObservables.forEach(function (statusObservable$) {
          return statusObservable$.unsubscribe();
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_redux__WEBPACK_IMPORTED_MODULE_2__["Provider"], {
        store: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_3__["default"]
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "experiment-detailed-view"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_ExperimentDetailPageTitle__WEBPACK_IMPORTED_MODULE_12__["default"], null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_TopPanel__WEBPACK_IMPORTED_MODULE_6__["default"], null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_DetailedView_ModelsTable__WEBPACK_IMPORTED_MODULE_7__["default"], null), this.showNewlyTrainingModel()));
    }
  }]);

  return ExperimentDetails;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(ExperimentDetails, "propTypes", {
  match: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  location: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
});



/***/ }),

/***/ "./components/Experiments/store/CreateExperimentActionCreator.js":
/*!***********************************************************************!*\
  !*** ./components/Experiments/store/CreateExperimentActionCreator.js ***!
  \***********************************************************************/
/*! exports provided: onExperimentNameChange, onExperimentDescriptionChange, onExperimentOutcomeChange, setSrcPath, setOutcomeColumns, setDirectives, setVisiblePopover, setExperimentCreated, setExperimentLoading, onModelNameChange, onModelDescriptionChange, setModelAlgorithm, setWorkspace, updateSchema, setSplitDetails, createExperiment, pollForSplitStatus, createSplitAndUpdateStatus, createModel, trainModel, getExperimentForEdit, getExperimentModelSplitForCreate, setAlgorithmList, setSplitFinalized, resetCreateExperimentsStore, fetchAlgorithmsList, updateHyperParam, setExperimentCreateError, setModelCreateError, setAlgorithmsListForCreateView, overrideCreationStep, updateModel, createWorkspace, applyDirectives */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onExperimentNameChange", function() { return onExperimentNameChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onExperimentDescriptionChange", function() { return onExperimentDescriptionChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onExperimentOutcomeChange", function() { return onExperimentOutcomeChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setSrcPath", function() { return setSrcPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setOutcomeColumns", function() { return setOutcomeColumns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setDirectives", function() { return setDirectives; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setVisiblePopover", function() { return setVisiblePopover; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setExperimentCreated", function() { return setExperimentCreated; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setExperimentLoading", function() { return setExperimentLoading; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onModelNameChange", function() { return onModelNameChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onModelDescriptionChange", function() { return onModelDescriptionChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setModelAlgorithm", function() { return setModelAlgorithm; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setWorkspace", function() { return setWorkspace; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateSchema", function() { return updateSchema; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setSplitDetails", function() { return setSplitDetails; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createExperiment", function() { return createExperiment; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pollForSplitStatus", function() { return pollForSplitStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createSplitAndUpdateStatus", function() { return createSplitAndUpdateStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createModel", function() { return createModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "trainModel", function() { return trainModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getExperimentForEdit", function() { return getExperimentForEdit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getExperimentModelSplitForCreate", function() { return getExperimentModelSplitForCreate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setAlgorithmList", function() { return setAlgorithmList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setSplitFinalized", function() { return setSplitFinalized; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetCreateExperimentsStore", function() { return resetCreateExperimentsStore; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchAlgorithmsList", function() { return fetchAlgorithmsList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateHyperParam", function() { return updateHyperParam; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setExperimentCreateError", function() { return setExperimentCreateError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setModelCreateError", function() { return setModelCreateError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setAlgorithmsListForCreateView", function() { return setAlgorithmsListForCreateView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "overrideCreationStep", function() { return overrideCreationStep; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateModel", function() { return updateModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createWorkspace", function() { return createWorkspace; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "applyDirectives", function() { return applyDirectives; });
/* harmony import */ var components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! components/Experiments/store/createExperimentStore */ "./components/Experiments/store/createExperimentStore.js");
/* harmony import */ var components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/Experiments/store/experimentDetailStore */ "./components/Experiments/store/experimentDetailStore.js");
/* harmony import */ var components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Experiments/store/SharedActionCreator */ "./components/Experiments/store/SharedActionCreator.js");
/* harmony import */ var api_experiments__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/experiments */ "./api/experiments.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_dataprep__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! api/dataprep */ "./api/dataprep.js");
/* harmony import */ var components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/DataPrep/helper */ "./components/DataPrep/helper.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/Experiments/store/ModelStatus */ "./components/Experiments/store/ModelStatus.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */











function onExperimentNameChange(e) {
  var value = e.target.value;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_NAME,
    payload: {
      name: value
    }
  });
}

function onExperimentDescriptionChange(e) {
  var value = e.target.value;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_DESCRIPTION,
    payload: {
      description: value
    }
  });
}

function onExperimentOutcomeChange(e) {
  var value = e.target.value;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_OUTCOME,
    payload: {
      outcome: value
    }
  });
}

function setSrcPath(srcpath) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_SRC_PATH,
    payload: {
      srcpath: srcpath
    }
  });
}

function setOutcomeColumns(columns) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_OUTCOME_COLUMNS,
    payload: {
      columns: columns
    }
  });
}

function setDirectives(directives) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_DIRECTIVES,
    payload: {
      directives: directives
    }
  });
}

function setVisiblePopover() {
  var popover = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["POPOVER_TYPES"].EXPERIMENT;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_VISIBLE_POPOVER,
    payload: {
      popover: popover
    }
  });
}

function setExperimentCreated(experimentId) {
  var url = "".concat(location.pathname, "?experimentId=").concat(experimentId);
  history.replaceState({
    url: url
  }, document.title, url);
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_VISIBLE_POPOVER,
    payload: {
      popover: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["POPOVER_TYPES"].MODEL
    }
  });
}

function setExperimentLoading() {
  var value = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_CREATE_EXPERIMENT_LOADING,
    payload: {
      loading: value
    }
  });
}

function onModelNameChange(e) {
  var value = e.target.value;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODEL_NAME,
    payload: {
      name: value
    }
  });
}

function onModelDescriptionChange(e) {
  var value = e.target.value;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODEL_DESCRIPTION,
    payload: {
      description: value
    }
  });
}

function setModelAlgorithm(algorithm) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODEL_ML_ALGORITHM,
    payload: {
      algorithm: algorithm
    }
  });
}

function updateHyperParam(key, value) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].UPDATE_HYPER_PARAM,
    payload: {
      key: key,
      value: value
    }
  });
}

function setWorkspace(workspaceId) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_WORKSPACE_ID,
    payload: {
      workspaceId: workspaceId
    }
  });
}

function updateSchema(fields) {
  var schema = {
    name: 'avroSchema',
    type: 'record',
    fields: fields
  };
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_SCHEMA,
    payload: {
      schema: schema
    }
  });
}

function setSplitDetails(experimentId, splitId) {
  if (splitId.id) {
    splitId = splitId.id;
  }

  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getSplitDetails({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experimentId,
    splitId: splitId
  }).subscribe(function (splitInfo) {
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_SPLIT_INFO,
      payload: {
        splitInfo: splitInfo
      }
    });
  }, function (err) {
    setModelCreateError("Failed to get split details of the experiment '".concat(experimentId, "' - ").concat(err.response || err));
  });
}

function createExperiment() {
  var _createExperimentStor = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      model_create = _createExperimentStor.model_create,
      experiments_create = _createExperimentStor.experiments_create;

  var name = experiments_create.name,
      description = experiments_create.description,
      outcome = experiments_create.outcome,
      srcpath = experiments_create.srcpath;
  var directives = model_create.directives;
  var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_6__["directiveRequestBodyCreator"])(directives);
  var experiment = {
    name: name,
    description: description,
    outcome: outcome,
    srcpath: srcpath,
    directives: directives
  };
  api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].getSchema({
    context: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    workspaceId: experiments_create.workspaceId
  }, requestBody).mergeMap(function (schema) {
    // The outcome will always be simple type. So ["null", "anything"] should give correct outcomeType at the end.
    var outcomeType = schema.map(function (field) {
      return Array.isArray(field.type) ? field : _objectSpread({}, field, {
        type: [field.type]
      });
    }).find(function (field) {
      return field.name === experiment.outcome;
    }).type.filter(function (t) {
      return t !== 'null';
    }).pop();
    experiment.outcomeType = outcomeType;
    updateSchema(schema);
    return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].createExperiment({
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
      experimentId: experiment.name
    }, experiment);
  }).subscribe(setExperimentCreated.bind(null, experiments_create.name), function (err) {
    return setExperimentCreateError("Failed to create the experiment '".concat(name, "' - ").concat(err.response || err));
  });
}

function pollForSplitStatus(experimentId, modelId) {
  var getStatusOfSplit = function getStatusOfSplit(callback, errorCallback) {
    var params = {
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
      experimentId: experimentId,
      modelId: modelId
    };
    var splitStatusPoll = api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].pollModel(params).subscribe(function (modelDetails) {
      var status = modelDetails.status,
          split = modelDetails.split;

      if (status === 'Splitting') {
        return;
      }

      if (status === 'Data Ready' || status === 'Split Failed') {
        splitStatusPoll.unsubscribe();
        return callback(split);
      } // TODO: Should this be called on split failed?


      errorCallback();
    });
  };

  return rxjs_Observable__WEBPACK_IMPORTED_MODULE_7__["Observable"].create(function (observer) {
    var successCallback = function successCallback(split) {
      observer.next(split);
    };

    var failureCallback = function failureCallback() {
      observer.error("Couldn't create split");
    };

    getStatusOfSplit(successCallback, failureCallback);
  });
}

function overrideCreationStep(step) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].OVERRIDE_CREATION_STEP,
    payload: {
      active_step: step
    }
  });
}
/*
  This is needed when user clicks "Split Data" button in the split step

  1. Create a split under the model (POST `/models/:modelId/split`)
  2. This will create a split and assign it to the model
  3. Once the model is assigned a split poll the model for an update on its status
  4. Once the status is "Data Ready" or "Split Failed" update UI appropriately.

*/


function createSplitAndUpdateStatus() {
  var _arguments = arguments;

  var _createExperimentStor2 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      model_create = _createExperimentStor2.model_create,
      experiments_create = _createExperimentStor2.experiments_create;

  var directives = model_create.directives,
      schema = model_create.schema,
      modelId = model_create.modelId,
      modelName = model_create.name;
  var splitInfo = {
    schema: schema,
    directives: directives,
    type: 'random',
    parameters: {
      percent: '80'
    },
    description: "Default Random split created for the model '".concat(modelName, "'")
  };
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_SPLIT_INFO,
    payload: {
      splitInfo: {
        id: null,
        status: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["SPLIT_STATUS"].CREATING // INTERMEDIATE STATE TO SHOW LOADING ANIMATION FOR THE SPLIT BUTTON

      }
    }
  });
  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].createSplit({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experiments_create.name,
    modelId: modelId
  }, splitInfo).mergeMap(function () {
    return pollForSplitStatus(experiments_create.name, modelId);
  }).subscribe(setSplitDetails.bind(null, experiments_create.name), function (err) {
    setModelCreateError("Failed to create split for the model '".concat(modelName, "' - ").concat(err.response || err));
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_SPLIT_INFO,
      payload: {
        splitInfo: {
          id: null
        }
      }
    });
  }, function () {
    return console.log('Split Task complete ', _arguments);
  });
}

function updateModel() {
  var _createExperimentStor3 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      experiments_create = _createExperimentStor3.experiments_create,
      model_create = _createExperimentStor3.model_create;

  var directives = model_create.directives;
  var params = {
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experiments_create.name,
    modelId: model_create.modelId
  };
  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getModelStatus(params).flatMap(function (status) {
    if (components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_9__["MODEL_STATUS"].PREPARING === status) {
      return rxjs_Observable__WEBPACK_IMPORTED_MODULE_7__["Observable"].create(function (observer) {
        return observer.next();
      });
    }

    return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].deleteSplitInModel(params);
  }).flatMap(function () {
    return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].updateDirectivesInModel(params, {
      directives: directives
    });
  }).subscribe(function () {
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].MODEL_UPDATE
    });
  });
}

function createModel() {
  var _createExperimentStor4 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      experiments_create = _createExperimentStor4.experiments_create,
      model_create = _createExperimentStor4.model_create;

  var directives = model_create.directives;
  var model = {
    name: model_create.name,
    description: model_create.description,
    directives: directives
  };
  return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].createModelInExperiment({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experiments_create.name
  }, model).subscribe(function (_ref) {
    var modelId = _ref.id;
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODEL_ID,
      payload: {
        modelId: modelId
      }
    });
    setExperimentLoading(false);
    var url = "".concat(location.pathname).concat(location.search, "&modelId=").concat(modelId);
    history.replaceState({
      url: url
    }, document.title, url);
  }, function (err) {
    setExperimentCreateError("Failed to create the model '".concat(model_create.name, "' - ").concat(err.response || err));
    setExperimentLoading(false);
  });
}

function trainModel() {
  var _createExperimentStor5 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      experiments_create = _createExperimentStor5.experiments_create,
      model_create = _createExperimentStor5.model_create;

  var experimentId = experiments_create.name;
  var modelId = model_create.modelId,
      modelName = model_create.name;
  var formattedExperimentName = experimentId.replace(/[^\w]/g, '');
  var formattedModelName = modelName.replace(/[^\w]/g, '');
  var postBody = {
    algorithm: model_create.algorithm.name,
    hyperparameters: model_create.algorithm.hyperparameters,
    predictionsDataset: "".concat(formattedExperimentName, "_").concat(formattedModelName, "_dataset")
  };
  return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].trainModel({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experimentId,
    modelId: modelId
  }, postBody).subscribe(function () {
    components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
      type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_NEWLY_TRAINING_MODEL,
      payload: {
        model: model_create
      }
    });
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODEL_TRAINED
    });
  }, function (err) {
    setModelCreateError("Failed to train the model '".concat(modelName, "': ").concat(err.response || err));
  });
}

function createWorkspace(filePath) {
  var params = {
    context: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    path: filePath,
    lines: 10000,
    sampler: 'first',
    scope: 'mmds'
  };
  var headers = {
    'Content-Type': 'text/plain' // FIXME: THIS IS A HACK. NEED TO GET THIS FROM EXPERIMENT

  }; // FIXME: When we go to split step and create a workspace for
  // switching between steps we don't have the file content type
  // Need to store that somehow in the model/experiment
  // JIRA: CDAP-13815

  var filePathLength = filePath.length;

  if (filePathLength > 5 && filePath.substr(filePathLength - 5) === '.json') {
    headers['Content-Type'] = 'application/json';
  }

  return api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].readFile(params, null, headers);
}

function applyDirectives(workspaceId, directives) {
  return api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].getWorkspace({
    context: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    workspaceId: workspaceId
  }).mergeMap(function (res) {
    var workspaceInfo = res.values[0];
    var params = {
      workspaceId: workspaceId,
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])()
    };
    var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_6__["directiveRequestBodyCreator"])(directives);
    requestBody.properties = workspaceInfo.properties;
    return api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].execute(params, requestBody);
  });
}
/*
  This is needed when user has already created an experiment but is still in dataprep stage.
  On refresh in this state we need to go back to the same view the user left.

  1. Fetch the experiments details
  2. Get directives and srcpath from the details
  3. Create a workspace with the srcpath
  4. Once created execute it with the list of directives
  5. Once the workspace is setup and update the stores.

  After step5 CreateView will pass the workspaceid to DataPrepConnection which will render the browser.
*/


var getExperimentForEdit = function getExperimentForEdit(experimentId) {
  setExperimentLoading();
  var experiment, directives;
  var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])();
  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getExperiment({
    namespace: namespace,
    experimentId: experimentId
  }).mergeMap(function (exp) {
    experiment = exp;
    return createWorkspace(exp.srcpath);
  }).mergeMap(function (res) {
    var workspaceId = res.values[0].id;
    experiment.workspaceId = workspaceId;
    directives = experiment.directives;
    setDirectives(directives);
    return applyDirectives(workspaceId, directives);
  }).mergeMap(function () {
    // Get schema with workspaceId and directives
    var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_6__["directiveRequestBodyCreator"])(directives);
    return api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].getSchema({
      namespace: namespace,
      workspaceId: experiment.workspaceId
    }, requestBody);
  }).subscribe(function (fields) {
    var schema = {
      name: 'avroSchema',
      type: 'record',
      fields: fields
    };
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_METADATA_FOR_EDIT,
      payload: {
        experimentDetails: experiment,
        schema: schema
      }
    });
  }, function (err) {
    // The error message returned from backend for this request is at err.response.message instead of just err.response
    var error = err.response.message || err.response || err;
    setExperimentLoading(false);
    setExperimentCreateError("Failed to retrieve the experiment '".concat(experimentId, "' - ").concat(error));
  });
};
/*
  This is needed when the user has created the model but still is in the split stage.
  On refresh in this state we need to go back to the same view the user left.

  1. Fetch the experiments details
  2. Get the srcpath from the details
  3. Create a workspace with the srcpath
  4. Once created execute it with the list of directives from model
  5. Once the workspace is setup and update the stores.
  6. Check if the model already has a splitid
  7. If yes fetch split details and update the store

  After step 7 UI will land in the split stage with all the split details.
*/


var getExperimentModelSplitForCreate = function getExperimentModelSplitForCreate(experimentId, modelId) {
  setExperimentLoading();
  var experiment, model; // Get experiment

  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getExperiment({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experimentId
  }).mergeMap(function (exp) {
    experiment = exp;
    return createWorkspace(exp.srcpath);
  }).mergeMap(function (res) {
    var workspaceId = res.values[0].id;
    experiment.workspaceId = workspaceId;
    return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getModel({
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
      experimentId: experiment.name,
      modelId: modelId
    });
  }).mergeMap(function (m) {
    model = m; // Apply the directives from the model

    return applyDirectives(experiment.workspaceId, m.directives);
  }).mergeMap(function () {
    // Get schema with workspaceId and directives
    var _model = model,
        directives = _model.directives;
    setDirectives(directives);
    var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_6__["directiveRequestBodyCreator"])(directives);
    return api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].getSchema({
      context: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
      workspaceId: experiment.workspaceId
    }, requestBody);
  }).mergeMap(function (schema) {
    updateSchema(schema); // The user refreshed before creating the split. So no split info is present in model.

    if (!model.split) {
      return rxjs_Observable__WEBPACK_IMPORTED_MODULE_7__["Observable"].create(function (observer) {
        observer.next(false);
      });
    } // If split already created get the split info to check the status of split.


    return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getSplitDetails({
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
      experimentId: experiment.name,
      splitId: model.split
    });
  }).subscribe(function (splitInfo) {
    setExperimentModelForEdit(experiment, model, splitInfo);

    if (_typeof(splitInfo) === 'object' && splitInfo.status !== 'Complete') {
      pollForSplitStatus(experiment.name, modelId).subscribe(setSplitDetails.bind(null, experiment.name));
    }
  }, function (err) {
    // The error message returned from backend for this request is at err.response.message instead of just err.response
    var error = err.response.message || err.response || err;
    setExperimentCreateError("Failed to retrieve the model '".concat(model.name, "' of the experiment '").concat(experimentId, "' - ").concat(error));
    setExperimentLoading(false);
    setExperimentModelForEdit(experiment, model);
  });
};

function setExperimentModelForEdit(experiment, model, splitInfo) {
  var payload = {
    experimentDetails: experiment,
    modelDetails: model
  };

  if (splitInfo) {
    payload.splitInfo = splitInfo;
  }

  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_MODEL_FOR_EDIT,
    payload: payload
  });
}

function setAlgorithmList() {
  var _createExperimentStor6 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      experiments_create = _createExperimentStor6.experiments_create;

  var outcome = experiments_create.outcome;

  var _createExperimentStor7 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      model_create = _createExperimentStor7.model_create;

  var directives = model_create.directives,
      algorithmsList = model_create.algorithmsList;
  var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_6__["directiveRequestBodyCreator"])(directives);
  api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].getSchema({
    context: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    workspaceId: experiments_create.workspaceId
  }, requestBody).subscribe(function (fields) {
    updateSchema(fields);
    var outcomeType = fields.find(function (field) {
      return field.name === outcome;
    }).type.filter(function (t) {
      return t !== 'null';
    }).pop();
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_VALID_ALGORITHMS_LIST,
      payload: {
        validAlgorithmsList: services_global_constants__WEBPACK_IMPORTED_MODULE_8__["NUMBER_TYPES"].indexOf(outcomeType) !== -1 ? algorithmsList.filter(function (algo) {
          return algo.type === 'REGRESSION';
        }) : algorithmsList.filter(function (algo) {
          return algo.type === 'CLASSIFICATION';
        })
      }
    });
  }, function (err) {
    setExperimentCreateError("Failed to find algorithms for outcome: ".concat(err.response || err));
  });
}

function setSplitFinalized() {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_SPLIT_FINALIZED,
    payload: {
      isSplitFinalized: true
    }
  });
}

function resetCreateExperimentsStore() {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].RESET
  });
}

function fetchAlgorithmsList() {
  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getAlgorithms({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])()
  }).subscribe(function (algorithmsList) {
    algorithmsList = algorithmsList.map(function (alg) {
      return _objectSpread({}, alg, {
        name: alg.algorithm
      });
    });
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_ALGORITHMS_LIST,
      payload: {
        algorithmsList: algorithmsList
      }
    });
  }, function (err) {
    setExperimentCreateError("Failed to fetch algorithms: ".concat(err.response || err));
  });
}

function setExperimentCreateError() {
  var error = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_ERROR,
    payload: {
      error: error
    }
  });
}

function setModelCreateError() {
  var error = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODEL_ERROR,
    payload: {
      error: error
    }
  });
}

function setAlgorithmsListForCreateView() {
  Object(components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_2__["setAlgorithmsList"])().subscribe(function () {}, function (err) {
    setExperimentCreateError("Failed to get list of algorithms: ".concat(err.response || err));
  });
}



/***/ }),

/***/ "./components/Experiments/store/ExperimentDetailActionCreator.js":
/*!***********************************************************************!*\
  !*** ./components/Experiments/store/ExperimentDetailActionCreator.js ***!
  \***********************************************************************/
/*! exports provided: setExperimentDetailError, getExperimentDetails, getModelsInExperiment, handleModelsPageChange, handleModelsSorting, updateQueryParametersForModels, getSplitsInExperiment, getModelStatus, pollModelStatus, setActiveModel, setAlgorithmsListForDetailedView, resetExperimentDetailStore, resetNewlyTrainingModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setExperimentDetailError", function() { return setExperimentDetailError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getExperimentDetails", function() { return getExperimentDetails; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getModelsInExperiment", function() { return getModelsInExperiment; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "handleModelsPageChange", function() { return handleModelsPageChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "handleModelsSorting", function() { return handleModelsSorting; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateQueryParametersForModels", function() { return updateQueryParametersForModels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSplitsInExperiment", function() { return getSplitsInExperiment; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getModelStatus", function() { return getModelStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pollModelStatus", function() { return pollModelStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setActiveModel", function() { return setActiveModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setAlgorithmsListForDetailedView", function() { return setAlgorithmsListForDetailedView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetExperimentDetailStore", function() { return resetExperimentDetailStore; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetNewlyTrainingModel", function() { return resetNewlyTrainingModel; });
/* harmony import */ var components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! components/Experiments/store */ "./components/Experiments/store/index.js");
/* harmony import */ var components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/Experiments/store/experimentDetailStore */ "./components/Experiments/store/experimentDetailStore.js");
/* harmony import */ var components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Experiments/store/SharedActionCreator */ "./components/Experiments/store/SharedActionCreator.js");
/* harmony import */ var api_experiments__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/experiments */ "./api/experiments.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






function setExperimentDetailError() {
  var error = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
  components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
    type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_ERROR,
    payload: {
      error: error
    }
  });
}

function getExperimentDetails(experimentId) {
  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getExperiment({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experimentId
  }).subscribe(function (res) {
    components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
      type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_EXPERIMENT_DETAILS,
      payload: {
        experimentDetails: _objectSpread({}, res)
      }
    });
  }, function (err) {
    setExperimentDetailError("Failed to get details for the experiment '".concat(experimentId, "' - ").concat(err.response || err));
  });
}

function getModelsInExperiment(experimentId) {
  components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
    type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_LOADING
  });

  var _experimentDetailsSto = components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].getState(),
      offset = _experimentDetailsSto.modelsOffset,
      limit = _experimentDetailsSto.modelsLimit,
      modelsSortMethod = _experimentDetailsSto.modelsSortMethod,
      modelsSortColumn = _experimentDetailsSto.modelsSortColumn;

  var ModelsObservable$ = api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getModelsInExperiment({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experimentId,
    offset: offset,
    limit: limit,
    sort: "".concat(modelsSortColumn, " ").concat(modelsSortMethod)
  });
  ModelsObservable$.subscribe(function (res) {
    var models = res.models;
    components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
      type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_MODELS,
      payload: {
        models: models,
        totalCount: res.totalRowCount
      }
    });
    getSplitsInExperiment(experimentId);
  }, function (err) {
    setExperimentDetailError("Failed to get models in the experiment '".concat(experimentId, "' - ").concat(err.response || err));
  });
  return ModelsObservable$;
}

function handleModelsPageChange(_ref) {
  var selected = _ref.selected;

  var _experimentDetailsSto2 = components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].getState(),
      modelsLimit = _experimentDetailsSto2.modelsLimit,
      experimentId = _experimentDetailsSto2.name;

  components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
    type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_MODEL_PAGINATION,
    payload: {
      modelsOffset: selected * modelsLimit
    }
  });
  updateQueryForModelsListView();
  getModelsInExperiment(experimentId);
}

function handleModelsSorting(field) {
  var _experimentDetailsSto3 = components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].getState(),
      modelsSortMethod = _experimentDetailsSto3.modelsSortMethod,
      modelsSortColumn = _experimentDetailsSto3.modelsSortColumn,
      experimentId = _experimentDetailsSto3.name;

  var newSortField = field !== modelsSortColumn ? field : modelsSortColumn;
  var newSortMethod = components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["MMDS_SORT_METHODS"].ASC === modelsSortMethod ? components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["MMDS_SORT_METHODS"].DESC : components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["MMDS_SORT_METHODS"].ASC;
  components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
    type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_MODELS_SORT,
    payload: {
      modelsSortMethod: newSortMethod,
      modelsSortColumn: newSortField
    }
  });
  updateQueryForModelsListView();
  getModelsInExperiment(experimentId);
}

function updateQueryParametersForModels(_ref2) {
  var modelsLimit = _ref2.modelsLimit,
      modelsOffset = _ref2.modelsOffset,
      modelsSortMethod = _ref2.modelsSortMethod,
      modelsSortColumn = _ref2.modelsSortColumn;
  components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
    type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_MODELS_QUERY_PARAMS,
    payload: {
      modelsOffset: modelsOffset,
      modelsLimit: modelsLimit,
      modelsSortMethod: modelsSortMethod,
      modelsSortColumn: modelsSortColumn
    }
  });
}

function updateQueryForModelsListView() {
  var _experimentDetailsSto4 = components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].getState(),
      offset = _experimentDetailsSto4.modelsOffset,
      limit = _experimentDetailsSto4.modelsLimit,
      modelsSortMethod = _experimentDetailsSto4.modelsSortMethod,
      modelsSortColumn = _experimentDetailsSto4.modelsSortColumn;

  var newQuery = "offset=".concat(offset, "&limit=").concat(limit, "&sort=").concat(modelsSortColumn, " ").concat(modelsSortMethod);
  var obj = {
    title: document.title,
    url: "".concat(location.pathname, "?").concat(newQuery)
  };
  history.pushState(obj, obj.title, obj.url);
}

function getSplitsInExperiment(experimentId) {
  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getSplitsInExperiment({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experimentId
  }).subscribe(function (splits) {
    components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
      type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_SPLITS,
      payload: {
        splits: splits
      }
    });
  }, function (err) {
    setExperimentDetailError("Failed to get splits in the experiment '".concat(experimentId, "' - ").concat(err.response || err));
  });
}

function pollModelStatus(experimentId, modelId) {
  return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].pollModelStatus({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experimentId,
    modelId: modelId
  }).subscribe(function (modelStatus) {
    components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
      type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_MODEL_STATUS,
      payload: {
        modelId: modelId,
        modelStatus: modelStatus
      }
    });
  }, function () {
    addModelsWithError(modelId);
  });
}

function getModelStatus(experimentId, modelId) {
  addModelsLoading(modelId);
  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getModelStatus({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experimentId,
    modelId: modelId
  }).subscribe(function (modelStatus) {
    components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
      type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_MODEL_STATUS,
      payload: {
        modelId: modelId,
        modelStatus: modelStatus
      }
    });
  }, function () {
    addModelsWithError(modelId);
  }, function () {
    removeModelsLoading(modelId);
  });
}

function addModelsLoading(modelId) {
  var modelsLoading = _toConsumableArray(components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].getState().modelsLoading);

  if (modelsLoading.indexOf(modelId) === -1) {
    modelsLoading.push(modelId);
  }

  components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
    type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_MODELS_LOADING,
    payload: {
      modelsLoading: modelsLoading
    }
  });
}

function removeModelsLoading(modelId) {
  var modelsLoading = _toConsumableArray(components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].getState().modelsLoading);

  var modelIndex = modelsLoading.indexOf(modelId);

  if (modelIndex !== -1) {
    modelsLoading.splice(modelIndex, 1);
  }

  components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
    type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_MODELS_LOADING,
    payload: {
      modelsLoading: modelsLoading
    }
  });
}

function addModelsWithError(modelId) {
  var modelsWithError = _toConsumableArray(components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].getState().modelsWithError);

  if (modelsWithError.indexOf(modelId) === -1) {
    modelsWithError.push(modelId);
  }

  components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
    type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_MODELS_WITH_ERROR,
    payload: {
      modelsWithError: modelsWithError
    }
  });
}

function setActiveModel(activeModelId) {
  var state = components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].getState();

  var _ref3 = state.models.find(function (model) {
    return model.id === activeModelId;
  }) || {},
      splitDetails = _ref3.splitDetails;

  if (!splitDetails) {
    getSplitsInExperiment(state.name);
  }

  components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
    type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_ACTIVE_MODEL,
    payload: {
      activeModelId: activeModelId
    }
  });
}

var setAlgorithmsListForDetailedView = function setAlgorithmsListForDetailedView() {
  Object(components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_2__["setAlgorithmsList"])().subscribe(function () {}, function (err) {
    setExperimentDetailError("Failed to get list of algorithms: ".concat(err.response || err));
  });
};

function resetExperimentDetailStore() {
  components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
    type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].RESET
  });
}

function resetNewlyTrainingModel() {
  components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
    type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].RESET_NEWLY_TRAINING_MODEL
  });
}



/***/ }),

/***/ "./components/Experiments/store/ModelStatus.js":
/*!*****************************************************!*\
  !*** ./components/Experiments/store/ModelStatus.js ***!
  \*****************************************************/
/*! exports provided: MODEL_STATUS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MODEL_STATUS", function() { return MODEL_STATUS; });
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var MODEL_STATUS = {
  PREPARING: 'Preparing',
  SPLITTING: 'Splitting',
  SPLIT_FAILED: 'Split Failed',
  DATA_READY: 'Data Ready',
  TRAINING: 'Training',
  TRAINED: 'Trained',
  TRAINING_FAILED: 'Training Failed',
  DEPLOYED: 'Deployed'
};


/***/ }),

/***/ "./components/Experiments/store/createExperimentStore.js":
/*!***************************************************************!*\
  !*** ./components/Experiments/store/createExperimentStore.js ***!
  \***************************************************************/
/*! exports provided: CREATION_STEPS, ACTIONS, POPOVER_TYPES, SPLIT_STATUS, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CREATION_STEPS", function() { return CREATION_STEPS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTIONS", function() { return ACTIONS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "POPOVER_TYPES", function() { return POPOVER_TYPES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SPLIT_STATUS", function() { return SPLIT_STATUS; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var CREATION_STEPS = {
  DATAPREP_CONNECTIONS: 'DATAPREP_CONNECTIONS',
  DATAPREP: 'DATAPREP',
  DATASPLIT: 'DATASPLIT',
  ALGORITHM_SELECTION: 'ALGORITHM_SELECTION'
};
var ACTIONS = {
  SET_EXPERIMENT_NAME: 'SET_EXPERIMENT_NAME',
  SET_EXPERIMENT_DESCRIPTION: 'SET_EXPERIMENT_DESCRIPTION',
  SET_EXPERIMENT_OUTCOME: 'SET_EXPERIMENT_OUTCOME',
  SET_EXPERIMENT_SRC_PATH: 'SET_EXPERIMENT_SRC_PATH',
  SET_CREATE_EXPERIMENT_LOADING: 'SET_CREATE_EXPERIMENT_LOADING',
  SET_EXPERIMENT_METADATA_FOR_EDIT: 'SET_EXPERIMENT_METADATA_FOR_EDIT',
  SET_VISIBLE_POPOVER: 'SET_VISIBLE_POPOVER',
  SET_EXPERIMENT_ERROR: 'SET_EXPERIMENT_ERROR',
  OVERRIDE_CREATION_STEP: 'OVERRIDE_CREATION_STEP',
  MODEL_UPDATE: 'MODEL_UPDATE',
  SET_SPLIT_INFO: 'SET_SPLIT_INFO',
  SET_SCHEMA: 'SET_SCHEMA',
  SET_OUTCOME_COLUMNS: 'SET_OUTCOME_COLUMNS',
  SET_DIRECTIVES: 'SET_DIRECTIVES',
  SET_MODEL_NAME: 'SET_MODEL_NAME',
  SET_MODEL_ID: 'SET_MODEL_ID',
  SET_EXPERIMENT_MODEL_FOR_EDIT: 'SET_EXPERIMENT_MODEL_FOR_EDIT',
  SET_MODEL_DESCRIPTION: 'SET_MODEL_DESCRIPTION',
  SET_MODEL_ML_ALGORITHM: 'SET_MODEL_ML_ALGORITHM',
  SET_VALID_ALGORITHMS_LIST: 'SET_VALID_ALGORITHMS_LIST',
  SET_ALGORITHMS_LIST: 'SET_ALGORITHMS_LIST',
  SET_WORKSPACE_ID: 'SET_WORKSPACE_ID',
  SET_SPLIT_FINALIZED: 'SET_SPLIT_FINALIZED',
  UPDATE_HYPER_PARAM: 'UPDATE_HYPER_PARAM',
  SET_MODEL_TRAINED: 'SET_MODEL_TRAINED',
  SET_MODEL_ERROR: 'SET_MODEL_ERROR',
  RESET: 'RESET'
};
var POPOVER_TYPES = {
  EXPERIMENT: 'EXPERIMENT',
  MODEL: 'MODEL'
};
var DEFAULT_EXPERIMENTS_CREATE_VALUE = {
  name: '',
  description: '',
  outcome: '',
  srcpath: '',
  loading: false,
  popover: POPOVER_TYPES.EXPERIMENT,
  isEdit: false,
  workspaceId: null,
  error: null
};
var DEFAULT_MODEL_CREATE_VALUE = {
  name: '',
  description: '',
  modelId: null,
  directives: [],
  columns: [],
  schema: null,
  splitInfo: {},
  isSplitFinalized: false,
  algorithm: {
    name: ''
  },
  validAlgorithmsList: [],
  algorithmsList: [],
  isModelTrained: false,
  error: null
};
var DEFAULT_ACTIVE_STEP = {
  override: false,
  step_name: CREATION_STEPS.DATAPREP_CONNECTIONS
};

var experiments_create = function experiments_create() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_EXPERIMENTS_CREATE_VALUE;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ACTIONS.SET_EXPERIMENT_NAME:
      return _objectSpread({}, state, {
        name: action.payload.name
      });

    case ACTIONS.SET_EXPERIMENT_DESCRIPTION:
      return _objectSpread({}, state, {
        description: action.payload.description
      });

    case ACTIONS.SET_EXPERIMENT_OUTCOME:
      return _objectSpread({}, state, {
        outcome: action.payload.outcome
      });

    case ACTIONS.SET_EXPERIMENT_SRC_PATH:
      return _objectSpread({}, state, {
        srcpath: action.payload.srcpath
      });

    case ACTIONS.SET_CREATE_EXPERIMENT_LOADING:
      return _objectSpread({}, state, {
        loading: action.payload.loading
      });

    case ACTIONS.SET_WORKSPACE_ID:
      return _objectSpread({}, state, {
        workspaceId: action.payload.workspaceId
      });

    case ACTIONS.SET_EXPERIMENT_METADATA_FOR_EDIT:
    case ACTIONS.SET_EXPERIMENT_MODEL_FOR_EDIT:
      {
        var _action$payload$exper = action.payload.experimentDetails,
            name = _action$payload$exper.name,
            description = _action$payload$exper.description,
            outcome = _action$payload$exper.outcome,
            srcpath = _action$payload$exper.srcpath,
            workspaceId = _action$payload$exper.workspaceId;
        return _objectSpread({}, state, {
          name: name,
          description: description,
          outcome: outcome,
          srcpath: srcpath,
          workspaceId: workspaceId,
          isEdit: true,
          loading: false,
          popover: POPOVER_TYPES.MODEL
        });
      }

    case ACTIONS.SET_VISIBLE_POPOVER:
      return _objectSpread({}, state, {
        popover: action.payload.popover
      });

    case ACTIONS.SET_EXPERIMENT_ERROR:
      return _objectSpread({}, state, {
        error: action.payload.error
      });

    case ACTIONS.RESET:
      return DEFAULT_EXPERIMENTS_CREATE_VALUE;

    default:
      return state;
  }
};

var model_create = function model_create() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_MODEL_CREATE_VALUE;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ACTIONS.SET_MODEL_ID:
      return _objectSpread({}, state, {
        modelId: action.payload.modelId
      });

    case ACTIONS.SET_MODEL_NAME:
      return _objectSpread({}, state, {
        name: action.payload.name
      });

    case ACTIONS.SET_MODEL_DESCRIPTION:
      return _objectSpread({}, state, {
        description: action.payload.description
      });

    case ACTIONS.SET_SPLIT_INFO:
      return _objectSpread({}, state, {
        splitInfo: action.payload.splitInfo
      });

    case ACTIONS.MODEL_UPDATE:
      return _objectSpread({}, state, {
        splitInfo: DEFAULT_MODEL_CREATE_VALUE.splitInfo
      });

    case ACTIONS.SET_SPLIT_FINALIZED:
      return _objectSpread({}, state, {
        isSplitFinalized: action.payload.isSplitFinalized
      });

    case ACTIONS.SET_OUTCOME_COLUMNS:
      return _objectSpread({}, state, {
        columns: action.payload.columns
      });

    case ACTIONS.SET_DIRECTIVES:
      return _objectSpread({}, state, {
        directives: action.payload.directives
      });

    case ACTIONS.SET_MODEL_ML_ALGORITHM:
      return _objectSpread({}, state, {
        algorithm: action.payload.algorithm
      });

    case ACTIONS.SET_ALGORITHMS_LIST:
      return _objectSpread({}, state, {
        algorithmsList: action.payload.algorithmsList
      });

    case ACTIONS.UPDATE_HYPER_PARAM:
      {
        var _action$payload = action.payload,
            key = _action$payload.key,
            value = _action$payload.value;
        return _objectSpread({}, state, {
          algorithm: _objectSpread({}, state.algorithm, {
            hyperparameters: _objectSpread({}, state.algorithm.hyperparameters, _defineProperty({}, key, value))
          })
        });
      }

    case ACTIONS.SET_EXPERIMENT_METADATA_FOR_EDIT:
    case ACTIONS.SET_SCHEMA:
      return _objectSpread({}, state, {
        schema: action.payload.schema || state.schema
      });

    case ACTIONS.SET_EXPERIMENT_MODEL_FOR_EDIT:
      {
        var _action$payload$model = action.payload.modelDetails,
            name = _action$payload$model.name,
            description = _action$payload$model.description,
            modelId = _action$payload$model.id;
        return _objectSpread({}, state, {
          name: name,
          description: description,
          modelId: modelId,
          splitInfo: action.payload.splitInfo
        });
      }

    case ACTIONS.SET_VALID_ALGORITHMS_LIST:
      return _objectSpread({}, state, {
        validAlgorithmsList: state.algorithmsList.filter(function (algo) {
          return action.payload.validAlgorithmsList.map(function (al) {
            return al.name;
          }).indexOf(algo.algorithm) !== -1;
        })
      });

    case ACTIONS.SET_MODEL_TRAINED:
      return _objectSpread({}, state, {
        isModelTrained: true
      });

    case ACTIONS.SET_MODEL_ERROR:
      return _objectSpread({}, state, {
        error: action.payload.error
      });

    case ACTIONS.RESET:
      return DEFAULT_MODEL_CREATE_VALUE;

    default:
      return state;
  }
};

var active_step = function active_step() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_ACTIVE_STEP;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  var getActiveStep = function getActiveStep(state) {
    var override = state.active_step.override;

    if (override) {
      return state.active_step;
    }

    var _state$experiments_cr = state.experiments_create,
        name = _state$experiments_cr.name,
        workspaceId = _state$experiments_cr.workspaceId;
    var _state$model_create = state.model_create,
        modelId = _state$model_create.modelId,
        isSplitFinalized = _state$model_create.isSplitFinalized,
        algorithm = _state$model_create.algorithm;

    if (!workspaceId) {
      if (name) {
        return _objectSpread({}, state.active_step, {
          step_name: CREATION_STEPS.DATAPREP
        });
      }

      return _objectSpread({}, state.active_step, {
        step_name: CREATION_STEPS.DATAPREP_CONNECTIONS
      });
    }

    if (workspaceId && !modelId) {
      return _objectSpread({}, state.active_step, {
        step_name: CREATION_STEPS.DATAPREP
      });
    }

    if (modelId && !isSplitFinalized) {
      return _objectSpread({}, state.active_step, {
        step_name: CREATION_STEPS.DATASPLIT
      });
    }

    if (modelId && !algorithm.name.length) {
      return _objectSpread({}, state.active_step, {
        step_name: CREATION_STEPS.ALGORITHM_SELECTION
      });
    }

    return state.active_step;
  };

  switch (action.type) {
    case ACTIONS.SET_WORKSPACE_ID:
      {
        var newState = _objectSpread({}, state, {
          experiments_create: _objectSpread({}, state.experiments_create, {
            workspaceId: action.payload.workspaceId
          }),
          active_step: _objectSpread({}, state.active_step, {
            step_name: state.active_step.step_name
          })
        });

        return _objectSpread({}, state.active_step, {
          step_name: getActiveStep(newState).step_name
        });
      }

    case ACTIONS.MODEL_UPDATE:
      {
        var _newState = _objectSpread({}, state, {
          active_step: {
            override: false,
            step_name: state.active_step.step_name
          }
        });

        return {
          override: false,
          step_name: getActiveStep(_newState).step_name
        };
      }

    case ACTIONS.OVERRIDE_CREATION_STEP:
      return {
        override: true,
        step_name: action.payload.active_step
      };

    case ACTIONS.SET_SPLIT_FINALIZED:
      {
        var _newState2 = _objectSpread({}, state, {
          model_create: _objectSpread({}, state.model_create, {
            isSplitFinalized: action.payload.isSplitFinalized
          }),
          active_step: _objectSpread({}, state.active_step, {
            override: false
          })
        });

        return getActiveStep(_newState2);
      }

    case ACTIONS.SET_EXPERIMENT_METADATA_FOR_EDIT:
      {
        var _action$payload$exper2 = action.payload.experimentDetails,
            name = _action$payload$exper2.name,
            description = _action$payload$exper2.description,
            outcome = _action$payload$exper2.outcome,
            srcpath = _action$payload$exper2.srcpath,
            workspaceId = _action$payload$exper2.workspaceId;
        var _newState3 = {
          experiments_create: _objectSpread({}, state.experiments_create, {
            name: name,
            description: description,
            outcome: outcome,
            srcpath: srcpath,
            workspaceId: workspaceId
          }),
          model_create: state.model_create,
          active_step: state.active_step
        };
        return getActiveStep(_newState3);
      }

    case ACTIONS.SET_EXPERIMENT_MODEL_FOR_EDIT:
      {
        var _action$payload$exper3 = action.payload.experimentDetails,
            experimentName = _action$payload$exper3.name,
            experimentDescription = _action$payload$exper3.description,
            _outcome = _action$payload$exper3.outcome,
            _srcpath = _action$payload$exper3.srcpath,
            _workspaceId = _action$payload$exper3.workspaceId;
        var _action$payload$model2 = action.payload.modelDetails,
            modelName = _action$payload$model2.name,
            modelDescription = _action$payload$model2.description,
            modelId = _action$payload$model2.id;
        var _newState4 = {
          experiments_create: _objectSpread({}, state.experiments_create, {
            name: experimentName,
            description: experimentDescription,
            outcome: _outcome,
            srcpath: _srcpath,
            workspaceId: _workspaceId
          }),
          model_create: _objectSpread({}, state.model_create, {
            name: modelName,
            description: modelDescription,
            modelId: modelId
          }),
          active_step: state.active_step
        };
        return getActiveStep(_newState4);
      }

    case ACTIONS.RESET:
      return DEFAULT_ACTIVE_STEP;

    default:
      return getActiveStep(state);
  }
};

var rootReducer = function rootReducer(state, action) {
  return {
    experiments_create: experiments_create(state.experiments_create, action),
    model_create: model_create(state.model_create, action),
    active_step: active_step(state, action)
  };
};

var createExperimentStore = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(rootReducer, {
  experiments_create: DEFAULT_EXPERIMENTS_CREATE_VALUE,
  model_create: DEFAULT_MODEL_CREATE_VALUE,
  active_step: DEFAULT_ACTIVE_STEP
}, Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["composeEnhancers"])('CreateExperimentStore')());
var SPLIT_STATUS = {
  SPLITTING: 'Splitting',
  COMPLETE: 'Complete',
  FAILED: 'Failed',
  CREATING: 'CREATING' // Purely UI state. Used when UI calls backend to create a split.

};

/* harmony default export */ __webpack_exports__["default"] = (createExperimentStore);

/***/ }),

/***/ "./components/Experiments/store/experimentDetailStore.js":
/*!***************************************************************!*\
  !*** ./components/Experiments/store/experimentDetailStore.js ***!
  \***************************************************************/
/*! exports provided: DEFAULT_EXPERIMENT_DETAILS, default, ACTIONS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_EXPERIMENT_DETAILS", function() { return DEFAULT_EXPERIMENT_DETAILS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTIONS", function() { return ACTIONS; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_Experiments_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Experiments/store */ "./components/Experiments/store/index.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var ACTIONS = {
  SET_EXPERIMENT_DETAILS: 'SET_EXPERIMENT_DETAILS',
  SET_MODELS: 'SET_MODELS',
  SET_MODEL_DETAILS: 'SET_MODEL_DETAILS',
  SET_ACTIVE_MODEL: 'SET_ACTIVE_MODEL',
  SET_LOADING: 'SET_LOADING',
  SET_SPLITS: 'SET_SPLITS',
  SET_MODEL_STATUS: 'SET_MODEL_STATUS',
  SET_MODEL_PAGINATION: 'SET_MODEL_PAGINATION',
  SET_MODELS_QUERY_PARAMS: 'SET_MODELS_QUERY_PARAMS',
  SET_NEWLY_TRAINING_MODEL: 'SET_NEWLY_TRAINING_MODEL',
  RESET_NEWLY_TRAINING_MODEL: 'RESET_NEWLY_TRAINING_MODEL',
  SET_MODELS_SORT: 'SET_MODELS_SORT',
  SET_ERROR: 'SET_ERROR',
  SET_MODELS_LOADING: 'SET_MODELS_LOADING',
  SET_MODELS_WITH_ERROR: 'SET_MODELS_WITH_ERROR',
  RESET: 'RESET'
};
var DEFAULT_EXPERIMENT_DETAILS = {
  name: '',
  description: '',
  srcpath: '',
  outcome: '',
  outcomeType: '',
  evaluationMetrics: {},
  algorithms: {},
  statuses: {},
  models: [],
  newlyTrainingModel: null,
  modelsOffset: 0,
  modelsLimit: 10,
  modelsTotalCount: 0,
  modelsTotalPages: 0,
  modelsSortMethod: components_Experiments_store__WEBPACK_IMPORTED_MODULE_2__["MMDS_SORT_METHODS"].ASC,
  modelsSortColumn: components_Experiments_store__WEBPACK_IMPORTED_MODULE_2__["MMDS_SORT_COLUMN"],
  modelsLoading: [],
  modelsWithError: [],
  loading: false,
  error: null
};

var experimentDetails = function experimentDetails() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_EXPERIMENT_DETAILS;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ACTIONS.SET_EXPERIMENT_DETAILS:
      {
        var _action$payload$exper = action.payload.experimentDetails,
            _action$payload$exper2 = _action$payload$exper.name,
            name = _action$payload$exper2 === void 0 ? '' : _action$payload$exper2,
            _action$payload$exper3 = _action$payload$exper.description,
            description = _action$payload$exper3 === void 0 ? '' : _action$payload$exper3,
            _action$payload$exper4 = _action$payload$exper.srcpath,
            srcpath = _action$payload$exper4 === void 0 ? '' : _action$payload$exper4,
            _action$payload$exper5 = _action$payload$exper.outcome,
            outcome = _action$payload$exper5 === void 0 ? '' : _action$payload$exper5,
            _action$payload$exper6 = _action$payload$exper.outcomeType,
            outcomeType = _action$payload$exper6 === void 0 ? '' : _action$payload$exper6,
            _action$payload$exper7 = _action$payload$exper.evaluationMetrics,
            evaluationMetrics = _action$payload$exper7 === void 0 ? {} : _action$payload$exper7,
            _action$payload$exper8 = _action$payload$exper.algorithms,
            algorithms = _action$payload$exper8 === void 0 ? {} : _action$payload$exper8,
            _action$payload$exper9 = _action$payload$exper.statuses,
            statuses = _action$payload$exper9 === void 0 ? {} : _action$payload$exper9;
        return _objectSpread({}, state, {
          name: name,
          description: description,
          srcpath: srcpath,
          outcome: outcome,
          outcomeType: outcomeType,
          evaluationMetrics: evaluationMetrics,
          algorithms: algorithms,
          statuses: statuses
        });
      }

    case ACTIONS.SET_NEWLY_TRAINING_MODEL:
      return _objectSpread({}, state, {
        newlyTrainingModel: action.payload.model
      });

    case ACTIONS.RESET_NEWLY_TRAINING_MODEL:
      return _objectSpread({}, state, {
        newlyTrainingModel: null
      });

    case ACTIONS.SET_MODELS:
      {
        var models = action.payload.models;

        if (state.newlyTrainingModel) {
          models = models.map(function (model) {
            if (model.id === state.newlyTrainingModel.modelId) {
              return _objectSpread({}, model, {
                active: true
              });
            }

            return model;
          });
        }

        return _objectSpread({}, state, {
          models: models,
          modelsTotalCount: action.payload.totalCount,
          modelsTotalPages: Math.ceil(action.payload.totalCount / state.modelsLimit),
          loading: false
        });
      }

    case ACTIONS.SET_MODEL_PAGINATION:
      return _objectSpread({}, state, {
        modelsOffset: action.payload.modelsOffset,
        modelsLimit: action.payload.modelsLimit || state.modelsLimit
      });

    case ACTIONS.SET_MODELS_QUERY_PARAMS:
      return _objectSpread({}, state, {
        modelsOffset: action.payload.modelsOffset,
        modelsLimit: action.payload.modelsLimit || state.modelsLimit,
        modelsSortMethod: action.payload.modelsSortMethod,
        modelsSortColumn: action.payload.modelsSortColumn
      });

    case ACTIONS.SET_ACTIVE_MODEL:
      return _objectSpread({}, state, {
        models: state.models.map(function (model) {
          return _objectSpread({}, model, {
            active: !model.active ? model.id === action.payload.activeModelId : !model.active,
            loading: false
          });
        })
      });

    case ACTIONS.SET_LOADING:
      return _objectSpread({}, state, {
        loading: true
      });

    case ACTIONS.SET_SPLITS:
      return _objectSpread({}, state, {
        models: state.models.map(function (model) {
          var matchingSplit = action.payload.splits.find(function (split) {
            return split.id === model.split;
          });

          if (matchingSplit) {
            return _objectSpread({}, model, {
              splitDetails: matchingSplit
            });
          }

          return model;
        })
      });

    case ACTIONS.SET_MODEL_STATUS:
      {
        var modelsWithError = _toConsumableArray(state.modelsWithError);

        var modelIndex = modelsWithError.indexOf(action.payload.modelId);

        if (modelIndex !== -1) {
          modelsWithError.splice(modelIndex, 1);
        }

        return _objectSpread({}, state, {
          models: state.models.map(function (model) {
            if (model.id === action.payload.modelId) {
              return _objectSpread({}, model, {
                status: action.payload.modelStatus
              });
            }

            return model;
          }),
          modelsWithError: modelsWithError
        });
      }

    case ACTIONS.SET_MODELS_SORT:
      return _objectSpread({}, state, {
        modelsSortMethod: action.payload.modelsSortMethod,
        modelsSortColumn: action.payload.modelsSortColumn
      });

    case ACTIONS.SET_ERROR:
      return _objectSpread({}, state, {
        error: action.payload.error
      });

    case ACTIONS.SET_MODELS_LOADING:
      return _objectSpread({}, state, {
        modelsLoading: action.payload.modelsLoading
      });

    case ACTIONS.SET_MODELS_WITH_ERROR:
      return _objectSpread({}, state, {
        modelsWithError: action.payload.modelsWithError
      });

    default:
      return state;
  }
};

var experimentDetailsStore = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(experimentDetails, DEFAULT_EXPERIMENT_DETAILS, Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["composeEnhancers"])('ExperimentDetailStore')());
/* harmony default export */ __webpack_exports__["default"] = (experimentDetailsStore);


/***/ }),

/***/ "./components/FastAction/ExploreAction/ExploreAction.scss":
/*!****************************************************************!*\
  !*** ./components/FastAction/ExploreAction/ExploreAction.scss ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./ExploreAction.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/FastAction/ExploreAction/ExploreAction.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/FastAction/ExploreAction/ExploreModal.js":
/*!*************************************************************!*\
  !*** ./components/FastAction/ExploreAction/ExploreModal.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ExploreModal; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var api_explore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/explore */ "./api/explore.js");
/* harmony import */ var lodash_isObject__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/isObject */ "../../node_modules/lodash/isObject.js");
/* harmony import */ var lodash_isObject__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_isObject__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var whatwg_fetch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! whatwg-fetch */ "../../node_modules/whatwg-fetch/fetch.js");
/* harmony import */ var whatwg_fetch__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(whatwg_fetch__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/UncontrolledComponents */ "./components/UncontrolledComponents/index.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_11__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */










__webpack_require__(/*! ./ExploreModal.scss */ "./components/FastAction/ExploreAction/ExploreModal.scss");




var PREFIX = 'features.FastAction.Explore';

var ExploreModal =
/*#__PURE__*/
function (_Component) {
  _inherits(ExploreModal, _Component);

  function ExploreModal(props) {
    var _this;

    _classCallCheck(this, ExploreModal);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ExploreModal).call(this, props));
    _this.type = _this.props.entity.type;
    _this.state = {
      queryString: "SELECT * FROM ".concat(_this.props.entity.databaseName, ".").concat(_this.props.entity.tableName, " LIMIT 500"),
      queries: [],
      error: null,
      loading: false
    }; // Show any queries that were executed when the modal is open, like `show tables`.
    // This is maintained in the current session and when the modal is opened again it doesn't need to be surfaced.

    _this.sessionQueryHandles = [];
    _this.submitQuery = _this.submitQuery.bind(_assertThisInitialized(_this));
    _this.onQueryStringChange = _this.onQueryStringChange.bind(_assertThisInitialized(_this));
    _this.subscriptions = [];
    _this.updateState = _this.updateState.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(ExploreModal, [{
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this._mounted = false;
      this.subscriptions.map(function (subscriber) {
        return subscriber.unsubscribe();
      });
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      var _this$props$entity = this.props.entity,
          existingDatabaseName = _this$props$entity.databaseName,
          existingTableName = _this$props$entity.tableName;
      var _nextProps$entity = nextProps.entity,
          newDatabaseName = _nextProps$entity.databaseName,
          newTablename = _nextProps$entity.tableName;

      if (existingDatabaseName !== newDatabaseName || existingTableName !== newTablename) {
        this.setState({
          queryString: "SELECT * FROM ".concat(nextProps.entity.databaseName, ".").concat(nextProps.entity.tableName, " LIMIT 500")
        });
      }
    }
  }, {
    key: "updateState",
    value: function updateState() {
      if (!this._mounted) {
        return;
      }

      this.setState.apply(this, arguments);
    }
  }, {
    key: "onQueryStringChange",
    value: function onQueryStringChange(e) {
      this.updateState({
        queryString: e.target.value
      });
    }
  }, {
    key: "setQueryString",
    value: function setQueryString(query) {
      this.updateState({
        queryString: query.statement
      });
    }
  }, {
    key: "getValidQueries",
    value: function getValidQueries(queries) {
      var _this2 = this;

      var updatedQueries = queries.filter(function (q) {
        return q.statement.indexOf("".concat(_this2.props.entity.databaseName, ".").concat(_this2.props.entity.tableName)) !== -1 || q.statement.indexOf("".concat(_this2.props.entity.id)) !== -1 // For queries run before 4.1
        ;
      });

      var updatedStateQueries = _toConsumableArray(updatedQueries);

      var intersectingQueries = [];

      if (this.state.queries.length) {
        updatedStateQueries = this.state.queries.map(function (query) {
          var matchedQuery = updatedQueries.find(function (q) {
            return q.query_handle === query.query_handle;
          });

          if (matchedQuery) {
            return Object.assign(query, {}, matchedQuery);
          }

          return query;
        });
        intersectingQueries = updatedQueries.filter(function (q) {
          return !_this2.state.queries.filter(function (qq) {
            return qq.query_handle === q.query_handle;
          }).length;
        });
      }

      return [].concat(_toConsumableArray(intersectingQueries), _toConsumableArray(updatedStateQueries));
    }
  }, {
    key: "submitQuery",
    value: function submitQuery() {
      var _this3 = this;

      var _NamespaceStore$getSt = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_9__["default"].getState(),
          namespace = _NamespaceStore$getSt.selectedNamespace;

      this.setState({
        loading: true
      });
      var queriesSubscription$ = api_explore__WEBPACK_IMPORTED_MODULE_3__["default"].submitQuery({
        namespace: namespace
      }, {
        query: this.state.queryString
      }).mergeMap(function (res) {
        _this3.sessionQueryHandles.push(res.handle);

        return api_explore__WEBPACK_IMPORTED_MODULE_3__["default"].fetchQueries({
          namespace: namespace
        });
      }).subscribe(function (res) {
        _this3.updateState({
          queries: _this3.getValidQueries(res),
          loading: false,
          error: null
        });
      }, function (error) {
        _this3.updateState({
          error: lodash_isObject__WEBPACK_IMPORTED_MODULE_4___default()(error) ? error.response : error,
          loading: false
        });
      });
      this.subscriptions.push(queriesSubscription$);
    }
  }, {
    key: "fetchAndUpdateQueries",
    value: function fetchAndUpdateQueries() {
      var _this4 = this;

      if (!this._mounted) {
        return;
      }

      var _NamespaceStore$getSt2 = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_9__["default"].getState(),
          namespace = _NamespaceStore$getSt2.selectedNamespace;

      var queriesSubscription$ = api_explore__WEBPACK_IMPORTED_MODULE_3__["default"].fetchQueries({
        namespace: namespace
      }).subscribe(function () {
        var res = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];

        if (!res.length) {
          return;
        }

        var queries = _this4.getValidQueries(res);

        _this4.updateState({
          queries: queries
        });
      }, function (error) {
        _this4.updateState({
          error: lodash_isObject__WEBPACK_IMPORTED_MODULE_4___default()(error) ? error.response : error
        });
      });
      this.subscriptions.push(queriesSubscription$);
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      this._mounted = true;
      this.fetchAndUpdateQueries();
    }
  }, {
    key: "showPreview",
    value: function showPreview(query) {
      var _this5 = this;

      var queryHandle = query.query_handle;
      var queries = this.state.queries;
      var matchIndex;
      queries.forEach(function (q, index) {
        if (q.query_handle === queryHandle) {
          matchIndex = index;
        }

        return q;
      });

      if (queries[matchIndex + 1] && queries[matchIndex + 1].preview) {
        queries = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["removeAt"])(queries, matchIndex + 1);
        this.updateState({
          queries: queries
        });
        return;
      }

      var previewSubscription$ = api_explore__WEBPACK_IMPORTED_MODULE_3__["default"].getQuerySchema({
        queryHandle: queryHandle
      }).mergeMap(function (res) {
        queries = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["insertAt"])(queries, matchIndex, {
          schema: res.map(function (s) {
            if (s.name.indexOf('.') !== -1) {
              s.name = s.name.split('.')[1];
            }

            return s;
          })
        });

        _this5.updateState({
          queries: queries
        });

        return api_explore__WEBPACK_IMPORTED_MODULE_3__["default"].getQueryPreview({
          queryHandle: queryHandle
        });
      }).subscribe(function (res) {
        var matchIndex;
        queries.forEach(function (q, index) {
          if (q.query_handle === queryHandle) {
            matchIndex = index;
          }

          return q;
        });
        queries[matchIndex + 1] = Object.assign(queries[matchIndex + 1], {
          preview: res
        });

        _this5.updateState({
          queries: queries
        });
      });
      this.subscriptions.push(previewSubscription$);
    }
  }, {
    key: "getDownloadUrl",
    value: function getDownloadUrl(query) {
      var path = "/v3/data/explore/queries/".concat(query.query_handle, "/download");
      path = encodeURIComponent(path);
      var url = "/downloadLogs?backendPath=".concat(path, "&type=download&method=POST&filename=").concat(query.query_handle, ".csv");
      return url;
    }
  }, {
    key: "updateQueryState",
    value: function updateQueryState(currentQuery, event) {
      var _this6 = this;

      if (currentQuery.is_active === false) {
        event.preventDefault();
      } else {
        var queries = this.state.queries;
        queries.forEach(function (query, index) {
          if (currentQuery == query) {
            currentQuery.is_active = false;
            queries[index] = currentQuery;

            _this6.updateState(_this6.state.queries);
          }
        });
      }
    }
  }, {
    key: "onModalToggle",
    value: function onModalToggle() {
      var runningQueries = this.state.queries.filter(function (query) {
        return query.status === 'RUNNING';
      });
      this.props.onClose(runningQueries.length);
    }
  }, {
    key: "render",
    value: function render() {
      var _this7 = this;

      var renderQueryRow = function renderQueryRow(query) {
        var id = "explore-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()());
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
          key: id
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, " ", Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["humanReadableDate"])(query.timestamp, true), " "), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, " ", query.statement, " "), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, query.status === 'RUNNING' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "query-status-value"
        }, query.status), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
          className: "fa fa-spinner fa-spin"
        })) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, query.status)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "btn-group"
        }, !query.is_active || query.status !== 'FINISHED' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "btn btn-secondary",
          disabled: "disabled"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
          id: "download-".concat(id),
          className: "fa fa-download"
        }), !query.is_active ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_8__["UncontrolledTooltip"], {
          target: "download-".concat(id),
          placement: "left",
          delay: 300
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "text-left"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('features.FastAction.downloadDisabledMessage'))) : null) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
          href: _this7.getDownloadUrl(query),
          onClick: _this7.updateQueryState.bind(_this7, query),
          className: "btn btn-secondary"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
          className: "fa fa-download"
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "btn btn-secondary",
          onClick: _this7.showPreview.bind(_this7, query),
          disabled: !query.is_active || query.status !== 'FINISHED' ? 'disabled' : null
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
          className: "fa fa-eye",
          id: "explore-".concat(id),
          delay: 300
        }), !query.is_active ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_8__["UncontrolledTooltip"], {
          target: "explore-".concat(id),
          placement: "top"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "text-left"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('features.FastAction.previewDisabledMessage'))) : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "btn btn-secondary",
          onClick: _this7.setQueryString.bind(_this7, query)
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
          className: "fa fa-clone"
        })))));
      };

      var renderPreviewRow = function renderPreviewRow(query) {
        var previewContent = function previewContent(query) {
          return query.preview.length ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("table", {
            className: "table table-bordered"
          }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("thead", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, query.schema.map(function (s) {
            return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
              key: "A-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()())
            }, s.name);
          }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tbody", null, query.preview.map(function (row) {
            return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
              key: "A-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()())
            }, !row.columns ? i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('features.FastAction.viewEvents.noResults') : row.columns.map(function (column) {
              var content = column;

              if (content === null) {
                content = 'null';
              } else if (typeof content === 'boolean') {
                content = content === true ? 'true' : 'false';
              }

              return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", {
                key: "A-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()())
              }, content);
            }));
          })))) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
            className: "text-center"
          }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".noResults")));
        };

        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
          key: "A-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()())
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", {
          colSpan: "4",
          className: "preview-cell"
        }, query.schema && !query.preview ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "fa fa-spinner fa-spin text-center"
        }) : previewContent(query)));
      };

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Modal"], {
        className: "explore-modal confirmation-modal cdap-modal",
        toggle: this.onModalToggle.bind(this),
        isOpen: this.props.isOpen,
        backdrop: "static"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalHeader"], null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".label")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        onClick: this.onModalToggle.bind(this),
        className: "float-right"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-times"
      }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalBody"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "explore-modal-body"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("textarea", {
        rows: "5",
        className: "form-control",
        value: this.state.queryString,
        onChange: this.onQueryStringChange
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "clearfix"
      }, this.state.error ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "float-left text-danger"
      }, this.state.error) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
        className: "btn btn-primary float-right",
        onClick: this.submitQuery,
        disabled: this.state.loading ? 'disabled' : null
      }, this.state.loading ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-spinner fa-spin"
      }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, "Execute"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "queries-table-wrapper"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("table", {
        className: "table table-bordered queries-table"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("thead", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
        className: "query-timestamp"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".startTime"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".SQLQuery"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
        className: "query-status"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".status"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
        className: "query-actions"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".actions"))))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tbody", null, !this.state.queries.length ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", {
        colSpan: "4",
        className: "text-center"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".noResults")))) : this.state.queries.map(function (query) {
        if (query.preview || query.schema) {
          return renderPreviewRow(query);
        }

        return renderQueryRow(query);
      })))))));
    }
  }]);

  return ExploreModal;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


ExploreModal.contextTypes = {
  params: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    namespace: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  })
};
ExploreModal.propTypes = {
  isOpen: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  onClose: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    version: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    scope: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf([services_global_constants__WEBPACK_IMPORTED_MODULE_10__["SCOPES"].SYSTEM, services_global_constants__WEBPACK_IMPORTED_MODULE_10__["SCOPES"].USER]),
    type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf(['application', 'artifact', 'dataset']).isRequired,
    databaseName: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    tableName: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  })
};

/***/ }),

/***/ "./components/FastAction/ExploreAction/ExploreModal.scss":
/*!***************************************************************!*\
  !*** ./components/FastAction/ExploreAction/ExploreModal.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./ExploreModal.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/FastAction/ExploreAction/ExploreModal.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/FastAction/ExploreAction/index.js":
/*!******************************************************!*\
  !*** ./components/FastAction/ExploreAction/index.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ExploreAction; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_ExploreTables_ExploreTablesStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/ExploreTables/ExploreTablesStore */ "./services/ExploreTables/ExploreTablesStore.js");
/* harmony import */ var _FastActionButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../FastActionButton */ "./components/FastAction/FastActionButton/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var components_FastAction_ExploreAction_ExploreModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/FastAction/ExploreAction/ExploreModal */ "./components/FastAction/ExploreAction/ExploreModal.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var api_explore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! api/explore */ "./api/explore.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2016-2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */













__webpack_require__(/*! ./ExploreAction.scss */ "./components/FastAction/ExploreAction/ExploreAction.scss");

var ExploreAction =
/*#__PURE__*/
function (_Component) {
  _inherits(ExploreAction, _Component);

  function ExploreAction(props) {
    var _this;

    _classCallCheck(this, ExploreAction);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ExploreAction).call(this, props));
    _this.state = {
      disabled: true,
      showModal: false,
      tooltipOpen: false,
      entity: _this.props.entity || {},
      runningQueries: null,
      showRunningQueriesDoneLabel: false
    };
    _this.subscription = null;
    _this.toggleTooltip = _this.toggleTooltip.bind(_assertThisInitialized(_this));
    _this.toggleModal = _this.toggleModal.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(ExploreAction, [{
    key: "toggleModal",
    value: function toggleModal(runningQueries) {
      var _this2 = this;

      var showRunningQueriesDoneLabel = false;

      if (runningQueries && this.state.showModal) {
        showRunningQueriesDoneLabel = true;
      }

      this.setState({
        showModal: !this.state.showModal,
        showRunningQueriesDoneLabel: showRunningQueriesDoneLabel,
        runningQueries: !showRunningQueriesDoneLabel ? null : runningQueries
      }, function () {
        if (typeof _this2.props.onClose === 'function') {
          _this2.props.onClose();
        }
      });
    }
  }, {
    key: "toggleTooltip",
    value: function toggleTooltip() {
      this.setState({
        tooltipOpen: !this.state.tooltipOpen
      });
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      if (this.props.opened) {
        this.setState({
          showModal: true
        });
      }
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this3 = this;

      var updateDisabledProp = function updateDisabledProp() {
        var _ExploreTablesStore$g = services_ExploreTables_ExploreTablesStore__WEBPACK_IMPORTED_MODULE_2__["default"].getState(),
            explorableTables = _ExploreTablesStore$g.tables;

        var entityId = _this3.props.entity.id.replace(/[\.\-]/g, '_');

        var type = _this3.props.entity.type;
        var match = explorableTables.filter(function (db) {
          return db.table === "".concat(type, "_").concat(entityId.toLowerCase()) || db.table === entityId.toLowerCase();
        });

        if (match.length) {
          _this3.setState({
            entity: Object.assign({}, _this3.props.entity, {
              tableName: match[0].table,
              databaseName: match[0].database
            }),
            disabled: false
          });
        }
      };

      this.subscription = services_ExploreTables_ExploreTablesStore__WEBPACK_IMPORTED_MODULE_2__["default"].subscribe(updateDisabledProp.bind(this));
      updateDisabledProp();

      if (Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(this.props.argsToAction, 'showQueriesCount')) {
        var namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_9__["default"].getState().selectedNamespace;
        this.explroeQueriesSubscription$ = api_explore__WEBPACK_IMPORTED_MODULE_8__["default"].fetchQueries({
          namespace: namespace
        }).subscribe(function (res) {
          var runningQueries = res.filter(function (q) {
            var tablename = "".concat(_this3.state.entity.databaseName, ".").concat(_this3.state.entity.tableName);
            return (q.statement.indexOf(tablename) !== -1 || q.statement.indexOf(_this3.props.entity.id) !== -1) && q.status === 'RUNNING';
          }).length;

          if (runningQueries) {
            _this3.setState({
              runningQueries: runningQueries
            });

            return;
          }

          if (_this3.state.runningQueries) {
            _this3.setState({
              runningQueries: i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.FastAction.doneLabel')
            });
          }
        });
      }
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (nextProps.opened !== this.state.showModal) {
        this.setState({
          showModal: nextProps.opened
        });
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.subscription();

      if (this.explroeQueriesSubscription$) {
        this.explroeQueriesSubscription$.unsubscribe();
      }
    }
  }, {
    key: "render",
    value: function render() {
      var tooltipID = "explore-".concat(this.props.entity.uniqueId);
      var showRunningQueriesNotification = this.state.showRunningQueriesDoneLabel && this.state.runningQueries && Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(this.props.argsToAction, 'showQueriesCount');
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: classnames__WEBPACK_IMPORTED_MODULE_10___default()('btn btn-secondary btn-sm', {
          'fast-action-with-popover': showRunningQueriesNotification
        })
      }, this.props.renderActionButton ? this.props.renderActionButton(tooltipID) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_FastActionButton__WEBPACK_IMPORTED_MODULE_3__["default"], {
        icon: "icon-eye",
        action: this.toggleModal,
        disabled: this.state.disabled,
        id: tooltipID
      }), showRunningQueriesNotification ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fast-action-popover-container"
      }, this.state.runningQueries) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_4__["Tooltip"], {
        placement: "top",
        className: "fast-action-tooltip",
        isOpen: this.state.tooltipOpen,
        target: tooltipID,
        toggle: this.toggleTooltip,
        delay: 0
      }, this.props.customTooltip ? this.props.customTooltip : i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.FastAction.Explore.label')), this.state.showModal ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_FastAction_ExploreAction_ExploreModal__WEBPACK_IMPORTED_MODULE_5__["default"], {
        isOpen: this.state.showModal,
        onClose: this.toggleModal,
        entity: this.state.entity
      }) : null);
    }
  }]);

  return ExploreAction;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(ExploreAction, "propTypes", {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    version: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    uniqueId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    scope: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf([services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SCOPES"].SYSTEM, services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SCOPES"].USER]),
    type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf(['application', 'artifact', 'dataset']).isRequired
  }),
  opened: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  renderActionButton: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  argsToAction: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  customTooltip: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onClose: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
});



/***/ }),

/***/ "./components/PieChartWithLegend/PieChartWithLegend.scss":
/*!***************************************************************!*\
  !*** ./components/PieChartWithLegend/PieChartWithLegend.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./PieChartWithLegend.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PieChartWithLegend/PieChartWithLegend.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PieChartWithLegend/index.js":
/*!************************************************!*\
  !*** ./components/PieChartWithLegend/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PieChartWithLegends; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_PieChart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PieChart */ "./components/PieChart/index.js");
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




__webpack_require__(/*! ./PieChartWithLegend.scss */ "./components/PieChartWithLegend/PieChartWithLegend.scss");

function PieChartWithLegends(_ref) {
  var data = _ref.data,
      width = _ref.width,
      height = _ref.height;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "pie-chart-with-legends"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PieChart__WEBPACK_IMPORTED_MODULE_2__["default"], {
    data: data,
    width: width,
    height: height
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "pie-chart-legends"
  }, !data.length ? null : data.map(function (d) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
      key: d.color
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
      className: "pie-legend-color",
      style: {
        backgroundColor: d.color
      }
    }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, d.value));
  })));
}
PieChartWithLegends.defaultProps = {
  width: 150,
  height: 150
};
PieChartWithLegends.propTypes = {
  data: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    color: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    value: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  })),
  width: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  height: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number
};

/***/ }),

/***/ "./components/StyledSelectTag/StyledSelectTag.scss":
/*!*********************************************************!*\
  !*** ./components/StyledSelectTag/StyledSelectTag.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./StyledSelectTag.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/StyledSelectTag/StyledSelectTag.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/StyledSelectTag/index.js":
/*!*********************************************!*\
  !*** ./components/StyledSelectTag/index.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return StyledSelectTag; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




__webpack_require__(/*! ./StyledSelectTag.scss */ "./components/StyledSelectTag/StyledSelectTag.scss");

function StyledSelectTag(_ref) {
  var keys = _ref.keys,
      onChange = _ref.onChange,
      _ref$defaultEmptyMess = _ref.defaultEmptyMessage,
      defaultEmptyMessage = _ref$defaultEmptyMess === void 0 ? 'No Values' : _ref$defaultEmptyMess;

  var renderOptions = function renderOptions() {
    if (Array.isArray(keys) && keys.length) {
      return keys.map(function (key) {
        key = key || {};
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("option", {
          key: key.id,
          value: key.id
        }, key.value);
      });
    }

    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("option", null, defaultEmptyMessage);
  };

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "styled-select-wrapper"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("select", {
    className: "styled-select-tag",
    onChange: onChange ? onChange : function () {}
  }, renderOptions()), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
    name: "icon-caret-down"
  }));
}
StyledSelectTag.propTypes = {
  keys: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    value: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  })),
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  defaultEmptyMessage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./services/ExploreTables/ActionCreator.js":
/*!*************************************************!*\
  !*** ./services/ExploreTables/ActionCreator.js ***!
  \*************************************************/
/*! exports provided: fetchTables */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchTables", function() { return fetchTables; });
/* harmony import */ var api_explore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! api/explore */ "./api/explore.js");
/* harmony import */ var api_dataset__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! api/dataset */ "./api/dataset.js");
/* harmony import */ var services_ExploreTables_ExploreTablesActions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/ExploreTables/ExploreTablesActions */ "./services/ExploreTables/ExploreTablesActions.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__);
/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
*/





var fetchTables = function fetchTables(namespace) {
  return function (dispatch) {
    var exploreTables$ = api_explore__WEBPACK_IMPORTED_MODULE_0__["default"].fetchTables({
      namespace: namespace
    });
    var datasetsSpec$ = api_dataset__WEBPACK_IMPORTED_MODULE_1__["MyDatasetApi"].list({
      namespace: namespace
    });
    return rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__["Observable"].combineLatest(exploreTables$, datasetsSpec$).subscribe(function (res) {
      dispatch({
        type: services_ExploreTables_ExploreTablesActions__WEBPACK_IMPORTED_MODULE_2__["default"].SET_TABLES,
        payload: {
          exploreTables: res[0],
          datasetsSpec: res[1]
        }
      });
    });
  };
};



/***/ }),

/***/ "./services/ExploreTables/ExploreTablesActions.js":
/*!********************************************************!*\
  !*** ./services/ExploreTables/ExploreTablesActions.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var ExploreTablesActions = {
  FETCH_TABLES: 'FETCH_TABLES',
  SET_TABLES: 'SET_TABLES'
};
/* harmony default export */ __webpack_exports__["default"] = (ExploreTablesActions);

/***/ }),

/***/ "./services/ExploreTables/ExploreTablesStore.js":
/*!******************************************************!*\
  !*** ./services/ExploreTables/ExploreTablesStore.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux-thunk */ "../../node_modules/redux-thunk/es/index.js");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_ExploreTables_ExploreTablesActions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/ExploreTables/ExploreTablesActions */ "./services/ExploreTables/ExploreTablesActions.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_findIndex__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/findIndex */ "../../node_modules/lodash/findIndex.js");
/* harmony import */ var lodash_findIndex__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_findIndex__WEBPACK_IMPORTED_MODULE_4__);
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var defaultAction = {
  type: '',
  payload: {},
  uniqueId: uuid_v4__WEBPACK_IMPORTED_MODULE_3___default()()
};
var defaultInitialState = {
  tables: []
};
/*
  TL;DR -
  conditions to determine if a dataset is explorable =
    dataset spec properties (explore.table.name & explore.database.name)
  +
    /explore/tables

  - UI will query dataset service endpoint .../<namespace>/data/datasets. This returns all dataset specs
  - UI will query the explore endpoint .../<namespace>/explore/tables. This returns a TableNameInfo all tables in the default database for that namespace (but not the ones that have a custom database)
    - for each dataset:
      - the explore table name is either given as property explore.table.name or defaults to dataset_<name>.
      - if the dataset spec's properties contain explore.database.name, then the table is explorable with that database name and the above table name
      - otherwise, determine whether the dataset is explorable by finding the TableNameInfo for the explore table name.
        - if that entry exists, the table is explorable, and the database name is in the TableNameInfo
        - otherwise the dataset is not explorable
*/

var tables = function tables() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultInitialState.tables;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : defaultAction;

  switch (action.type) {
    case services_ExploreTables_ExploreTablesActions__WEBPACK_IMPORTED_MODULE_2__["default"].SET_TABLES:
      {
        var datasetsSpec = action.payload.datasetsSpec.filter(function (dSpec) {
          return dSpec.properties['explore.database.name'] || dSpec.properties['explore.table.name'];
        }).map(function (dSpec) {
          return {
            datasetName: dSpec.name,
            database: dSpec.properties['explore.database.name'] || 'default',
            table: dSpec.properties['explore.table.name'] || ''
          };
        });
        var exploreTables = action.payload.exploreTables;

        var _tables = exploreTables.map(function (tb) {
          var tableIndex = tb.table.indexOf('_');
          var dbIndex = tb.database.indexOf('_');
          var matchingSpec = datasetsSpec.find(function (dspec) {
            var isSameTable = dspec.table === (tableIndex !== -1 ? tb.table.slice(tableIndex) : tb.table);
            var isSameDB = dspec.database === (dbIndex !== -1 ? tb.database.slice(dbIndex) : tb.table);
            return isSameTable || isSameDB;
          });

          if (matchingSpec) {
            var matchingSpecIndex = lodash_findIndex__WEBPACK_IMPORTED_MODULE_4___default()(datasetsSpec, matchingSpec);
            datasetsSpec.splice(matchingSpecIndex, 1);
            return {
              table: matchingSpec.table || tb.table,
              database: matchingSpec.database || tb.database
            };
          }

          return tb;
        });

        if (datasetsSpec.length) {
          _tables = [].concat(_toConsumableArray(_tables), _toConsumableArray(datasetsSpec));
        }

        return _toConsumableArray(_tables || []);
      }

    default:
      return state;
  }
};

var composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || redux__WEBPACK_IMPORTED_MODULE_1__["compose"];
var ExploreTablesStore = Object(redux__WEBPACK_IMPORTED_MODULE_1__["createStore"])(Object(redux__WEBPACK_IMPORTED_MODULE_1__["combineReducers"])({
  tables: tables
}), defaultInitialState, composeEnhancers(Object(redux__WEBPACK_IMPORTED_MODULE_1__["applyMiddleware"])(redux_thunk__WEBPACK_IMPORTED_MODULE_0__["default"])));
/* harmony default export */ __webpack_exports__["default"] = (ExploreTablesStore);

/***/ })

}]);
//# sourceMappingURL=ExperimentsDetailedView.f96599a6f548093f84a4.js.map