(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[1],{

/***/ "../../node_modules/@material-ui/icons/Close.js":
/*!**********************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/@material-ui/icons/Close.js ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@material-ui/icons/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "../../node_modules/react/index.js"));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@material-ui/icons/utils/createSvgIcon.js"));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
}), _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0z"
})), 'Close');

exports.default = _default;

/***/ }),

/***/ "../../node_modules/@material-ui/icons/KeyboardArrowLeft.js":
/*!**********************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/@material-ui/icons/KeyboardArrowLeft.js ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@material-ui/icons/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "../../node_modules/react/index.js"));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@material-ui/icons/utils/createSvgIcon.js"));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  d: "M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41z"
}), _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0V0z"
})), 'KeyboardArrowLeft');

exports.default = _default;

/***/ }),

/***/ "../../node_modules/@material-ui/icons/KeyboardArrowRight.js":
/*!***********************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/@material-ui/icons/KeyboardArrowRight.js ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@material-ui/icons/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "../../node_modules/react/index.js"));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@material-ui/icons/utils/createSvgIcon.js"));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  d: "M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"
}), _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0V0z"
})), 'KeyboardArrowRight');

exports.default = _default;

/***/ }),

/***/ "../../node_modules/lodash/_baseRange.js":
/*!***************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/_baseRange.js ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeCeil = Math.ceil,
    nativeMax = Math.max;

/**
 * The base implementation of `_.range` and `_.rangeRight` which doesn't
 * coerce arguments.
 *
 * @private
 * @param {number} start The start of the range.
 * @param {number} end The end of the range.
 * @param {number} step The value to increment or decrement by.
 * @param {boolean} [fromRight] Specify iterating from right to left.
 * @returns {Array} Returns the range of numbers.
 */
function baseRange(start, end, step, fromRight) {
  var index = -1,
      length = nativeMax(nativeCeil((end - start) / (step || 1)), 0),
      result = Array(length);

  while (length--) {
    result[fromRight ? length : ++index] = start;
    start += step;
  }
  return result;
}

module.exports = baseRange;


/***/ }),

/***/ "../../node_modules/lodash/_createRange.js":
/*!*****************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/_createRange.js ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseRange = __webpack_require__(/*! ./_baseRange */ "../../node_modules/lodash/_baseRange.js"),
    isIterateeCall = __webpack_require__(/*! ./_isIterateeCall */ "../../node_modules/lodash/_isIterateeCall.js"),
    toFinite = __webpack_require__(/*! ./toFinite */ "../../node_modules/lodash/toFinite.js");

/**
 * Creates a `_.range` or `_.rangeRight` function.
 *
 * @private
 * @param {boolean} [fromRight] Specify iterating from right to left.
 * @returns {Function} Returns the new range function.
 */
function createRange(fromRight) {
  return function(start, end, step) {
    if (step && typeof step != 'number' && isIterateeCall(start, end, step)) {
      end = step = undefined;
    }
    // Ensure the sign of `-0` is preserved.
    start = toFinite(start);
    if (end === undefined) {
      end = start;
      start = 0;
    } else {
      end = toFinite(end);
    }
    step = step === undefined ? (start < end ? 1 : -1) : toFinite(step);
    return baseRange(start, end, step, fromRight);
  };
}

module.exports = createRange;


/***/ }),

/***/ "../../node_modules/lodash/range.js":
/*!**********************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/range.js ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var createRange = __webpack_require__(/*! ./_createRange */ "../../node_modules/lodash/_createRange.js");

/**
 * Creates an array of numbers (positive and/or negative) progressing from
 * `start` up to, but not including, `end`. A step of `-1` is used if a negative
 * `start` is specified without an `end` or `step`. If `end` is not specified,
 * it's set to `start` with `start` then set to `0`.
 *
 * **Note:** JavaScript follows the IEEE-754 standard for resolving
 * floating-point values which can produce unexpected results.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Util
 * @param {number} [start=0] The start of the range.
 * @param {number} end The end of the range.
 * @param {number} [step=1] The value to increment or decrement by.
 * @returns {Array} Returns the range of numbers.
 * @see _.inRange, _.rangeRight
 * @example
 *
 * _.range(4);
 * // => [0, 1, 2, 3]
 *
 * _.range(-4);
 * // => [0, -1, -2, -3]
 *
 * _.range(1, 5);
 * // => [1, 2, 3, 4]
 *
 * _.range(0, 20, 5);
 * // => [0, 5, 10, 15]
 *
 * _.range(0, -4, -1);
 * // => [0, -1, -2, -3]
 *
 * _.range(1, 4, 0);
 * // => [1, 1, 1]
 *
 * _.range(0);
 * // => []
 */
var range = createRange();

module.exports = range;


/***/ }),

/***/ "../../node_modules/lodash/throttle.js":
/*!*************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/throttle.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var debounce = __webpack_require__(/*! ./debounce */ "../../node_modules/lodash/debounce.js"),
    isObject = __webpack_require__(/*! ./isObject */ "../../node_modules/lodash/isObject.js");

/** Error message constants. */
var FUNC_ERROR_TEXT = 'Expected a function';

/**
 * Creates a throttled function that only invokes `func` at most once per
 * every `wait` milliseconds. The throttled function comes with a `cancel`
 * method to cancel delayed `func` invocations and a `flush` method to
 * immediately invoke them. Provide `options` to indicate whether `func`
 * should be invoked on the leading and/or trailing edge of the `wait`
 * timeout. The `func` is invoked with the last arguments provided to the
 * throttled function. Subsequent calls to the throttled function return the
 * result of the last `func` invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the throttled function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.throttle` and `_.debounce`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to throttle.
 * @param {number} [wait=0] The number of milliseconds to throttle invocations to.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=true]
 *  Specify invoking on the leading edge of the timeout.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new throttled function.
 * @example
 *
 * // Avoid excessively updating the position while scrolling.
 * jQuery(window).on('scroll', _.throttle(updatePosition, 100));
 *
 * // Invoke `renewToken` when the click event is fired, but not more than once every 5 minutes.
 * var throttled = _.throttle(renewToken, 300000, { 'trailing': false });
 * jQuery(element).on('click', throttled);
 *
 * // Cancel the trailing throttled invocation.
 * jQuery(window).on('popstate', throttled.cancel);
 */
function throttle(func, wait, options) {
  var leading = true,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  if (isObject(options)) {
    leading = 'leading' in options ? !!options.leading : leading;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }
  return debounce(func, wait, {
    'leading': leading,
    'maxWait': wait,
    'trailing': trailing
  });
}

module.exports = throttle;


/***/ }),

/***/ "../../node_modules/lodash/toFinite.js":
/*!*************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/toFinite.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * This method returns the first argument it receives.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Util
 * @param {*} value Any value.
 * @returns {*} Returns `value`.
 * @example
 *
 * var object = { 'a': 1 };
 *
 * console.log(_.identity(object) === object);
 * // => true
 */
function identity(value) {
  return value;
}

module.exports = identity;


/***/ }),

/***/ "./components/HorizontalCarousel/index.tsx":
/*!*************************************************!*\
  !*** ./components/HorizontalCarousel/index.tsx ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/IconButton */ "../../node_modules/@material-ui/core/esm/IconButton/index.js");
/* harmony import */ var _material_ui_icons_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/icons/KeyboardArrowRight */ "../../node_modules/@material-ui/icons/KeyboardArrowRight.js");
/* harmony import */ var _material_ui_icons_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_icons_KeyboardArrowLeft__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/icons/KeyboardArrowLeft */ "../../node_modules/@material-ui/icons/KeyboardArrowLeft.js");
/* harmony import */ var _material_ui_icons_KeyboardArrowLeft__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_KeyboardArrowLeft__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var lodash_throttle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash/throttle */ "../../node_modules/lodash/throttle.js");
/* harmony import */ var lodash_throttle__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_throttle__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2020 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();








var styles = function styles() {
  return {
    contentContainer: {
      paddingLeft: '60px',
      paddingRight: '60px',
      whiteSpace: 'nowrap',
      overflowX: 'scroll',
      scrollSnapType: 'x proximity',
      scrollPadding: '60px',
      display: 'flex',
      scrollBehavior: 'smooth',
      '-ms-overflow-style': 'none',
      '&::-webkit-scrollbar': {
        display: 'none'
      },
      '&:after': {
        content: '""',
        borderLeft: "30px solid transparent"
      },
      '& > *': {
        scrollSnapAlign: 'end'
      }
    },
    arrowsContainer: {
      position: 'relative',
      height: 0,
      width: '100%'
    },
    arrow: {
      position: 'absolute',
      top: '50px',
      transform: 'translateY(-50%)',
      '&:focus': {
        outline: 0
      }
    },
    back: {
      left: 0
    },
    forward: {
      right: 0
    },
    icon: {
      fontSize: '45px'
    }
  };
};

var HorizontalCarouselView =
/** @class */
function (_super) {
  __extends(HorizontalCarouselView, _super);

  function HorizontalCarouselView(props) {
    var _this = _super.call(this, props) || this;

    _this.isScrollable = function () {
      if (!_this.carouselRef || !_this.carouselRef.current) {
        return false;
      }

      return _this.carouselRef.current.scrollWidth > _this.carouselRef.current.clientWidth;
    };

    _this.leftDisabled = function () {
      if (!_this.isScrollable()) {
        return true;
      }

      var carousel = _this.carouselRef.current;
      return carousel.scrollLeft === 0;
    };

    _this.rightDisabled = function () {
      if (!_this.isScrollable()) {
        return true;
      }

      var carousel = _this.carouselRef.current;
      return carousel.scrollLeft + carousel.clientWidth >= carousel.scrollWidth;
    };

    _this.setArrowDisabled = function () {
      var leftDisabled = _this.leftDisabled();

      var rightDisabled = _this.rightDisabled();

      if (_this.state.leftDisabled !== leftDisabled || _this.state.rightDisabled !== rightDisabled) {
        _this.setState({
          leftDisabled: leftDisabled,
          rightDisabled: rightDisabled
        });
      }
    };

    _this.state = {
      leftDisabled: _this.leftDisabled(),
      rightDisabled: _this.rightDisabled()
    };
    _this.throttledSetArrowDisabled = lodash_throttle__WEBPACK_IMPORTED_MODULE_5___default()(_this.setArrowDisabled, 300, {
      trailing: true,
      leading: true
    });

    _this.scrollRight = function () {
      _this.carouselRef.current.scrollLeft += _this.props.scrollAmount;
    };

    _this.scrollLeft = function () {
      _this.carouselRef.current.scrollLeft -= _this.props.scrollAmount;
    };

    _this.carouselRef = react__WEBPACK_IMPORTED_MODULE_0__["createRef"]();
    return _this;
  }

  HorizontalCarouselView.prototype.componentDidMount = function () {
    this.carouselRef.current.addEventListener('scroll', this.throttledSetArrowDisabled);
    window.addEventListener('resize', this.throttledSetArrowDisabled);
  };

  HorizontalCarouselView.prototype.componentDidUpdate = function () {
    this.setArrowDisabled();
  };

  HorizontalCarouselView.prototype.componentWillUnmount = function () {
    this.throttledSetArrowDisabled.cancel();
    window.removeEventListener('resize', this.throttledSetArrowDisabled);
  };

  HorizontalCarouselView.prototype.render = function () {
    var classes = this.props.classes;
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.root
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.arrowsContainer
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_2__["default"], {
      size: "small",
      className: classes.arrow + " " + classes.back,
      onClick: this.scrollLeft,
      disabled: this.state.leftDisabled
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_icons_KeyboardArrowLeft__WEBPACK_IMPORTED_MODULE_4___default.a, {
      className: classes.icon
    })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_2__["default"], {
      size: "small",
      className: classes.arrow + " " + classes.forward,
      onClick: this.scrollRight,
      disabled: this.state.rightDisabled
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_icons_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_3___default.a, {
      className: classes.icon
    }))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.contentContainer,
      ref: this.carouselRef
    }, this.props.children));
  };

  return HorizontalCarouselView;
}(react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"]);

var HorizontalCarousel = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(HorizontalCarouselView);
/* harmony default export */ __webpack_exports__["default"] = (HorizontalCarousel);

/***/ }),

/***/ "./components/Ingestion/PluginList/index.tsx":
/*!***************************************************!*\
  !*** ./components/Ingestion/PluginList/index.tsx ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Button */ "../../node_modules/@material-ui/core/esm/Button/index.js");
/* harmony import */ var _material_ui_core_Card__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/Card */ "../../node_modules/@material-ui/core/esm/Card/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var _material_ui_core_Popover__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Popover */ "../../node_modules/@material-ui/core/esm/Popover/index.js");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Ingestion/helpers */ "./components/Ingestion/helpers.ts");
/* harmony import */ var components_HorizontalCarousel__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/HorizontalCarousel */ "./components/HorizontalCarousel/index.tsx");
/* harmony import */ var components_Ingestion_SinkList__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/Ingestion/SinkList */ "./components/Ingestion/SinkList/index.tsx");
/*
 * Copyright © 2020 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */












var styles = function styles(theme) {
  return {
    root: {
      width: '100%'
    },
    pluginsRow: {
      display: 'flex',
      flexDirection: 'row',
      flexWrap: 'wrap'
    },
    title: {
      display: 'flex',
      alignItems: 'center'
    },
    pluginCard: {
      display: 'flex',
      flexDirection: 'column',
      margin: '10px',
      alignItems: 'center',
      width: '250px',
      height: '255px',
      flexShrink: 0,
      justifyContent: 'space-around'
    },
    pluginImageContainer: {
      display: 'flex',
      alignItems: 'center'
    },
    pluginImageBackground: {
      display: 'flex',
      width: '100%',
      minHeight: '128px',
      justifyContent: 'center',
      backgroundColor: theme.palette.grey[700]
    },
    sourceListTable: {
      width: '900px'
    },
    tablePluginIcon: {
      width: '32px',
      height: 'auto'
    },
    tablePluginFAIcon: {
      fontSize: '32px'
    },
    ingestionHeader: {
      backgroundColor: theme.palette.grey[700],
      color: theme.palette.grey[100]
    },
    targetName: {
      cursor: 'pointer',
      marginRight: '5px'
    },
    targetsCell: {},
    pluginIcon: {
      width: '100px',
      height: 'auto'
    },
    pluginFAIcon: {
      fontSize: '64px'
    },
    cardTitle: {
      padding: '15px'
    },
    cardButtonsContainer: {
      display: 'flex',
      width: '100%',
      justifyContent: 'center'
    }
  };
};

var PluginListView = function PluginListView(_a) {
  var classes = _a.classes,
      plugins = _a.plugins,
      sinks = _a.sinks,
      onPluginSelect = _a.onPluginSelect;

  var _b = react__WEBPACK_IMPORTED_MODULE_0__["useState"](null),
      anchorEl = _b[0],
      setAnchorEl = _b[1];

  var open = Boolean(anchorEl);

  function handleClick(event, plugin) {
    setAnchorEl(event.currentTarget);
    onPluginSelect(plugin);
  }

  function handleClose() {
    setAnchorEl(null);
  }

  function renderCarousel() {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_HorizontalCarousel__WEBPACK_IMPORTED_MODULE_8__["default"], {
      scrollAmount: 650
    }, plugins.map(function (plugin) {
      var displayName = Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_7__["getPluginDisplayName"])(plugin);
      var iconData = Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(plugin, 'widgetJson', 'icon', 'arguments', 'data');
      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_Card__WEBPACK_IMPORTED_MODULE_3__["default"], {
        key: plugin.name + " - " + plugin.artifact.version,
        className: classes.pluginCard
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
        className: classes.pluginImageBackground
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
        className: classes.pluginImageContainer
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_6__["default"], {
        condition: iconData
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", {
        className: classes.pluginIcon,
        src: iconData
      })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_6__["default"], {
        condition: !iconData
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
        className: classes.pluginFAIcon + " fa " + Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_7__["getIcon"])(plugin.name.toLowerCase())
      })))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
        className: classes.cardTitle
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h3", null, displayName)), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
        className: classes.cardButtonsContainer
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_2__["default"], {
        className: classes.targetsButton,
        color: "primary",
        onClick: function onClick(e) {
          return handleClick(e, plugin);
        }
      }, "Show Targets")));
    }));
  }

  var targetList = react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Ingestion_SinkList__WEBPACK_IMPORTED_MODULE_9__["default"], {
    title: "Sinks",
    plugins: sinks,
    onPluginSelect: onPluginSelect
  });
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: classes.root
  }, renderCarousel(), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_Popover__WEBPACK_IMPORTED_MODULE_5__["default"], {
    open: open,
    anchorEl: anchorEl,
    onClose: handleClose,
    anchorOrigin: {
      vertical: 'bottom',
      horizontal: 'center'
    },
    transformOrigin: {
      vertical: 'top',
      horizontal: 'center'
    }
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_6__["default"], {
    condition: sinks.length > 0
  }, targetList)));
};

var StyledPluginList = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(PluginListView);
/* harmony default export */ __webpack_exports__["default"] = (StyledPluginList);

/***/ }),

/***/ "./components/Ingestion/PluginWidgetRenderer/index.tsx":
/*!*************************************************************!*\
  !*** ./components/Ingestion/PluginWidgetRenderer/index.tsx ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_ConfigurationGroup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/ConfigurationGroup */ "./components/ConfigurationGroup/index.tsx");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core */ "../../node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Ingestion/helpers */ "./components/Ingestion/helpers.ts");
/*
 * Copyright © 2020 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();









var styles = function styles() {
  return {
    root: {
      height: 'auto',
      padding: '20px'
    },
    labelContainer: {
      padding: '10px',
      paddingLeft: '0px',
      width: '100%'
    },
    heading: {
      display: 'flex',
      justifyContent: 'space-between'
    },
    pluginIconContainer: {
      display: 'flex',
      alignSelf: 'right'
    },
    pluginFAIcon: {
      fontSize: '32px'
    },
    headingTitle: {
      display: 'flex',
      flexDirection: 'column'
    },
    pluginIcon: {
      width: '64px'
    }
  };
};

var PluginWidgetRendererView =
/** @class */
function (_super) {
  __extends(PluginWidgetRendererView, _super);

  function PluginWidgetRendererView() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  PluginWidgetRendererView.prototype.render = function () {
    var _a = this.props,
        classes = _a.classes,
        configurationGroupProps = _a.configurationGroupProps,
        title = _a.title,
        plugin = _a.plugin;
    var pluginLabel = Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_6__["getPluginDisplayName"])(plugin);
    var iconData = Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["objectQuery"])(plugin, 'widgetJson', 'icon', 'arguments', 'data');
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Card"], {
      className: classes.root
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.heading
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.headingTitle
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h5", null, title.toUpperCase()), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h2", null, pluginLabel)), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.pluginIconContainer
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_3__["default"], {
      condition: iconData
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", {
      className: classes.pluginIcon,
      src: iconData
    })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_3__["default"], {
      condition: !iconData
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.pluginFAIcon + " fa " + Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_6__["getIcon"])(this.props.plugin.name.toLowerCase())
    })))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.labelContainer
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["TextField"], {
      label: "Label",
      variant: "outlined",
      margin: "dense",
      fullWidth: true,
      value: configurationGroupProps.label,
      onChange: function onChange(event) {
        return configurationGroupProps.onLabelChange(event.target.value);
      }
    })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_3__["default"], {
      condition: configurationGroupProps.pluginProperties
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_ConfigurationGroup__WEBPACK_IMPORTED_MODULE_2__["default"], {
      pluginProperties: configurationGroupProps.pluginProperties,
      widgetJson: plugin.widgetJson,
      values: configurationGroupProps.values,
      onChange: configurationGroupProps.onChange,
      validateProperties: function validateProperties(cb) {
        cb();
      }
    })));
  };

  return PluginWidgetRendererView;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

var PluginWidgetRenderer = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(PluginWidgetRendererView);
/* harmony default export */ __webpack_exports__["default"] = (PluginWidgetRenderer);

/***/ }),

/***/ "./components/Ingestion/PluginsTableView/index.tsx":
/*!*********************************************************!*\
  !*** ./components/Ingestion/PluginsTableView/index.tsx ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_ThemeWrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/ThemeWrapper */ "./components/ThemeWrapper/index.tsx");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Ingestion/helpers */ "./components/Ingestion/helpers.ts");
/* harmony import */ var _material_ui_core_Table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/Table */ "../../node_modules/@material-ui/core/esm/Table/index.js");
/* harmony import */ var _material_ui_core_TableBody__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/TableBody */ "../../node_modules/@material-ui/core/esm/TableBody/index.js");
/* harmony import */ var _material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/TableCell */ "../../node_modules/@material-ui/core/esm/TableCell/index.js");
/* harmony import */ var _material_ui_core_TableHead__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/core/TableHead */ "../../node_modules/@material-ui/core/esm/TableHead/index.js");
/* harmony import */ var _material_ui_core_TableRow__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/core/TableRow */ "../../node_modules/@material-ui/core/esm/TableRow/index.js");
/* harmony import */ var _material_ui_core_Paper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @material-ui/core/Paper */ "../../node_modules/@material-ui/core/esm/Paper/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_12__);
/*
 * Copyright © 2020 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
    }

    return t;
  };

  return __assign.apply(this, arguments);
};
















var styles = function styles(theme) {
  return {
    // root: { display: 'flex', flexDirection: 'column', alignItems: 'center', width: 700 },
    root: {
      width: '100%'
    },
    pluginsRow: {
      display: 'flex',
      flexDirection: 'row',
      flexWrap: 'wrap'
    },
    title: {
      display: 'flex',
      alignItems: 'center'
    },
    pluginCard: {
      display: 'flex',
      flexDirection: 'column',
      margin: '10px',
      alignItems: 'center',
      width: '250px',
      height: '255px',
      flexShrink: 0,
      justifyContent: 'space-around'
    },
    pluginImageContainer: {
      display: 'flex',
      alignItems: 'center'
    },
    tableText: {
      fontSize: '1rem'
    },
    tableRow: {
      width: '100%'
    },
    pluginImageBackground: {
      display: 'flex',
      width: '100%',
      minHeight: '128px',
      justifyContent: 'center',
      backgroundColor: theme.palette.grey[700]
    },
    tablePluginIcon: {
      width: '32px',
      height: 'auto'
    },
    tablePluginFAIcon: {
      fontSize: '32px'
    },
    ingestionHeader: {
      backgroundColor: theme.palette.grey[700],
      color: theme.palette.grey[100]
    },
    targetName: {
      cursor: 'pointer',
      margin: '0px 5px',
      color: theme.palette.blue[100]
    },
    targetsCell: {
      maxWidth: '50%'
    },
    sourceNameCell: {
      minWidth: '300px'
    },
    targetsCellHeader: {
      maxWidth: '50%'
    },
    pluginIcon: {
      width: '100px',
      height: 'auto'
    },
    pluginFAIcon: {
      fontSize: '64px'
    },
    cardTitle: {
      padding: '15px'
    },
    cardButtonsContainer: {
      display: 'flex',
      width: '100%',
      justifyContent: 'center'
    },
    targetsButton: {}
  };
};

var PluginListView = function PluginListView(_a) {
  var classes = _a.classes,
      plugins = _a.plugins,
      sinks = _a.sinks,
      onSourceSinkSelect = _a.onSourceSinkSelect;
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: classes.root
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_Paper__WEBPACK_IMPORTED_MODULE_11__["default"], {
    className: classes.sourceListTable
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_Table__WEBPACK_IMPORTED_MODULE_6__["default"], {
    className: classes.table
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableHead__WEBPACK_IMPORTED_MODULE_9__["default"], {
    className: classes.ingestionHeader
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableRow__WEBPACK_IMPORTED_MODULE_10__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_8__["default"], null), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_8__["default"], {
    className: classes.tableText
  }, "Source Name"), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_8__["default"], {
    align: "left",
    className: classes.tableText
  }, "Target"))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableBody__WEBPACK_IMPORTED_MODULE_7__["default"], null, plugins.map(function (plugin, i) {
    var displayName = Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_5__["getPluginDisplayName"])(plugin);
    var iconData = Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["objectQuery"])(plugin, 'widgetJson', 'icon', 'arguments', 'data');
    var matchedSinks = sinks.map(function (sink, idx) {
      var sinkName = Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_5__["getPluginDisplayName"])(sink);
      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
        key: idx + "-" + sinkName
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
        className: classes.targetName,
        onClick: function onClick() {
          return onSourceSinkSelect(plugin, sink);
        }
      }, sinkName), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_4__["default"], {
        condition: idx !== sinks.length - 1
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null, " | ")));
    });
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableRow__WEBPACK_IMPORTED_MODULE_10__["default"], {
      key: i + "-" + displayName,
      className: classnames__WEBPACK_IMPORTED_MODULE_12___default()(classes.tableRow, classes.tableText)
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_8__["default"], {
      className: classes.tableText
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_4__["default"], {
      condition: iconData
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", {
      className: classes.tablePluginIcon,
      src: iconData
    })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_4__["default"], {
      condition: !iconData
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.tablePluginFAIcon + " fa " + Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_5__["getIcon"])(plugin.name.toLowerCase())
    }))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_8__["default"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_12___default()(classes.sourceNameCell, classes.tableText)
    }, displayName), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_8__["default"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_12___default()(classes.targetsCell, classes.tableText),
      align: "left"
    }, matchedSinks));
  })))));
};

var StyledPluginList = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(PluginListView);

function PluginList(props) {
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_ThemeWrapper__WEBPACK_IMPORTED_MODULE_2__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](StyledPluginList, __assign({}, props)));
}

PluginList.propTypes = {};
/* harmony default export */ __webpack_exports__["default"] = (PluginList);

/***/ }),

/***/ "./components/Ingestion/SinkList/index.tsx":
/*!*************************************************!*\
  !*** ./components/Ingestion/SinkList/index.tsx ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_Card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Card */ "../../node_modules/@material-ui/core/esm/Card/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Ingestion/helpers */ "./components/Ingestion/helpers.ts");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var components_HorizontalCarousel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/HorizontalCarousel */ "./components/HorizontalCarousel/index.tsx");
/*
 * Copyright © 2020 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








var styles = function styles(theme) {
  return {
    root: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      backgroundColor: theme.palette.grey[700],
      padding: '20px',
      width: '95vw'
    },
    pluginsRow: {
      width: '100%'
    },
    title: {
      display: 'flex',
      alignItems: 'center'
    },
    pluginCard: {
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0,
      margin: '10px',
      alignItems: 'center',
      width: '175px',
      height: '120px',
      cursor: 'pointer',
      justifyContent: 'space-around'
    },
    pluginImageContainer: {
      display: 'flex',
      alignItems: 'center',
      marginTop: '10px'
    },
    pluginIcon: {
      width: '50px',
      height: 'auto'
    },
    pluginFAIcon: {
      fontSize: '32px'
    },
    cardTitle: {
      padding: '15px'
    },
    cardButtonsContainer: {
      display: 'flex',
      width: '100%',
      justifyContent: 'center'
    },
    targetsButton: {}
  };
};

var SinkListView = function SinkListView(_a) {
  var classes = _a.classes,
      plugins = _a.plugins,
      onPluginSelect = _a.onPluginSelect;
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: classes.root
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h6", null, " Select a target"), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: classes.pluginsRow
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_HorizontalCarousel__WEBPACK_IMPORTED_MODULE_6__["default"], {
    scrollAmount: 300
  }, plugins.map(function (plugin) {
    var displayName = Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["objectQuery"])(plugin, 'widgetJson', 'display-name') || plugin.name;
    var iconData = Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["objectQuery"])(plugin, 'widgetJson', 'icon', 'arguments', 'data');
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_Card__WEBPACK_IMPORTED_MODULE_2__["default"], {
      key: plugin.name + " - " + plugin.artifact.version,
      className: classes.pluginCard,
      onClick: function onClick() {
        onPluginSelect(plugin);
      }
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.pluginImageContainer
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_5__["default"], {
      condition: iconData
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", {
      className: classes.pluginIcon,
      src: iconData
    })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_5__["default"], {
      condition: !iconData
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.pluginFAIcon + " fa " + Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_4__["getIcon"])(plugin.name.toLowerCase())
    }))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h5", {
      className: classes.cardTitle
    }, displayName));
  }))));
};

var StyledPluginList = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(SinkListView);
/* harmony default export */ __webpack_exports__["default"] = (StyledPluginList);

/***/ }),

/***/ "./components/Ingestion/SourceSinkConfigurator/index.tsx":
/*!***************************************************************!*\
  !*** ./components/Ingestion/SourceSinkConfigurator/index.tsx ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_ThemeWrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/ThemeWrapper */ "./components/ThemeWrapper/index.tsx");
/* harmony import */ var components_Ingestion_PluginWidgetRenderer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Ingestion/PluginWidgetRenderer */ "./components/Ingestion/PluginWidgetRenderer/index.tsx");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
    }

    return t;
  };

  return __assign.apply(this, arguments);
};







var styles = function styles(theme) {
  return {
    root: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      backgroundColor: theme.palette.grey[700],
      padding: '20px'
    },
    propsRenderBlock: {
      margin: '0 40px',
      minWidth: '40%',
      maxHeight: '60vh',
      overflowY: 'scroll'
    },
    propsContainer: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'center',
      width: '100%'
    },
    jobInfo: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center'
    }
  };
};

var SourceSinkConfig = function SourceSinkConfig(_a) {
  var classes = _a.classes,
      sourceBP = _a.sourceBP,
      selectedSource = _a.selectedSource,
      sinkBP = _a.sinkBP,
      selectedSink = _a.selectedSink,
      onSourceChange = _a.onSourceChange,
      onSinkChange = _a.onSinkChange;
  var sourceCGProps = {
    pluginProperties: sourceBP && sourceBP.properties,
    widgetJson: selectedSource && selectedSource.widgetJson,
    values: selectedSource && selectedSource.properties,
    label: selectedSource.label,
    onChange: function onChange(property) {
      var newSource = __assign({}, selectedSource);

      newSource.properties = __assign(__assign({}, newSource.properties), property);
      onSourceChange(newSource);
    },
    onLabelChange: function onLabelChange(label) {
      var newSource = __assign({}, selectedSource);

      newSource.label = label;
      onSourceChange(newSource);
    }
  };
  var sinkCGProps = {
    pluginProperties: sinkBP && sinkBP.properties,
    widgetJson: selectedSink && selectedSink.widgetJson,
    values: selectedSink && selectedSink.properties,
    label: selectedSink.label,
    onChange: function onChange(property) {
      var stateCopy = __assign({}, selectedSink);

      stateCopy.properties = __assign(__assign({}, stateCopy.properties), property);
      onSinkChange(stateCopy);
    },
    onLabelChange: function onLabelChange(label) {
      var stateCopy = __assign({}, selectedSink);

      stateCopy.label = label;
      onSinkChange(stateCopy);
    }
  };
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: classes.root
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: classes.propsContainer
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_4__["default"], {
    condition: sourceBP && selectedSource
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: classes.propsRenderBlock
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Ingestion_PluginWidgetRenderer__WEBPACK_IMPORTED_MODULE_3__["default"], {
    title: "Source",
    plugin: selectedSource,
    configurationGroupProps: sourceCGProps
  }))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_4__["default"], {
    condition: sinkBP && selectedSink
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: classes.propsRenderBlock
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Ingestion_PluginWidgetRenderer__WEBPACK_IMPORTED_MODULE_3__["default"], {
    title: "Target",
    plugin: selectedSink,
    configurationGroupProps: sinkCGProps
  })))));
};

var StyledSourceSinkConfig = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(SourceSinkConfig);

function SourceSinkConfigurator(props) {
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_ThemeWrapper__WEBPACK_IMPORTED_MODULE_2__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](StyledSourceSinkConfig, __assign({}, props)));
}

/* harmony default export */ __webpack_exports__["default"] = (SourceSinkConfigurator);

/***/ }),

/***/ "./components/Ingestion/helpers.ts":
/*!*****************************************!*\
  !*** ./components/Ingestion/helpers.ts ***!
  \*****************************************/
/*! exports provided: getIcon, getPluginDisplayName */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getIcon", function() { return getIcon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPluginDisplayName", function() { return getPluginDisplayName; });
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");

function getIcon(plugin) {
  var iconMap = {
    script: 'icon-script',
    scriptfilter: 'icon-scriptfilter',
    twitter: 'icon-twitter',
    cube: 'icon-cube',
    data: 'fa-database',
    database: 'icon-database',
    table: 'icon-table',
    kafka: 'icon-kafka',
    jms: 'icon-jms',
    projection: 'icon-projection',
    amazonsqs: 'icon-amazonsqs',
    datagenerator: 'icon-datagenerator',
    validator: 'icon-validator',
    corevalidator: 'corevalidator',
    logparser: 'icon-logparser',
    file: 'icon-file',
    kvtable: 'icon-kvtable',
    s3: 'icon-s3',
    s3avro: 'icon-s3avro',
    s3parquet: 'icon-s3parquet',
    snapshotavro: 'icon-snapshotavro',
    snapshotparquet: 'icon-snapshotparquet',
    tpfsavro: 'icon-tpfsavro',
    tpfsparquet: 'icon-tpfsparquet',
    sink: 'icon-sink',
    hive: 'icon-hive',
    structuredrecordtogenericrecord: 'icon-structuredrecord',
    cassandra: 'icon-cassandra',
    teradata: 'icon-teradata',
    elasticsearch: 'icon-elasticsearch',
    hbase: 'icon-hbase',
    mongodb: 'icon-mongodb',
    pythonevaluator: 'icon-pythonevaluator',
    csvformatter: 'icon-csvformatter',
    csvparser: 'icon-csvparser',
    clonerecord: 'icon-clonerecord',
    compressor: 'icon-compressor',
    decompressor: 'icon-decompressor',
    encoder: 'icon-encoder',
    decoder: 'icon-decoder',
    jsonformatter: 'icon-jsonformatter',
    jsonparser: 'icon-jsonparser',
    hdfs: 'icon-hdfs',
    hasher: 'icon-hasher',
    javascript: 'icon-javascript',
    deduper: 'icon-deduper',
    distinct: 'icon-distinct',
    naivebayestrainer: 'icon-naivebayestrainer',
    groupbyaggregate: 'icon-groupbyaggregate',
    naivebayesclassifier: 'icon-naivebayesclassifier',
    azureblobstore: 'icon-azureblobstore',
    xmlreader: 'icon-XMLreader',
    xmlparser: 'icon-XMLparser',
    ftp: 'icon-FTP',
    joiner: 'icon-joiner',
    deduplicate: 'icon-deduplicator',
    valuemapper: 'icon-valuemapper',
    rowdenormalizer: 'icon-rowdenormalizer',
    ssh: 'icon-ssh',
    sshaction: 'icon-sshaction',
    copybookreader: 'icon-COBOLcopybookreader',
    excel: 'icon-excelinputsource',
    encryptor: 'icon-Encryptor',
    decryptor: 'icon-Decryptor',
    hdfsfilemoveaction: 'icon-filemoveaction',
    hdfsfilecopyaction: 'icon-filecopyaction',
    sqlaction: 'icon-SQLaction',
    impalahiveaction: 'icon-impalahiveaction',
    email: 'icon-emailaction',
    kinesissink: 'icon-Amazon-Kinesis',
    bigquerysource: 'icon-Big-Query',
    tpfsorc: 'icon-ORC',
    groupby: 'icon-groupby',
    sparkmachinelearning: 'icon-sparkmachinelearning',
    solrsearch: 'icon-solr',
    sparkstreaming: 'icon-sparkstreaming',
    rename: 'icon-rename',
    archive: 'icon-archive',
    wrangler: 'icon-DataPreparation',
    normalize: 'icon-normalize',
    xmlmultiparser: 'icon-XMLmultiparser',
    xmltojson: 'icon-XMLtoJSON',
    decisiontreepredictor: 'icon-decisiontreeanalytics',
    decisiontreetrainer: 'icon-DesicionTree',
    hashingtffeaturegenerator: 'icon-HashingTF',
    ngramtransform: 'icon-NGram',
    tokenizer: 'icon-tokenizeranalytics',
    skipgramfeaturegenerator: 'icon-skipgram',
    skipgramtrainer: 'icon-skipgramtrainer',
    logisticregressionclassifier: 'icon-logisticregressionanalytics',
    logisticregressiontrainer: 'icon-LogisticRegressionclassifier',
    hdfsdelete: 'icon-hdfsdelete',
    hdfsmove: 'icon-hdfsmove',
    windowssharecopy: 'icon-windowssharecopy',
    httppoller: 'icon-httppoller',
    window: 'icon-window',
    run: 'icon-Run',
    oracleexport: 'icon-OracleDump',
    snapshottext: 'icon-SnapshotTextSink',
    errorcollector: 'fa-exclamation-triangle',
    mainframereader: 'icon-MainframeReader',
    fastfilter: 'icon-fastfilter',
    trash: 'icon-TrashSink',
    staterestore: 'icon-Staterestore',
    topn: 'icon-TopN',
    wordcount: 'icon-WordCount',
    datetransform: 'icon-DateTransform',
    sftpcopy: 'icon-FTPcopy',
    sftpdelete: 'icon-FTPdelete',
    validatingxmlconverter: 'icon-XMLvalidator',
    wholefilereader: 'icon-Filereader',
    xmlschemaaction: 'icon-XMLschemagenerator',
    s3toredshift: 'icon-S3toredshift',
    redshifttos3: 'icon-redshifttoS3',
    verticabulkexportaction: 'icon-Verticabulkexport',
    verticabulkimportaction: 'icon-Verticabulkload',
    loadtosnowflake: 'icon-snowflake',
    kudu: 'icon-apachekudu',
    orientdb: 'icon-OrientDB',
    recordsplitter: 'icon-recordsplitter',
    scalasparkprogram: 'icon-spark',
    scalasparkcompute: 'icon-spark',
    cdcdatabase: 'icon-database',
    cdchbase: 'icon-hbase',
    cdckudu: 'icon-apachekudu',
    changetrackingsqlserver: 'icon-database',
    conditional: 'fa-question-circle-o'
  };
  var pluginName = plugin ? plugin.toLowerCase() : '';
  var icon = iconMap[pluginName] ? iconMap[pluginName] : 'fa-plug';
  return icon;
}
function getPluginDisplayName(plugin) {
  var displayName = Object(services_helpers__WEBPACK_IMPORTED_MODULE_0__["objectQuery"])(plugin, 'widgetJson', 'display-name');
  var pluginName = Object(services_helpers__WEBPACK_IMPORTED_MODULE_0__["objectQuery"])(plugin, 'name') || '';
  return displayName ? displayName : pluginName;
}

/***/ }),

/***/ "./components/Ingestion/index.tsx":
/*!****************************************!*\
  !*** ./components/Ingestion/index.tsx ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Ingestion_PluginList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Ingestion/PluginList */ "./components/Ingestion/PluginList/index.tsx");
/* harmony import */ var components_Ingestion_PluginsTableView__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Ingestion/PluginsTableView */ "./components/Ingestion/PluginsTableView/index.tsx");
/* harmony import */ var api_pipeline__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! api/pipeline */ "./api/pipeline.js");
/* harmony import */ var components_Ingestion_SourceSinkConfigurator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Ingestion/SourceSinkConfigurator */ "./components/Ingestion/SourceSinkConfigurator/index.tsx");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core */ "../../node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-helmet */ "../../node_modules/react-helmet/lib/Helmet.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/core/IconButton */ "../../node_modules/@material-ui/core/esm/IconButton/index.js");
/* harmony import */ var _material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @material-ui/icons/Close */ "../../node_modules/@material-ui/icons/Close.js");
/* harmony import */ var _material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var components_Alert__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! components/Alert */ "./components/Alert/index.js");
/* harmony import */ var components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! components/Ingestion/helpers */ "./components/Ingestion/helpers.ts");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_VersionStore__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! services/VersionStore */ "./services/VersionStore/index.js");
/* harmony import */ var services_VersionStore_VersionActions__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! services/VersionStore/VersionActions */ "./services/VersionStore/VersionActions.js");
/* harmony import */ var api_version_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! api/version.js */ "./api/version.js");
/* harmony import */ var components_PipelineConfigurations_Store__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! components/PipelineConfigurations/Store */ "./components/PipelineConfigurations/Store/index.js");
/*
 * Copyright © 2020 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
    }

    return t;
  };

  return __assign.apply(this, arguments);
};

var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
    label: 0,
    sent: function sent() {
      if (t[0] & 1) throw t[1];
      return t[1];
    },
    trys: [],
    ops: []
  },
      f,
      y,
      t,
      g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;

  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }

  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");

    while (_) {
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];

        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;

          case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;

          case 7:
            op = _.ops.pop();

            _.trys.pop();

            continue;

          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }

            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }

            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }

            if (t && _.label < t[2]) {
              _.label = t[2];

              _.ops.push(op);

              break;
            }

            if (t[2]) _.ops.pop();

            _.trys.pop();

            continue;
        }

        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    }

    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};





















var styles = function styles(theme) {
  return {
    root: {
      display: 'flex',
      flexDirection: 'column'
    },
    createJobHeader: {
      backgroundColor: theme.palette.grey[700],
      padding: '5px',
      paddingLeft: '20px',
      height: '60px',
      display: 'flex',
      alignItems: 'center'
    },
    selectionContainer: {
      padding: '20px'
    },
    propsRenderBlock: {
      margin: '0 40px',
      width: '40%',
      propsContainer: {
        display: 'flex'
      },
      flexDirection: 'row',
      justifyContent: 'center'
    },
    filterBox: {
      display: 'flex',
      flexDirection: 'column',
      maxWidth: '500px',
      marginBottom: '10px'
    },
    filterInput: {
      marginBottom: '10px'
    },
    jobInfo: {
      display: 'flex',
      flexDirection: 'column',
      margin: '10px'
    },
    instructionHeading: {
      marginTop: '10px'
    },
    modalContent: {
      height: '90%',
      margin: '100px'
    },
    countAndToggle: {
      display: 'flex',
      justifyContent: 'space-between',
      marginBottom: '10px',
      fontSize: '1rem'
    },
    toggleView: {
      color: theme.palette.blue[100],
      cursor: 'pointer'
    },
    configureHeader: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '5px',
      paddingLeft: '20px',
      backgroundColor: theme.palette.grey[700]
    },
    transferDetailsContainer: {
      maxWidth: '500px',
      flexDirection: 'column',
      display: 'flex'
    },
    deployTransferBtn: {
      alignSelf: 'flex-end'
    }
  };
}; // TODO(itsanudeep) : Extract utility functions in the feature and make them reusable.


var IngestionView =
/** @class */
function (_super) {
  __extends(IngestionView, _super);

  function IngestionView() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.state = {
      filterStr: '',
      filteredSources: [],
      batchsource: [],
      batchsink: [],
      selectedSource: null,
      selectedSink: null,
      sourceBP: null,
      sinkBP: null,
      pipelineName: '',
      publishingPipeline: false,
      pipelineDescription: '',
      modalOpen: false,
      tableView: true,
      showConfig: false,
      pipelineNameError: false,
      deployFailed: false,
      cdapVersion: '',
      currentNs: 'default'
    };

    _this.fetchSourceSink = function (version, namespace) {
      _this.fetchPlugins('batchsource', version, namespace);

      _this.fetchPlugins('batchsink', version, namespace);
    };

    _this.fetchPlugins = function (extensionType, version, namespace) {
      if (namespace === void 0) {
        namespace = 'default';
      }

      return __awaiter(_this, void 0, void 0, function () {
        var res, promises;

        var _this = this;

        return __generator(this, function (_a) {
          switch (_a.label) {
            case 0:
              return [4
              /*yield*/
              , api_pipeline__WEBPACK_IMPORTED_MODULE_4__["MyPipelineApi"].fetchPlugins({
                namespace: namespace,
                pipelineType: 'cdap-data-pipeline',
                version: version,
                extensionType: extensionType
              }).toPromise()];

            case 1:
              res = _a.sent();
              promises = res.map(function (plugin) {
                return __awaiter(_this, void 0, void 0, function () {
                  var params, widgetJ, widgetJson, pluginWithWidgetJson;
                  return __generator(this, function (_a) {
                    switch (_a.label) {
                      case 0:
                        params = {
                          namespace: namespace,
                          artifactName: plugin.artifact.name,
                          artifactVersion: plugin.artifact.version,
                          scope: plugin.artifact.scope,
                          keys: "widgets." + plugin.name + "-" + plugin.type
                        };
                        return [4
                        /*yield*/
                        , api_pipeline__WEBPACK_IMPORTED_MODULE_4__["MyPipelineApi"].fetchWidgetJson(params).toPromise()];

                      case 1:
                        widgetJ = _a.sent();
                        widgetJson = JSON.parse(widgetJ["widgets." + plugin.name + "-" + plugin.type]);
                        pluginWithWidgetJson = __assign(__assign({}, plugin), {
                          widgetJson: widgetJson
                        });
                        return [2
                        /*return*/
                        , pluginWithWidgetJson];
                    }
                  });
                });
              }); // TODO(itsanudeep): Refactor to use combineLatest instead of converting to promises.

              Promise.all(promises).then(function (data) {
                var _a;

                _this.setState((_a = {}, _a[extensionType] = data.sort(function (a, b) {
                  var aName = Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_13__["getPluginDisplayName"])(a);
                  var bName = Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_13__["getPluginDisplayName"])(b);
                  return aName.localeCompare(bName, undefined, {
                    sensitivity: 'accent'
                  });
                }), _a), function () {
                  if (extensionType === 'batchsource') {
                    _this.onFilter({
                      target: {
                        value: ''
                      }
                    });
                  }
                });
              });
              return [2
              /*return*/
              ];
          }
        });
      });
    };

    _this.onPluginSelect = function (plugin) {
      var _a;

      var type;

      if (plugin.type === 'batchsource') {
        if ((_this.state.selectedSource && _this.state.selectedSource.name) === plugin.name) {
          return;
        }

        type = 'selectedSource';
      } else if (plugin.type === 'batchsink') {
        if ((_this.state.selectedSink && _this.state.selectedSink.name) === plugin.name) {
          return;
        }

        type = 'selectedSink';
      } else {
        return;
      }

      var label = Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_13__["getPluginDisplayName"])(plugin);

      _this.setState((_a = {}, _a[type] = __assign(__assign({}, plugin), {
        label: label
      }), _a.modalOpen = type === 'selectedSink' ? true : false, _a.showConfig = type === 'selectedSink' ? true : false, _a), function () {
        _this.getPluginProps(plugin);
      });
    };

    _this.onSourceSinkSelect = function (selectedSource, selectedSink) {
      var sourceLabel = Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_13__["getPluginDisplayName"])(selectedSource);
      var sinkLabel = Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_13__["getPluginDisplayName"])(selectedSink);

      _this.setState({
        selectedSink: __assign(__assign({}, selectedSink), {
          label: sinkLabel
        }),
        selectedSource: __assign(__assign({}, selectedSource), {
          label: sourceLabel
        })
      }, function () {
        _this.getPluginProps(selectedSource);

        _this.getPluginProps(selectedSink);

        _this.setState({
          modalOpen: true,
          showConfig: true
        });
      });
    };

    _this.toggleView = function () {
      _this.setState({
        tableView: !_this.state.tableView
      });
    };

    _this.getPluginProps = function (plugin) {
      var pluginParams = {
        namespace: _this.state.currentNs,
        parentArtifact: 'cdap-data-pipeline',
        version: _this.state.cdapVersion,
        extension: plugin.type,
        pluginName: plugin.name,
        scope: 'SYSTEM',
        artifactName: plugin.artifact.name,
        artifactScope: plugin.artifact.scope,
        limit: 1,
        order: 'DESC'
      };
      api_pipeline__WEBPACK_IMPORTED_MODULE_4__["MyPipelineApi"].getPluginProperties(pluginParams).subscribe(function (res) {
        if (plugin.type === 'batchsource') {
          _this.setState({
            sourceBP: res[0]
          });
        } else if (plugin.type === 'batchsink') {
          _this.setState({
            sinkBP: res[0]
          });
        }
      });
    };

    _this.generatePipelineConfig = function () {
      var stages = [];
      var connections = [];

      if (_this.state.selectedSource && _this.state.selectedSink) {
        var sourceName = _this.state.selectedSource.label || Object(services_helpers__WEBPACK_IMPORTED_MODULE_8__["objectQuery"])(_this.state.selectedSource, 'plugin', 'name') || Object(services_helpers__WEBPACK_IMPORTED_MODULE_8__["objectQuery"])(_this.state.selectedSource, 'name');
        var sinkName = _this.state.selectedSink.label || Object(services_helpers__WEBPACK_IMPORTED_MODULE_8__["objectQuery"])(_this.state.selectedSink, 'plugin', 'name') || Object(services_helpers__WEBPACK_IMPORTED_MODULE_8__["objectQuery"])(_this.state.selectedSink, 'name');
        stages = [{
          name: sourceName,
          plugin: {
            name: _this.state.selectedSource.name,
            type: _this.state.selectedSource.type,
            label: _this.state.selectedSource.label,
            artifact: _this.state.selectedSource.artifact,
            properties: _this.state.selectedSource.properties
          }
        }, {
          name: sinkName,
          plugin: {
            name: _this.state.selectedSink.name,
            type: _this.state.selectedSink.type,
            label: _this.state.selectedSink.label,
            artifact: _this.state.selectedSink.artifact,
            properties: _this.state.selectedSink.properties
          }
        }];
        connections = [{
          to: sinkName,
          from: sourceName
        }];
      }

      var _a = components_PipelineConfigurations_Store__WEBPACK_IMPORTED_MODULE_18__["default"].getState(),
          engine = _a.engine,
          driverResources = _a.driverResources,
          resources = _a.resources,
          maxConcurrentRuns = _a.maxConcurrentRuns,
          numOfRecordsPreview = _a.numOfRecordsPreview,
          stageLoggingEnabled = _a.stageLoggingEnabled,
          processTimingEnabled = _a.processTimingEnabled,
          schedule = _a.schedule;

      var configuration = {
        artifact: {
          name: 'cdap-data-pipeline',
          version: _this.state.cdapVersion,
          scope: 'SYSTEM'
        },
        description: _this.state.pipelineDescription,
        name: _this.state.pipelineName,
        label: 'data-ingestion-job',
        config: {
          resources: resources,
          driverResources: driverResources,
          connections: connections,
          properties: {},
          processTimingEnabled: processTimingEnabled,
          stageLoggingEnabled: stageLoggingEnabled,
          stages: stages,
          schedule: schedule,
          engine: engine,
          numOfRecordsPreview: numOfRecordsPreview,
          maxConcurrentRuns: maxConcurrentRuns
        }
      };
      return configuration;
    };

    _this.publishPipeline = function () {
      if (_this.state.pipelineName) {
        _this.setState({
          publishingPipeline: true
        });

        var configuration = _this.generatePipelineConfig();

        api_pipeline__WEBPACK_IMPORTED_MODULE_4__["MyPipelineApi"].publish({
          namespace: _this.state.currentNs,
          appId: configuration.name
        }, configuration).toPromise().then(function () {
          var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_14__["getCurrentNamespace"])();
          window.location.href = "../pipelines/ns/" + namespace + "/view/" + _this.state.pipelineName;

          _this.setState({
            publishingPipeline: false
          });
        })["catch"](function (err) {
          // tslint:disable-next-line: no-console
          console.log('publishing pipeline failed', err);

          _this.setState({
            publishingPipeline: false,
            deployFailed: true
          });
        });
      } else {
        _this.setState({
          pipelineNameError: true
        });
      }
    };

    _this.onFilter = function (event) {
      var value = event.target.value;

      var filteredSources = _this.state.batchsource.filter(function (source) {
        var displayName = Object(components_Ingestion_helpers__WEBPACK_IMPORTED_MODULE_13__["getPluginDisplayName"])(source);
        return displayName && displayName.toLowerCase().includes(value);
      });

      _this.setState({
        filteredSources: filteredSources,
        filterStr: value
      });
    };

    _this.onSourceChange = function (newSource) {
      _this.setState({
        selectedSource: newSource
      });
    };

    _this.onSinkChange = function (newSource) {
      _this.setState({
        selectedSink: newSource
      });
    };

    _this.closeModal = function () {
      _this.setState({
        modalOpen: false,
        showConfig: false,
        pipelineName: '',
        pipelineDescription: ''
      });
    };

    return _this;
  }

  IngestionView.prototype.componentDidMount = function () {
    var _this = this;

    var currentNs = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_14__["getCurrentNamespace"])();
    var cdapVersion = services_VersionStore__WEBPACK_IMPORTED_MODULE_15__["default"].getState().version;

    if (!cdapVersion) {
      api_version_js__WEBPACK_IMPORTED_MODULE_17__["default"].get().subscribe(function (res) {
        cdapVersion = res.version;
        services_VersionStore__WEBPACK_IMPORTED_MODULE_15__["default"].dispatch({
          type: services_VersionStore_VersionActions__WEBPACK_IMPORTED_MODULE_16__["default"].updateVersion,
          payload: {
            version: res.version
          }
        });

        _this.fetchSourceSink(cdapVersion, currentNs);

        _this.setState({
          currentNs: currentNs,
          cdapVersion: cdapVersion
        });
      });
    } else {
      this.fetchSourceSink(cdapVersion, currentNs);
      this.setState({
        currentNs: currentNs,
        cdapVersion: cdapVersion
      });
    }
  };

  IngestionView.prototype.render = function () {
    var _this = this;

    var classes = this.props.classes;
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.root
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react_helmet__WEBPACK_IMPORTED_MODULE_7___default.a, {
      title: 'Ingestion'
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Alert__WEBPACK_IMPORTED_MODULE_12__["default"], {
      showAlert: this.state.deployFailed,
      type: 'error',
      message: 'Failed to deploy transfer job',
      onClose: function onClose() {
        return _this.setState({
          deployFailed: false
        });
      }
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_9__["default"], {
      condition: !this.state.showConfig
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.createJobHeader
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h4", null, "Create a transfer job.")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.selectionContainer
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h4", {
      className: classes.instructionHeading
    }, "Select a source and target for the transfer."), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.filterBox
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["TextField"], {
      className: classes.filterInput,
      variant: "outlined",
      label: "Search by source name",
      margin: "dense",
      value: this.state.filterStr,
      onChange: this.onFilter
    })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.countAndToggle
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null, this.state.filteredSources.length + " sources"), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
      className: classes.toggleView,
      onClick: this.toggleView
    }, "Toggle View")), this.state.tableView ? react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Ingestion_PluginsTableView__WEBPACK_IMPORTED_MODULE_3__["default"], {
      onSourceSinkSelect: this.onSourceSinkSelect,
      plugins: this.state.filteredSources,
      sinks: this.state.batchsink
    }) : react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Ingestion_PluginList__WEBPACK_IMPORTED_MODULE_2__["default"], {
      title: "Sources",
      plugins: this.state.filteredSources,
      onPluginSelect: this.onPluginSelect,
      onSourceSinkSelect: this.onSourceSinkSelect,
      sinks: this.state.batchsink
    })))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_9__["default"], {
      condition: this.state.showConfig
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.configureHeader
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h4", null, "Configure the transfer job."), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_10__["default"], {
      onClick: this.closeModal
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_11___default.a, {
      fontSize: "large"
    }))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.jobInfo
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.transferDetailsContainer
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["TextField"], {
      variant: "outlined",
      label: "Transfer Name",
      margin: "dense",
      required: true,
      error: this.state.pipelineNameError,
      value: this.state.pipelineName,
      onChange: function onChange(event) {
        return _this.setState({
          pipelineName: event.target.value,
          pipelineNameError: false
        });
      }
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["TextField"], {
      variant: "outlined",
      label: "Description",
      margin: "dense",
      value: this.state.pipelineDescription,
      onChange: function onChange(event) {
        return _this.setState({
          pipelineDescription: event.target.value
        });
      }
    })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Button"], {
      className: classes.deployTransferBtn,
      disabled: this.state.publishingPipeline,
      color: "primary",
      variant: "contained",
      onClick: this.publishPipeline
    }, "Deploy Transfer")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Ingestion_SourceSinkConfigurator__WEBPACK_IMPORTED_MODULE_5__["default"], {
      sourceBP: this.state.sourceBP,
      selectedSource: this.state.selectedSource,
      sinkBP: this.state.sinkBP,
      selectedSink: this.state.selectedSink,
      onSourceChange: this.onSourceChange,
      onSinkChange: this.onSinkChange
    })));
  };

  return IngestionView;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

var Ingestion = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(IngestionView);
/* harmony default export */ __webpack_exports__["default"] = (Ingestion);

/***/ }),

/***/ "./components/PipelineConfigurations/PipelineConfigConstants.tsx":
/*!***********************************************************************!*\
  !*** ./components/PipelineConfigurations/PipelineConfigConstants.tsx ***!
  \***********************************************************************/
/*! exports provided: SPARK_EXECUTOR_INSTANCES, DEPRECATED_SPARK_MASTER, SPARK_BACKPRESSURE_ENABLED, ENGINE_OPTIONS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SPARK_EXECUTOR_INSTANCES", function() { return SPARK_EXECUTOR_INSTANCES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEPRECATED_SPARK_MASTER", function() { return DEPRECATED_SPARK_MASTER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SPARK_BACKPRESSURE_ENABLED", function() { return SPARK_BACKPRESSURE_ENABLED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ENGINE_OPTIONS", function() { return ENGINE_OPTIONS; });
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var SPARK_EXECUTOR_INSTANCES = 'system.spark.spark.executor.instances';
var DEPRECATED_SPARK_MASTER = 'system.spark.spark.master';
var SPARK_BACKPRESSURE_ENABLED = 'system.spark.spark.streaming.backpressure.enabled';
var ENGINE_OPTIONS = {
  MAPREDUCE: 'mapreduce',
  SPARK: 'spark'
};


/***/ }),

/***/ "./components/PipelineConfigurations/Store/index.js":
/*!**********************************************************!*\
  !*** ./components/PipelineConfigurations/Store/index.js ***!
  \**********************************************************/
/*! exports provided: default, ACTIONS, BATCH_INTERVAL_RANGE, BATCH_INTERVAL_UNITS, NUM_EXECUTORS_OPTIONS, ENGINE_OPTIONS, DEFAULT_RUNTIME_ARGS, getCustomConfigForDisplay, getEngineDisplayLabel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTIONS", function() { return ACTIONS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BATCH_INTERVAL_RANGE", function() { return BATCH_INTERVAL_RANGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BATCH_INTERVAL_UNITS", function() { return BATCH_INTERVAL_UNITS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NUM_EXECUTORS_OPTIONS", function() { return NUM_EXECUTORS_OPTIONS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_RUNTIME_ARGS", function() { return DEFAULT_RUNTIME_ARGS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCustomConfigForDisplay", function() { return getCustomConfigForDisplay; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getEngineDisplayLabel", function() { return getEngineDisplayLabel; });
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var lodash_range__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/range */ "../../node_modules/lodash/range.js");
/* harmony import */ var lodash_range__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_range__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_KeyValuePairs_KeyValueStoreActions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/KeyValuePairs/KeyValueStoreActions */ "./components/KeyValuePairs/KeyValueStoreActions.js");
/* harmony import */ var components_KeyValuePairs_KeyValueStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/KeyValuePairs/KeyValueStore */ "./components/KeyValuePairs/KeyValueStore.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash/cloneDeep */ "../../node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var components_PipelineConfigurations_PipelineConfigConstants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/PipelineConfigurations/PipelineConfigConstants */ "./components/PipelineConfigurations/PipelineConfigConstants.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ENGINE_OPTIONS", function() { return components_PipelineConfigurations_PipelineConfigConstants__WEBPACK_IMPORTED_MODULE_8__["ENGINE_OPTIONS"]; });

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

/*
  This store represents the state of the Pipeline Configure modeless.

  In Studio view, all the configs will have default values, while in Detail view
  this store is initialized using values from the pipeline json/PipelineDetailStore

  When the user makes a change inside the modeless and clicks Save, then we dispatch
  an action in PipelineConfigurations component to save the new configs to config-store.js
  (in Studio view) or to PipelineDetailStore (in Detail view)
*/










var ACTIONS = {
  INITIALIZE_CONFIG: 'INITIALIZE_CONFIG',
  SET_RUNTIME_ARGS: 'SET_RUNTIME_ARGS',
  SET_RESOLVED_MACROS: 'SET_RESOLVED_MACROS',
  RESET_RUNTIME_ARG_TO_RESOLVED_VALUE: 'RESET_RUNTIME_ARG_TO_RESOLVED_VALUE',
  SET_ENGINE: 'SET_ENGINE',
  SET_BATCH_INTERVAL_RANGE: 'SET_BATCH_INTERVAL_RANGE',
  SET_BATCH_INTERVAL_UNIT: 'SET_BATCH_INTERVAL_UNIT',
  SET_MEMORY_MB: 'SET_MEMORY_MB',
  SET_MEMORY_VIRTUAL_CORES: 'SET_MEMORY_VIRTUAL_CORES',
  SET_DRIVER_MEMORY_MB: 'SET_DRIVER_MEMORY_MB',
  SET_DRIVER_VIRTUAL_CORES: 'SET_DRIVER_VIRTUAL_CORES',
  SET_CLIENT_MEMORY_MB: 'SET_CLIENT_MEMORY_MB',
  SET_CLIENT_VIRTUAL_CORES: 'SET_CLIENT_VIRTUAL_CORES',
  SET_BACKPRESSURE: 'SET_BACKPRESSURE',
  SET_CUSTOM_CONFIG: 'SET_CUSTOM_CONFIG',
  SET_CUSTOM_CONFIG_KEY_VALUE_PAIRS: 'SET_CUSTOM_CONFIG_KEY_VALUE_PAIRS',
  SET_NUM_EXECUTORS: 'SET_NUM_EXECUTORS',
  SET_INSTRUMENTATION: 'SET_INSTRUMENTATION',
  SET_STAGE_LOGGING: 'SET_STAGE_LOGGING',
  SET_CHECKPOINTING: 'SET_CHECKPOINTING',
  SET_CHECKPOINT_DIR: 'SET_CHECKPOINT_DIR',
  SET_NUM_RECORDS_PREVIEW: 'SET_NUM_RECORDS_PREVIEW',
  SET_MODELESS_OPEN_STATUS: 'SET_MODELESS_OPEN_STATUS',
  SET_PIPELINE_VISUAL_CONFIGURATION: 'SET_PIPELINE_VISUAL_CONFIGURATION',
  SET_SERVICE_ACCOUNT_PATH: 'SET_SERVICE_ACCOUNT_PATH',
  RESET: 'RESET'
};
var BATCH_INTERVAL_RANGE = lodash_range__WEBPACK_IMPORTED_MODULE_3___default()(1, 61);
var BATCH_INTERVAL_UNITS = [{
  id: 's',
  value: 'Seconds'
}, {
  id: 'm',
  value: 'Minutes'
}];
var NUM_EXECUTORS_OPTIONS = lodash_range__WEBPACK_IMPORTED_MODULE_3___default()(1, 11);
var DEFAULT_RUNTIME_ARGS = {
  pairs: [Object(components_KeyValuePairs_KeyValueStore__WEBPACK_IMPORTED_MODULE_5__["getDefaultKeyValuePair"])()]
};
var DEFAULT_CONFIGURE_OPTIONS = {
  runtimeArgs: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7___default()(DEFAULT_RUNTIME_ARGS),
  resolvedMacros: {},
  customConfigKeyValuePairs: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7___default()(DEFAULT_RUNTIME_ARGS),
  postRunActions: [],
  properties: {},
  engine: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].engine,
  resources: _objectSpread({}, services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].resources),
  driverResources: _objectSpread({}, services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].resources),
  clientResources: _objectSpread({}, services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].resources),
  processTimingEnabled: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].processTimingEnabled,
  stageLoggingEnabled: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].stageLoggingEnabled,
  disableCheckpoints: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].disableCheckpoints,
  checkpointDir: window.CDAP_CONFIG.hydrator.defaultCheckpointDir,
  stopGracefully: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].stopGracefully,
  backpressure: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].backpressure,
  numExecutors: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].numExecutors,
  numOfRecordsPreview: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].numOfRecordsPreview,
  previewTimeoutInMin: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].previewTimeoutInMin,
  batchInterval: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].batchInterval,
  postActions: [],
  schedule: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["HYDRATOR_DEFAULT_VALUES"].schedule,
  maxConcurrentRuns: 1,
  isMissingKeyValues: false,
  modelessOpen: false,
  pipelineVisualConfiguration: {
    pipelineType: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["GLOBALS"].etlDataPipeline,
    isHistoricalRun: false,
    isPreview: false,
    isDetailView: false
  }
};

var getCustomConfigFromProperties = function getCustomConfigFromProperties() {
  var properties = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var pipelineType = arguments.length > 1 ? arguments[1] : undefined;
  var backendProperties = [components_PipelineConfigurations_PipelineConfigConstants__WEBPACK_IMPORTED_MODULE_8__["SPARK_BACKPRESSURE_ENABLED"], components_PipelineConfigurations_PipelineConfigConstants__WEBPACK_IMPORTED_MODULE_8__["SPARK_EXECUTOR_INSTANCES"]];

  if (services_global_constants__WEBPACK_IMPORTED_MODULE_2__["GLOBALS"].etlBatchPipelines.includes(pipelineType)) {
    backendProperties = [];
  }

  var customConfig = {};
  Object.keys(properties).forEach(function (key) {
    if (backendProperties.indexOf(key) === -1) {
      customConfig[key] = properties[key];
    }
  });
  return customConfig;
};

var getCustomConfigForDisplay = function getCustomConfigForDisplay(properties, engine, pipelineType) {
  var currentCustomConfig = getCustomConfigFromProperties(properties, pipelineType);
  var customConfigForDisplay = {};

  for (var key in currentCustomConfig) {
    if (Object.prototype.hasOwnProperty.call(currentCustomConfig, key)) {
      var newKey = key;
      var mapReduceKey = 'system.mapreduce.';
      var sparkKey = 'system.spark.';

      if (engine === 'mapreduce' && key.startsWith(mapReduceKey)) {
        newKey = newKey.slice(mapReduceKey.length);
      } else if (key.startsWith(sparkKey)) {
        newKey = newKey.slice(sparkKey.length);
      }

      customConfigForDisplay[newKey] = currentCustomConfig[key];
    }
  }

  return Object(components_KeyValuePairs_KeyValueStoreActions__WEBPACK_IMPORTED_MODULE_4__["convertMapToKeyValuePairsObj"])(customConfigForDisplay);
};

var getEngineDisplayLabel = function getEngineDisplayLabel(engine, pipelineType) {
  return engine === components_PipelineConfigurations_PipelineConfigConstants__WEBPACK_IMPORTED_MODULE_8__["ENGINE_OPTIONS"].MAPREDUCE && services_global_constants__WEBPACK_IMPORTED_MODULE_2__["GLOBALS"].etlBatchPipelines.includes(pipelineType) ? 'MapReduce' : 'Apache Spark';
};

var checkForReset = function checkForReset(runtimeArgs, resolvedMacros) {
  var runtimeArgsPairs = runtimeArgs.pairs;
  runtimeArgsPairs.forEach(function (runtimeArg) {
    if (!runtimeArg.notDeletable) {
      return;
    }

    if (runtimeArg.provided) {
      runtimeArg.showReset = false;
    } else {
      var runtimeArgKey = runtimeArg.key;

      if (Object.prototype.hasOwnProperty.call(resolvedMacros, runtimeArgKey)) {
        if (resolvedMacros[runtimeArgKey] !== runtimeArg.value) {
          runtimeArg.showReset = true;
        } else {
          runtimeArg.showReset = false;
        }
      }
    }
  });
  return getRuntimeArgsForDisplay(runtimeArgs, resolvedMacros);
};

var resetRuntimeArgToResolvedValue = function resetRuntimeArgToResolvedValue(index, runtimeArgs, resolvedMacros) {
  var runtimeArgKey = runtimeArgs.pairs[index].key;
  runtimeArgs.pairs[index].value = resolvedMacros[runtimeArgKey];
  return runtimeArgs;
};

var getRuntimeArgsForDisplay = function getRuntimeArgsForDisplay(currentRuntimeArgs, macrosMap) {
  var providedMacros = {};
  var runtimeArgsMap = {}; // holds provided macros in an object here even though we don't need the value,
  // because object hash is faster than Array.indexOf

  if (currentRuntimeArgs.pairs) {
    currentRuntimeArgs.pairs.forEach(function (currentPair) {
      var key = currentPair.key;
      runtimeArgsMap[key] = currentPair.value || '';

      if (currentPair.notDeletable && currentPair.provided) {
        providedMacros[key] = currentPair.value;
      }
    });
    currentRuntimeArgs.pairs = currentRuntimeArgs.pairs.filter(function (keyValuePair) {
      return Object.keys(macrosMap).indexOf(keyValuePair.key) === -1;
    });
  }

  var macros = Object.keys(macrosMap).map(function (macroKey) {
    return {
      key: macroKey,
      value: runtimeArgsMap[macroKey] || '',
      showReset: macrosMap[macroKey].showReset,
      uniqueId: 'id-' + uuid_v4__WEBPACK_IMPORTED_MODULE_6___default()(),
      notDeletable: true,
      provided: Object.prototype.hasOwnProperty.call(providedMacros, macroKey)
    };
  });
  currentRuntimeArgs.pairs = macros.concat(currentRuntimeArgs.pairs);
  return currentRuntimeArgs;
};

var checkIfMissingKeyValues = function checkIfMissingKeyValues(runtimeArguments, customConfig) {
  return Object(components_KeyValuePairs_KeyValueStoreActions__WEBPACK_IMPORTED_MODULE_4__["keyValuePairsHaveMissingValues"])(runtimeArguments) || Object(components_KeyValuePairs_KeyValueStoreActions__WEBPACK_IMPORTED_MODULE_4__["keyValuePairsHaveMissingValues"])(customConfig);
};

var configure = function configure() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_CONFIGURE_OPTIONS;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_0__["defaultAction"];

  switch (action.type) {
    case ACTIONS.INITIALIZE_CONFIG:
      return _objectSpread({}, state, {}, action.payload, {
        customConfigKeyValuePairs: getCustomConfigForDisplay(action.payload.properties, action.payload.engine, state.pipelineVisualConfiguration.pipelineType)
      });

    case ACTIONS.SET_RUNTIME_ARGS:
      return _objectSpread({}, state, {
        runtimeArgs: checkForReset(action.payload.runtimeArgs, state.resolvedMacros),
        isMissingKeyValues: checkIfMissingKeyValues(action.payload.runtimeArgs, state.customConfigKeyValuePairs)
      });

    case ACTIONS.SET_RESOLVED_MACROS:
      {
        var resolvedMacros = action.payload.resolvedMacros;
        var runtimeArgs = getRuntimeArgsForDisplay(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7___default()(state.runtimeArgs), resolvedMacros);
        var isMissingKeyValues = checkIfMissingKeyValues(runtimeArgs, state.customConfigKeyValuePairs);
        return _objectSpread({}, state, {
          resolvedMacros: resolvedMacros,
          runtimeArgs: runtimeArgs,
          isMissingKeyValues: isMissingKeyValues
        });
      }

    case ACTIONS.RESET_RUNTIME_ARG_TO_RESOLVED_VALUE:
      return _objectSpread({}, state, {
        runtimeArgs: resetRuntimeArgToResolvedValue(action.payload.index, _objectSpread({}, state.runtimeArgs), state.resolvedMacros)
      });

    case ACTIONS.SET_ENGINE:
      return _objectSpread({}, state, {
        engine: action.payload.engine
      });

    case ACTIONS.SET_BATCH_INTERVAL_RANGE:
      return _objectSpread({}, state, {
        batchInterval: action.payload.batchIntervalRange + state.batchInterval.slice(-1)
      });

    case ACTIONS.SET_BATCH_INTERVAL_UNIT:
      return _objectSpread({}, state, {
        batchInterval: state.batchInterval.slice(0, -1) + action.payload.batchIntervalUnit
      });

    case ACTIONS.SET_MEMORY_MB:
      return _objectSpread({}, state, {
        resources: _objectSpread({}, state.resources, {
          memoryMB: action.payload.memoryMB
        })
      });

    case ACTIONS.SET_MEMORY_VIRTUAL_CORES:
      return _objectSpread({}, state, {
        resources: _objectSpread({}, state.resources, {
          virtualCores: action.payload.virtualCores
        })
      });

    case ACTIONS.SET_DRIVER_MEMORY_MB:
      return _objectSpread({}, state, {
        driverResources: _objectSpread({}, state.driverResources, {
          memoryMB: action.payload.memoryMB
        })
      });

    case ACTIONS.SET_DRIVER_VIRTUAL_CORES:
      return _objectSpread({}, state, {
        driverResources: _objectSpread({}, state.driverResources, {
          virtualCores: action.payload.virtualCores
        })
      });

    case ACTIONS.SET_CLIENT_MEMORY_MB:
      return _objectSpread({}, state, {
        clientResources: _objectSpread({}, state.clientResources, {
          memoryMB: action.payload.memoryMB
        })
      });

    case ACTIONS.SET_CLIENT_VIRTUAL_CORES:
      return _objectSpread({}, state, {
        clientResources: _objectSpread({}, state.clientResources, {
          virtualCores: action.payload.virtualCores
        })
      });

    case ACTIONS.SET_BACKPRESSURE:
      return _objectSpread({}, state, {
        properties: _objectSpread({}, state.properties, {
          'system.spark.spark.streaming.backpressure.enabled': action.payload.backpressure
        })
      });

    case ACTIONS.SET_CUSTOM_CONFIG_KEY_VALUE_PAIRS:
      return _objectSpread({}, state, {
        customConfigKeyValuePairs: action.payload.keyValues,
        isMissingKeyValues: checkIfMissingKeyValues(state.runtimeArgs, action.payload.keyValues)
      });

    case ACTIONS.SET_CUSTOM_CONFIG:
      {
        // Need to remove previous custom configs from config.properties before setting new ones
        var currentProperties = _objectSpread({}, state.properties);

        var currentCustomConfigs = getCustomConfigFromProperties(currentProperties);
        Object.keys(currentCustomConfigs).forEach(function (customConfigKey) {
          if (Object.prototype.hasOwnProperty.call(currentProperties, customConfigKey)) {
            delete currentProperties[customConfigKey];
          }
        }); // Need to add system.mapreduce or system.spark to beginning of the keys that the user added

        var newCustomConfigs = {};
        Object.keys(action.payload.customConfig).forEach(function (newCustomConfigKey) {
          var newCustomConfigValue = action.payload.customConfig[newCustomConfigKey];

          if (services_global_constants__WEBPACK_IMPORTED_MODULE_2__["GLOBALS"].etlBatchPipelines.includes(action.payload.pipelineType) && state.engine === components_PipelineConfigurations_PipelineConfigConstants__WEBPACK_IMPORTED_MODULE_8__["ENGINE_OPTIONS"].MAPREDUCE) {
            newCustomConfigKey = 'system.mapreduce.' + newCustomConfigKey;
          } else {
            newCustomConfigKey = 'system.spark.' + newCustomConfigKey;
          }

          newCustomConfigs[newCustomConfigKey] = newCustomConfigValue;
        });
        return _objectSpread({}, state, {
          properties: _objectSpread({}, currentProperties, {}, newCustomConfigs)
        });
      }

    case ACTIONS.SET_NUM_EXECUTORS:
      {
        var numExecutorsValue = action.payload.numExecutors;
        return _objectSpread({}, state, {
          properties: _objectSpread({}, state.properties, _defineProperty({}, components_PipelineConfigurations_PipelineConfigConstants__WEBPACK_IMPORTED_MODULE_8__["SPARK_EXECUTOR_INSTANCES"], numExecutorsValue))
        });
      }

    case ACTIONS.SET_INSTRUMENTATION:
      return _objectSpread({}, state, {
        processTimingEnabled: action.payload.instrumentation
      });

    case ACTIONS.SET_STAGE_LOGGING:
      return _objectSpread({}, state, {
        stageLoggingEnabled: action.payload.stageLogging
      });

    case ACTIONS.SET_CHECKPOINTING:
      return _objectSpread({}, state, {
        disableCheckpoints: action.payload.disableCheckpoints
      });

    case ACTIONS.SET_CHECKPOINT_DIR:
      return _objectSpread({}, state, {
        checkpointDir: action.payload.checkpointDir
      });

    case ACTIONS.SET_NUM_RECORDS_PREVIEW:
      return _objectSpread({}, state, {
        numOfRecordsPreview: action.payload.numRecordsPreview
      });

    case ACTIONS.SET_MODELESS_OPEN_STATUS:
      return _objectSpread({}, state, {
        modelessOpen: action.payload.open
      });

    case ACTIONS.SET_SERVICE_ACCOUNT_PATH:
      return _objectSpread({}, state, {
        serviceAccountPath: action.payload.serviceAccountPath
      });

    case ACTIONS.RESET:
      return lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7___default()(DEFAULT_CONFIGURE_OPTIONS);

    case ACTIONS.SET_PIPELINE_VISUAL_CONFIGURATION:
      return _objectSpread({}, state, {
        pipelineVisualConfiguration: _objectSpread({}, state.pipelineVisualConfiguration, {}, action.payload.pipelineVisualConfiguration)
      });

    default:
      return state;
  }
};

var PipelineConfigurationsStore = Object(redux__WEBPACK_IMPORTED_MODULE_1__["createStore"])(configure, lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7___default()(DEFAULT_CONFIGURE_OPTIONS), Object(services_helpers__WEBPACK_IMPORTED_MODULE_0__["composeEnhancers"])('PipelineConfigurationsStore')());
/* harmony default export */ __webpack_exports__["default"] = (PipelineConfigurationsStore);


/***/ })

}]);
//# sourceMappingURL=1.54114ccc698058af23d9.js.map