(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["AddToPipelineModal"],{

/***/ "../../node_modules/lodash/isString.js":
/*!*************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/isString.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(/*! ./_baseGetTag */ "../../node_modules/lodash/_baseGetTag.js"),
    isArray = __webpack_require__(/*! ./isArray */ "../../node_modules/lodash/isArray.js"),
    isObjectLike = __webpack_require__(/*! ./isObjectLike */ "../../node_modules/lodash/isObjectLike.js");

/** `Object#toString` result references. */
var stringTag = '[object String]';

/**
 * Checks if `value` is classified as a `String` primitive or object.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a string, else `false`.
 * @example
 *
 * _.isString('abc');
 * // => true
 *
 * _.isString(1);
 * // => false
 */
function isString(value) {
  return typeof value == 'string' ||
    (!isArray(value) && isObjectLike(value) && baseGetTag(value) == stringTag);
}

module.exports = isString;


/***/ }),

/***/ "./components/DataPrep/TopPanel/AddToPipelineModal.js":
/*!************************************************************!*\
  !*** ./components/DataPrep/TopPanel/AddToPipelineModal.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AddToHydratorModal; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var components_DataPrep_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/DataPrep/store */ "./components/DataPrep/store/index.js");
/* harmony import */ var components_DataPrep_store_DataPrepActions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/DataPrep/store/DataPrepActions */ "./components/DataPrep/store/DataPrepActions.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var components_DataPrep_store_DataPrepActionCreator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/DataPrep/store/DataPrepActionCreator */ "./components/DataPrep/store/DataPrepActionCreator.js");
/* harmony import */ var components_CardActionFeedback__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/CardActionFeedback */ "./components/CardActionFeedback/index.js");
/* harmony import */ var components_DataPrep_TopPanel_PipelineConfigHelper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/DataPrep/TopPanel/PipelineConfigHelper */ "./components/DataPrep/TopPanel/PipelineConfigHelper.js");
/* harmony import */ var lodash_isString__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! lodash/isString */ "../../node_modules/lodash/isString.js");
/* harmony import */ var lodash_isString__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(lodash_isString__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
















var mapErrorToMessage = function mapErrorToMessage(message) {
  if (message.indexOf('invalid field name') !== -1) {
    var splitMessage = message.split('field name: ');
    var fieldName = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(splitMessage, 1) || message;
    return {
      message: i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".invalidFieldNameMessage"), {
        fieldName: fieldName
      }),
      remedies: "".concat(i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".invalidFieldNameRemedies1")))
    };
  }

  return {
    message: message
  };
};

var PREFIX = 'features.DataPrep.TopPanel';

var AddToHydratorModal =
/*#__PURE__*/
function (_Component) {
  _inherits(AddToHydratorModal, _Component);

  function AddToHydratorModal(props) {
    var _this;

    _classCallCheck(this, AddToHydratorModal);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(AddToHydratorModal).call(this, props));
    _this.state = {
      loading: true,
      batchUrl: null,
      realtimeUrl: null,
      error: null,
      workspaceId: null,
      realtimeConfig: null,
      batchConfig: null
    };
    return _this;
  }

  _createClass(AddToHydratorModal, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      this.generateLinks();
    }
  }, {
    key: "generateLinks",
    value: function generateLinks() {
      var _this2 = this;

      var state = components_DataPrep_store__WEBPACK_IMPORTED_MODULE_3__["default"].getState().dataprep;
      var workspaceId = state.workspaceId;
      var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__["getCurrentNamespace"])();
      Object(components_DataPrep_TopPanel_PipelineConfigHelper__WEBPACK_IMPORTED_MODULE_11__["default"])().subscribe(function (res) {
        var realtimeUrl;

        if (!res.realtimeConfig) {
          realtimeUrl = null;
        } else {
          realtimeUrl = window.getHydratorUrl({
            stateName: 'hydrator.create',
            stateParams: {
              namespace: namespace,
              workspaceId: workspaceId,
              artifactType: 'cdap-data-streams'
            }
          });
        }

        var batchUrl = window.getHydratorUrl({
          stateName: 'hydrator.create',
          stateParams: {
            namespace: namespace,
            workspaceId: workspaceId,
            artifactType: 'cdap-data-pipeline'
          }
        });

        _this2.setState({
          loading: false,
          realtimeUrl: realtimeUrl,
          batchUrl: batchUrl,
          workspaceId: workspaceId,
          realtimeConfig: res.realtimeConfig,
          batchConfig: res.batchConfig
        });
      }, function (err) {
        var _mapErrorToMessage = mapErrorToMessage(err),
            message = _mapErrorToMessage.message,
            _mapErrorToMessage$re = _mapErrorToMessage.remedies,
            remedies = _mapErrorToMessage$re === void 0 ? null : _mapErrorToMessage$re;

        if (remedies) {
          _this2.setState({
            error: {
              message: message,
              remedies: remedies
            },
            loading: false
          });

          return;
        }

        _this2.setState({
          error: err,
          loading: false
        });
      });
    }
  }, {
    key: "applyDirective",
    value: function applyDirective(directive) {
      var _this3 = this;

      Object(components_DataPrep_store_DataPrepActionCreator__WEBPACK_IMPORTED_MODULE_9__["execute"])([directive]).subscribe(function () {
        _this3.setState({
          error: null,
          loading: true,
          schema: []
        }, function () {
          _this3.generateLinks();
        });
      }, function (err) {
        console.log('Error', err);
        components_DataPrep_store__WEBPACK_IMPORTED_MODULE_3__["default"].dispatch({
          type: components_DataPrep_store_DataPrepActions__WEBPACK_IMPORTED_MODULE_4__["default"].setError,
          payload: {
            message: err.message || err.response.message
          }
        });
      });
    }
  }, {
    key: "renderInvalidFieldError",
    value: function renderInvalidFieldError() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "message"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("pre", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "remedy-message"
      }, Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(this.state, 'error', 'remedies') ? this.state.error.remedies : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".invalidFieldNameRemedies2")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "btn-link",
        onClick: this.applyDirective.bind(this, 'cleanse-column-names')
      }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".cleanseLinkLabel"))), i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".invalidFieldNameRemedies3")))));
    }
  }, {
    key: "render",
    value: function render() {
      var _this4 = this;

      var disableRealtime = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_14__["Theme"].showRealtimePipeline === false;
      var content;

      if (this.state.loading) {
        content = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "loading-container"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h4", {
          className: "text-center"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "fa fa-spin fa-spinner"
        })));
      } else {
        var realtimeDisabledTooltip;
        var type = components_DataPrep_store__WEBPACK_IMPORTED_MODULE_3__["default"].getState().dataprep.workspaceInfo.properties.connection;

        if (!this.state.realtimeUrl) {
          realtimeDisabledTooltip = i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".realtimeDisabledTooltip"), {
            type: i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".").concat(type))
          });
        }

        var realtimeUrl = disableRealtime ? null : this.state.realtimeUrl;
        content = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "message"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".addToPipelineModal.title"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "action-buttons"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
          href: this.state.error ? null : this.state.batchUrl,
          className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('btn btn-secondary', {
            inactive: this.state.error
          }),
          onClick: function () {
            if (_this4.state.error) {
              return;
            }

            window.localStorage.setItem(_this4.state.workspaceId, JSON.stringify(_this4.state.batchConfig));
          }.bind(this)
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
          className: "fa icon-ETLBatch"
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".addToPipelineModal.batchPipelineBtn")))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
          href: realtimeUrl,
          className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('btn btn-secondary', {
            inactive: !this.state.realtimeUrl || this.state.error || disableRealtime
          }),
          onClick: function () {
            if (!_this4.state.realtimeUrl || disableRealtime) {
              return;
            }

            window.localStorage.setItem(_this4.state.workspaceId, JSON.stringify(_this4.state.realtimeConfig));
          }.bind(this),
          title: realtimeDisabledTooltip
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
          className: "fa icon-sparkstreaming"
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".addToPipelineModal.realtimePipelineBtn"))))));
      }

      var showContent = !Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(this.state, 'error', 'remedies');
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Modal"], {
        isOpen: true,
        toggle: this.props.toggle,
        size: "lg",
        className: "add-to-pipeline-dataprep-modal cdap-modal"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalHeader"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".addToPipelineBtnLabel"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "close-section float-right",
        onClick: this.props.toggle
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-times"
      }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalBody"], null, showContent ? content : this.renderInvalidFieldError()), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_13__["default"], {
        condition: this.state.error
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_CardActionFeedback__WEBPACK_IMPORTED_MODULE_10__["default"], {
        type: "DANGER",
        message: i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".addToPipelineModal.errorTitle")),
        extendedMessage: lodash_isString__WEBPACK_IMPORTED_MODULE_12___default()(this.state.error) ? this.state.error : null
      })));
    }
  }]);

  return AddToHydratorModal;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


AddToHydratorModal.propTypes = {
  toggle: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/***/ }),

/***/ "./components/DataPrep/TopPanel/PipelineConfigHelper.js":
/*!**************************************************************!*\
  !*** ./components/DataPrep/TopPanel/PipelineConfigHelper.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return getPipelineConfig; });
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_dataprep__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! api/dataprep */ "./api/dataprep.js");
/* harmony import */ var components_DataPrep_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/DataPrep/store */ "./components/DataPrep/store/index.js");
/* harmony import */ var components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/DataPrep/helper */ "./components/DataPrep/helper.js");
/* harmony import */ var api_artifact__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! api/artifact */ "./api/artifact.js");
/* harmony import */ var components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/SchemaEditor/SchemaHelpers */ "./components/SchemaEditor/SchemaHelpers.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_VersionRange_VersionUtilities__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/VersionRange/VersionUtilities */ "./services/VersionRange/VersionUtilities.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var rxjs_Subject__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/Subject */ "../../node_modules/rxjs/Subject.js");
/* harmony import */ var rxjs_Subject__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(rxjs_Subject__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var lodash_find__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash/find */ "../../node_modules/lodash/find.js");
/* harmony import */ var lodash_find__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(lodash_find__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */












var PREFIX = 'features.DataPrep.PipelineError';
function getPipelineConfig() {
  var workspaceInfo = components_DataPrep_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().dataprep.workspaceInfo;
  return api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getInfo().mergeMap(function (res) {
    if (res.statusCode === 404) {
      console.log("can't find method; use latest wrangler-transform");
      return constructProperties(workspaceInfo);
    }

    var pluginVersion = res.values[0]['plugin.version'];
    return constructProperties(workspaceInfo, pluginVersion);
  });
}

function findWranglerArtifacts(artifacts, pluginVersion) {
  var wranglerArtifacts = artifacts.filter(function (artifact) {
    if (pluginVersion) {
      return artifact.name === 'wrangler-transform' && artifact.version === pluginVersion;
    }

    return artifact.name === 'wrangler-transform';
  });

  if (wranglerArtifacts.length === 0) {
    // cannot find plugin. Error out
    throw i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".missingWranglerPlugin"));
  }

  var filteredArtifacts = wranglerArtifacts;

  if (!pluginVersion) {
    var highestVersion = Object(services_VersionRange_VersionUtilities__WEBPACK_IMPORTED_MODULE_7__["findHighestVersion"])(wranglerArtifacts.map(function (artifact) {
      return artifact.version;
    }), true);
    filteredArtifacts = wranglerArtifacts.filter(function (artifact) {
      return artifact.version === highestVersion;
    });
  }

  var returnArtifact = filteredArtifacts[0];

  if (filteredArtifacts.length > 1) {
    returnArtifact.scope = services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SCOPES"].USER;
  }

  return returnArtifact;
}

function constructFileSource(artifactsList, properties) {
  if (!properties) {
    return null;
  }

  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(properties, 'values', '0');
  var pluginName = Object.keys(plugin)[0];
  plugin = plugin[pluginName];
  var batchArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'core-plugins'
  });
  var realtimeArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'spark-plugins'
  });

  if (!batchArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".fileBatch"));
  }

  if (!realtimeArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".fileRealtime"));
  }

  batchArtifact.version = '[1.7.0, 3.0.0)';
  realtimeArtifact.version = '[1.7.0, 3.0.0)';
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: batchArtifact,
    properties: plugin.properties
  };
  var realtimePluginInfo = Object.assign({}, batchPluginInfo, {
    type: 'streamingsource',
    artifact: realtimeArtifact
  });
  var batchStage = {
    name: 'File',
    plugin: batchPluginInfo
  };
  var realtimeStage = {
    name: 'File',
    plugin: realtimePluginInfo
  };
  return {
    batchSource: batchStage,
    realtimeSource: realtimeStage,
    connections: [{
      from: 'File',
      to: 'Wrangler'
    }]
  };
} // Need to be modified once backend is complete


function constructDatabaseSource(artifactsList, dbInfo) {
  if (!dbInfo) {
    return null;
  }

  var batchArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'database-plugins'
  });

  if (!batchArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".database"));
  }

  batchArtifact.version = '[1.7.0, 3.0.0)';
  var pluginName = 'Database';

  try {
    var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(dbInfo, 'values', 0, 'Database');
    var pluginInfo = {
      name: 'Database',
      label: plugin.name,
      type: 'batchsource',
      artifact: batchArtifact,
      properties: plugin.properties
    };
    var batchStage = {
      name: pluginName,
      plugin: pluginInfo
    };
    return {
      batchSource: batchStage,
      connections: [{
        from: pluginName,
        to: 'Wrangler'
      }]
    };
  } catch (e) {
    console.log('properties parse error', e);
  }
}

function constructKafkaSource(artifactsList, kafkaInfo) {
  if (!kafkaInfo) {
    return null;
  }

  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(kafkaInfo, 'values', '0');
  var pluginName = Object.keys(plugin)[0]; // This is a hack.. should not do this
  // We are still shipping kafka-plugins with hydrator-plugins 1.7 but
  // it doesn't contain the streamingsource or batchsource plugins

  var pluginArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'kafka-plugins'
  });

  if (!pluginArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".kafka"));
  }

  plugin = plugin[pluginName];
  plugin.properties.schema = JSON.stringify({
    name: 'kafkaAvroSchema',
    type: 'record',
    fields: [{
      name: 'body',
      type: 'string'
    }]
  });
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: pluginArtifact,
    properties: plugin.properties
  };
  var realtimePluginInfo = Object.assign({}, batchPluginInfo, {
    type: 'streamingsource',
    artifact: pluginArtifact
  });
  var batchStage = {
    name: plugin.name,
    plugin: batchPluginInfo
  };
  var realtimeStage = {
    name: plugin.name,
    plugin: realtimePluginInfo
  };
  return {
    batchSource: batchStage,
    realtimeSource: realtimeStage,
    connections: [{
      from: plugin.name,
      to: 'Wrangler'
    }]
  };
}

function constructS3Source(artifactsList, s3Info) {
  if (!s3Info) {
    return null;
  }

  var batchArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'amazon-s3-plugins'
  });

  if (!batchArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".s3"));
  }

  batchArtifact.version = '[1.7.0, 3.0.0)';
  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(s3Info, 'values', 0, 'S3');
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: batchArtifact,
    properties: _objectSpread({}, plugin.properties, {
      referenceName: plugin.name
    })
  };
  var batchStage = {
    name: 'S3',
    plugin: batchPluginInfo
  };
  return {
    batchSource: batchStage,
    connections: [{
      from: 'S3',
      to: 'Wrangler'
    }]
  };
}

function constructGCSSource(artifactsList, gcsInfo) {
  if (!gcsInfo) {
    return null;
  }

  var batchArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'google-cloud'
  });

  if (!batchArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".gcs"));
  }

  batchArtifact.version = '[0.9.0, 3.0.0)';
  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(gcsInfo, 'values', 0);
  var pluginName = Object.keys(plugin)[0]; // this is because the plugin can be GCSFile or GCSFileBlob

  plugin = plugin[pluginName];
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: batchArtifact,
    properties: plugin.properties
  };
  var batchStage = {
    name: 'GCS',
    plugin: batchPluginInfo
  };
  return {
    batchSource: batchStage,
    connections: [{
      from: 'GCS',
      to: 'Wrangler'
    }]
  };
}

function constructBigQuerySource(artifactsList, bigqueryInfo) {
  if (!bigqueryInfo) {
    return null;
  }

  var batchArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'google-cloud'
  });

  if (!batchArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".bigquery"));
  }

  batchArtifact.version = '[0.9.2, 3.0.0)';
  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(bigqueryInfo, 'values', 0);
  var pluginName = Object.keys(plugin)[0];
  plugin = plugin[pluginName];
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: batchArtifact,
    properties: plugin.properties
  };
  var batchStage = {
    name: 'BigQueryTable',
    plugin: batchPluginInfo
  };
  return {
    batchSource: batchStage,
    connections: [{
      from: 'BigQueryTable',
      to: 'Wrangler'
    }]
  };
}

function constructSpannerSource(artifactsList, spannerInfo) {
  if (!spannerInfo) {
    return null;
  }

  var googleCloudArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'google-cloud'
  });

  if (!googleCloudArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".spanner"));
  }

  googleCloudArtifact.version = '[0.11.0-SNAPSHOT, 3.0.0)';
  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(spannerInfo, 'values', 0);
  var pluginName = Object.keys(plugin)[0];
  plugin = plugin[pluginName];
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: googleCloudArtifact,
    properties: plugin.properties
  };
  var batchStage = {
    name: 'SpannerTable',
    plugin: batchPluginInfo
  };
  return {
    batchSource: batchStage,
    connections: [{
      from: 'SpannerTable',
      to: 'Wrangler'
    }]
  };
}

function constructAdlsSource(artifactsList, adlsInfo) {
  if (!adlsInfo) {
    return null;
  }

  var batchArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'adls-plugins'
  });

  if (!batchArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".adls"));
  }

  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(adlsInfo, 'values', 0);
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: batchArtifact,
    properties: plugin.properties
  };
  var batchStage = {
    name: 'ADLS Batch Source',
    plugin: batchPluginInfo
  };
  return {
    batchSource: batchStage,
    connections: [{
      from: 'ADLS Batch Source',
      to: 'Wrangler'
    }]
  };
}

function constructProperties(workspaceInfo, pluginVersion) {
  var observable = new rxjs_Subject__WEBPACK_IMPORTED_MODULE_9__["Subject"]();
  var namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().selectedNamespace;
  var state = components_DataPrep_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().dataprep;
  var workspaceId = state.workspaceId;
  var requestObj = {
    context: namespace,
    workspaceId: workspaceId
  };
  var directives = state.directives;
  var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_3__["directiveRequestBodyCreator"])(directives);
  var rxArray = [api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getSchema(requestObj, requestBody)];
  var connectionId = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(state, 'workspaceInfo', 'properties', 'connectionid');

  if (state.workspaceInfo.properties.connection === 'file') {
    var specParams = {
      context: namespace,
      path: state.workspaceUri,
      wid: workspaceId
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getSpecification(specParams));
  } else if (state.workspaceInfo.properties.connection === 'database') {
    var _specParams = {
      context: namespace,
      connectionId: connectionId,
      tableId: state.workspaceInfo.properties.id
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getDatabaseSpecification(_specParams));

    var _requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_3__["directiveRequestBodyCreator"])([]);

    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getSchema(requestObj, _requestBody));
  } else if (state.workspaceInfo.properties.connection === 'kafka') {
    var _specParams2 = {
      context: namespace,
      connectionId: connectionId,
      topic: state.workspaceInfo.properties.topic
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getKafkaSpecification(_specParams2));
  } else if (state.workspaceInfo.properties.connection === 's3') {
    var activeBucket = state.workspaceInfo.properties['bucket-name'];
    var key = state.workspaceInfo.properties.key;
    var _specParams3 = {
      context: namespace,
      connectionId: connectionId,
      activeBucket: activeBucket,
      key: key,
      wid: workspaceId
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getS3Specification(_specParams3));
  } else if (state.workspaceInfo.properties.connection === 'gcs') {
    var _specParams4 = {
      context: namespace,
      connectionId: state.workspaceInfo.properties.connectionid,
      wid: workspaceId
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getGCSSpecification(_specParams4));
  } else if (state.workspaceInfo.properties.connection === 'bigquery') {
    var _specParams5 = {
      context: namespace,
      connectionId: state.workspaceInfo.properties.connectionid,
      wid: workspaceId
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getBigQuerySpecification(_specParams5));
  } else if (state.workspaceInfo.properties.connection === 'spanner') {
    var _specParams6 = {
      context: namespace,
      workspaceId: workspaceId
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getSpannerSpecification(_specParams6));
  } else if (state.workspaceInfo.properties.connection === 'adls') {
    var _specParams7 = {
      context: namespace,
      path: state.workspaceUri,
      wid: workspaceId,
      connectionId: state.workspaceInfo.properties.connectionid
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getAdlsSpecification(_specParams7));
  }

  try {
    api_artifact__WEBPACK_IMPORTED_MODULE_4__["MyArtifactApi"].list({
      namespace: namespace
    }).combineLatest(rxArray).subscribe(function (res) {
      var batchArtifactsList = res[0].filter(function (artifact) {
        return artifact.name === 'cdap-data-pipeline';
      });
      var realtimeArtifactsList = res[0].filter(function (artifact) {
        return artifact.name === 'cdap-data-streams';
      });
      var highestBatchArtifactVersion = Object(services_VersionRange_VersionUtilities__WEBPACK_IMPORTED_MODULE_7__["findHighestVersion"])(batchArtifactsList.map(function (artifact) {
        return artifact.version;
      }), true);
      var highestRealtimeArtifactVersion = Object(services_VersionRange_VersionUtilities__WEBPACK_IMPORTED_MODULE_7__["findHighestVersion"])(realtimeArtifactsList.map(function (artifact) {
        return artifact.version;
      }), true);
      var batchArtifact = {
        name: 'cdap-data-pipeline',
        version: highestBatchArtifactVersion,
        scope: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SCOPES"].SYSTEM
      };
      var realtimeArtifact = {
        name: 'cdap-data-streams',
        version: highestRealtimeArtifactVersion,
        scope: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SCOPES"].SYSTEM
      };
      var wranglerArtifact;

      try {
        wranglerArtifact = findWranglerArtifacts(res[0], pluginVersion);
      } catch (e) {
        observable.error(e);
      }

      var tempSchema = {
        name: 'avroSchema',
        type: 'record',
        fields: res[1]
      };
      var properties = {
        workspaceId: workspaceId,
        directives: directives.join('\n'),
        schema: JSON.stringify(tempSchema),
        field: '*',
        precondition: 'false',
        threshold: '1'
      };

      if (state.workspaceInfo.properties.connection === 'file') {
        properties.field = 'body';
      }

      try {
        Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_5__["getParsedSchemaForDataPrep"])(tempSchema);
      } catch (e) {
        observable.error(Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(e, 'message'));
      }

      var wranglerStage = {
        name: 'Wrangler',
        plugin: {
          name: 'Wrangler',
          label: 'Wrangler',
          type: 'transform',
          artifact: wranglerArtifact,
          properties: properties
        }
      };
      var realtimeStages = [wranglerStage];
      var batchStages = [wranglerStage];
      var sourceConfigs, realtimeSource, batchSource;
      var connections = [];
      var connectionType = state.workspaceInfo.properties.connection;

      if (connectionType === 'file') {
        sourceConfigs = constructFileSource(res[0], res[2]);
      } else if (connectionType === 'database') {
        sourceConfigs = constructDatabaseSource(res[0], res[2]);
        delete sourceConfigs.batchSource.plugin.properties.schema;
      } else if (connectionType === 'kafka') {
        sourceConfigs = constructKafkaSource(res[0], res[2]);
      } else if (connectionType === 's3') {
        sourceConfigs = constructS3Source(res[0], res[2]);
      } else if (connectionType === 'gcs') {
        sourceConfigs = constructGCSSource(res[0], res[2]);
      } else if (connectionType === 'bigquery') {
        sourceConfigs = constructBigQuerySource(res[0], res[2]);
      } else if (state.workspaceInfo.properties.connection === 'spanner') {
        sourceConfigs = constructSpannerSource(res[0], res[2]);
      } else if (connectionType === 'adls') {
        sourceConfigs = constructAdlsSource(res[0], res[2]);
      }

      if (typeof sourceConfigs === 'string') {
        observable.error(sourceConfigs);
        return;
      }

      if (sourceConfigs) {
        var _sourceConfigs = sourceConfigs;
        realtimeSource = _sourceConfigs.realtimeSource;
        batchSource = _sourceConfigs.batchSource;
        connections = _sourceConfigs.connections;
      }

      var realtimeConfig = null,
          batchConfig = null;

      if (realtimeSource || connectionType === 'upload') {
        if (realtimeSource) {
          realtimeStages.push(realtimeSource);
        }

        realtimeConfig = {
          artifact: realtimeArtifact,
          config: {
            stages: realtimeStages,
            batchInterval: '10s',
            connections: connections,
            resources: {
              memoryMB: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.memoryMB,
              virtualCores: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.virtualCores
            },
            driverResources: {
              memoryMB: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.memoryMB,
              virtualCores: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.virtualCores
            }
          }
        };
      }

      if (batchSource || connectionType === 'upload') {
        if (batchSource) {
          batchStages.push(batchSource);
        }

        batchConfig = {
          artifact: batchArtifact,
          config: {
            stages: batchStages,
            connections: connections,
            resources: {
              memoryMB: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.memoryMB,
              virtualCores: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.virtualCores
            },
            driverResources: {
              memoryMB: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.memoryMB,
              virtualCores: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.virtualCores
            }
          }
        };
      }

      observable.next({
        realtimeConfig: realtimeConfig,
        batchConfig: batchConfig
      });
    }, function (err) {
      observable.error(Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(err, 'response', 'message') || i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".defaultMessage")));
    });
  } catch (e) {
    observable.error(Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(e, 'message') || e);
  }

  return observable;
}

/***/ })

}]);
//# sourceMappingURL=AddToPipelineModal.c992502de4e0197492f5.js.map