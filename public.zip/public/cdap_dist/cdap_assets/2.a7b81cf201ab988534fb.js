(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ "../../node_modules/@material-ui/icons/NewReleasesRounded.js":
/*!***********************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/@material-ui/icons/NewReleasesRounded.js ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@material-ui/icons/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "../../node_modules/react/index.js"));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@material-ui/icons/utils/createSvgIcon.js"));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  d: "M22.42 11.34l-1.86-2.12.26-2.81c.05-.5-.29-.96-.77-1.07l-2.76-.63-1.44-2.43c-.26-.43-.79-.61-1.25-.41L12 3 9.41 1.89c-.46-.2-1-.02-1.25.41L6.71 4.72l-2.75.62c-.49.11-.83.56-.78 1.07l.26 2.8-1.86 2.13c-.33.38-.33.94 0 1.32l1.86 2.12-.26 2.82c-.05.5.29.96.77 1.07l2.76.63 1.44 2.42c.26.43.79.61 1.26.41L12 21l2.59 1.11c.46.2 1 .02 1.25-.41l1.44-2.43 2.76-.63c.49-.11.82-.57.77-1.07l-.26-2.81 1.86-2.12c.34-.36.34-.92.01-1.3zM13 17h-2v-2h2v2zm-1-4c-.55 0-1-.45-1-1V8c0-.55.45-1 1-1s1 .45 1 1v4c0 .55-.45 1-1 1z"
})), 'NewReleasesRounded');

exports.default = _default;

/***/ }),

/***/ "./components/Lab/experiment-list.tsx":
/*!********************************************!*\
  !*** ./components/Lab/experiment-list.tsx ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*
 * Copyright © 2020 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
/* harmony default export */ __webpack_exports__["default"] = ([{
  name: 'CDAP Common',
  description: "This is a common flag that developers can use to hide or show features. The flag is stored in browser's local storage with experiment ID as the name.",
  id: 'cdap-common-experiment',
  screenshot: null,
  value: false
}, {
  name: 'Data Ingestion',
  description: "Easily transfer data between a source and a sink.",
  id: 'data-ingestion',
  screenshot: '/cdap_assets/img/ingest-tile.svg',
  value: false
}]);

/***/ }),

/***/ "./components/Lab/index.tsx":
/*!**********************************!*\
  !*** ./components/Lab/index.tsx ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_Table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Table */ "../../node_modules/@material-ui/core/esm/Table/index.js");
/* harmony import */ var _material_ui_core_TableBody__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/TableBody */ "../../node_modules/@material-ui/core/esm/TableBody/index.js");
/* harmony import */ var _material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/TableCell */ "../../node_modules/@material-ui/core/esm/TableCell/index.js");
/* harmony import */ var _material_ui_core_TableHead__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/TableHead */ "../../node_modules/@material-ui/core/esm/TableHead/index.js");
/* harmony import */ var _material_ui_core_TableRow__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/TableRow */ "../../node_modules/@material-ui/core/esm/TableRow/index.js");
/* harmony import */ var _material_ui_core_Paper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/Paper */ "../../node_modules/@material-ui/core/esm/Paper/index.js");
/* harmony import */ var _material_ui_core_Switch__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/Switch */ "../../node_modules/@material-ui/core/esm/Switch/index.js");
/* harmony import */ var _material_ui_core_FormControlLabel__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/core/FormControlLabel */ "../../node_modules/@material-ui/core/esm/FormControlLabel/index.js");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/core */ "../../node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _material_ui_icons_NewReleasesRounded__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @material-ui/icons/NewReleasesRounded */ "../../node_modules/@material-ui/icons/NewReleasesRounded.js");
/* harmony import */ var _material_ui_icons_NewReleasesRounded__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_NewReleasesRounded__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _experiment_list__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./experiment-list */ "./components/Lab/experiment-list.tsx");
/*
 * Copyright © 2020 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();















var styles = function styles() {
  return {
    root: {
      display: 'flex',
      justifyContent: 'center',
      paddingTop: '5%'
    },
    paperContainer: {
      display: 'flex'
    },
    experimentsTable: {
      maxWidth: 900
    },
    screenshot: {
      maxWidth: 256
    },
    defaultExperimentIcon: {
      display: 'block',
      fontSize: 64,
      margin: '0 auto'
    },
    switchCell: {
      width: 145
    }
  };
};

var Lab =
/** @class */
function (_super) {
  __extends(Lab, _super);

  function Lab() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.updatePreference = function (event) {
      var experiments = _this.state.experiments.map(function (experiment) {
        if (experiment.id === event.target.name) {
          experiment.value = !experiment.value;
          window.localStorage.setItem(event.target.name, experiment.value.toString());
        }

        return experiment;
      });

      _this.setState({
        experiments: experiments
      });
    };

    return _this;
  }

  Lab.prototype.componentWillMount = function () {
    _experiment_list__WEBPACK_IMPORTED_MODULE_12__["default"].forEach(function (experiment) {
      experiment.value = window.localStorage.getItem(experiment.id) === 'true' ? true : false;
    });
    this.state = {
      experiments: _experiment_list__WEBPACK_IMPORTED_MODULE_12__["default"]
    };
  };

  Lab.prototype.render = function () {
    var _this = this;

    var classes = this.props.classes;
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: classes.root
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_Paper__WEBPACK_IMPORTED_MODULE_7__["default"], {
      className: classes.paperContainer
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_Table__WEBPACK_IMPORTED_MODULE_2__["default"], {
      className: classes.experimentsTable
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableHead__WEBPACK_IMPORTED_MODULE_5__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableRow__WEBPACK_IMPORTED_MODULE_6__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_4__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_10__["Typography"], {
      variant: "h5"
    }, "Image")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_4__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_10__["Typography"], {
      variant: "h5"
    }, "Experiment")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_4__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_10__["Typography"], {
      variant: "h5"
    }, "Status")))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableBody__WEBPACK_IMPORTED_MODULE_3__["default"], null, this.state.experiments.map(function (experiment) {
      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableRow__WEBPACK_IMPORTED_MODULE_6__["default"], {
        key: experiment.id
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_4__["default"], null, experiment.screenshot ? react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", {
        className: classes.screenshot,
        src: experiment.screenshot
      }) : react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_icons_NewReleasesRounded__WEBPACK_IMPORTED_MODULE_11___default.a, {
        className: classes.defaultExperimentIcon
      })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_4__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_10__["Typography"], {
        variant: "h5"
      }, experiment.name), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("br", null), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_10__["Typography"], {
        variant: "body1"
      }, experiment.description), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("br", null), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_10__["Typography"], {
        variant: "caption"
      }, "ID: ", experiment.id)), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_4__["default"], {
        className: classes.switchCell
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_FormControlLabel__WEBPACK_IMPORTED_MODULE_9__["default"], {
        label: experiment.value ? 'Enabled' : 'Disabled',
        control: react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_Switch__WEBPACK_IMPORTED_MODULE_8__["default"], {
          "data-cy": experiment.id + "-switch",
          name: experiment.id,
          color: "primary",
          onChange: _this.updatePreference,
          checked: experiment.value,
          value: experiment.value
        })
      })));
    })))));
  };

  return Lab;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

var StyledLab = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(Lab);
/* harmony default export */ __webpack_exports__["default"] = (StyledLab);

/***/ })

}]);
//# sourceMappingURL=2.a7b81cf201ab988534fb.js.map