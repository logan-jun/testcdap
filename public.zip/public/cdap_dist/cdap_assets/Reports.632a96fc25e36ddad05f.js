(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Reports"],{

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/NamespacesPicker/NamespacesPicker.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/NamespacesPicker/NamespacesPicker.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.namespace-picker {\n  margin-top: 15px; }\n  .namespace-picker .namespace-list-monitor {\n    font-weight: bold;\n    max-width: 350px;\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis; }\n  .namespace-picker .namespaces-list-popover .monitor-more {\n    color: #0076dc;\n    cursor: pointer; }\n  .namespace-picker .namespaces-list-popover .popper {\n    width: 300px;\n    z-index: 1;\n    text-align: left; }\n    .namespace-picker .namespaces-list-popover .popper .popover-content {\n      padding: 15px; }\n    .namespace-picker .namespaces-list-popover .popper .title {\n      font-size: 16px; }\n    .namespace-picker .namespaces-list-popover .popper .namespaces-count {\n      margin-top: 5px;\n      margin-bottom: 5px;\n      color: #999999; }\n    .namespace-picker .namespaces-list-popover .popper .toggle-all-dropdown .dropdown-toggle-btn {\n      color: #333333;\n      background-color: transparent;\n      border: 0;\n      padding: 0;\n      line-height: 25px; }\n      .namespace-picker .namespaces-list-popover .popper .toggle-all-dropdown .dropdown-toggle-btn:hover {\n        color: #333333;\n        background-color: transparent;\n        border: 0; }\n      .namespace-picker .namespaces-list-popover .popper .toggle-all-dropdown .dropdown-toggle-btn:focus {\n        outline: none; }\n    .namespace-picker .namespaces-list-popover .popper .namespaces-list hr {\n      margin-top: 5px;\n      margin-bottom: 5px; }\n    .namespace-picker .namespaces-list-popover .popper .namespaces-list .namespace-row {\n      line-height: 25px; }\n      .namespace-picker .namespaces-list-popover .popper .namespaces-list .namespace-row:not(.non-selectable) {\n        cursor: pointer; }\n      .namespace-picker .namespaces-list-popover .popper .namespaces-list .namespace-row .checkbox-column,\n      .namespace-picker .namespaces-list-popover .popper .namespaces-list .namespace-row .namespace-section {\n        display: inline-block; }\n      .namespace-picker .namespaces-list-popover .popper .namespaces-list .namespace-row .checkbox-column {\n        width: 20px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PaginationWithTitle/PaginationWithTitle.scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PaginationWithTitle/PaginationWithTitle.scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.pagination-with-title {\n  float: right;\n  margin-right: 50px;\n  margin-bottom: initial; }\n  .pagination-with-title .total-entities {\n    display: inline-block;\n    vertical-align: top; }\n    .pagination-with-title .total-entities span {\n      font-weight: bold;\n      font-size: 12px; }\n  .pagination-with-title .page-list {\n    padding-left: 16px;\n    list-style-type: none;\n    display: inline-block;\n    margin-bottom: 0;\n    vertical-align: top; }\n    .pagination-with-title .page-list li {\n      font-weight: bold;\n      display: inline-block;\n      border-radius: 100%; }\n      .pagination-with-title .page-list li a,\n      .pagination-with-title .page-list li span {\n        display: -webkit-box;\n        display: flex;\n        height: 22px;\n        width: 22px;\n        -webkit-box-pack: center;\n                justify-content: center;\n        -webkit-box-align: center;\n                align-items: center;\n        color: inherit;\n        -webkit-user-select: none;\n           -moz-user-select: none;\n            -ms-user-select: none;\n                user-select: none; }\n        .pagination-with-title .page-list li a:hover, .pagination-with-title .page-list li a:focus,\n        .pagination-with-title .page-list li span:hover,\n        .pagination-with-title .page-list li span:focus {\n          text-decoration: none;\n          outline: 0; }\n      .pagination-with-title .page-list li:not(:first-child) {\n        margin-left: 15px; }\n      .pagination-with-title .page-list li.current-page {\n        background-color: #5d6789; }\n        .pagination-with-title .page-list li.current-page a {\n          color: #ffffff; }\n      .pagination-with-title .page-list li.ellipsis {\n        margin-left: 5px;\n        margin-right: -10px; }\n        .pagination-with-title .page-list li.ellipsis span {\n          -webkit-user-select: none;\n             -moz-user-select: none;\n              -ms-user-select: none;\n                  user-select: none; }\n      .pagination-with-title .page-list li:hover:not(.current-page):not(.ellipsis) {\n        cursor: pointer;\n        background-color: #dbdbdb; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/Customizer/Customizer.scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Reports/Customizer/Customizer.scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.customizer-container {\n  background-color: #f5f5f5;\n  padding: 10px 25px; }\n  .customizer-container:not(.collapsed) {\n    height: 170px; }\n  .customizer-container .collapsed-toggle-container .toggle {\n    cursor: pointer;\n    line-height: 40px;\n    display: inline-block; }\n    .customizer-container .collapsed-toggle-container .toggle .icon-svg {\n      margin-right: 15px; }\n  .customizer-container .options-container {\n    display: -webkit-box;\n    display: flex; }\n    .customizer-container .options-container .title {\n      font-weight: bold;\n      margin-bottom: 2px; }\n    .customizer-container .options-container .option span {\n      cursor: pointer; }\n    .customizer-container .options-container .option .icon-svg {\n      margin-right: 5px; }\n    .customizer-container .options-container .app-type-selector,\n    .customizer-container .options-container .status-selector,\n    .customizer-container .options-container .reports-time-range-selector {\n      width: 200px; }\n    .customizer-container .options-container .columns-selector {\n      -webkit-box-flex: 1;\n              flex-grow: 1;\n      display: -webkit-box;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n              flex-direction: column;\n      height: 70px;\n      flex-wrap: wrap; }\n  .customizer-container .action-buttons .btn:focus {\n    outline: none;\n    text-decoration: none; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/Customizer/StatusSelector/StatusSelector.scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Reports/Customizer/StatusSelector/StatusSelector.scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.status-selector .status-viewer {\n  cursor: pointer;\n  border-bottom: 1px solid #999999;\n  margin-right: 25px; }\n  .status-selector .status-viewer .status-text,\n  .status-selector .status-viewer .caret-dropdown {\n    display: inline-block;\n    vertical-align: top; }\n  .status-selector .status-viewer .status-text {\n    width: calc(100% - 25px);\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis; }\n  .status-selector .status-viewer .caret-dropdown {\n    width: 25px;\n    text-align: center; }\n\n.status-selector .status-selector-popover .popper {\n  text-align: left;\n  padding: 15px;\n  z-index: 1; }\n  .status-selector .status-selector-popover .popper .option {\n    line-height: 25px; }\n    .status-selector .status-selector-popover .popper .option span {\n      vertical-align: middle; }\n  .status-selector .status-selector-popover .popper .action {\n    margin-top: 15px; }\n  .status-selector .status-selector-popover .popper .running {\n    color: #0076dc; }\n  .status-selector .status-selector-popover .popper .failed {\n    color: #d40001; }\n  .status-selector .status-selector-popover .popper .completed {\n    color: #3cc801; }\n  .status-selector .status-selector-popover .popper .killed {\n    color: #bbbbbb; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/Customizer/TimeRangeSelector/TimeRangeSelector.scss":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Reports/Customizer/TimeRangeSelector/TimeRangeSelector.scss ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.reports-time-range-selector .time-icon {\n  display: inline-block;\n  margin-right: 5px; }\n  .reports-time-range-selector .time-icon .icon-calendar {\n    cursor: pointer;\n    color: #0076dc; }\n\n.time-range-popover .popper {\n  width: 400px;\n  text-align: left;\n  padding: 15px 10px;\n  z-index: 1; }\n  .time-range-popover .popper .options {\n    padding: 10px 15px; }\n    .time-range-popover .popper .options .option {\n      display: inline-block;\n      width: 33%; }\n      .time-range-popover .popper .options .option .icon-svg {\n        margin-right: 5px; }\n  .time-range-popover .popper .apply-button {\n    margin-top: 15px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/Reports.scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Reports/Reports.scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.reports-container {\n  height: 100%;\n  background-color: #f5f5f5; }\n  .reports-container .header {\n    height: 70px;\n    background-color: white; }\n    .reports-container .header .reports-view-options {\n      font-size: 18px;\n      line-height: 70px;\n      padding-left: 25px; }\n      .reports-container .header .reports-view-options .separator {\n        margin-right: 10px;\n        margin-left: 10px; }\n    .reports-container .header .namespace-picker {\n      padding-right: 15px; }\n  .reports-container .error-container {\n    padding: 25px;\n    height: calc(100% - 70px);\n    overflow: auto; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/Expiry/Expiry.scss":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/Expiry/Expiry.scss ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.reports-container .expiry-saved {\n  color: #3cc801; }\n\n.reports-container .duration-display {\n  margin-left: 5px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/ReportsDetail.scss":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/ReportsDetail.scss ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.reports-detail-container {\n  height: calc(100% - 70px); }\n  .reports-detail-container .separator {\n    margin-left: 5px;\n    margin-right: 5px; }\n  .reports-detail-container .action-section {\n    height: 40px;\n    line-height: 40px;\n    background-color: white;\n    padding: 0 35px; }\n    .reports-detail-container .action-section .btn {\n      padding: 3px 10px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/Runs/Runs.scss":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/Runs/Runs.scss ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.reports-runs-container {\n  height: calc(100% - 40px - 182px); }\n  .reports-runs-container .grid-wrapper {\n    height: 100%;\n    min-height: 300px; }\n  .reports-runs-container .grid.grid-container {\n    max-height: 100%; }\n    .reports-runs-container .grid.grid-container .grid-header,\n    .reports-runs-container .grid.grid-container .grid-body {\n      padding: 0 35px; }\n      .reports-runs-container .grid.grid-container .grid-header .grid-row > *,\n      .reports-runs-container .grid.grid-container .grid-body .grid-row > * {\n        padding: 5px 10px; }\n    .reports-runs-container .grid.grid-container .grid-header {\n      background-color: #f5f5f5;\n      border-bottom: 2px solid #999999;\n      font-weight: bold; }\n      .reports-runs-container .grid.grid-container .grid-header .grid-row {\n        border-bottom: 0;\n        -webkit-box-align: end;\n                align-items: end; }\n    .reports-runs-container .grid.grid-container .grid-body {\n      background-color: white;\n      font-size: 12px; }\n      .reports-runs-container .grid.grid-container .grid-body .grid-row {\n        padding: 3px 0; }\n        .reports-runs-container .grid.grid-container .grid-body .grid-row:hover {\n          background-color: white; }\n        .reports-runs-container .grid.grid-container .grid-body .grid-row .runtime-args-row {\n          overflow: hidden;\n          text-overflow: ellipsis;\n          margin-bottom: 0;\n          margin-top: 0.5rem; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/SaveButton/SaveButton.scss":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/SaveButton/SaveButton.scss ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.report-save-button-modal .error-container {\n  margin-top: 10px; }\n\n.report-save-button-modal .modal-header {\n  border-bottom: 0;\n  background-color: #f5f5f5; }\n  .report-save-button-modal .modal-header .close-section {\n    cursor: pointer; }\n\n.report-save-button-modal .modal-footer {\n  text-align: left;\n  border-top: 0; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/Summary/Summary.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/Summary/Summary.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.reports-summary-container {\n  background-color: white;\n  padding: 0 50px 15px; }\n  .reports-summary-container .summary-section {\n    background-color: #f5f5f5;\n    border-top: 3px solid #999999; }\n    .reports-summary-container .summary-section .table td {\n      border-color: #999999; }\n    .reports-summary-container .summary-section .table .no-border td {\n      border-top: 0; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsList/ReportsList.scss":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsList/ReportsList.scss ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.reports-list-container .customizer-container {\n  border-bottom: 2px solid #999999; }\n\n.reports-list-container .list-view {\n  padding: 0 25px;\n  background-color: #f5f5f5; }\n\n.reports-list-container .section-title {\n  font-size: 16px;\n  font-weight: 500;\n  line-height: 40px; }\n\n.reports-list-container .list-container {\n  padding: 10px 10px 40px; }\n  .reports-list-container .list-container.empty {\n    padding: 50px 0 75px;\n    font-size: 16px;\n    font-weight: bold;\n    line-height: 2;\n    color: #666666; }\n  .reports-list-container .list-container.grid-wrapper {\n    clear: right; }\n  .reports-list-container .list-container .grid.grid-container {\n    max-height: 100%;\n    height: 100%;\n    grid-template-rows: 45px;\n    background-color: white; }\n    .reports-list-container .list-container .grid.grid-container .grid-header .grid-row,\n    .reports-list-container .list-container .grid.grid-container .grid-body .grid-row {\n      grid-template-columns: 1fr 250px 250px 50px; }\n    .reports-list-container .list-container .grid.grid-container .grid-header .grid-link,\n    .reports-list-container .list-container .grid.grid-container .grid-body .grid-link {\n      color: #333333; }\n      .reports-list-container .list-container .grid.grid-container .grid-header .grid-link.active,\n      .reports-list-container .list-container .grid.grid-container .grid-body .grid-link.active {\n        border: 2px solid #01b133; }\n      .reports-list-container .list-container .grid.grid-container .grid-header .grid-link.not-allowed,\n      .reports-list-container .list-container .grid.grid-container .grid-body .grid-link.not-allowed {\n        cursor: not-allowed; }\n    .reports-list-container .list-container .grid.grid-container .grid-header {\n      font-weight: bold; }\n  .reports-list-container .list-container .report-name {\n    font-size: 14px; }\n  .reports-list-container .list-container .generating span.fa {\n    margin-right: 5px; }\n\n.reports-list-container .reports-list-action-popover {\n  display: inline-block; }\n  .reports-list-container .reports-list-action-popover .popper {\n    padding: 10px;\n    text-align: left; }\n    .reports-list-container .reports-list-action-popover .popper .option {\n      cursor: pointer; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsServiceControl/ReportsServiceControl.scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsServiceControl/ReportsServiceControl.scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.reports-service-control {\n  display: -webkit-box;\n  display: flex;\n  height: calc(100vh - (53px + 48px));\n  font-size: 15px;\n  overflow: auto; }\n  .reports-service-control .text-container,\n  .reports-service-control .image-containers {\n    width: 50%;\n    height: 100%; }\n  .reports-service-control .image-containers {\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n            flex-direction: column;\n    -webkit-box-align: center;\n            align-items: center;\n    padding-top: 50px;\n    padding-left: 25px; }\n    .reports-service-control .image-containers img {\n      height: auto;\n      margin: 20px;\n      width: 75%; }\n      .reports-service-control .image-containers img:first-child {\n        margin-top: 0; }\n  .reports-service-control .text-container {\n    padding-top: 50px;\n    padding-left: 30px;\n    padding-right: 30px; }\n    .reports-service-control .text-container p {\n      line-height: 2;\n      padding-right: 20px; }\n    .reports-service-control .text-container .reports-benefit li {\n      padding: 10px 0; }\n    .reports-service-control .text-container .action-container {\n      padding-top: 25px;\n      padding-bottom: 25px; }\n      .reports-service-control .text-container .action-container .loading-bar {\n        height: 16px; }\n        .reports-service-control .text-container .action-container .loading-bar rect {\n          fill: #cae7ef; }\n      .reports-service-control .text-container .action-container.service-disabled {\n        display: grid;\n        -webkit-box-align: center;\n                align-items: center;\n        grid-template-columns: 20px 1fr;\n        grid-gap: 5px; }\n    .reports-service-control .text-container .btn .btn-label {\n      vertical-align: top; }\n  .reports-service-control .reports-service-control-error .icon-svg {\n    margin-right: 5px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/react-paginate/dist/BreakView.js":
/*!***************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/dist/BreakView.js ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(/*! react */ "../../node_modules/react/index.js");

var _react2 = _interopRequireDefault(_react);

var _propTypes = __webpack_require__(/*! prop-types */ "../../node_modules/react-paginate/node_modules/prop-types/index.js");

var _propTypes2 = _interopRequireDefault(_propTypes);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var BreakView = function BreakView(props) {
  var breakLabel = props.breakLabel,
      breakClassName = props.breakClassName,
      breakLinkClassName = props.breakLinkClassName,
      onClick = props.onClick;

  var className = breakClassName || 'break';

  return _react2.default.createElement(
    'li',
    { className: className },
    _react2.default.createElement(
      'a',
      {
        className: breakLinkClassName,
        onClick: onClick,
        role: 'button',
        tabIndex: '0',
        onKeyPress: onClick
      },
      breakLabel
    )
  );
};

BreakView.propTypes = {
  breakLabel: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.node]),
  breakClassName: _propTypes2.default.string,
  breakLinkClassName: _propTypes2.default.string,
  onClick: _propTypes2.default.func.isRequired
};

exports.default = BreakView;
//# sourceMappingURL=BreakView.js.map

/***/ }),

/***/ "../../node_modules/react-paginate/dist/PageView.js":
/*!**************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/dist/PageView.js ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(/*! react */ "../../node_modules/react/index.js");

var _react2 = _interopRequireDefault(_react);

var _propTypes = __webpack_require__(/*! prop-types */ "../../node_modules/react-paginate/node_modules/prop-types/index.js");

var _propTypes2 = _interopRequireDefault(_propTypes);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var PageView = function PageView(props) {
  var pageClassName = props.pageClassName;
  var pageLinkClassName = props.pageLinkClassName;

  var onClick = props.onClick;
  var href = props.href;
  var ariaLabel = props.ariaLabel || 'Page ' + props.page + (props.extraAriaContext ? ' ' + props.extraAriaContext : '');
  var ariaCurrent = null;

  if (props.selected) {
    ariaCurrent = 'page';

    ariaLabel = props.ariaLabel || 'Page ' + props.page + ' is your current page';

    if (typeof pageClassName !== 'undefined') {
      pageClassName = pageClassName + ' ' + props.activeClassName;
    } else {
      pageClassName = props.activeClassName;
    }

    if (typeof pageLinkClassName !== 'undefined') {
      if (typeof props.activeLinkClassName !== 'undefined') {
        pageLinkClassName = pageLinkClassName + ' ' + props.activeLinkClassName;
      }
    } else {
      pageLinkClassName = props.activeLinkClassName;
    }
  }

  return _react2.default.createElement(
    'li',
    { className: pageClassName },
    _react2.default.createElement(
      'a',
      {
        onClick: onClick,
        role: 'button',
        className: pageLinkClassName,
        href: href,
        tabIndex: '0',
        'aria-label': ariaLabel,
        'aria-current': ariaCurrent,
        onKeyPress: onClick
      },
      props.page
    )
  );
};

PageView.propTypes = {
  onClick: _propTypes2.default.func.isRequired,
  selected: _propTypes2.default.bool.isRequired,
  pageClassName: _propTypes2.default.string,
  pageLinkClassName: _propTypes2.default.string,
  activeClassName: _propTypes2.default.string,
  activeLinkClassName: _propTypes2.default.string,
  extraAriaContext: _propTypes2.default.string,
  href: _propTypes2.default.string,
  ariaLabel: _propTypes2.default.string,
  page: _propTypes2.default.number.isRequired
};

exports.default = PageView;
//# sourceMappingURL=PageView.js.map

/***/ }),

/***/ "../../node_modules/react-paginate/dist/PaginationBoxView.js":
/*!***********************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/dist/PaginationBoxView.js ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(/*! react */ "../../node_modules/react/index.js");

var _react2 = _interopRequireDefault(_react);

var _propTypes = __webpack_require__(/*! prop-types */ "../../node_modules/react-paginate/node_modules/prop-types/index.js");

var _propTypes2 = _interopRequireDefault(_propTypes);

var _PageView = __webpack_require__(/*! ./PageView */ "../../node_modules/react-paginate/dist/PageView.js");

var _PageView2 = _interopRequireDefault(_PageView);

var _BreakView = __webpack_require__(/*! ./BreakView */ "../../node_modules/react-paginate/dist/BreakView.js");

var _BreakView2 = _interopRequireDefault(_BreakView);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var PaginationBoxView = function (_Component) {
  _inherits(PaginationBoxView, _Component);

  function PaginationBoxView(props) {
    _classCallCheck(this, PaginationBoxView);

    var _this = _possibleConstructorReturn(this, (PaginationBoxView.__proto__ || Object.getPrototypeOf(PaginationBoxView)).call(this, props));

    _this.handlePreviousPage = function (evt) {
      var selected = _this.state.selected;

      evt.preventDefault ? evt.preventDefault() : evt.returnValue = false;
      if (selected > 0) {
        _this.handlePageSelected(selected - 1, evt);
      }
    };

    _this.handleNextPage = function (evt) {
      var selected = _this.state.selected;
      var pageCount = _this.props.pageCount;


      evt.preventDefault ? evt.preventDefault() : evt.returnValue = false;
      if (selected < pageCount - 1) {
        _this.handlePageSelected(selected + 1, evt);
      }
    };

    _this.handlePageSelected = function (selected, evt) {
      evt.preventDefault ? evt.preventDefault() : evt.returnValue = false;

      if (_this.state.selected === selected) return;

      _this.setState({ selected: selected });

      // Call the callback with the new selected item:
      _this.callCallback(selected);
    };

    _this.handleBreakClick = function (index, evt) {
      evt.preventDefault ? evt.preventDefault() : evt.returnValue = false;

      var selected = _this.state.selected;


      _this.handlePageSelected(selected < index ? _this.getForwardJump() : _this.getBackwardJump(), evt);
    };

    _this.callCallback = function (selectedItem) {
      if (typeof _this.props.onPageChange !== 'undefined' && typeof _this.props.onPageChange === 'function') {
        _this.props.onPageChange({ selected: selectedItem });
      }
    };

    _this.pagination = function () {
      var items = [];
      var _this$props = _this.props,
          pageRangeDisplayed = _this$props.pageRangeDisplayed,
          pageCount = _this$props.pageCount,
          marginPagesDisplayed = _this$props.marginPagesDisplayed,
          breakLabel = _this$props.breakLabel,
          breakClassName = _this$props.breakClassName,
          breakLinkClassName = _this$props.breakLinkClassName;
      var selected = _this.state.selected;


      if (pageCount <= pageRangeDisplayed) {
        for (var index = 0; index < pageCount; index++) {
          items.push(_this.getPageElement(index));
        }
      } else {
        var leftSide = pageRangeDisplayed / 2;
        var rightSide = pageRangeDisplayed - leftSide;

        // If the selected page index is on the default right side of the pagination,
        // we consider that the new right side is made up of it (= only one break element).
        // If the selected page index is on the default left side of the pagination,
        // we consider that the new left side is made up of it (= only one break element).
        if (selected > pageCount - pageRangeDisplayed / 2) {
          rightSide = pageCount - selected;
          leftSide = pageRangeDisplayed - rightSide;
        } else if (selected < pageRangeDisplayed / 2) {
          leftSide = selected;
          rightSide = pageRangeDisplayed - leftSide;
        }

        var _index = void 0;
        var page = void 0;
        var breakView = void 0;
        var createPageView = function createPageView(index) {
          return _this.getPageElement(index);
        };

        for (_index = 0; _index < pageCount; _index++) {
          page = _index + 1;

          // If the page index is lower than the margin defined,
          // the page has to be displayed on the left side of
          // the pagination.
          if (page <= marginPagesDisplayed) {
            items.push(createPageView(_index));
            continue;
          }

          // If the page index is greater than the page count
          // minus the margin defined, the page has to be
          // displayed on the right side of the pagination.
          if (page > pageCount - marginPagesDisplayed) {
            items.push(createPageView(_index));
            continue;
          }

          // If the page index is near the selected page index
          // and inside the defined range (pageRangeDisplayed)
          // we have to display it (it will create the center
          // part of the pagination).
          if (_index >= selected - leftSide && _index <= selected + rightSide) {
            items.push(createPageView(_index));
            continue;
          }

          // If the page index doesn't meet any of the conditions above,
          // we check if the last item of the current "items" array
          // is a break element. If not, we add a break element, else,
          // we do nothing (because we don't want to display the page).
          if (breakLabel && items[items.length - 1] !== breakView) {
            breakView = _react2.default.createElement(_BreakView2.default, {
              key: _index,
              breakLabel: breakLabel,
              breakClassName: breakClassName,
              breakLinkClassName: breakLinkClassName,
              onClick: _this.handleBreakClick.bind(null, _index)
            });
            items.push(breakView);
          }
        }
      }

      return items;
    };

    var initialSelected = void 0;
    if (props.initialPage) {
      initialSelected = props.initialPage;
    } else if (props.forcePage) {
      initialSelected = props.forcePage;
    } else {
      initialSelected = 0;
    }

    _this.state = {
      selected: initialSelected
    };
    return _this;
  }

  _createClass(PaginationBoxView, [{
    key: 'componentDidMount',
    value: function componentDidMount() {
      var _props = this.props,
          initialPage = _props.initialPage,
          disableInitialCallback = _props.disableInitialCallback,
          extraAriaContext = _props.extraAriaContext;
      // Call the callback with the initialPage item:

      if (typeof initialPage !== 'undefined' && !disableInitialCallback) {
        this.callCallback(initialPage);
      }

      if (extraAriaContext) {
        console.warn('DEPRECATED (react-paginate): The extraAriaContext prop is deprecated. You should now use the ariaLabelBuilder instead.');
      }
    }
  }, {
    key: 'componentDidUpdate',
    value: function componentDidUpdate(prevProps) {
      if (typeof this.props.forcePage !== 'undefined' && this.props.forcePage !== prevProps.forcePage) {
        this.setState({ selected: this.props.forcePage });
      }
    }
  }, {
    key: 'getForwardJump',
    value: function getForwardJump() {
      var selected = this.state.selected;
      var _props2 = this.props,
          pageCount = _props2.pageCount,
          pageRangeDisplayed = _props2.pageRangeDisplayed;


      var forwardJump = selected + pageRangeDisplayed;
      return forwardJump >= pageCount ? pageCount - 1 : forwardJump;
    }
  }, {
    key: 'getBackwardJump',
    value: function getBackwardJump() {
      var selected = this.state.selected;
      var pageRangeDisplayed = this.props.pageRangeDisplayed;


      var backwardJump = selected - pageRangeDisplayed;
      return backwardJump < 0 ? 0 : backwardJump;
    }
  }, {
    key: 'hrefBuilder',
    value: function hrefBuilder(pageIndex) {
      var _props3 = this.props,
          hrefBuilder = _props3.hrefBuilder,
          pageCount = _props3.pageCount;

      if (hrefBuilder && pageIndex !== this.state.selected && pageIndex >= 0 && pageIndex < pageCount) {
        return hrefBuilder(pageIndex + 1);
      }
    }
  }, {
    key: 'ariaLabelBuilder',
    value: function ariaLabelBuilder(pageIndex) {
      var selected = pageIndex === this.state.selected;
      if (this.props.ariaLabelBuilder && pageIndex >= 0 && pageIndex < this.props.pageCount) {
        var label = this.props.ariaLabelBuilder(pageIndex + 1, selected);
        // DEPRECATED: The extraAriaContext prop was used to add additional context
        // to the aria-label. Users should now use the ariaLabelBuilder instead.
        if (this.props.extraAriaContext && !selected) {
          label = label + ' ' + this.props.extraAriaContext;
        }
        return label;
      }
    }
  }, {
    key: 'getPageElement',
    value: function getPageElement(index) {
      var selected = this.state.selected;
      var _props4 = this.props,
          pageClassName = _props4.pageClassName,
          pageLinkClassName = _props4.pageLinkClassName,
          activeClassName = _props4.activeClassName,
          activeLinkClassName = _props4.activeLinkClassName,
          extraAriaContext = _props4.extraAriaContext;


      return _react2.default.createElement(_PageView2.default, {
        key: index,
        onClick: this.handlePageSelected.bind(null, index),
        selected: selected === index,
        pageClassName: pageClassName,
        pageLinkClassName: pageLinkClassName,
        activeClassName: activeClassName,
        activeLinkClassName: activeLinkClassName,
        extraAriaContext: extraAriaContext,
        href: this.hrefBuilder(index),
        ariaLabel: this.ariaLabelBuilder(index),
        page: index + 1
      });
    }
  }, {
    key: 'render',
    value: function render() {
      var _props5 = this.props,
          disabledClassName = _props5.disabledClassName,
          previousClassName = _props5.previousClassName,
          nextClassName = _props5.nextClassName,
          pageCount = _props5.pageCount,
          containerClassName = _props5.containerClassName,
          previousLinkClassName = _props5.previousLinkClassName,
          previousLabel = _props5.previousLabel,
          nextLinkClassName = _props5.nextLinkClassName,
          nextLabel = _props5.nextLabel;
      var selected = this.state.selected;


      var previousClasses = previousClassName + (selected === 0 ? ' ' + disabledClassName : '');
      var nextClasses = nextClassName + (selected === pageCount - 1 ? ' ' + disabledClassName : '');

      var previousAriaDisabled = selected === 0 ? 'true' : 'false';
      var nextAriaDisabled = selected === pageCount - 1 ? 'true' : 'false';

      return _react2.default.createElement(
        'ul',
        { className: containerClassName },
        _react2.default.createElement(
          'li',
          { className: previousClasses },
          _react2.default.createElement(
            'a',
            {
              onClick: this.handlePreviousPage,
              className: previousLinkClassName,
              href: this.hrefBuilder(selected - 1),
              tabIndex: '0',
              role: 'button',
              onKeyPress: this.handlePreviousPage,
              'aria-disabled': previousAriaDisabled
            },
            previousLabel
          )
        ),
        this.pagination(),
        _react2.default.createElement(
          'li',
          { className: nextClasses },
          _react2.default.createElement(
            'a',
            {
              onClick: this.handleNextPage,
              className: nextLinkClassName,
              href: this.hrefBuilder(selected + 1),
              tabIndex: '0',
              role: 'button',
              onKeyPress: this.handleNextPage,
              'aria-disabled': nextAriaDisabled
            },
            nextLabel
          )
        )
      );
    }
  }]);

  return PaginationBoxView;
}(_react.Component);

PaginationBoxView.propTypes = {
  pageCount: _propTypes2.default.number.isRequired,
  pageRangeDisplayed: _propTypes2.default.number.isRequired,
  marginPagesDisplayed: _propTypes2.default.number.isRequired,
  previousLabel: _propTypes2.default.node,
  nextLabel: _propTypes2.default.node,
  breakLabel: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.node]),
  hrefBuilder: _propTypes2.default.func,
  onPageChange: _propTypes2.default.func,
  initialPage: _propTypes2.default.number,
  forcePage: _propTypes2.default.number,
  disableInitialCallback: _propTypes2.default.bool,
  containerClassName: _propTypes2.default.string,
  pageClassName: _propTypes2.default.string,
  pageLinkClassName: _propTypes2.default.string,
  activeClassName: _propTypes2.default.string,
  activeLinkClassName: _propTypes2.default.string,
  previousClassName: _propTypes2.default.string,
  nextClassName: _propTypes2.default.string,
  previousLinkClassName: _propTypes2.default.string,
  nextLinkClassName: _propTypes2.default.string,
  disabledClassName: _propTypes2.default.string,
  breakClassName: _propTypes2.default.string,
  breakLinkClassName: _propTypes2.default.string,
  extraAriaContext: _propTypes2.default.string,
  ariaLabelBuilder: _propTypes2.default.func
};
PaginationBoxView.defaultProps = {
  pageCount: 10,
  pageRangeDisplayed: 2,
  marginPagesDisplayed: 3,
  activeClassName: 'selected',
  previousClassName: 'previous',
  nextClassName: 'next',
  previousLabel: 'Previous',
  nextLabel: 'Next',
  breakLabel: '...',
  disabledClassName: 'disabled',
  disableInitialCallback: false
};
exports.default = PaginationBoxView;
//# sourceMappingURL=PaginationBoxView.js.map

/***/ }),

/***/ "../../node_modules/react-paginate/dist/index.js":
/*!***********************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/dist/index.js ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _PaginationBoxView = __webpack_require__(/*! ./PaginationBoxView */ "../../node_modules/react-paginate/dist/PaginationBoxView.js");

var _PaginationBoxView2 = _interopRequireDefault(_PaginationBoxView);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _PaginationBoxView2.default;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "../../node_modules/react-paginate/node_modules/prop-types/checkPropTypes.js":
/*!***************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/node_modules/prop-types/checkPropTypes.js ***!
  \***************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var printWarning = function() {};

if (true) {
  var ReactPropTypesSecret = __webpack_require__(/*! ./lib/ReactPropTypesSecret */ "../../node_modules/react-paginate/node_modules/prop-types/lib/ReactPropTypesSecret.js");
  var loggedTypeFailures = {};

  printWarning = function(text) {
    var message = 'Warning: ' + text;
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  };
}

/**
 * Assert that the values match with the type specs.
 * Error messages are memorized and will only be shown once.
 *
 * @param {object} typeSpecs Map of name to a ReactPropType
 * @param {object} values Runtime values that need to be type-checked
 * @param {string} location e.g. "prop", "context", "child context"
 * @param {string} componentName Name of the component for error messages.
 * @param {?Function} getStack Returns the component stack.
 * @private
 */
function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
  if (true) {
    for (var typeSpecName in typeSpecs) {
      if (typeSpecs.hasOwnProperty(typeSpecName)) {
        var error;
        // Prop type validation may throw. In case they do, we don't want to
        // fail the render phase where it didn't fail before. So we log it.
        // After these have been cleaned up, we'll let them throw.
        try {
          // This is intentionally an invariant that gets caught. It's the same
          // behavior as without this statement except with a better message.
          if (typeof typeSpecs[typeSpecName] !== 'function') {
            var err = Error(
              (componentName || 'React class') + ': ' + location + ' type `' + typeSpecName + '` is invalid; ' +
              'it must be a function, usually from the `prop-types` package, but received `' + typeof typeSpecs[typeSpecName] + '`.'
            );
            err.name = 'Invariant Violation';
            throw err;
          }
          error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
        } catch (ex) {
          error = ex;
        }
        if (error && !(error instanceof Error)) {
          printWarning(
            (componentName || 'React class') + ': type specification of ' +
            location + ' `' + typeSpecName + '` is invalid; the type checker ' +
            'function must return `null` or an `Error` but returned a ' + typeof error + '. ' +
            'You may have forgotten to pass an argument to the type checker ' +
            'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' +
            'shape all require an argument).'
          )

        }
        if (error instanceof Error && !(error.message in loggedTypeFailures)) {
          // Only monitor this failure once because there tends to be a lot of the
          // same error.
          loggedTypeFailures[error.message] = true;

          var stack = getStack ? getStack() : '';

          printWarning(
            'Failed ' + location + ' type: ' + error.message + (stack != null ? stack : '')
          );
        }
      }
    }
  }
}

module.exports = checkPropTypes;


/***/ }),

/***/ "../../node_modules/react-paginate/node_modules/prop-types/factoryWithTypeCheckers.js":
/*!************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/node_modules/prop-types/factoryWithTypeCheckers.js ***!
  \************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var assign = __webpack_require__(/*! object-assign */ "../../node_modules/object-assign/index.js");

var ReactPropTypesSecret = __webpack_require__(/*! ./lib/ReactPropTypesSecret */ "../../node_modules/react-paginate/node_modules/prop-types/lib/ReactPropTypesSecret.js");
var checkPropTypes = __webpack_require__(/*! ./checkPropTypes */ "../../node_modules/react-paginate/node_modules/prop-types/checkPropTypes.js");

var printWarning = function() {};

if (true) {
  printWarning = function(text) {
    var message = 'Warning: ' + text;
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  };
}

function emptyFunctionThatReturnsNull() {
  return null;
}

module.exports = function(isValidElement, throwOnDirectAccess) {
  /* global Symbol */
  var ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
  var FAUX_ITERATOR_SYMBOL = '@@iterator'; // Before Symbol spec.

  /**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */
  function getIteratorFn(maybeIterable) {
    var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
    if (typeof iteratorFn === 'function') {
      return iteratorFn;
    }
  }

  /**
   * Collection of methods that allow declaration and validation of props that are
   * supplied to React components. Example usage:
   *
   *   var Props = require('ReactPropTypes');
   *   var MyArticle = React.createClass({
   *     propTypes: {
   *       // An optional string prop named "description".
   *       description: Props.string,
   *
   *       // A required enum prop named "category".
   *       category: Props.oneOf(['News','Photos']).isRequired,
   *
   *       // A prop named "dialog" that requires an instance of Dialog.
   *       dialog: Props.instanceOf(Dialog).isRequired
   *     },
   *     render: function() { ... }
   *   });
   *
   * A more formal specification of how these methods are used:
   *
   *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
   *   decl := ReactPropTypes.{type}(.isRequired)?
   *
   * Each and every declaration produces a function with the same signature. This
   * allows the creation of custom validation functions. For example:
   *
   *  var MyLink = React.createClass({
   *    propTypes: {
   *      // An optional string or URI prop named "href".
   *      href: function(props, propName, componentName) {
   *        var propValue = props[propName];
   *        if (propValue != null && typeof propValue !== 'string' &&
   *            !(propValue instanceof URI)) {
   *          return new Error(
   *            'Expected a string or an URI for ' + propName + ' in ' +
   *            componentName
   *          );
   *        }
   *      }
   *    },
   *    render: function() {...}
   *  });
   *
   * @internal
   */

  var ANONYMOUS = '<<anonymous>>';

  // Important!
  // Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
  var ReactPropTypes = {
    array: createPrimitiveTypeChecker('array'),
    bool: createPrimitiveTypeChecker('boolean'),
    func: createPrimitiveTypeChecker('function'),
    number: createPrimitiveTypeChecker('number'),
    object: createPrimitiveTypeChecker('object'),
    string: createPrimitiveTypeChecker('string'),
    symbol: createPrimitiveTypeChecker('symbol'),

    any: createAnyTypeChecker(),
    arrayOf: createArrayOfTypeChecker,
    element: createElementTypeChecker(),
    instanceOf: createInstanceTypeChecker,
    node: createNodeChecker(),
    objectOf: createObjectOfTypeChecker,
    oneOf: createEnumTypeChecker,
    oneOfType: createUnionTypeChecker,
    shape: createShapeTypeChecker,
    exact: createStrictShapeTypeChecker,
  };

  /**
   * inlined Object.is polyfill to avoid requiring consumers ship their own
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
   */
  /*eslint-disable no-self-compare*/
  function is(x, y) {
    // SameValue algorithm
    if (x === y) {
      // Steps 1-5, 7-10
      // Steps 6.b-6.e: +0 != -0
      return x !== 0 || 1 / x === 1 / y;
    } else {
      // Step 6.a: NaN == NaN
      return x !== x && y !== y;
    }
  }
  /*eslint-enable no-self-compare*/

  /**
   * We use an Error-like object for backward compatibility as people may call
   * PropTypes directly and inspect their output. However, we don't use real
   * Errors anymore. We don't inspect their stack anyway, and creating them
   * is prohibitively expensive if they are created too often, such as what
   * happens in oneOfType() for any type before the one that matched.
   */
  function PropTypeError(message) {
    this.message = message;
    this.stack = '';
  }
  // Make `instanceof Error` still work for returned errors.
  PropTypeError.prototype = Error.prototype;

  function createChainableTypeChecker(validate) {
    if (true) {
      var manualPropTypeCallCache = {};
      var manualPropTypeWarningCount = 0;
    }
    function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
      componentName = componentName || ANONYMOUS;
      propFullName = propFullName || propName;

      if (secret !== ReactPropTypesSecret) {
        if (throwOnDirectAccess) {
          // New behavior only for users of `prop-types` package
          var err = new Error(
            'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
            'Use `PropTypes.checkPropTypes()` to call them. ' +
            'Read more at http://fb.me/use-check-prop-types'
          );
          err.name = 'Invariant Violation';
          throw err;
        } else if ( true && typeof console !== 'undefined') {
          // Old behavior for people using React.PropTypes
          var cacheKey = componentName + ':' + propName;
          if (
            !manualPropTypeCallCache[cacheKey] &&
            // Avoid spamming the console because they are often not actionable except for lib authors
            manualPropTypeWarningCount < 3
          ) {
            printWarning(
              'You are manually calling a React.PropTypes validation ' +
              'function for the `' + propFullName + '` prop on `' + componentName  + '`. This is deprecated ' +
              'and will throw in the standalone `prop-types` package. ' +
              'You may be seeing this warning due to a third-party PropTypes ' +
              'library. See https://fb.me/react-warning-dont-call-proptypes ' + 'for details.'
            );
            manualPropTypeCallCache[cacheKey] = true;
            manualPropTypeWarningCount++;
          }
        }
      }
      if (props[propName] == null) {
        if (isRequired) {
          if (props[propName] === null) {
            return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required ' + ('in `' + componentName + '`, but its value is `null`.'));
          }
          return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required in ' + ('`' + componentName + '`, but its value is `undefined`.'));
        }
        return null;
      } else {
        return validate(props, propName, componentName, location, propFullName);
      }
    }

    var chainedCheckType = checkType.bind(null, false);
    chainedCheckType.isRequired = checkType.bind(null, true);

    return chainedCheckType;
  }

  function createPrimitiveTypeChecker(expectedType) {
    function validate(props, propName, componentName, location, propFullName, secret) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== expectedType) {
        // `propValue` being instance of, say, date/regexp, pass the 'object'
        // check, but we can offer a more precise error message here rather than
        // 'of type `object`'.
        var preciseType = getPreciseType(propValue);

        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + preciseType + '` supplied to `' + componentName + '`, expected ') + ('`' + expectedType + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createAnyTypeChecker() {
    return createChainableTypeChecker(emptyFunctionThatReturnsNull);
  }

  function createArrayOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside arrayOf.');
      }
      var propValue = props[propName];
      if (!Array.isArray(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an array.'));
      }
      for (var i = 0; i < propValue.length; i++) {
        var error = typeChecker(propValue, i, componentName, location, propFullName + '[' + i + ']', ReactPropTypesSecret);
        if (error instanceof Error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createElementTypeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      if (!isValidElement(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createInstanceTypeChecker(expectedClass) {
    function validate(props, propName, componentName, location, propFullName) {
      if (!(props[propName] instanceof expectedClass)) {
        var expectedClassName = expectedClass.name || ANONYMOUS;
        var actualClassName = getClassName(props[propName]);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + actualClassName + '` supplied to `' + componentName + '`, expected ') + ('instance of `' + expectedClassName + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createEnumTypeChecker(expectedValues) {
    if (!Array.isArray(expectedValues)) {
       true ? printWarning('Invalid argument supplied to oneOf, expected an instance of array.') : undefined;
      return emptyFunctionThatReturnsNull;
    }

    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      for (var i = 0; i < expectedValues.length; i++) {
        if (is(propValue, expectedValues[i])) {
          return null;
        }
      }

      var valuesString = JSON.stringify(expectedValues);
      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of value `' + propValue + '` ' + ('supplied to `' + componentName + '`, expected one of ' + valuesString + '.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createObjectOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside objectOf.');
      }
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an object.'));
      }
      for (var key in propValue) {
        if (propValue.hasOwnProperty(key)) {
          var error = typeChecker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
          if (error instanceof Error) {
            return error;
          }
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createUnionTypeChecker(arrayOfTypeCheckers) {
    if (!Array.isArray(arrayOfTypeCheckers)) {
       true ? printWarning('Invalid argument supplied to oneOfType, expected an instance of array.') : undefined;
      return emptyFunctionThatReturnsNull;
    }

    for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
      var checker = arrayOfTypeCheckers[i];
      if (typeof checker !== 'function') {
        printWarning(
          'Invalid argument supplied to oneOfType. Expected an array of check functions, but ' +
          'received ' + getPostfixForTypeWarning(checker) + ' at index ' + i + '.'
        );
        return emptyFunctionThatReturnsNull;
      }
    }

    function validate(props, propName, componentName, location, propFullName) {
      for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
        var checker = arrayOfTypeCheckers[i];
        if (checker(props, propName, componentName, location, propFullName, ReactPropTypesSecret) == null) {
          return null;
        }
      }

      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createNodeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      if (!isNode(props[propName])) {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`, expected a ReactNode.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      for (var key in shapeTypes) {
        var checker = shapeTypes[key];
        if (!checker) {
          continue;
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createStrictShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      // We need to check all keys in case some are required but missing from
      // props.
      var allKeys = assign({}, props[propName], shapeTypes);
      for (var key in allKeys) {
        var checker = shapeTypes[key];
        if (!checker) {
          return new PropTypeError(
            'Invalid ' + location + ' `' + propFullName + '` key `' + key + '` supplied to `' + componentName + '`.' +
            '\nBad object: ' + JSON.stringify(props[propName], null, '  ') +
            '\nValid keys: ' +  JSON.stringify(Object.keys(shapeTypes), null, '  ')
          );
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }

    return createChainableTypeChecker(validate);
  }

  function isNode(propValue) {
    switch (typeof propValue) {
      case 'number':
      case 'string':
      case 'undefined':
        return true;
      case 'boolean':
        return !propValue;
      case 'object':
        if (Array.isArray(propValue)) {
          return propValue.every(isNode);
        }
        if (propValue === null || isValidElement(propValue)) {
          return true;
        }

        var iteratorFn = getIteratorFn(propValue);
        if (iteratorFn) {
          var iterator = iteratorFn.call(propValue);
          var step;
          if (iteratorFn !== propValue.entries) {
            while (!(step = iterator.next()).done) {
              if (!isNode(step.value)) {
                return false;
              }
            }
          } else {
            // Iterator will provide entry [k,v] tuples rather than values.
            while (!(step = iterator.next()).done) {
              var entry = step.value;
              if (entry) {
                if (!isNode(entry[1])) {
                  return false;
                }
              }
            }
          }
        } else {
          return false;
        }

        return true;
      default:
        return false;
    }
  }

  function isSymbol(propType, propValue) {
    // Native Symbol.
    if (propType === 'symbol') {
      return true;
    }

    // 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
    if (propValue['@@toStringTag'] === 'Symbol') {
      return true;
    }

    // Fallback for non-spec compliant Symbols which are polyfilled.
    if (typeof Symbol === 'function' && propValue instanceof Symbol) {
      return true;
    }

    return false;
  }

  // Equivalent of `typeof` but with special handling for array and regexp.
  function getPropType(propValue) {
    var propType = typeof propValue;
    if (Array.isArray(propValue)) {
      return 'array';
    }
    if (propValue instanceof RegExp) {
      // Old webkits (at least until Android 4.0) return 'function' rather than
      // 'object' for typeof a RegExp. We'll normalize this here so that /bla/
      // passes PropTypes.object.
      return 'object';
    }
    if (isSymbol(propType, propValue)) {
      return 'symbol';
    }
    return propType;
  }

  // This handles more types than `getPropType`. Only used for error messages.
  // See `createPrimitiveTypeChecker`.
  function getPreciseType(propValue) {
    if (typeof propValue === 'undefined' || propValue === null) {
      return '' + propValue;
    }
    var propType = getPropType(propValue);
    if (propType === 'object') {
      if (propValue instanceof Date) {
        return 'date';
      } else if (propValue instanceof RegExp) {
        return 'regexp';
      }
    }
    return propType;
  }

  // Returns a string that is postfixed to a warning about an invalid type.
  // For example, "undefined" or "of type array"
  function getPostfixForTypeWarning(value) {
    var type = getPreciseType(value);
    switch (type) {
      case 'array':
      case 'object':
        return 'an ' + type;
      case 'boolean':
      case 'date':
      case 'regexp':
        return 'a ' + type;
      default:
        return type;
    }
  }

  // Returns class name of the object, if any.
  function getClassName(propValue) {
    if (!propValue.constructor || !propValue.constructor.name) {
      return ANONYMOUS;
    }
    return propValue.constructor.name;
  }

  ReactPropTypes.checkPropTypes = checkPropTypes;
  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};


/***/ }),

/***/ "../../node_modules/react-paginate/node_modules/prop-types/index.js":
/*!******************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/node_modules/prop-types/index.js ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

if (true) {
  var REACT_ELEMENT_TYPE = (typeof Symbol === 'function' &&
    Symbol.for &&
    Symbol.for('react.element')) ||
    0xeac7;

  var isValidElement = function(object) {
    return typeof object === 'object' &&
      object !== null &&
      object.$$typeof === REACT_ELEMENT_TYPE;
  };

  // By explicitly using `prop-types` you are opting into new development behavior.
  // http://fb.me/prop-types-in-prod
  var throwOnDirectAccess = true;
  module.exports = __webpack_require__(/*! ./factoryWithTypeCheckers */ "../../node_modules/react-paginate/node_modules/prop-types/factoryWithTypeCheckers.js")(isValidElement, throwOnDirectAccess);
} else {}


/***/ }),

/***/ "../../node_modules/react-paginate/node_modules/prop-types/lib/ReactPropTypesSecret.js":
/*!*************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/node_modules/prop-types/lib/ReactPropTypesSecret.js ***!
  \*************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

module.exports = ReactPropTypesSecret;


/***/ }),

/***/ "./api/reports.js":
/*!************************!*\
  !*** ./api/reports.js ***!
  \************************/
/*! exports provided: MyReportsApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyReportsApi", function() { return MyReportsApi; });
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__["default"].getInstance();
var appPath = '/namespaces/system/apps/ReportGenerationApp';
var programPath = "".concat(appPath, "/spark/ReportGenerationSpark");
var methodsPath = "".concat(programPath, "/methods");
var reportsPath = "".concat(methodsPath, "/reports");
var basepath = "".concat(reportsPath, "/:reportId");
var MyReportsApi = {
  list: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', reportsPath),
  getDetails: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(reportsPath, "/download")),
  getReport: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(reportsPath, "/info")),
  generateReport: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', reportsPath),
  deleteReport: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', basepath),
  saveReport: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/save")),
  // report service lifecycle
  getApp: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', appPath),
  startService: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(programPath, "/start")),
  stopService: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(programPath, "/stop")),
  getServiceStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(programPath, "/status")),
  pollServiceStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'POLL', "".concat(programPath, "/status"), {
    interval: 2000
  }),
  createApp: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'PUT', 'REQUEST', appPath),
  ping: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(methodsPath, "/health")),
  deleteApp: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', appPath)
};

/***/ }),

/***/ "./components/Duration/index.js":
/*!**************************************!*\
  !*** ./components/Duration/index.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Duration; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "../../node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var Duration =
/*#__PURE__*/
function (_Component) {
  _inherits(Duration, _Component);

  function Duration() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, Duration);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(Duration)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      displayDuration: null
    });

    _defineProperty(_assertThisInitialized(_this), "calculateTimeCallback", function (duration) {
      var delay = services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_SECOND_MS"];

      if (!_this.props.showFullDuration) {
        var absDuration = Math.abs(duration);

        if (absDuration > services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_HOUR_SECONDS"]) {
          delay = 15 * services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_MIN_SECONDS"];
        } else if (absDuration > 5 * services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_MIN_SECONDS"]) {
          delay = services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_MIN_SECONDS"];
        } else if (absDuration > 2 * services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_MIN_SECONDS"]) {
          delay = 15 * services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_SECOND_MS"];
        }
      }

      _this.timeout = setTimeout(function () {
        _this.calculateTime();
      }, delay);
    });

    return _this;
  }

  _createClass(Duration, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      this.calculateTime();
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (nextProps.targetTime !== this.props.targetTime) {
        this.stopCounter();
      }

      this.calculateTime(nextProps.targetTime);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.stopCounter();
    }
  }, {
    key: "stopCounter",
    value: function stopCounter() {
      if (this.timeout) {
        clearTimeout(this.timeout);
      }
    }
  }, {
    key: "calculateTime",
    value: function calculateTime() {
      var newTime = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.props.targetTime;

      if (!newTime) {
        return;
      }

      var targetTime = newTime;

      if (!this.props.isMillisecond) {
        targetTime *= services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_SECOND_MS"];
      }

      if (this.props.showFullDuration) {
        var duration = new Date().valueOf() - targetTime;
        this.setState({
          displayDuration: Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableDuration"])(duration /= services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_SECOND_MS"])
        }, this.calculateTimeCallback.bind(this, duration));
      } else {
        var _duration = targetTime - new Date().valueOf();

        var isPast = _duration < 0;
        this.setState({
          displayDuration: moment__WEBPACK_IMPORTED_MODULE_2___default.a.duration(_duration).humanize(isPast)
        }, this.calculateTimeCallback.bind(this, _duration));
      }
    }
  }, {
    key: "render",
    value: function render() {
      if (!this.props.targetTime) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "duration-display"
        }, "--");
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "duration-display"
      }, this.state.displayDuration);
    }
  }]);

  return Duration;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(Duration, "propTypes", {
  targetTime: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  isMillisecond: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  showFullDuration: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});

_defineProperty(Duration, "defaultProps", {
  isMillisecond: true,
  showFullDuration: false
});



/***/ }),

/***/ "./components/NamespacesPicker/NamespacesPicker.scss":
/*!***********************************************************!*\
  !*** ./components/NamespacesPicker/NamespacesPicker.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./NamespacesPicker.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/NamespacesPicker/NamespacesPicker.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/NamespacesPicker/NamespacesPopover.js":
/*!**********************************************************!*\
  !*** ./components/NamespacesPicker/NamespacesPopover.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/UncontrolledComponents */ "./components/UncontrolledComponents/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_8__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









var PREFIX = 'features.NamespacesPicker';

var NamespacesPopoverView =
/*#__PURE__*/
function (_Component) {
  _inherits(NamespacesPopoverView, _Component);

  function NamespacesPopoverView() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, NamespacesPopoverView);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(NamespacesPopoverView)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])(),
      namespaces: _this.getNamespaceList()
    });

    _defineProperty(_assertThisInitialized(_this), "namespaceClick", function (ns) {
      var index = _this.props.namespacesPick.indexOf(ns);

      var namespacesPick = _toConsumableArray(_this.props.namespacesPick);

      if (index === -1) {
        namespacesPick.push(ns);
      } else {
        namespacesPick.splice(index, 1);
      }

      _this.props.setNamespacesPick(namespacesPick);
    });

    _defineProperty(_assertThisInitialized(_this), "selectAll", function () {
      _this.props.setNamespacesPick(_this.state.namespaces);
    });

    _defineProperty(_assertThisInitialized(_this), "clearAll", function () {
      _this.props.setNamespacesPick([]);
    });

    return _this;
  }

  _createClass(NamespacesPopoverView, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var _this2 = this;

      this.namespaceStoreSub = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["default"].subscribe(function () {
        _this2.setState({
          namespaces: _this2.getNamespaceList()
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.namespaceStoreSub) {
        this.namespaceStoreSub();
      }
    }
  }, {
    key: "getNamespaceList",
    value: function getNamespaceList() {
      var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])();
      return services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["default"].getState().namespaces.map(function (ns) {
        return ns.name;
      }).filter(function (ns) {
        return ns !== namespace;
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      if (this.state.namespaces.length === 0) {
        return null;
      }

      var targetElem = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "monitor-more text-right"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".monitorMore")));
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_2__["default"], {
        target: function target() {
          return targetElem;
        },
        className: "namespaces-list-popover",
        placement: "top",
        bubbleEvent: false,
        enableInteractionInPopover: true
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "popover-content"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "title"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".popoverHeader"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "namespaces-count"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".namespacesCount"), {
        context: this.state.namespaces.length + 1
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "namespaces-list"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "namespace-row non-selectable"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "checkbox-column"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_6__["UncontrolledDropdown"], {
        className: "toggle-all-dropdown"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_7__["DropdownToggle"], {
        className: "dropdown-toggle-btn"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-caret-square-o-down"
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_7__["DropdownMenu"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_7__["DropdownItem"], {
        className: "toggle-option",
        onClick: this.selectAll
      }, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".selectAll"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_7__["DropdownItem"], {
        className: "toggle-option",
        onClick: this.clearAll
      }, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".clearAll")))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "namespace-section"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".namespaceName")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("hr", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "list"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "namespace-row non-selectable"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "checkbox-column"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-check"
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "namespace-section"
      }, this.state.namespace)), this.state.namespaces.map(function (ns) {
        var isPicked = _this3.props.namespacesPick.indexOf(ns) !== -1;
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "namespace-row",
          onClick: _this3.namespaceClick.bind(_this3, ns)
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "checkbox-column"
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
          name: isPicked ? 'icon-check-square' : 'icon-square-o'
        })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "namespace-section"
        }, ns));
      })))));
    }
  }]);

  return NamespacesPopoverView;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(NamespacesPopoverView, "propTypes", {
  namespacesPick: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array,
  setNamespacesPick: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
});

var mapStateToProps = function mapStateToProps(state, ownProps) {
  return {
    namespacesPick: state.namespaces.namespacesPick,
    setNamespacesPick: ownProps.setNamespacesPick
  };
};

var NamespacesPopover = Object(react_redux__WEBPACK_IMPORTED_MODULE_5__["connect"])(mapStateToProps)(NamespacesPopoverView);
/* harmony default export */ __webpack_exports__["default"] = (NamespacesPopover);

/***/ }),

/***/ "./components/NamespacesPicker/index.js":
/*!**********************************************!*\
  !*** ./components/NamespacesPicker/index.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var components_NamespacesPicker_NamespacesPopover__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/NamespacesPicker/NamespacesPopover */ "./components/NamespacesPicker/NamespacesPopover.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PREFIX = 'features.NamespacesPicker';

__webpack_require__(/*! ./NamespacesPicker.scss */ "./components/NamespacesPicker/NamespacesPicker.scss");

function NamespacesPickerView(_ref) {
  var namespacesPick = _ref.namespacesPick,
      setNamespacesPick = _ref.setNamespacesPick;
  var monitorTitle;

  if (namespacesPick.length === 0) {
    monitorTitle = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "namespace-list-monitor"
    }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".monitorNamespace"), {
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])()
    }));
  } else {
    var namespacesList = [Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])()].concat(namespacesPick);
    var namespaces = namespacesList.map(function (ns) {
      return "'".concat(ns, "'");
    }).join('; ');
    var title = namespacesList.join('\n');
    monitorTitle = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "namespace-list-monitor",
      title: title
    }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".monitorMultipleNamespaces"), {
      count: namespacesPick.length + 1,
      namespaces: namespaces
    }));
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "namespace-picker float-right"
  }, monitorTitle, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "monitor-more text-right"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "d-inline-block"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_NamespacesPicker_NamespacesPopover__WEBPACK_IMPORTED_MODULE_4__["default"], {
    setNamespacesPick: setNamespacesPick
  }))));
}

NamespacesPickerView.propTypes = {
  namespacesPick: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array,
  setNamespacesPick: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
};

var mapStateToProps = function mapStateToProps(state, ownProps) {
  return {
    namespacesPick: state.namespaces.namespacesPick,
    setNamespacesPick: ownProps.setNamespacesPick
  };
};

var NamespacesPicker = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps)(NamespacesPickerView);
/* harmony default export */ __webpack_exports__["default"] = (NamespacesPicker);

/***/ }),

/***/ "./components/PaginationWithTitle/PaginationWithTitle.scss":
/*!*****************************************************************!*\
  !*** ./components/PaginationWithTitle/PaginationWithTitle.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./PaginationWithTitle.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PaginationWithTitle/PaginationWithTitle.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PaginationWithTitle/index.js":
/*!*************************************************!*\
  !*** ./components/PaginationWithTitle/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PaginationWithTitle; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_paginate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-paginate */ "../../node_modules/react-paginate/dist/index.js");
/* harmony import */ var react_paginate__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_paginate__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




__webpack_require__(/*! ./PaginationWithTitle.scss */ "./components/PaginationWithTitle/PaginationWithTitle.scss");

var PaginationWithTitle =
/*#__PURE__*/
function (_Component) {
  _inherits(PaginationWithTitle, _Component);

  function PaginationWithTitle() {
    _classCallCheck(this, PaginationWithTitle);

    return _possibleConstructorReturn(this, _getPrototypeOf(PaginationWithTitle).apply(this, arguments));
  }

  _createClass(PaginationWithTitle, [{
    key: "renderPaginationComponent",
    value: function renderPaginationComponent() {
      if (this.props.totalPages < 2) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react_paginate__WEBPACK_IMPORTED_MODULE_1___default.a, {
        pageCount: this.props.totalPages,
        pageRangeDisplayed: 3,
        marginPagesDisplayed: 1,
        breakLabel: react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("span", null, "..."),
        breakClassName: 'ellipsis',
        previousLabel: react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("span", {
          className: "fa fa-angle-left"
        }),
        nextLabel: react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("span", {
          className: "fa fa-angle-right"
        }),
        onPageChange: this.props.handlePageChange.bind(this),
        disableInitialCallback: true,
        initialPage: this.props.currentPage - 1,
        forcePage: this.props.currentPage - 1,
        containerClassName: 'page-list',
        activeClassName: 'current-page'
      });
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("span", {
        className: "pagination-with-title"
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("ul", {
        className: "total-entities"
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("span", null, this.props.title)), this.renderPaginationComponent());
    }
  }]);

  return PaginationWithTitle;
}(react__WEBPACK_IMPORTED_MODULE_2__["Component"]);

_defineProperty(PaginationWithTitle, "propTypes", {
  currentPage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  totalPages: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  title: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  handlePageChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
});



/***/ }),

/***/ "./components/Reports/Customizer/ActionButtons/index.js":
/*!**************************************************************!*\
  !*** ./components/Reports/Customizer/ActionButtons/index.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Reports/store/ReportsStore */ "./components/Reports/store/ReportsStore.js");
/* harmony import */ var components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Reports/store/ActionCreator */ "./components/Reports/store/ActionCreator.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PREFIX = 'features.Reports.Customizer';

function ActionButtonsView(_ref) {
  var clearSelection = _ref.clearSelection,
      timeRange = _ref.timeRange,
      customizer = _ref.customizer,
      status = _ref.status;
  var disabled = !timeRange.selection || !customizer.pipelines && !customizer.customApps || status.statusSelections.length === 0;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "action-buttons"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("button", {
    className: "btn btn-primary",
    onClick: components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_4__["generateReport"],
    disabled: disabled
  }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".generate"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("button", {
    className: "btn btn-link",
    onClick: clearSelection
  }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".clear"))));
}

ActionButtonsView.propTypes = {
  clearSelection: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func,
  timeRange: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  customizer: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  status: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    timeRange: state.timeRange,
    customizer: state.customizer,
    status: state.status
  };
};

var mapDispatch = function mapDispatch(dispatch) {
  return {
    clearSelection: function clearSelection() {
      dispatch({
        type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_3__["ReportsActions"].clearSelection
      });
    }
  };
};

var ActionButtons = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps, mapDispatch)(ActionButtonsView);
/* harmony default export */ __webpack_exports__["default"] = (ActionButtons);

/***/ }),

/***/ "./components/Reports/Customizer/AppTypeSelector/index.js":
/*!****************************************************************!*\
  !*** ./components/Reports/Customizer/AppTypeSelector/index.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Reports/store/ReportsStore */ "./components/Reports/store/ReportsStore.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PREFIX = 'features.Reports.Customizer';
var OPTIONS = ['pipelines', 'customApps'];
AppTypeSelectorView.propTypes = {
  onClick: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
};
OPTIONS.forEach(function (option) {
  AppTypeSelectorView.propTypes[option] = prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool;
});

function AppTypeSelectorView(props) {
  var _this = this;

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "app-type-selector"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "title"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".header"))), OPTIONS.map(function (option) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "option",
      key: option
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
      onClick: props.onClick.bind(_this, option)
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
      name: props[option] ? 'icon-check-square' : 'icon-square-o'
    }), i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".Options.").concat(option))));
  }));
}

var mapStateToProps = function mapStateToProps(state) {
  var obj = {};
  OPTIONS.forEach(function (option) {
    obj[option] = state.customizer[option];
  });
  return obj;
};

var mapDispatch = function mapDispatch(dispatch) {
  return {
    onClick: function onClick(option) {
      dispatch({
        type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_3__["ReportsActions"].toggleCustomizerOption,
        payload: {
          type: option
        }
      });
    }
  };
};

var AppTypeSelector = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["connect"])(mapStateToProps, mapDispatch)(AppTypeSelectorView);
/* harmony default export */ __webpack_exports__["default"] = (AppTypeSelector);

/***/ }),

/***/ "./components/Reports/Customizer/ColumnsSelector/index.js":
/*!****************************************************************!*\
  !*** ./components/Reports/Customizer/ColumnsSelector/index.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Reports/store/ReportsStore */ "./components/Reports/store/ReportsStore.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PREFIX = 'features.Reports.Customizer';
var OPTIONS = ['namespace', 'status', 'start', 'end', 'duration', 'user', 'startMethod', 'runtimeArgs', 'numLogWarnings', 'numLogErrors', 'numRecordsOut'];
ColumnsSelectorView.propTypes = {
  onClick: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
};
OPTIONS.forEach(function (option) {
  ColumnsSelectorView.propTypes[option] = prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool;
});

function ColumnsSelectorView(props) {
  var _this = this;

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "columns-selector"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "title"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".selectColumns"))), OPTIONS.map(function (option) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      key: option,
      className: "option"
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
      onClick: props.onClick.bind(_this, option)
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
      name: props[option] ? 'icon-check-square' : 'icon-square-o'
    }), i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".Options.").concat(option))));
  }));
}

var mapStateToProps = function mapStateToProps(state) {
  var obj = {};
  OPTIONS.forEach(function (option) {
    obj[option] = state.customizer[option];
  });
  return obj;
};

var mapDispatch = function mapDispatch(dispatch) {
  return {
    onClick: function onClick(option) {
      dispatch({
        type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_3__["ReportsActions"].toggleCustomizerOption,
        payload: {
          type: option
        }
      });
    }
  };
};

var ColumnsSelector = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["connect"])(mapStateToProps, mapDispatch)(ColumnsSelectorView);
/* harmony default export */ __webpack_exports__["default"] = (ColumnsSelector);

/***/ }),

/***/ "./components/Reports/Customizer/Customizer.scss":
/*!*******************************************************!*\
  !*** ./components/Reports/Customizer/Customizer.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./Customizer.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/Customizer/Customizer.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Reports/Customizer/StatusSelector/StatusPopover.js":
/*!***********************************************************************!*\
  !*** ./components/Reports/Customizer/StatusSelector/StatusPopover.js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Reports/store/ReportsStore */ "./components/Reports/store/ReportsStore.js");
/* harmony import */ var components_Reports_Customizer_StatusSelector_StatusViewer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Reports/Customizer/StatusSelector/StatusViewer */ "./components/Reports/Customizer/StatusSelector/StatusViewer.js");
/* harmony import */ var services_StatusMapper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/StatusMapper */ "./services/StatusMapper.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_8__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */










var StatusPopoverView =
/*#__PURE__*/
function (_Component) {
  _inherits(StatusPopoverView, _Component);

  function StatusPopoverView() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, StatusPopoverView);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(StatusPopoverView)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      selections: _this.props.selections
    });

    _defineProperty(_assertThisInitialized(_this), "isSelected", function (option) {
      return _this.state.selections.indexOf(option) !== -1;
    });

    _defineProperty(_assertThisInitialized(_this), "toggleOption", function (option) {
      var index = _this.state.selections.indexOf(option);

      var newArr = _toConsumableArray(_this.state.selections);

      if (index === -1) {
        newArr.push(option);
      } else {
        newArr.splice(index, 1);
      }

      _this.setState({
        selections: newArr
      });
    });

    _defineProperty(_assertThisInitialized(_this), "apply", function () {
      _this.props.onApply(_this.state.selections); // Closing popover


      document.body.click();
    });

    _defineProperty(_assertThisInitialized(_this), "onTogglePopover", function (showPopover) {
      if (!showPopover) {
        _this.setState({
          selections: _this.props.selections
        });
      }
    });

    return _this;
  }

  _createClass(StatusPopoverView, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.setState({
        selections: nextProps.selections
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_2__["default"], {
        target: components_Reports_Customizer_StatusSelector_StatusViewer__WEBPACK_IMPORTED_MODULE_6__["default"].bind(null, this.state.selections),
        className: "status-selector-popover",
        placement: "bottom",
        bubbleEvent: false,
        enableInteractionInPopover: true,
        injectOnToggle: true,
        onTogglePopover: this.onTogglePopover
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "options"
      }, components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_5__["STATUS_OPTIONS"].map(function (option) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          key: option,
          className: "option",
          onClick: _this2.toggleOption.bind(_this2, option)
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
          name: _this2.isSelected(option) ? 'icon-check-square' : 'icon-square-o'
        }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
          name: "icon-circle",
          className: option.toLowerCase()
        }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, services_StatusMapper__WEBPACK_IMPORTED_MODULE_7__["default"].lookupDisplayStatus(option)));
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "action"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("button", {
        className: "btn btn-primary",
        onClick: this.apply
      }, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate('commons.apply'))));
    }
  }]);

  return StatusPopoverView;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(StatusPopoverView, "propTypes", {
  selections: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array,
  onApply: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
});

var mapStateToProps = function mapStateToProps(state) {
  return {
    selections: state.status.statusSelections
  };
};

var mapDispatch = function mapDispatch(dispatch) {
  return {
    onApply: function onApply(statusSelections) {
      dispatch({
        type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_5__["ReportsActions"].setStatus,
        payload: {
          statusSelections: statusSelections
        }
      });
    }
  };
};

var StatusPopover = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["connect"])(mapStateToProps, mapDispatch)(StatusPopoverView);
/* harmony default export */ __webpack_exports__["default"] = (StatusPopover);

/***/ }),

/***/ "./components/Reports/Customizer/StatusSelector/StatusSelector.scss":
/*!**************************************************************************!*\
  !*** ./components/Reports/Customizer/StatusSelector/StatusSelector.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./StatusSelector.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/Customizer/StatusSelector/StatusSelector.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Reports/Customizer/StatusSelector/StatusViewer.js":
/*!**********************************************************************!*\
  !*** ./components/Reports/Customizer/StatusSelector/StatusViewer.js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Reports/store/ReportsStore */ "./components/Reports/store/ReportsStore.js");
/* harmony import */ var components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Reports/store/ActionCreator */ "./components/Reports/store/ActionCreator.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PREFIX = 'features.Reports.Customizer.StatusSelector';

function StatusViewer(selections) {
  var text = i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".selectOne"));
  var numSelections = selections.length;

  if (numSelections > 0) {
    if (numSelections === components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_3__["STATUS_OPTIONS"].length) {
      text = i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".allStatuses"));
    } else {
      text = Object(components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_4__["getStatusSelectionsLabels"])(selections).join(', ');

      if (numSelections > 1) {
        text = "(".concat(numSelections, ") ") + text;
      }
    }
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "status-viewer"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "status-text"
  }, text), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "caret-dropdown"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
    name: "icon-caret-down"
  })));
}

StatusViewer.propTypes = {
  selections: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array
};
/* harmony default export */ __webpack_exports__["default"] = (StatusViewer);

/***/ }),

/***/ "./components/Reports/Customizer/StatusSelector/index.js":
/*!***************************************************************!*\
  !*** ./components/Reports/Customizer/StatusSelector/index.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return StatusSelector; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_Reports_Customizer_StatusSelector_StatusPopover__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/Reports/Customizer/StatusSelector/StatusPopover */ "./components/Reports/Customizer/StatusSelector/StatusPopover.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_2__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */



var PREFIX = 'features.Reports.Customizer.StatusSelector';

__webpack_require__(/*! ./StatusSelector.scss */ "./components/Reports/Customizer/StatusSelector/StatusSelector.scss");

function StatusSelector() {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "status-selector"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "title"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".selectStatus"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_Customizer_StatusSelector_StatusPopover__WEBPACK_IMPORTED_MODULE_1__["default"], null));
}

/***/ }),

/***/ "./components/Reports/Customizer/TimeRangeSelector/TimeRangePopover.js":
/*!*****************************************************************************!*\
  !*** ./components/Reports/Customizer/TimeRangeSelector/TimeRangePopover.js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_TimeRangePicker__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/TimeRangePicker */ "./components/TimeRangePicker/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Reports/store/ReportsStore */ "./components/Reports/store/ReportsStore.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_7__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








var PREFIX = 'features.Reports.Customizer.TimeRangeSelector';

var TimeRangePopoverView =
/*#__PURE__*/
function (_Component) {
  _inherits(TimeRangePopoverView, _Component);

  function TimeRangePopoverView() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, TimeRangePopoverView);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(TimeRangePopoverView)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      selection: _this.props.selection,
      start: _this.props.start,
      end: _this.props.end
    });

    _defineProperty(_assertThisInitialized(_this), "changeSelection", function (selection) {
      _this.setState({
        selection: selection
      });
    });

    _defineProperty(_assertThisInitialized(_this), "onCustomRangeChange", function (_ref) {
      var start = _ref.start,
          end = _ref.end;

      _this.setState({
        start: start,
        end: end
      });
    });

    _defineProperty(_assertThisInitialized(_this), "apply", function () {
      var selection = _this.state.selection;
      var start = null,
          end = null;

      if (selection === 'custom') {
        start = _this.state.start;
        end = _this.state.end;
      }

      _this.props.onApply({
        selection: selection,
        start: start,
        end: end
      }); // to close popover


      document.body.click();
    });

    _defineProperty(_assertThisInitialized(_this), "renderCustomRange", function () {
      if (_this.state.selection !== 'custom') {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "custom-range-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_TimeRangePicker__WEBPACK_IMPORTED_MODULE_4__["default"], {
        onChange: _this.onCustomRangeChange,
        start: _this.state.start,
        end: _this.state.end
      }));
    });

    _defineProperty(_assertThisInitialized(_this), "renderApplyButton", function () {
      var startTime = parseInt(_this.state.start, 10);
      var endTime = parseInt(_this.state.end, 10);
      /**
       * Disabled Rule
       *  1. Must have time selection
       *  2. If time selection is custom range:
       *    a. Must have start and end time
       *    b. End time must be greater than startTime
       **/

      var disabled = !_this.state.selection || _this.state.selection === 'custom' && (!startTime || !endTime || !(startTime < endTime));
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "apply-button"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("button", {
        className: "btn btn-primary",
        disabled: disabled,
        onClick: _this.apply
      }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('commons.apply')));
    });

    return _this;
  }

  _createClass(TimeRangePopoverView, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.setState({
        selection: nextProps.selection,
        start: nextProps.start,
        end: nextProps.end
      });
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_2__["default"], {
        target: function target() {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
            name: "icon-calendar"
          });
        },
        className: "time-range-popover",
        placement: "bottom",
        bubbleEvent: false,
        enableInteractionInPopover: true,
        injectOnToggle: true,
        modifiers: {
          flip: {
            enabled: true,
            behavior: ['bottom', 'left']
          },
          preventOverflow: {
            enabled: true,
            boundariesElement: 'scrollParent'
          }
        }
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "title"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".labelWithColon"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "options"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "option",
        onClick: this.changeSelection.bind(this, 'last30')
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
        name: this.state.selection === 'last30' ? 'icon-circle' : 'icon-circle-o'
      }), i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".last30Min"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "option",
        onClick: this.changeSelection.bind(this, 'lastHour')
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
        name: this.state.selection === 'lastHour' ? 'icon-circle' : 'icon-circle-o'
      }), i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".lastHour"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "option",
        onClick: this.changeSelection.bind(this, 'custom')
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
        name: this.state.selection === 'custom' ? 'icon-circle' : 'icon-circle-o'
      }), i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".customRange")))), this.renderCustomRange(), this.renderApplyButton());
    }
  }]);

  return TimeRangePopoverView;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(TimeRangePopoverView, "propTypes", {
  onApply: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func,
  start: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  end: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  selection: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
});

var mapStateToProps = function mapStateToProps(state) {
  return {
    start: state.timeRange.start,
    end: state.timeRange.end,
    selection: state.timeRange.selection
  };
};

var mapDispatch = function mapDispatch(dispatch) {
  return {
    onApply: function onApply(payload) {
      dispatch({
        type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_6__["ReportsActions"].setTimeRange,
        payload: payload
      });
    }
  };
};

var TimeRangePopover = Object(react_redux__WEBPACK_IMPORTED_MODULE_5__["connect"])(mapStateToProps, mapDispatch)(TimeRangePopoverView);
/* harmony default export */ __webpack_exports__["default"] = (TimeRangePopover);

/***/ }),

/***/ "./components/Reports/Customizer/TimeRangeSelector/TimeRangeSelector.scss":
/*!********************************************************************************!*\
  !*** ./components/Reports/Customizer/TimeRangeSelector/TimeRangeSelector.scss ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./TimeRangeSelector.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/Customizer/TimeRangeSelector/TimeRangeSelector.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Reports/Customizer/TimeRangeSelector/index.js":
/*!******************************************************************!*\
  !*** ./components/Reports/Customizer/TimeRangeSelector/index.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Reports_Customizer_TimeRangeSelector_TimeRangePopover__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Reports/Customizer/TimeRangeSelector/TimeRangePopover */ "./components/Reports/Customizer/TimeRangeSelector/TimeRangePopover.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ "../../node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PREFIX = 'features.Reports.Customizer.TimeRangeSelector';

__webpack_require__(/*! ./TimeRangeSelector.scss */ "./components/Reports/Customizer/TimeRangeSelector/TimeRangeSelector.scss");

var format = 'MMM. D, YYYY h:mma';

function renderDisplay(selection, start, end) {
  var startTime, endTime;

  if (selection === 'custom') {
    startTime = moment__WEBPACK_IMPORTED_MODULE_4___default()(start).format(format);
    endTime = moment__WEBPACK_IMPORTED_MODULE_4___default()(end).format(format);
  }

  switch (selection) {
    case 'last30':
      return i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".last30Minutes"));

    case 'lastHour':
      return i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".lastHour"));

    case 'custom':
      return i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".timeRange"), {
        startTime: startTime,
        endTime: endTime
      });

    default:
      return i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".select"));
  }
}

function TimeRangeSelectorView(_ref) {
  var selection = _ref.selection,
      start = _ref.start,
      end = _ref.end;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "reports-time-range-selector"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "title"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".label"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "time-selector-value"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "time-icon"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_Customizer_TimeRangeSelector_TimeRangePopover__WEBPACK_IMPORTED_MODULE_2__["default"], null)), renderDisplay(selection, start, end)));
}

TimeRangeSelectorView.propTypes = {
  selection: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  start: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  end: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    selection: state.timeRange.selection,
    start: state.timeRange.start,
    end: state.timeRange.end
  };
};

var TimeRangeSelector = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["connect"])(mapStateToProps)(TimeRangeSelectorView);
/* harmony default export */ __webpack_exports__["default"] = (TimeRangeSelector);

/***/ }),

/***/ "./components/Reports/Customizer/index.js":
/*!************************************************!*\
  !*** ./components/Reports/Customizer/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Customizer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_Reports_Customizer_ColumnsSelector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Reports/Customizer/ColumnsSelector */ "./components/Reports/Customizer/ColumnsSelector/index.js");
/* harmony import */ var components_Reports_Customizer_TimeRangeSelector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Reports/Customizer/TimeRangeSelector */ "./components/Reports/Customizer/TimeRangeSelector/index.js");
/* harmony import */ var components_Reports_Customizer_AppTypeSelector__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Reports/Customizer/AppTypeSelector */ "./components/Reports/Customizer/AppTypeSelector/index.js");
/* harmony import */ var components_Reports_Customizer_ActionButtons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Reports/Customizer/ActionButtons */ "./components/Reports/Customizer/ActionButtons/index.js");
/* harmony import */ var components_Reports_Customizer_StatusSelector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Reports/Customizer/StatusSelector */ "./components/Reports/Customizer/StatusSelector/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_8__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









var PREFIX = 'features.Reports.Customizer';

__webpack_require__(/*! ./Customizer.scss */ "./components/Reports/Customizer/Customizer.scss");

var Customizer =
/*#__PURE__*/
function (_Component) {
  _inherits(Customizer, _Component);

  function Customizer() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, Customizer);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(Customizer)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      isCollapsed: false
    });

    _defineProperty(_assertThisInitialized(_this), "toggleCollapsed", function () {
      _this.setState({
        isCollapsed: !_this.state.isCollapsed
      });
    });

    _defineProperty(_assertThisInitialized(_this), "renderCollapsedDetail", function () {
      if (_this.state.isCollapsed) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "options-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_Customizer_AppTypeSelector__WEBPACK_IMPORTED_MODULE_4__["default"], null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_Customizer_StatusSelector__WEBPACK_IMPORTED_MODULE_6__["default"], null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_Customizer_ColumnsSelector__WEBPACK_IMPORTED_MODULE_2__["default"], null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_Customizer_TimeRangeSelector__WEBPACK_IMPORTED_MODULE_3__["default"], null)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_Customizer_ActionButtons__WEBPACK_IMPORTED_MODULE_5__["default"], null));
    });

    return _this;
  }

  _createClass(Customizer, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()('customizer-container', {
          collapsed: this.state.isCollapsed
        })
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "collapsed-toggle-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "toggle",
        onClick: this.toggleCollapsed
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_1__["default"], {
        name: this.state.isCollapsed ? 'icon-caret-right' : 'icon-caret-down'
      }), this.state.isCollapsed ? i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".show")) : i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".hide")))), this.renderCollapsedDetail());
    }
  }]);

  return Customizer;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);



/***/ }),

/***/ "./components/Reports/Reports.scss":
/*!*****************************************!*\
  !*** ./components/Reports/Reports.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Reports.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/Reports.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Reports/ReportsAppDelete/index.js":
/*!******************************************************!*\
  !*** ./components/Reports/ReportsAppDelete/index.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ReportsAppDelete; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var api_reports__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! api/reports */ "./api/reports.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var ReportsAppDelete =
/*#__PURE__*/
function (_Component) {
  _inherits(ReportsAppDelete, _Component);

  function ReportsAppDelete() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ReportsAppDelete);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ReportsAppDelete)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      loading: false,
      error: null,
      finished: false
    });

    _defineProperty(_assertThisInitialized(_this), "stopService", function () {
      console.log('stopping service');
      api_reports__WEBPACK_IMPORTED_MODULE_1__["MyReportsApi"].stopService().subscribe(function () {
        _this.pollStatus();
      }, function (err) {
        console.log('failed to stop service');

        _this.setState({
          loading: false,
          error: err
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "pollStatus", function () {
      var servicePoll = api_reports__WEBPACK_IMPORTED_MODULE_1__["MyReportsApi"].pollServiceStatus().subscribe(function (res) {
        if (res.status === 'STOPPED') {
          servicePoll.unsubscribe();

          _this.deleteApplication();
        }
      });
    });

    _defineProperty(_assertThisInitialized(_this), "deleteApplication", function () {
      console.log('deleting application');
      api_reports__WEBPACK_IMPORTED_MODULE_1__["MyReportsApi"].deleteApp().subscribe(function () {
        _this.setState({
          finished: true
        });
      }, function (err) {
        console.log('failed to delete app');

        _this.setState({
          loading: false,
          error: err
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "removeApp", function () {
      _this.setState({
        loading: true
      });

      _this.stopService();
    });

    _defineProperty(_assertThisInitialized(_this), "renderError", function () {
      if (!_this.state.error) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "error-container text-danger"
      }, _this.state.error);
    });

    _defineProperty(_assertThisInitialized(_this), "renderFinish", function () {
      if (!_this.state.finished) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Redirect"], {
        to: "/ns/".concat(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])())
      });
    });

    return _this;
  }

  _createClass(ReportsAppDelete, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "text-center"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h3", null, "Are you sure you want to delete Reports app?"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "button"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("button", {
        className: "btn btn-danger",
        onClick: this.removeApp,
        disabled: this.state.loading
      }, "Delete")), this.renderError(), this.renderFinish());
    }
  }]);

  return ReportsAppDelete;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);



/***/ }),

/***/ "./components/Reports/ReportsDetail/Expiry/Expiry.scss":
/*!*************************************************************!*\
  !*** ./components/Reports/ReportsDetail/Expiry/Expiry.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./Expiry.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/Expiry/Expiry.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Reports/ReportsDetail/Expiry/index.js":
/*!**********************************************************!*\
  !*** ./components/Reports/ReportsDetail/Expiry/index.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Duration__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Duration */ "./components/Duration/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var PREFIX = 'features.Reports.ReportsDetail';

__webpack_require__(/*! ./Expiry.scss */ "./components/Reports/ReportsDetail/Expiry/Expiry.scss");

function ExpiryView(_ref) {
  var expiry = _ref.expiry;

  if (!expiry) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
      className: "expiry-saved"
    }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".saved")));
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "expiry"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".expiresIn")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Duration__WEBPACK_IMPORTED_MODULE_3__["default"], {
    targetTime: expiry,
    isMillisecond: false
  })));
}

ExpiryView.propTypes = {
  expiry: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    expiry: state.details.expiry
  };
};

var Expiry = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps)(ExpiryView);
/* harmony default export */ __webpack_exports__["default"] = (Expiry);

/***/ }),

/***/ "./components/Reports/ReportsDetail/ReportsDetail.scss":
/*!*************************************************************!*\
  !*** ./components/Reports/ReportsDetail/ReportsDetail.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./ReportsDetail.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/ReportsDetail.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Reports/ReportsDetail/Runs/Runs.scss":
/*!*********************************************************!*\
  !*** ./components/Reports/ReportsDetail/Runs/Runs.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./Runs.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/Runs/Runs.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Reports/ReportsDetail/Runs/index.js":
/*!********************************************************!*\
  !*** ./components/Reports/ReportsDetail/Runs/index.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Reports/store/ActionCreator */ "./components/Reports/store/ActionCreator.js");
/* harmony import */ var lodash_difference__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash/difference */ "../../node_modules/lodash/difference.js");
/* harmony import */ var lodash_difference__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash_difference__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var lodash_capitalize__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash/capitalize */ "../../node_modules/lodash/capitalize.js");
/* harmony import */ var lodash_capitalize__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_capitalize__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var services_StatusMapper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! services/StatusMapper */ "./services/StatusMapper.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_9__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */










var PREFIX = 'features.Reports.Customizer.Options';

__webpack_require__(/*! ./Runs.scss */ "./components/Reports/ReportsDetail/Runs/Runs.scss");

var PIPELINES = [services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline, services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams];

function getName(run) {
  if (!run.applicationName) {
    return '--';
  }

  var name = run.applicationName;

  if (PIPELINES.indexOf(run.artifactName) == -1) {
    name = "".concat(name, " - ").concat(run.program);
  }

  return name;
}

function getType(run) {
  switch (run.artifactName) {
    case services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline:
      return i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate('features.Reports.ReportsDetail.batch');

    case services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams:
      return i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate('features.Reports.ReportsDetail.realtime');

    default:
      return run.programType;
  }
}

function renderHeader(headers) {
  var nameLabel = i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate('commons.nameLabel');
  var typeLabel = i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate('commons.typeLabel');
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "grid-header"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "grid-row"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    title: nameLabel
  }, nameLabel), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    title: typeLabel
  }, typeLabel), headers.map(function (head) {
    var headerLabel = i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".").concat(head));
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      title: headerLabel
    }, headerLabel);
  })));
}

function renderBody(runs, headers) {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "grid-body"
  }, runs.map(function (run, i) {
    var name = getName(run);
    var type = getType(run);
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      key: i,
      className: "grid-row"
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      title: name
    }, name), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      title: type
    }, type), headers.map(function (head) {
      var value = run[head];

      if (['start', 'end'].indexOf(head) !== -1) {
        value = Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["humanReadableDate"])(value);
      } else if (head === 'duration') {
        value = Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["humanReadableDuration"])(value);
      } else if (head === 'status') {
        value = services_StatusMapper__WEBPACK_IMPORTED_MODULE_8__["default"].lookupDisplayStatus(value);
      } else if (head === 'startMethod') {
        value = lodash_capitalize__WEBPACK_IMPORTED_MODULE_7___default()(value);
      } else if (head === 'runtimeArgs') {
        var keyValuePairs = Object.entries(value).map(function (keyValuePair) {
          return "".concat(keyValuePair[0], " = ").concat(keyValuePair[1]);
        });
        value = keyValuePairs.join(', ');
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("pre", {
          title: value,
          className: "runtime-args-row"
        }, value));
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        title: value || '--'
      }, value || '--');
    }));
  }));
}

function getHeaders(request) {
  if (!request.fields) {
    return [];
  }

  var headers = lodash_difference__WEBPACK_IMPORTED_MODULE_6___default()(request.fields, components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_5__["DefaultSelection"]);
  return headers;
}

var RunsView =
/*#__PURE__*/
function (_Component) {
  _inherits(RunsView, _Component);

  function RunsView() {
    _classCallCheck(this, RunsView);

    return _possibleConstructorReturn(this, _getPrototypeOf(RunsView).apply(this, arguments));
  }

  _createClass(RunsView, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      this.adjustGridColumnsWidth(this.props.request);
    }
  }, {
    key: "adjustGridColumnsWidth",
    value: function adjustGridColumnsWidth(request) {
      var headers = getHeaders(request);

      if (!headers.length) {
        return;
      }

      var runtimeArgsIndex = headers.indexOf('runtimeArgs');

      if (runtimeArgsIndex === -1) {
        return;
      }
      /*
        This is to make the width of the 'runtimeArgs' column constant, while
        making the others dynamic. We have to do this in Javascript since we don't
        know in advance what index the 'runtimeArgs' column will be at. For example,
        if the 'runtimeArgs' column is the fifth one (index 4), and there are 7
        columns in total, then the css of the grid-row element would be:
        grid-template-columns: repeat(4, minmax(10px, 1fr)) 300px repeat(2, minmax(10px, 1fr))
      */


      var reportRunsGridRowClass = '.reports-runs-container .grid.grid-container .grid-row';
      var reportRunsGridRowElements = document.querySelectorAll(reportRunsGridRowClass);
      var dynamicColWidth = 'minmax(10px, 1fr)';
      var runtimeArgsColWidth = '300px';
      var numColsAfterRuntimeArgsCol = headers.length - runtimeArgsIndex - 1;
      var gridTemplateColumnsStyle = "repeat(".concat(runtimeArgsIndex + 2, ", ").concat(dynamicColWidth, ")\n       ").concat(runtimeArgsColWidth, "\n       repeat(").concat(numColsAfterRuntimeArgsCol, ", ").concat(dynamicColWidth, ")\n      ");
      reportRunsGridRowElements.forEach(function (gridRow) {
        gridRow.style.gridTemplateColumns = gridTemplateColumnsStyle;
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          runs = _this$props.runs,
          request = _this$props.request;
      var headers = getHeaders(request);
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "reports-runs-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-wrapper"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid grid-container"
      }, renderHeader(headers), renderBody(runs, headers))));
    }
  }]);

  return RunsView;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(RunsView, "propTypes", {
  runs: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array,
  request: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
});

var mapStateToProps = function mapStateToProps(state) {
  return {
    runs: state.details.runs,
    request: state.details.request
  };
};

var Runs = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps)(RunsView);
/* harmony default export */ __webpack_exports__["default"] = (Runs);

/***/ }),

/***/ "./components/Reports/ReportsDetail/RunsPagination/index.js":
/*!******************************************************************!*\
  !*** ./components/Reports/ReportsDetail/RunsPagination/index.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Reports/store/ActionCreator */ "./components/Reports/store/ActionCreator.js");
/* harmony import */ var components_PaginationWithTitle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/PaginationWithTitle */ "./components/PaginationWithTitle/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PREFIX = 'features.Reports.ReportsDetail';

function RunsPaginationView(_ref) {
  var totalCount = _ref.totalCount,
      offset = _ref.offset,
      limit = _ref.limit;
  var totalPages = Math.ceil(totalCount / limit);
  var currentPage;

  if (offset === 0) {
    currentPage = 1;
  } else {
    currentPage = Math.ceil((offset + 1) / limit);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_PaginationWithTitle__WEBPACK_IMPORTED_MODULE_4__["default"], {
    handlePageChange: components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_3__["handleRunsPageChange"],
    currentPage: currentPage,
    totalPages: totalPages,
    title: i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".runs"), {
      context: totalCount
    })
  });
}

RunsPaginationView.propTypes = {
  totalCount: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  offset: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  limit: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    totalCount: state.details.totalRunsCount,
    offset: state.details.runsOffset,
    limit: state.details.runsLimit
  };
};

var RunsPagination = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps)(RunsPaginationView);
/* harmony default export */ __webpack_exports__["default"] = (RunsPagination);

/***/ }),

/***/ "./components/Reports/ReportsDetail/SaveButton/SaveButton.scss":
/*!*********************************************************************!*\
  !*** ./components/Reports/ReportsDetail/SaveButton/SaveButton.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./SaveButton.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/SaveButton/SaveButton.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Reports/ReportsDetail/SaveButton/SaveModal.js":
/*!******************************************************************!*\
  !*** ./components/Reports/ReportsDetail/SaveButton/SaveModal.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SaveModal; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var api_reports__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/reports */ "./api/reports.js");
/* harmony import */ var components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Reports/store/ReportsStore */ "./components/Reports/store/ReportsStore.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PREFIX = 'features.Reports.ReportsDetail';

var SaveModal =
/*#__PURE__*/
function (_Component) {
  _inherits(SaveModal, _Component);

  function SaveModal() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SaveModal);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SaveModal)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      name: _this.props.name,
      error: null
    });

    _defineProperty(_assertThisInitialized(_this), "onTextChange", function (e) {
      _this.setState({
        name: e.target.value
      });
    });

    _defineProperty(_assertThisInitialized(_this), "save", function () {
      var params = {
        reportId: _this.props.reportId
      };
      var detailParams = {
        'report-id': _this.props.reportId
      };
      var body = {
        name: _this.state.name
      };
      api_reports__WEBPACK_IMPORTED_MODULE_3__["MyReportsApi"].saveReport(params, body).subscribe(function () {
        api_reports__WEBPACK_IMPORTED_MODULE_3__["MyReportsApi"].getReport(detailParams).subscribe(function (res) {
          components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_4__["default"].dispatch({
            type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_4__["ReportsActions"].setInfoStatus,
            payload: {
              info: _objectSpread({}, res, {
                expiry: null
              })
            }
          });
        });

        _this.props.toggle();
      }, function (err) {
        console.log('Error', err);

        _this.setState({
          error: err.response
        });
      });
    });

    return _this;
  }

  _createClass(SaveModal, [{
    key: "renderError",
    value: function renderError() {
      if (!this.state.error) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "error-container text-danger"
      }, this.state.error);
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Modal"], {
        isOpen: true,
        toggle: this.props.toggle,
        size: "md",
        backdrop: "static",
        zIndex: "1061",
        className: "report-save-button-modal cdap-modal"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalHeader"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".saveReport"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "close-section float-right",
        onClick: this.props.toggle
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "fa fa-times"
      }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalBody"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "field-row"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("label", {
        className: "control-label"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate('features.Reports.reportName')), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("input", {
        type: "text",
        className: "form-control",
        value: this.state.name,
        onChange: this.onTextChange
      }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalFooter"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("button", {
        className: "btn btn-primary",
        onClick: this.save,
        disabled: this.state.name.length === 0
      }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".save"))), this.renderError()));
    }
  }]);

  return SaveModal;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(SaveModal, "propTypes", {
  toggle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func,
  name: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  reportId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
});



/***/ }),

/***/ "./components/Reports/ReportsDetail/SaveButton/index.js":
/*!**************************************************************!*\
  !*** ./components/Reports/ReportsDetail/SaveButton/index.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Reports_ReportsDetail_SaveButton_SaveModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Reports/ReportsDetail/SaveButton/SaveModal */ "./components/Reports/ReportsDetail/SaveButton/SaveModal.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var PREFIX = 'features.Reports.ReportsDetail';

__webpack_require__(/*! ./SaveButton.scss */ "./components/Reports/ReportsDetail/SaveButton/SaveButton.scss");

var SaveButtonView =
/*#__PURE__*/
function (_Component) {
  _inherits(SaveButtonView, _Component);

  function SaveButtonView() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SaveButtonView);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SaveButtonView)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      showModal: false
    });

    _defineProperty(_assertThisInitialized(_this), "toggleModal", function () {
      _this.setState({
        showModal: !_this.state.showModal
      });
    });

    _defineProperty(_assertThisInitialized(_this), "renderModal", function () {
      if (!_this.state.showModal) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_ReportsDetail_SaveButton_SaveModal__WEBPACK_IMPORTED_MODULE_3__["default"], {
        name: _this.props.name,
        toggle: _this.toggleModal,
        reportId: _this.props.reportId
      });
    });

    return _this;
  }

  _createClass(SaveButtonView, [{
    key: "render",
    value: function render() {
      if (!this.props.expiry) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("button", {
        className: "btn btn-primary",
        onClick: this.toggleModal
      }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".saveReport"))), this.renderModal());
    }
  }]);

  return SaveButtonView;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(SaveButtonView, "propTypes", {
  expiry: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  name: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  reportId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
});

var mapStateToProps = function mapStateToProps(state) {
  return {
    expiry: state.details.expiry,
    name: state.details.name,
    reportId: state.details.reportId
  };
};

var SaveButton = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps)(SaveButtonView);
/* harmony default export */ __webpack_exports__["default"] = (SaveButton);

/***/ }),

/***/ "./components/Reports/ReportsDetail/Summary/Summary.scss":
/*!***************************************************************!*\
  !*** ./components/Reports/ReportsDetail/Summary/Summary.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./Summary.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsDetail/Summary/Summary.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Reports/ReportsDetail/Summary/index.js":
/*!***********************************************************!*\
  !*** ./components/Reports/ReportsDetail/Summary/index.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PREFIX = 'features.Reports.ReportsDetail';

__webpack_require__(/*! ./Summary.scss */ "./components/Reports/ReportsDetail/Summary/Summary.scss");

function renderNamespaces(summary) {
  if (!summary.namespaces) {
    return null;
  }

  return summary.namespaces.map(function (ns) {
    return ns.namespace + i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".numRuns"), {
      num: ns.runs
    });
  }).join(', ');
}

function renderAppType(summary) {
  if (!summary.artifacts) {
    return null;
  }

  var customAppLabel = i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".customApp"));

  var counts = _defineProperty({
    batch: 0,
    realtime: 0
  }, customAppLabel, 0); // BatchPipeline and RealtimePipeline case should be removed once going to real API


  summary.artifacts.forEach(function (artifact) {
    switch (artifact.name) {
      case 'BatchPipeline':
      case services_global_constants__WEBPACK_IMPORTED_MODULE_4__["GLOBALS"].etlDataPipeline:
        counts.batch = artifact.runs;
        break;

      case 'RealtimePipeline':
      case services_global_constants__WEBPACK_IMPORTED_MODULE_4__["GLOBALS"].etlDataStreams:
        counts.realtime = artifact.runs;
        break;

      default:
        counts[customAppLabel] += artifact.runs;
    }
  });
  return Object.keys(counts).filter(function (type) {
    return counts[type] !== 0;
  }).map(function (type) {
    return "".concat(counts[type], " ").concat(type);
  }).join('; ');
}

function renderDuration(summary) {
  var durations = summary.durations;

  if (!durations) {
    return null;
  }

  var min = Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableDuration"])(durations.min);
  var max = Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableDuration"])(durations.max);
  var average = Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableDuration"])(Math.round(durations.average));
  return i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".runDuration"), {
    min: min,
    max: max,
    average: average
  });
}

function renderLastStarted(summary) {
  var starts = summary.starts;

  if (!starts) {
    return null;
  }

  return i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".lastStarted"), {
    newest: Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableDate"])(starts.newest),
    oldest: Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableDate"])(starts.oldest)
  });
}

function renderOwners(summary) {
  if (!summary.owners) {
    return null;
  }

  return summary.owners.map(function (owner) {
    return "".concat(owner.user, " (").concat(owner.runs, ")");
  }).join('; ');
}

function renderStartMethod(summary) {
  if (!summary.startMethods) {
    return null;
  }

  var labelMap = {
    MANUAL: i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".manually")),
    SCHEDULED: i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".bySchedule")),
    PROGRAM_STATUS: i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".byTrigger"))
  };
  return summary.startMethods.map(function (startMethod) {
    return "".concat(labelMap[startMethod.method], " (").concat(startMethod.runs, ")");
  }).join('; ');
}

function SummaryView(_ref) {
  var summary = _ref.summary;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "reports-summary-container"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "row summary-section"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "col-6"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("table", {
    className: "table"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tbody", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tr", {
    className: "no-border"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", {
    colSpan: "2"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".reportSummary"))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tr", {
    className: "no-border"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".namespaceLabel"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, renderNamespaces(summary))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".timeRangeLabel"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".timeRange"), {
    start: Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableDate"])(summary.start),
    end: Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableDate"])(summary.end)
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".appTypeLabel"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, renderAppType(summary)))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "col-6"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("table", {
    className: "table"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tbody", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tr", {
    className: "no-border"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".runDurationLabel"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, renderDuration(summary))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".lastStartedLabel"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, renderLastStarted(summary))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".ownersLabel"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, renderOwners(summary))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".startedLabel"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, renderStartMethod(summary))))))));
}

SummaryView.propTypes = {
  summary: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    summary: state.details.summary
  };
};

var Summary = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps)(SummaryView);
/* harmony default export */ __webpack_exports__["default"] = (Summary);

/***/ }),

/***/ "./components/Reports/ReportsDetail/index.js":
/*!***************************************************!*\
  !*** ./components/Reports/ReportsDetail/index.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_reports__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/reports */ "./api/reports.js");
/* harmony import */ var components_Reports_ReportsDetail_Summary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Reports/ReportsDetail/Summary */ "./components/Reports/ReportsDetail/Summary/index.js");
/* harmony import */ var components_Reports_ReportsDetail_Runs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Reports/ReportsDetail/Runs */ "./components/Reports/ReportsDetail/Runs/index.js");
/* harmony import */ var components_Reports_ReportsDetail_RunsPagination__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Reports/ReportsDetail/RunsPagination */ "./components/Reports/ReportsDetail/RunsPagination/index.js");
/* harmony import */ var components_Reports_ReportsDetail_SaveButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Reports/ReportsDetail/SaveButton */ "./components/Reports/ReportsDetail/SaveButton/index.js");
/* harmony import */ var components_Reports_ReportsDetail_Expiry__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Reports/ReportsDetail/Expiry */ "./components/Reports/ReportsDetail/Expiry/index.js");
/* harmony import */ var components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/Reports/store/ReportsStore */ "./components/Reports/store/ReportsStore.js");
/* harmony import */ var components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/Reports/store/ActionCreator */ "./components/Reports/store/ActionCreator.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

















var PREFIX = 'features.Reports.ReportsDetail';

__webpack_require__(/*! ./ReportsDetail.scss */ "./components/Reports/ReportsDetail/ReportsDetail.scss");

var ReportsDetailView =
/*#__PURE__*/
function (_Component) {
  _inherits(ReportsDetailView, _Component);

  function ReportsDetailView() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ReportsDetailView);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ReportsDetailView)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "fetchStatus", function () {
      var params = {
        'report-id': _this.props.match.params.reportId
      };
      api_reports__WEBPACK_IMPORTED_MODULE_2__["MyReportsApi"].getReport(params).subscribe(function (res) {
        components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_8__["default"].dispatch({
          type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_8__["ReportsActions"].setInfoStatus,
          payload: {
            info: res,
            reportId: _this.props.match.params.reportId
          }
        });

        if (res.status === 'COMPLETED') {
          Object(components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_9__["fetchRuns"])(_this.props.match.params.reportId);
        }
      }, function (err) {
        components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_8__["default"].dispatch({
          type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_8__["ReportsActions"].setDetailsError,
          payload: {
            error: err.response
          }
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "renderError", function (isDetail) {
      var errorHeaderLabel = isDetail ? 'Error' : 'Report Generation Failed';
      var error = isDetail ? _this.props.detailError : _this.props.error;
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "error-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", {
        className: "text-danger"
      }, errorHeaderLabel), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("pre", null, error));
    });

    _defineProperty(_assertThisInitialized(_this), "renderDetail", function () {
      if (_this.props.status === 'FAILED' && _this.props.error) {
        return _this.renderError(false);
      }

      if (_this.props.detailError) {
        return _this.renderError(true);
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "reports-detail-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "action-section clearfix"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "date-container float-left"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_15___default.a.translate("".concat(PREFIX, ".generatedTime"), {
        time: Object(services_helpers__WEBPACK_IMPORTED_MODULE_14__["humanReadableDate"])(_this.props.created)
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "separator"
      }, "-"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_ReportsDetail_Expiry__WEBPACK_IMPORTED_MODULE_7__["default"], null)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "action-button float-right"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_ReportsDetail_SaveButton__WEBPACK_IMPORTED_MODULE_6__["default"], null))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_ReportsDetail_Summary__WEBPACK_IMPORTED_MODULE_3__["default"], null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_ReportsDetail_RunsPagination__WEBPACK_IMPORTED_MODULE_5__["default"], null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_ReportsDetail_Runs__WEBPACK_IMPORTED_MODULE_4__["default"], null));
    });

    return _this;
  }

  _createClass(ReportsDetailView, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      this.fetchStatus();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_8__["default"].dispatch({
        type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_8__["ReportsActions"].detailsReset
      });
    }
  }, {
    key: "render",
    value: function render() {
      var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_16__["Theme"].featureNames.reports;
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "reports-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "header"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "reports-view-options"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_10__["Link"], {
        to: "/ns/".concat(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_11__["getCurrentNamespace"])(), "/reports")
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_12__["default"], {
        name: "icon-angle-double-left"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, featureName)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "separator"
      }, "|"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, this.props.reportName))), this.renderDetail());
    }
  }]);

  return ReportsDetailView;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(ReportsDetailView, "propTypes", {
  match: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  created: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  reportName: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  error: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  status: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  detailError: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
});

var mapStateToProps = function mapStateToProps(state, ownProps) {
  return {
    match: ownProps.match,
    created: state.details.created,
    reportName: state.details.name,
    error: state.details.error,
    status: state.details.status,
    detailError: state.details.detailError
  };
};

var ReportsDetail = Object(react_redux__WEBPACK_IMPORTED_MODULE_13__["connect"])(mapStateToProps)(ReportsDetailView);
/* harmony default export */ __webpack_exports__["default"] = (ReportsDetail);

/***/ }),

/***/ "./components/Reports/ReportsList/ActionPopover.js":
/*!*********************************************************!*\
  !*** ./components/Reports/ReportsList/ActionPopover.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ActionPopover; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var api_reports__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/reports */ "./api/reports.js");
/* harmony import */ var components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Reports/store/ActionCreator */ "./components/Reports/store/ActionCreator.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var lodash_difference__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash/difference */ "../../node_modules/lodash/difference.js");
/* harmony import */ var lodash_difference__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash_difference__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Reports/store/ReportsStore */ "./components/Reports/store/ReportsStore.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_9__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */











var PREFIX = 'features.Reports.ReportsList';

var ActionPopover =
/*#__PURE__*/
function (_Component) {
  _inherits(ActionPopover, _Component);

  function ActionPopover() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ActionPopover);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ActionPopover)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "delete", function () {
      var params = {
        reportId: _this.props.report.id
      };
      api_reports__WEBPACK_IMPORTED_MODULE_3__["MyReportsApi"].deleteReport(params).subscribe(components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_4__["listReports"], function (err) {
        console.log('Error', err);
      });
    });

    _defineProperty(_assertThisInitialized(_this), "cloneCriteria", function () {
      var params = {
        'report-id': _this.props.report.id
      };
      api_reports__WEBPACK_IMPORTED_MODULE_3__["MyReportsApi"].getReport(params).subscribe(function (res) {
        // Has to clear current selections, otherwise current selections in the
        // store will union with the cloned selections
        components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_7__["default"].dispatch({
          type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_7__["ReportsActions"].clearSelection
        });
        var request = res.request;
        var selectedFields = lodash_difference__WEBPACK_IMPORTED_MODULE_6___default()(request.fields, components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_4__["DefaultSelection"]);
        var selections = {};
        selectedFields.forEach(function (selection) {
          selections[selection] = true;
        });
        var timeRange = {
          selection: 'custom',
          start: request.start * 1000,
          end: request.end * 1000
        };
        var payload = {
          selections: selections,
          timeRange: timeRange
        };
        var hasArtifactFilter = false;

        if (request.filters && request.filters.length > 0) {
          request.filters.forEach(function (filter) {
            if (filter.fieldName === 'status') {
              // collapse status STOPPED and KILLED to STOPPED
              var statusSelections = filter.whitelist;
              var killedIndex = statusSelections.indexOf('KILLED');

              if (killedIndex !== -1) {
                statusSelections.splice(killedIndex, 1);

                if (statusSelections.indexOf('STOPPED') === -1) {
                  statusSelections.push('STOPPED');
                }
              }

              payload.statusSelections = statusSelections;
            } else if (filter.fieldName === 'artifactName') {
              if (filter.whitelist) {
                payload.selections.pipelines = true;
              } else if (filter.blacklist) {
                payload.selections.customApps = true;
              }

              hasArtifactFilter = true;
            } else if (filter.fieldName === 'namespace') {
              var namespaces = filter.whitelist;
              namespaces.splice(namespaces.indexOf(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_8__["getCurrentNamespace"])()), 1);
              payload.namespacesPick = namespaces;
            }
          });
        }

        if (!hasArtifactFilter) {
          payload.selections.pipelines = true;
          payload.selections.customApps = true;
        }

        components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_7__["default"].dispatch({
          type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_7__["ReportsActions"].setSelections,
          payload: payload
        }); // to close popover

        document.body.click();
      });
    });

    return _this;
  }

  _createClass(ActionPopover, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_2__["default"], {
        target: function target() {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_5__["default"], {
            name: "icon-cog"
          });
        },
        className: "reports-list-action-popover",
        placement: "bottom",
        bubbleEvent: false,
        injectOnToggle: true
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "option",
        onClick: this.cloneCriteria
      }, i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".cloneCriteria"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("hr", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "option text-danger",
        onClick: this["delete"]
      }, i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate('commons.delete'))));
    }
  }]);

  return ActionPopover;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(ActionPopover, "propTypes", {
  report: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
});



/***/ }),

/***/ "./components/Reports/ReportsList/ReportsList.scss":
/*!*********************************************************!*\
  !*** ./components/Reports/ReportsList/ReportsList.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./ReportsList.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsList/ReportsList.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Reports/ReportsList/ReportsPagination.js":
/*!*************************************************************!*\
  !*** ./components/Reports/ReportsList/ReportsPagination.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Reports/store/ActionCreator */ "./components/Reports/store/ActionCreator.js");
/* harmony import */ var components_PaginationWithTitle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/PaginationWithTitle */ "./components/PaginationWithTitle/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PREFIX = 'features.Reports';

function ReportsPaginationView(_ref) {
  var totalCount = _ref.totalCount,
      offset = _ref.offset,
      limit = _ref.limit;
  var totalPages = Math.ceil(totalCount / limit);
  var currentPage;

  if (offset === 0) {
    currentPage = 1;
  } else {
    currentPage = Math.ceil((offset + 1) / limit);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_PaginationWithTitle__WEBPACK_IMPORTED_MODULE_4__["default"], {
    handlePageChange: components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_3__["handleReportsPageChange"],
    currentPage: currentPage,
    totalPages: totalPages,
    title: i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate("".concat(PREFIX, ".reports"), {
      context: totalCount
    })
  });
}

ReportsPaginationView.propTypes = {
  totalCount: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  offset: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  limit: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    totalCount: state.list.total,
    offset: state.list.offset,
    limit: state.list.limit
  };
};

var ReportsPagination = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps)(ReportsPaginationView);
/* harmony default export */ __webpack_exports__["default"] = (ReportsPagination);

/***/ }),

/***/ "./components/Reports/ReportsList/index.js":
/*!*************************************************!*\
  !*** ./components/Reports/ReportsList/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Reports_Customizer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Reports/Customizer */ "./components/Reports/Customizer/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Duration__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Duration */ "./components/Duration/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/Reports/store/ActionCreator */ "./components/Reports/store/ActionCreator.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var components_Reports_ReportsList_ActionPopover__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! components/Reports/ReportsList/ActionPopover */ "./components/Reports/ReportsList/ActionPopover.js");
/* harmony import */ var components_Reports_ReportsList_ReportsPagination__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! components/Reports/ReportsList/ReportsPagination */ "./components/Reports/ReportsList/ReportsPagination.js");
/* harmony import */ var components_NamespacesPicker__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! components/NamespacesPicker */ "./components/NamespacesPicker/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


















var PREFIX = 'features.Reports.ReportsList';

__webpack_require__(/*! ./ReportsList.scss */ "./components/Reports/ReportsList/ReportsList.scss");

var ReportsListView =
/*#__PURE__*/
function (_Component) {
  _inherits(ReportsListView, _Component);

  function ReportsListView() {
    _classCallCheck(this, ReportsListView);

    return _possibleConstructorReturn(this, _getPrototypeOf(ReportsListView).apply(this, arguments));
  }

  _createClass(ReportsListView, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      Object(components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_9__["listReports"])();
      this.interval$ = rxjs_Observable__WEBPACK_IMPORTED_MODULE_10__["Observable"].interval(10000).subscribe(components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_9__["listReports"]);
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      // If switching to a different page, stop reports polling on
      // current page, and start polling on new page
      if (nextProps.offset !== this.props.offset) {
        this.pollReportsInNewPage();
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.interval$) {
        this.interval$.unsubscribe();
      }
    }
  }, {
    key: "pollReportsInNewPage",
    value: function pollReportsInNewPage() {
      if (this.interval$) {
        this.interval$.unsubscribe();
      }

      this.interval$ = rxjs_Observable__WEBPACK_IMPORTED_MODULE_10__["Observable"].interval(10000).subscribe(components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_9__["listReports"]);
    }
  }, {
    key: "renderCreated",
    value: function renderCreated(report) {
      if (report.status === 'COMPLETED') {
        return Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableDate"])(report.created);
      }

      if (report.status === 'FAILED') {
        return i18n_react__WEBPACK_IMPORTED_MODULE_15___default.a.translate("".concat(PREFIX, ".failed"));
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "generating"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "fa fa-spin"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-spinner"
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_15___default.a.translate("".concat(PREFIX, ".generating"))));
    }
  }, {
    key: "renderExpiry",
    value: function renderExpiry(report) {
      if (!report.expiry) {
        return '--';
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Duration__WEBPACK_IMPORTED_MODULE_6__["default"], {
        targetTime: report.expiry,
        isMillisecond: false
      });
    }
  }, {
    key: "renderHeader",
    value: function renderHeader() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-header"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-row"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, i18n_react__WEBPACK_IMPORTED_MODULE_15___default.a.translate('features.Reports.reportName')), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, i18n_react__WEBPACK_IMPORTED_MODULE_15___default.a.translate("".concat(PREFIX, ".created"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, i18n_react__WEBPACK_IMPORTED_MODULE_15___default.a.translate("".concat(PREFIX, ".expiration"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null)));
    }
  }, {
    key: "renderLoadingRow",
    value: function renderLoadingRow(report) {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        key: report.id,
        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('grid-row grid-link not-allowed', {
          active: report.id === this.props.activeId
        })
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "report-name"
      }, report.name), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, this.renderCreated(report)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, this.renderExpiry(report)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_ReportsList_ActionPopover__WEBPACK_IMPORTED_MODULE_12__["default"], {
        report: report
      })));
    }
  }, {
    key: "renderLinkRow",
    value: function renderLinkRow(report) {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_7__["Link"], {
        key: report.id,
        to: "/ns/".concat(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_8__["getCurrentNamespace"])(), "/reports/details/").concat(report.id),
        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('grid-row grid-link', {
          active: report.id === this.props.activeId
        })
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "report-name"
      }, report.name), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, this.renderCreated(report)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, this.renderExpiry(report)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_ReportsList_ActionPopover__WEBPACK_IMPORTED_MODULE_12__["default"], {
        report: report
      })));
    }
  }, {
    key: "renderBody",
    value: function renderBody() {
      var _this = this;

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-body"
      }, this.props.reports.map(function (report) {
        return report.status === 'RUNNING' ? _this.renderLoadingRow(report) : _this.renderLinkRow(report);
      }));
    }
  }, {
    key: "renderEmpty",
    value: function renderEmpty() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "list-container empty"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "text-center"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_15___default.a.translate("".concat(PREFIX, ".noReports"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "text-center"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_15___default.a.translate("".concat(PREFIX, ".makeSelection"))));
    }
  }, {
    key: "renderTable",
    value: function renderTable() {
      if (this.props.reports.length === 0) {
        return this.renderEmpty();
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_ReportsList_ReportsPagination__WEBPACK_IMPORTED_MODULE_13__["default"], null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "list-container grid-wrapper"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid grid-container"
      }, this.renderHeader(), this.renderBody())));
    }
  }, {
    key: "render",
    value: function render() {
      var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_16__["Theme"].featureNames.reports;
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "reports-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "header"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "reports-view-options float-left"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, featureName)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_NamespacesPicker__WEBPACK_IMPORTED_MODULE_14__["default"], {
        setNamespacesPick: components_Reports_store_ActionCreator__WEBPACK_IMPORTED_MODULE_9__["setNamespacesPick"]
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "reports-list-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_Customizer__WEBPACK_IMPORTED_MODULE_2__["default"], null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "list-view"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "section-title"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_15___default.a.translate("".concat(PREFIX, ".selectAReport"))), this.renderTable())));
    }
  }]);

  return ReportsListView;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(ReportsListView, "propTypes", {
  reports: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array,
  activeId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]),
  offset: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
});

var mapStateToProps = function mapStateToProps(state) {
  return {
    reports: state.list.reports,
    activeId: state.list.activeId,
    offset: state.list.offset
  };
};

var ReportsList = Object(react_redux__WEBPACK_IMPORTED_MODULE_5__["connect"])(mapStateToProps)(ReportsListView);
/* harmony default export */ __webpack_exports__["default"] = (ReportsList);

/***/ }),

/***/ "./components/Reports/ReportsServiceControl/ReportsServiceControl.scss":
/*!*****************************************************************************!*\
  !*** ./components/Reports/ReportsServiceControl/ReportsServiceControl.scss ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./ReportsServiceControl.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Reports/ReportsServiceControl/ReportsServiceControl.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Reports/ReportsServiceControl/index.js":
/*!***********************************************************!*\
  !*** ./components/Reports/ReportsServiceControl/index.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ReportsServiceControl; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_ServiceEnablerUtilities__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/ServiceEnablerUtilities */ "./services/ServiceEnablerUtilities.js");
/* harmony import */ var api_reports__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/reports */ "./api/reports.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_BtnWithLoading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/BtnWithLoading */ "./components/BtnWithLoading/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var services_CDAPComponentsVersions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/CDAPComponentsVersions */ "./services/CDAPComponentsVersions.js");
/* harmony import */ var lodash_isObject__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash/isObject */ "../../node_modules/lodash/isObject.js");
/* harmony import */ var lodash_isObject__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash_isObject__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-helmet */ "../../node_modules/react-helmet/lib/Helmet.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */












__webpack_require__(/*! ./ReportsServiceControl.scss */ "./components/Reports/ReportsServiceControl/ReportsServiceControl.scss");

var PREFIX = 'features.Reports.ReportsServiceControl';
var ReportsArtifact = 'cdap-program-report';

var ReportsServiceControl =
/*#__PURE__*/
function (_Component) {
  _inherits(ReportsServiceControl, _Component);

  function ReportsServiceControl() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ReportsServiceControl);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ReportsServiceControl)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      loading: false,
      disabled: false,
      checkingForSpark2: true,
      error: null,
      extendedError: null
    });

    _defineProperty(_assertThisInitialized(_this), "enableReports", function () {
      _this.setState({
        loading: true
      });

      var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__["Theme"].featureNames.reports;
      Object(services_ServiceEnablerUtilities__WEBPACK_IMPORTED_MODULE_2__["default"])({
        shouldStopService: false,
        artifactName: ReportsArtifact,
        api: api_reports__WEBPACK_IMPORTED_MODULE_3__["MyReportsApi"],
        i18nPrefix: PREFIX,
        featureName: featureName
      }).subscribe(_this.props.onServiceStart, function (err) {
        var extendedMessage = lodash_isObject__WEBPACK_IMPORTED_MODULE_8___default()(err.extendedMessage) ? err.extendedMessage.response || err.extendedMessage.message : err.extendedMessage;

        _this.setState({
          error: err.error,
          extendedError: extendedMessage,
          loading: false
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "renderEnableBtn", function () {
      var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__["Theme"].featureNames.reports;

      if (_this.state.checkingForSpark2) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "action-container service-disabled"
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
          name: "icon-spinner",
          className: "fa-spin"
        }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "text-primary"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".environmentCheckMessage"), {
          featureName: featureName
        })));
      }

      if (_this.state.disabled) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "action-container service-disabled"
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
          name: "icon-exclamation-triangle",
          className: "text-danger"
        }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "text-danger"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".serviceDisabledMessage"), {
          featureName: featureName
        })));
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "action-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_BtnWithLoading__WEBPACK_IMPORTED_MODULE_5__["default"], {
        className: "btn-primary",
        label: i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".enable"), {
          featureName: featureName
        }),
        loading: _this.state.loading,
        onClick: _this.enableReports
      }));
    });

    _defineProperty(_assertThisInitialized(_this), "renderError", function () {
      if (!_this.state.error) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "reports-service-control-error"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", {
        className: "text-danger"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-exclamation-triangle"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, _this.state.error)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
        className: "text-danger"
      }, _this.state.extendedError));
    });

    return _this;
  }

  _createClass(ReportsServiceControl, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      Object(services_CDAPComponentsVersions__WEBPACK_IMPORTED_MODULE_7__["isSpark2Available"])().subscribe(function (isAvailable) {
        return _this2.setState({
          disabled: !isAvailable,
          checkingForSpark2: false
        });
      });
    }
  }, {
    key: "render",
    value: function render() {
      var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__["Theme"].featureNames.reports;
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "reports-service-control"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_helmet__WEBPACK_IMPORTED_MODULE_9___default.a, {
        title: i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.Reports.pageTitle', {
          productName: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__["Theme"].productName,
          featureName: featureName
        })
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "image-containers"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
        className: "img-thumbnail",
        src: "/cdap_assets/img/Reports_preview1.png"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
        className: "img-thumbnail",
        src: "/cdap_assets/img/Reports_preview2.png"
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "text-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h2", null, " ", i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".title"), {
        featureName: featureName
      }), " "), this.renderEnableBtn(), this.renderError(), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".description"), {
        featureName: featureName
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "reports-benefit"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".Benefits.title"), {
        featureName: featureName
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("ul", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".Benefits.b1")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".Benefits.b2")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".Benefits.b3")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".Benefits.b4")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".Benefits.b5")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".Benefits.b6"))))))));
    }
  }]);

  return ReportsServiceControl;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(ReportsServiceControl, "propTypes", {
  onServiceStart: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
});



/***/ }),

/***/ "./components/Reports/index.js":
/*!*************************************!*\
  !*** ./components/Reports/index.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Reports; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Reports/store/ReportsStore */ "./components/Reports/store/ReportsStore.js");
/* harmony import */ var components_Reports_ReportsList__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Reports/ReportsList */ "./components/Reports/ReportsList/index.js");
/* harmony import */ var components_Reports_ReportsDetail__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Reports/ReportsDetail */ "./components/Reports/ReportsDetail/index.js");
/* harmony import */ var api_reports__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! api/reports */ "./api/reports.js");
/* harmony import */ var components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/LoadingSVGCentered */ "./components/LoadingSVGCentered/index.js");
/* harmony import */ var components_Reports_ReportsServiceControl__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/Reports/ReportsServiceControl */ "./components/Reports/ReportsServiceControl/index.js");
/* harmony import */ var components_Reports_ReportsAppDelete__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/Reports/ReportsAppDelete */ "./components/Reports/ReportsAppDelete/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-helmet */ "../../node_modules/react-helmet/lib/Helmet.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */













var PREFIX = 'features.Reports';

__webpack_require__(/*! ./Reports.scss */ "./components/Reports/Reports.scss");

var Reports =
/*#__PURE__*/
function (_Component) {
  _inherits(Reports, _Component);

  function Reports() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, Reports);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(Reports)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      loading: true,
      isRunning: false
    });

    _defineProperty(_assertThisInitialized(_this), "checkIfReportsRunning", function () {
      api_reports__WEBPACK_IMPORTED_MODULE_6__["MyReportsApi"].ping().subscribe(function () {
        _this.setState({
          loading: false,
          isRunning: true
        });
      }, function () {
        _this.setState({
          loading: false,
          isRunning: false
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "onServiceStart", function () {
      _this.setState({
        loading: false,
        isRunning: true
      });
    });

    return _this;
  }

  _createClass(Reports, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      this.checkIfReportsRunning();
    }
  }, {
    key: "render",
    value: function render() {
      if (this.state.loading) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_7__["default"], null);
      }

      if (!this.state.isRunning) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Reports_ReportsServiceControl__WEBPACK_IMPORTED_MODULE_8__["default"], {
          onServiceStart: this.onServiceStart
        });
      }

      var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_12__["Theme"].featureNames.reports;
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_redux__WEBPACK_IMPORTED_MODULE_1__["Provider"], {
        store: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_3__["default"]
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_helmet__WEBPACK_IMPORTED_MODULE_11___default.a, {
        title: i18n_react__WEBPACK_IMPORTED_MODULE_10___default.a.translate("".concat(PREFIX, ".pageTitle"), {
          productName: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_12__["Theme"].productName,
          featureName: featureName
        })
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Switch"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Route"], {
        exact: true,
        path: "/ns/:namespace/reports",
        component: components_Reports_ReportsList__WEBPACK_IMPORTED_MODULE_4__["default"]
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Route"], {
        exact: true,
        path: "/ns/:namespace/reports/details/:reportId",
        component: components_Reports_ReportsDetail__WEBPACK_IMPORTED_MODULE_5__["default"]
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Route"], {
        exact: true,
        path: "/ns/:namespace/reports/delete-app",
        component: components_Reports_ReportsAppDelete__WEBPACK_IMPORTED_MODULE_9__["default"]
      }))));
    }
  }]);

  return Reports;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);



/***/ }),

/***/ "./components/Reports/store/ActionCreator.js":
/*!***************************************************!*\
  !*** ./components/Reports/store/ActionCreator.js ***!
  \***************************************************/
/*! exports provided: DefaultSelection, generateReport, listReports, fetchRuns, handleRunsPageChange, handleReportsPageChange, setNamespacesPick, getStatusSelectionsLabels */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DefaultSelection", function() { return DefaultSelection; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateReport", function() { return generateReport; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "listReports", function() { return listReports; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchRuns", function() { return fetchRuns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "handleRunsPageChange", function() { return handleRunsPageChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "handleReportsPageChange", function() { return handleReportsPageChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setNamespacesPick", function() { return setNamespacesPick; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStatusSelectionsLabels", function() { return getStatusSelectionsLabels; });
/* harmony import */ var components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! components/Reports/store/ReportsStore */ "./components/Reports/store/ReportsStore.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ "../../node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_reports__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/reports */ "./api/reports.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/orderBy */ "../../node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_StatusMapper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/StatusMapper */ "./services/StatusMapper.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_7__);
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








var PREFIX = 'features.Reports.ReportsDetail';
var DefaultSelection = ['artifactName', 'applicationName', 'program', 'programType'];

function getTimeRange() {
  var state = components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().timeRange;
  var end = moment__WEBPACK_IMPORTED_MODULE_1___default()().format('x');
  var start;

  switch (state.selection) {
    case 'last30':
      start = moment__WEBPACK_IMPORTED_MODULE_1___default()().subtract(30, 'm').format('x');
      break;

    case 'lastHour':
      start = moment__WEBPACK_IMPORTED_MODULE_1___default()().subtract(1, 'h').format('x');
      break;

    case 'custom':
      start = state.start;
      end = state.end;
      break;
  }

  start = Math.round(parseInt(start, 10) / 1000);
  end = Math.round(parseInt(end, 10) / 1000);
  return {
    start: start,
    end: end
  };
}

function getName(start, end) {
  var format = 'MMM D, YYYY HH:mma';
  var startDate = moment__WEBPACK_IMPORTED_MODULE_1___default()(start * 1000).format(format);
  var endDate = moment__WEBPACK_IMPORTED_MODULE_1___default()(end * 1000).format(format);
  var statusSelections = components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().status.statusSelections;
  var statusLabel = getStatusSelectionsLabels(statusSelections).join(', ');
  return i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".getReportName"), {
    statusLabel: statusLabel,
    startDate: startDate,
    endDate: endDate
  });
}

function getFilters() {
  var filters = [];
  var selections = components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().customizer; // pipelines vs custom apps

  if (selections.pipelines && !selections.customApps) {
    filters.push({
      fieldName: 'artifactName',
      whitelist: services_global_constants__WEBPACK_IMPORTED_MODULE_4__["GLOBALS"].etlPipelineTypes
    });
  } else if (!selections.pipelines && selections.customApps) {
    filters.push({
      fieldName: 'artifactName',
      blacklist: services_global_constants__WEBPACK_IMPORTED_MODULE_4__["GLOBALS"].etlPipelineTypes
    });
  } // status


  var statusSelections = _toConsumableArray(components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().status.statusSelections); // expand status STOPPED with STOPPED and KILLED


  if (statusSelections.indexOf('STOPPED') !== -1) {
    statusSelections.push('KILLED');
  }

  filters.push({
    fieldName: 'status',
    whitelist: statusSelections
  }); // namespaces

  var namespacesPick = components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().namespaces.namespacesPick;
  filters.push({
    fieldName: 'namespace',
    whitelist: [].concat(_toConsumableArray(namespacesPick), [Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__["getCurrentNamespace"])()])
  });
  return filters;
}

function generateReport() {
  var _getTimeRange = getTimeRange(),
      start = _getTimeRange.start,
      end = _getTimeRange.end;

  var selections = components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().customizer;
  var FILTER_OUT = ['pipelines', 'customApps'];
  var fields = Object.keys(selections).filter(function (field) {
    return selections[field] && FILTER_OUT.indexOf(field) === -1;
  });
  fields = DefaultSelection.concat(fields);
  var requestBody = {
    name: getName(start, end),
    start: start,
    end: end,
    fields: fields
  };
  var filters = getFilters();

  if (filters.length > 0) {
    requestBody.filters = filters;
  }

  api_reports__WEBPACK_IMPORTED_MODULE_2__["MyReportsApi"].generateReport(null, requestBody).subscribe(function (res) {
    // Switch to 1st page after generating a report, so we can
    // highlight the new report
    handleReportsPageChange({
      selected: 0
    }, res.id);
  }, function (err) {
    console.log('error', err);
  });
}
function listReports(id) {
  var _ReportsStore$getStat = components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().list,
      offset = _ReportsStore$getStat.offset,
      limit = _ReportsStore$getStat.limit;
  var params = {
    offset: offset,
    limit: limit
  };
  api_reports__WEBPACK_IMPORTED_MODULE_2__["MyReportsApi"].list(params).subscribe(function (res) {
    res.reports = lodash_orderBy__WEBPACK_IMPORTED_MODULE_3___default()(res.reports, ['created'], ['desc']);
    components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["ReportsActions"].setList,
      payload: {
        list: res,
        activeId: id
      }
    });

    if (id) {
      setTimeout(function () {
        components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
          type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["ReportsActions"].setActiveId,
          payload: {
            activeId: null
          }
        });
      }, 3000);
    }
  });
}
function fetchRuns() {
  var reportId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().details.reportId;
  var _ReportsStore$getStat2 = components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().details,
      offset = _ReportsStore$getStat2.runsOffset,
      limit = _ReportsStore$getStat2.runsLimit;
  var params = {
    'report-id': reportId,
    offset: offset,
    limit: limit
  };
  api_reports__WEBPACK_IMPORTED_MODULE_2__["MyReportsApi"].getDetails(params).subscribe(function (res) {
    components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["ReportsActions"].setRuns,
      payload: {
        runs: res.details,
        totalRunsCount: res.total
      }
    });
  }, function (err) {
    console.log('err', err);
    components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["ReportsActions"].setDetailsError,
      payload: {
        error: err.response
      }
    });
  });
}
function handleRunsPageChange(_ref) {
  var selected = _ref.selected;
  var runsLimit = components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().details.runsLimit;
  components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["ReportsActions"].setRunsPagination,
    payload: {
      offset: selected * runsLimit
    }
  });
  fetchRuns();
}
function handleReportsPageChange(_ref2, id) {
  var selected = _ref2.selected;
  var limit = components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().list.limit;
  components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["ReportsActions"].setPagination,
    payload: {
      offset: selected * limit
    }
  });
  listReports(id);
}
function setNamespacesPick(namespacesPick) {
  components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Reports_store_ReportsStore__WEBPACK_IMPORTED_MODULE_0__["ReportsActions"].setNamespaces,
    payload: {
      namespacesPick: namespacesPick
    }
  });
}
function getStatusSelectionsLabels(selections) {
  return selections.map(function (selection) {
    return services_StatusMapper__WEBPACK_IMPORTED_MODULE_6__["default"].lookupDisplayStatus(selection);
  });
}

/***/ }),

/***/ "./components/Reports/store/ReportsStore.js":
/*!**************************************************!*\
  !*** ./components/Reports/store/ReportsStore.js ***!
  \**************************************************/
/*! exports provided: default, ReportsActions, STATUS_OPTIONS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportsActions", function() { return ReportsActions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STATUS_OPTIONS", function() { return STATUS_OPTIONS; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var ReportsActions = {
  toggleCustomizerOption: 'REPORTS_TOGGLE_CUSTOMIZER_OPTION',
  setSelections: 'REPORTS_SET_SELECTIONS',
  setList: 'REPORTS_SET_LIST',
  setPagination: 'REPORTS_SET_PAGINATION',
  setTimeRange: 'REPORTS_SET_TIME_RANGE',
  setRuns: 'REPORTS_SET_RUNS',
  setRunsPagination: 'REPORTS_SET_RUNS_PAGINATION',
  setInfoStatus: 'REPORTS_SET_INFO_STATUS',
  clearSelection: 'REPORTS_CUSTOMIZER_CLEAR',
  setActiveId: 'REPORTS_SET_ACTIVE_ID',
  setStatus: 'REPORTS_SET_STATUS',
  setDetailsError: 'REPORTS_DETAILS_ERROR',
  detailsReset: 'REPORTS_DETAILS_RESET',
  setNamespaces: 'REPORTS_SET_NAMESPACES',
  reset: 'REPORTS_RESET'
};
var STATUS_OPTIONS = ['FAILED', 'COMPLETED', 'RUNNING', 'STOPPED'];
var defaultCustomizerState = {
  pipelines: false,
  customApps: false,
  namespace: false,
  status: false,
  start: false,
  end: false,
  duration: false,
  user: false,
  startMethod: false,
  runtimeArgs: false,
  numLogWarnings: false,
  numLogErrors: false,
  numRecordsOut: false
};
var defaultStatusState = {
  statusSelections: [STATUS_OPTIONS[0]]
};
var defaultTimeRangeState = {
  selection: null,
  start: null,
  end: null
};
var namespacesInitialState = {
  namespacesPick: []
};
var defaultListState = {
  total: 0,
  reports: [],
  offset: 0,
  limit: 20,
  activeId: null
};
var defaultDetailsState = {
  reportId: null,
  created: null,
  expiry: null,
  name: null,
  request: {},
  status: null,
  summary: {},
  runs: [],
  runsOffset: 0,
  runsLimit: 20,
  totalRunsCount: 0,
  error: null,
  detailError: null
};

var customizer = function customizer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultCustomizerState;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ReportsActions.toggleCustomizerOption:
      return _objectSpread({}, state, _defineProperty({}, action.payload.type, !state[action.payload.type]));

    case ReportsActions.setSelections:
      return _objectSpread({}, state, {}, action.payload.selections);

    case ReportsActions.clearSelection:
    case ReportsActions.reset:
      return defaultCustomizerState;

    default:
      return state;
  }
};

var status = function status() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultStatusState;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ReportsActions.setStatus:
    case ReportsActions.setSelections:
      return _objectSpread({}, state, {
        statusSelections: action.payload.statusSelections
      });

    case ReportsActions.clearSelection:
    case ReportsActions.reset:
      return defaultStatusState;

    default:
      return state;
  }
};

var timeRange = function timeRange() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultTimeRangeState;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ReportsActions.setTimeRange:
      return _objectSpread({}, state, {
        selection: action.payload.selection,
        start: action.payload.start,
        end: action.payload.end
      });

    case ReportsActions.setSelections:
      return _objectSpread({}, state, {}, action.payload.timeRange);

    case ReportsActions.clearSelection:
    case ReportsActions.reset:
      return defaultTimeRangeState;

    default:
      return state;
  }
};

var namespaces = function namespaces() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : namespacesInitialState;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ReportsActions.setSelections:
    case ReportsActions.setNamespaces:
      return _objectSpread({}, state, {
        namespacesPick: action.payload.namespacesPick
      });

    case ReportsActions.clearSelection:
    case ReportsActions.reset:
      return namespacesInitialState;

    default:
      return state;
  }
};

var list = function list() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultListState;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ReportsActions.setList:
      return {
        total: action.payload.list.total,
        reports: action.payload.list.reports,
        offset: action.payload.list.offset,
        limit: action.payload.list.limit,
        activeId: action.payload.activeId
      };

    case ReportsActions.setPagination:
      return _objectSpread({}, state, {
        offset: action.payload.offset
      });

    case ReportsActions.setActiveId:
      return _objectSpread({}, state, {
        activeId: action.payload.activeId
      });

    case ReportsActions.reset:
      return defaultListState;

    default:
      return state;
  }
};

var details = function details() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultDetailsState;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ReportsActions.setInfoStatus:
      return _objectSpread({}, state, {}, action.payload.info, {
        reportId: action.payload.reportId
      });

    case ReportsActions.setRuns:
      return _objectSpread({}, state, {
        runs: action.payload.runs,
        totalRunsCount: action.payload.totalRunsCount
      });

    case ReportsActions.setRunsPagination:
      return _objectSpread({}, state, {
        runsOffset: action.payload.offset
      });

    case ReportsActions.setDetailsError:
      return _objectSpread({}, state, {
        detailError: action.payload.error
      });

    case ReportsActions.detailsReset:
    case ReportsActions.reset:
      return defaultDetailsState;

    default:
      return state;
  }
};

var ReportsStore = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  customizer: customizer,
  status: status,
  list: list,
  details: details,
  timeRange: timeRange,
  namespaces: namespaces
}), {
  customizer: defaultCustomizerState,
  status: defaultStatusState,
  list: defaultListState,
  details: defaultDetailsState,
  timeRange: defaultTimeRangeState,
  namespaces: namespacesInitialState
}, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__());
/* harmony default export */ __webpack_exports__["default"] = (ReportsStore);


/***/ }),

/***/ "./services/CDAPComponentsVersions.js":
/*!********************************************!*\
  !*** ./services/CDAPComponentsVersions.js ***!
  \********************************************/
/*! exports provided: isSpark2Available */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSpark2Available", function() { return isSpark2Available; });
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var api_version__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! api/version */ "./api/version.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var versions = [];

var checkForSpark2 = function checkForSpark2(versions) {
  var sparkcompat = versions.find(function (component) {
    return component.name === 'sparkcompat';
  });
  return !sparkcompat || sparkcompat && sparkcompat.version.indexOf('spark2') !== -1;
};

function isSpark2Available() {
  return rxjs_Observable__WEBPACK_IMPORTED_MODULE_0__["Observable"].create(function (observer) {
    if (versions.length) {
      return observer.next(checkForSpark2(versions));
    }

    api_version__WEBPACK_IMPORTED_MODULE_1__["default"].getCDAPComponentVersions().subscribe(function (v) {
      versions = v;
      observer.next(checkForSpark2(v));
    });
  });
}

/***/ }),

/***/ "./services/StatusMapper.js":
/*!**********************************!*\
  !*** ./services/StatusMapper.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
var _statusMap;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
*/

var statusMap = (_statusMap = {}, _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].DEPLOYED, 'Deployed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUBMITTING, 'Submitting'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].RUNNING, 'Running'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUCCEEDED, 'Succeeded'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].FAILED, 'Failed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].REJECTED, 'Rejected'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].DRAFT, 'Draft'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STOPPED, 'Stopped'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].COMPLETED, 'Succeeded'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].KILLED, 'Stopped'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].KILLED_BY_TIMER, 'Succeeded'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].DEPLOY_FAILED, 'Failed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].RUN_FAILED, 'Failed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUSPENDED, 'Deployed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SCHEDULED, 'Scheduled'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STARTING, 'Starting'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SCHEDULING, 'Scheduling'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STOPPING, 'Stopping'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUSPENDING, 'Suspending'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].PENDING, 'Provisioning'), _statusMap);

function lookupDisplayStatus(systemStatus) {
  if (systemStatus in statusMap) {
    return statusMap[systemStatus];
  } else {
    return systemStatus;
  }
}

function getStatusIndicatorClass(displayStatus) {
  if (displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].RUNNING] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STARTING] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].PENDING]) {
    return 'status-blue';
  } else if (displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUCCEEDED] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SCHEDULING] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STOPPING]) {
    return 'status-light-green';
  } else if (displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].FAILED] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].REJECTED]) {
    return 'status-light-red';
  } else {
    return 'status-light-grey';
  }
}

function getStatusIndicatorIcon(displayStatus) {
  if (displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].PENDING] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].DRAFT]) {
    return 'icon-circle-o';
  }

  return 'icon-circle';
}

/* harmony default export */ __webpack_exports__["default"] = ({
  statusMap: statusMap,
  lookupDisplayStatus: lookupDisplayStatus,
  getStatusIndicatorClass: getStatusIndicatorClass,
  getStatusIndicatorIcon: getStatusIndicatorIcon
});

/***/ })

}]);
//# sourceMappingURL=Reports.632a96fc25e36ddad05f.js.map