(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["DatasetDetailedView"],{

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/BreadCrumb/BreadCrumb.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/BreadCrumb/BreadCrumb.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.bread-crumb {\n  padding: 5px;\n  border: 1px solid #dbdbdb;\n  color: #666666;\n  height: 50px;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center; }\n  .bread-crumb a {\n    color: var(--brand-primary-color);\n    padding: 0 5px;\n    border-right: 1px solid darkgray; }\n    .bread-crumb a:hover {\n      color: var(--brand-primary-color); }\n    .bread-crumb a:before {\n      content: '< '; }\n  .bread-crumb > svg {\n    margin: 0 2px 0 5px; }\n  .bread-crumb span {\n    padding: 0 2px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/DatasetDetailedView/DatasetDetailedView.scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/DatasetDetailedView/DatasetDetailedView.scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.app-detailed-view {\n  height: calc(100vh - (53px + 48px));\n  background: #eeeeee;\n  color: #333333;\n  overflow-y: auto;\n  position: relative;\n  height: 100%;\n  display: grid;\n  grid-template-rows: auto auto 1fr; }\n  @media (min-width: 1701px) {\n    .app-detailed-view .overview-tab .entity-cards {\n      width: calc((100% - 20px - 10px - (6 * 10px)) / 7); } }\n  @media (min-width: 1601px) and (max-width: 1700px) {\n    .app-detailed-view .overview-tab .entity-cards {\n      width: calc((100% - 20px - 10px - (5 * 10px)) / 6); } }\n  @media (min-width: 1201px) and (max-width: 1600px) {\n    .app-detailed-view .overview-tab .entity-cards {\n      width: calc((100% - 20px - 10px - (4 * 10px)) / 5); } }\n  @media (min-width: 993px) and (max-width: 1200px) {\n    .app-detailed-view .overview-tab .entity-cards {\n      width: calc((100% - 20px - 10px - (3 * 10px)) / 4); } }\n  @media (min-width: 768px) and (max-width: 992px) {\n    .app-detailed-view .overview-tab .entity-cards {\n      width: calc((100% - 20px - 10px - (2 * 10px)) / 3); } }\n  .app-detailed-view .cask-resourcecenter-button {\n    top: 8px;\n    position: absolute; }\n  .app-detailed-view .overview-tab > .nav-tabs .nav-item .nav-link {\n    float: left;\n    padding: 0; }\n    .app-detailed-view .overview-tab > .nav-tabs .nav-item .nav-link a {\n      text-decoration: none;\n      padding: 0.5em 1em;\n      float: left;\n      color: inherit; }\n      .app-detailed-view .overview-tab > .nav-tabs .nav-item .nav-link a.active {\n        font-weight: bold;\n        text-decoration: none;\n        padding-bottom: 5px;\n        border-bottom: 2px solid var(--brand-primary-color); }\n  .app-detailed-view .bread-crumb-wrapper {\n    display: -webkit-box;\n    display: flex;\n    width: 100%;\n    -webkit-box-pack: justify;\n            justify-content: space-between;\n    height: 50px;\n    border: 1px solid #bbbbbb;\n    background: #eeeeee; }\n    .app-detailed-view .bread-crumb-wrapper .bread-crumb {\n      width: 100%;\n      border: 0; }\n    .app-detailed-view .bread-crumb-wrapper .plus-button {\n      margin: 20px; }\n      .app-detailed-view .bread-crumb-wrapper .plus-button .popper {\n        display: none; }\n  .app-detailed-view > .fa.fa-spinner.fa-spin {\n    position: fixed;\n    left: 50%;\n    top: 50%;\n    -webkit-transform: translate(-50%, -50%);\n            transform: translate(-50%, -50%);\n    color: gray; }\n  .app-detailed-view .properties-container {\n    height: 100%;\n    padding: 15px 10px;\n    overflow: auto; }\n    .app-detailed-view .properties-container .message-section {\n      padding: 0 10px;\n      margin-bottom: 15px; }\n\n.app-detailed-view.dataset-detailed-view .iframe-container {\n  height: 100%; }\n\n.app-detailed-view.dataset-detailed-view.loading {\n  height: 100%;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center; }\n\n.app-detailed-view.dataset-detailed-view .overview-tab > .nav-tabs .nav-item .nav-link {\n  float: left;\n  padding: 0; }\n  .app-detailed-view.dataset-detailed-view .overview-tab > .nav-tabs .nav-item .nav-link a {\n    text-decoration: none;\n    padding: 0.5em 1em;\n    float: left;\n    color: inherit; }\n    .app-detailed-view.dataset-detailed-view .overview-tab > .nav-tabs .nav-item .nav-link a.active {\n      font-weight: bold;\n      text-decoration: none;\n      padding-bottom: 5px;\n      border-bottom: 2px solid var(--brand-primary-color); }\n\n.app-detailed-view.dataset-detailed-view .bread-crumb-wrapper {\n  display: -webkit-box;\n  display: flex;\n  width: 100%;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  height: 50px;\n  border: 1px solid #bbbbbb;\n  background: #eeeeee; }\n  .app-detailed-view.dataset-detailed-view .bread-crumb-wrapper .bread-crumb {\n    width: 100%;\n    border: 0; }\n  .app-detailed-view.dataset-detailed-view .bread-crumb-wrapper .plus-button {\n    margin: 20px; }\n    .app-detailed-view.dataset-detailed-view .bread-crumb-wrapper .plus-button .popper {\n      display: none; }\n\n.app-detailed-view.dataset-detailed-view .properties-container {\n  height: 100%;\n  padding: 15px 10px;\n  overflow: auto; }\n  .app-detailed-view.dataset-detailed-view .properties-container .message-section {\n    padding: 0 10px;\n    margin-bottom: 15px; }\n\n.app-detailed-view.dataset-detailed-view .overview-meta-section .fast-actions-container {\n  -webkit-box-align: start;\n          align-items: flex-start; }\n  .app-detailed-view.dataset-detailed-view .overview-meta-section .fast-actions-container h4 {\n    vertical-align: top; }\n    .app-detailed-view.dataset-detailed-view .overview-meta-section .fast-actions-container h4 > span {\n      padding: 0;\n      vertical-align: top;\n      display: inline-block;\n      background: transparent; }\n      .app-detailed-view.dataset-detailed-view .overview-meta-section .fast-actions-container h4 > span:hover {\n        background: transparent; }\n\n.app-detailed-view.dataset-detailed-view .overview-tab .tab-content {\n  margin-top: 0;\n  overflow: hidden;\n  height: 100%; }\n  .app-detailed-view.dataset-detailed-view .overview-tab .tab-content .tab-pane > * {\n    height: 100%;\n    overflow: auto; }\n\n.app-detailed-view.dataset-detailed-view .dataset-lineage-tab .field-lineage-link {\n  position: absolute;\n  top: 25px;\n  right: 25px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Description/Description.scss":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Description/Description.scss ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.description-holder strong {\n  color: #333333; }\n\n.description-holder span {\n  color: #666666;\n  word-break: break-all; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/EntityCard/EntityCard.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/EntityCard/EntityCard.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.entity-cards {\n  padding: 0;\n  text-align: left;\n  border-radius: 0;\n  position: relative;\n  box-shadow: 0px 1px 10px 0 rgba(0, 0, 0, 0.3);\n  margin: 5px;\n  display: inline-block; }\n  .entity-cards.active.datapipeline .card-body {\n    background: #098cf9;\n    color: white; }\n    .entity-cards.active.datapipeline .card-body .entity-id-container small {\n      color: white; }\n    .entity-cards.active.datapipeline .card-body .metrics-container .metric-item p {\n      color: white; }\n    .entity-cards.active.datapipeline .card-body .fast-actions-container {\n      background: #098cf9; }\n      .entity-cards.active.datapipeline .card-body .fast-actions-container h4 {\n        vertical-align: top; }\n        .entity-cards.active.datapipeline .card-body .fast-actions-container h4 > span {\n          border: 0;\n          padding: 0;\n          vertical-align: top;\n          display: inline-block;\n          background: transparent; }\n          .entity-cards.active.datapipeline .card-body .fast-actions-container h4 > span:hover {\n            background: transparent; }\n      .entity-cards.active.datapipeline .card-body .fast-actions-container .btn-link {\n        color: white; }\n  .entity-cards.active.application .card-body {\n    background: #2c3e50;\n    color: white; }\n    .entity-cards.active.application .card-body .entity-id-container small {\n      color: white; }\n    .entity-cards.active.application .card-body .metrics-container .metric-item p {\n      color: white; }\n    .entity-cards.active.application .card-body .fast-actions-container {\n      background: #2c3e50; }\n      .entity-cards.active.application .card-body .fast-actions-container h4 {\n        vertical-align: top; }\n        .entity-cards.active.application .card-body .fast-actions-container h4 > span {\n          border: 0;\n          padding: 0;\n          vertical-align: top;\n          display: inline-block;\n          background: transparent; }\n          .entity-cards.active.application .card-body .fast-actions-container h4 > span:hover {\n            background: transparent; }\n      .entity-cards.active.application .card-body .fast-actions-container .btn-link {\n        color: white; }\n  .entity-cards.active.dataset .card-body {\n    background: #5DAFDB;\n    color: white; }\n    .entity-cards.active.dataset .card-body .entity-id-container small {\n      color: white; }\n    .entity-cards.active.dataset .card-body .metrics-container .metric-item p {\n      color: white; }\n    .entity-cards.active.dataset .card-body .fast-actions-container {\n      background: #5DAFDB; }\n      .entity-cards.active.dataset .card-body .fast-actions-container h4 {\n        vertical-align: top; }\n        .entity-cards.active.dataset .card-body .fast-actions-container h4 > span {\n          border: 0;\n          padding: 0;\n          vertical-align: top;\n          display: inline-block;\n          background: transparent; }\n          .entity-cards.active.dataset .card-body .fast-actions-container h4 > span:hover {\n            background: transparent; }\n      .entity-cards.active.dataset .card-body .fast-actions-container .btn-link {\n        color: white; }\n  .entity-cards.datapipeline .cask-card, .entity-cards.application .cask-card, .entity-cards.dataset .cask-card {\n    cursor: pointer; }\n  .entity-cards .cask-card {\n    padding: 0; }\n    .entity-cards .cask-card .card-header {\n      color: white;\n      padding: 0; }\n      .entity-cards .cask-card .card-header .card-header-wrapper {\n        width: 100%;\n        display: -webkit-box;\n        display: flex; }\n    .entity-cards .cask-card .card-body {\n      padding: 0; }\n  .entity-cards .entity-information {\n    height: 35px;\n    border-bottom: 1px solid #cccccc; }\n  .entity-cards .jump-button-container,\n  .entity-cards .entity-id-container {\n    display: inline-block; }\n  .entity-cards .jump-button-container {\n    width: 80px;\n    height: 100%; }\n    .entity-cards .jump-button-container .jump-button {\n      margin-top: 3px; }\n  .entity-cards .entity-id-container {\n    width: 100%;\n    padding-left: 10px;\n    margin-top: 3px;\n    position: relative; }\n    .entity-cards .entity-id-container.with-version {\n      margin-top: 0; }\n    .entity-cards .entity-id-container h4 {\n      font-weight: 500;\n      font-size: 15px;\n      margin: 0;\n      vertical-align: middle;\n      width: 90%;\n      overflow: hidden;\n      text-overflow: ellipsis;\n      white-space: nowrap;\n      line-height: 18px;\n      position: absolute;\n      bottom: -5px; }\n      .entity-cards .entity-id-container h4.with-version {\n        line-height: initial; }\n    .entity-cards .entity-id-container small {\n      font-size: 9px;\n      color: #999999;\n      display: block;\n      margin-top: 5px;\n      position: absolute; }\n  .entity-cards .metrics-container {\n    display: -webkit-box;\n    display: flex; }\n    .entity-cards .metrics-container .metric-item {\n      -webkit-box-flex: 1;\n              flex-grow: 1;\n      text-align: center;\n      padding: 0; }\n      .entity-cards .metrics-container .metric-item p {\n        margin-bottom: 4px;\n        color: #333333; }\n      .entity-cards .metrics-container .metric-item .metric-header {\n        font-weight: 500;\n        font-size: 11px;\n        margin-bottom: 3px;\n        color: #999999; }\n      .entity-cards .metrics-container .metric-item:not(:last-child) {\n        border-right: 1px solid #cccccc; }\n      .entity-cards .metrics-container .metric-item.app-name {\n        max-width: 50%; }\n        .entity-cards .metrics-container .metric-item.app-name p {\n          text-overflow: ellipsis;\n          white-space: nowrap;\n          overflow: hidden;\n          width: 95%;\n          margin-left: 3px; }\n  .entity-cards a {\n    color: inherit;\n    text-decoration: none; }\n    .entity-cards a:hover {\n      color: inherit;\n      text-decoration: none; }\n  .entity-cards .fast-actions-container {\n    background-color: white;\n    padding: 2px 0;\n    border-top: 1px solid #cccccc; }\n    .entity-cards .fast-actions-container .btn-link {\n      text-decoration: none;\n      font-size: 13px;\n      color: #4f5050;\n      padding: 0;\n      vertical-align: top;\n      margin: 0 15px; }\n      .entity-cards .fast-actions-container .btn-link[disabled] {\n        color: #818a91; }\n    .entity-cards .fast-actions-container h4 {\n      margin: 0;\n      vertical-align: top; }\n      .entity-cards .fast-actions-container h4 > span {\n        border: 0;\n        padding: 0;\n        vertical-align: top;\n        display: inline-block; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/EntityCard/EntityCardHeader/EntityCardHeader.scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/EntityCard/EntityCardHeader/EntityCardHeader.scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.entity-card-header {\n  padding-left: 10px;\n  width: 100%; }\n  .entity-card-header > div {\n    line-height: 13px;\n    margin-top: 5px;\n    margin-bottom: 5px;\n    font-size: 13px;\n    font-weight: 500; }\n    .entity-card-header > div span {\n      vertical-align: middle; }\n  .entity-card-header .entity-type {\n    margin-left: 5px; }\n  .entity-card-header.artifact {\n    background-color: #6399AB; }\n  .entity-card-header.application {\n    background-color: #2c3e50; }\n  .entity-card-header.datapipeline {\n    background-color: #098cf9; }\n  .entity-card-header.dataset {\n    background-color: #5DAFDB; }\n  .entity-card-header.view {\n    background-color: #1abc9c; }\n  .entity-card-header.program {\n    background-color: #29b19f; }\n  .entity-card-header.success-message {\n    background-color: #7ed321; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/FastAction/ExploreAction/ExploreAction.scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/FastAction/ExploreAction/ExploreAction.scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.fast-action-with-popover.btn.btn-secondary.btn-sm {\n  position: relative;\n  border: 1px solid #7ed321; }\n  .fast-action-with-popover.btn.btn-secondary.btn-sm .fast-action-popover-container {\n    position: absolute;\n    background: #7ed321;\n    padding: 5px;\n    top: -15px;\n    right: -3px;\n    border-radius: 7px;\n    font-size: 11px;\n    color: white; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/FastAction/ExploreAction/ExploreModal.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/FastAction/ExploreAction/ExploreModal.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.explore-modal.modal-dialog {\n  width: 80vw;\n  max-width: 80vw; }\n  .explore-modal.modal-dialog .explore-modal-body {\n    padding: 10px; }\n    .explore-modal.modal-dialog .explore-modal-body textarea {\n      resize: none;\n      margin: 0;\n      margin-bottom: 10px;\n      width: 100%; }\n    .explore-modal.modal-dialog .explore-modal-body .fa.fa-spinner {\n      margin-right: 10px; }\n    .explore-modal.modal-dialog .explore-modal-body .clearfix .text-danger {\n      word-wrap: break-word;\n      word-break: break-all; }\n    .explore-modal.modal-dialog .explore-modal-body .queries-table-wrapper {\n      margin-top: 10px;\n      max-height: calc(80vh - 225px);\n      overflow: auto; }\n    .explore-modal.modal-dialog .explore-modal-body .queries-table {\n      background-color: #f6f6f6;\n      border: 1px solid #bbbbbb; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table th,\n      .explore-modal.modal-dialog .explore-modal-body .queries-table td {\n        border: 0;\n        vertical-align: middle; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table tbody tr,\n      .explore-modal.modal-dialog .explore-modal-body .queries-table thead tr {\n        border-bottom: 1px solid #bbbbbb; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .btn-group .btn.btn-secondary {\n        padding: 7px;\n        border: 0;\n        background: transparent; }\n        .explore-modal.modal-dialog .explore-modal-body .queries-table .btn-group .btn.btn-secondary:first-child {\n          padding-left: 0; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .query-timestamp {\n        width: 185px; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .query-status {\n        width: 115px; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .query-status-value {\n        margin-right: 10px; }\n        .explore-modal.modal-dialog .explore-modal-body .queries-table .query-status-value ~ .fa-spinner {\n          margin: 0; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .query-actions {\n        width: 105px; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .preview-cell .fa.fa-spinner.fa-spin {\n        width: 100%; }\n      .explore-modal.modal-dialog .explore-modal-body .queries-table .preview-cell > div {\n        width: calc(80vw - 40px);\n        overflow: auto; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Overview/OverviewMetaSection/OverviewMetaSection.scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Overview/OverviewMetaSection/OverviewMetaSection.scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.overview-meta-section {\n  background: white;\n  padding: 10px 16px 10px 16px; }\n  .overview-meta-section hr {\n    margin-left: -16px;\n    margin-right: -16px;\n    border-color: #cccccc; }\n  .overview-meta-section > div {\n    margin-top: 8px; }\n  .overview-meta-section h2 {\n    color: #333333;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    white-space: nowrap;\n    width: 95%;\n    line-height: 1.3;\n    margin-bottom: 0; }\n  .overview-meta-section .fast-actions-container {\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-pack: justify;\n            justify-content: space-between;\n    -webkit-box-align: center;\n            align-items: center; }\n    .overview-meta-section .fast-actions-container h4 {\n      vertical-align: top; }\n      .overview-meta-section .fast-actions-container h4 > span {\n        padding: 0;\n        vertical-align: top;\n        display: inline-block;\n        background: transparent; }\n        .overview-meta-section .fast-actions-container h4 > span:hover, .overview-meta-section .fast-actions-container h4 > span:focus {\n          background: transparent;\n          outline: none; }\n    .overview-meta-section .fast-actions-container .btn-group .dropdown-toggle {\n      font-weight: bold;\n      color: #666666;\n      font-size: 12px;\n      border-color: #dbdbdb; }\n    .overview-meta-section .fast-actions-container small {\n      font-size: 10px;\n      color: #666666; }\n      .overview-meta-section .fast-actions-container small:not(:only-child) {\n        margin-left: 10px; }\n      .overview-meta-section .fast-actions-container small time {\n        margin-left: 5px; }\n    .overview-meta-section .fast-actions-container .overview-fast-actions {\n      margin: 0;\n      border-radius: 4px; }\n      .overview-meta-section .fast-actions-container .overview-fast-actions > span {\n        display: inline-block; }\n        .overview-meta-section .fast-actions-container .overview-fast-actions > span:last-child .btn.btn-link {\n          border-right: 0; }\n      .overview-meta-section .fast-actions-container .overview-fast-actions .btn.btn-link {\n        text-decoration: none;\n        font-size: 13px;\n        color: #4f5050;\n        padding: 0;\n        vertical-align: top; }\n        .overview-meta-section .fast-actions-container .overview-fast-actions .btn.btn-link:hover {\n          background-color: #eeeeee; }\n        .overview-meta-section .fast-actions-container .overview-fast-actions .btn.btn-link [class*=\"icon\"] {\n          margin: 8px 19px; }\n  .overview-meta-section .entity-info span {\n    font-weight: bold;\n    color: #666666; }\n  .overview-meta-section .tags-holder .tags-list {\n    /* 120px width of input box + 10px padding + 50px width of All Tags label + 10px padding + 60px width of Tags label + 15px width of loading icon */\n    max-width: calc(100% - 120px - 10px - 50px - 10px - 65px - 15px); }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Overview/Tabs/ProgramTab/ProgramTab.scss":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Overview/Tabs/ProgramTab/ProgramTab.scss ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.program-tab {\n  padding: 10px 10px 0 10px;\n  overflow-y: hidden;\n  height: 100%; }\n  .program-tab .message-section {\n    margin-left: 5px;\n    color: #666666;\n    height: 35px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Overview/Tabs/SchemaTab/SchemaTab.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Overview/Tabs/SchemaTab/SchemaTab.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.schema-tab {\n  padding: 10px 10px 0 10px;\n  overflow-y: auto;\n  height: 100%; }\n  .schema-tab .empty-schema {\n    margin-top: 10px; }\n  .schema-tab .disable-schema .fa-trash,\n  .schema-tab .disable-schema .fa-plus {\n    display: none; }\n  .schema-tab .schema-body .schema-row.nested > .field-name:before {\n    background-color: #eeeeee; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Pagination/Pagination.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Pagination/Pagination.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.pagination-container {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n          justify-content: center;\n  overflow-x: hidden;\n  position: relative; }\n  .pagination-container .pagination-content {\n    display: inline-block;\n    width: 100%; }\n  .pagination-container .change-page-panel {\n    display: inline-block;\n    position: absolute;\n    top: 0;\n    cursor: pointer;\n    /* Page height minus footer height */\n    height: 100%;\n    z-index: 300;\n    opacity: 0;\n    padding-left: 5px;\n    padding-right: 5px; }\n    .pagination-container .change-page-panel.first-page, .pagination-container .change-page-panel.last-page {\n      display: none; }\n    .pagination-container .change-page-panel:hover, .pagination-container .change-page-panel.pressed {\n      opacity: 0.8; }\n  .pagination-container .change-page-panel-left {\n    left: 0; }\n  .pagination-container .change-page-panel-right {\n    right: 0; }\n  .pagination-container .page-change-arrow-container {\n    position: relative;\n    top: 50%; }\n  .pagination-container .disabled-page-change {\n    visibility: hidden; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Pagination/PaginationDropdown.scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Pagination/PaginationDropdown.scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.pagination-dropdown {\n  cursor: pointer; }\n  .pagination-dropdown.dropdown.show {\n    /*\n      * We have important here because the 'show' css class added by reactstrap\n      * has important while showing the dropdown. Because of the display being\n      * set as block by reactstrap dropdown overflows out and screws up the display\n      * FIXME: CDAP-16605\n      */\n    display: inline-block !important; }\n  .pagination-dropdown.dropdown .dropdown-menu .dropdown-item {\n    cursor: pointer; }\n    .pagination-dropdown.dropdown .dropdown-menu .dropdown-item .dropdownItems .page-number {\n      line-height: 1; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/ProgramCards/ProgramCards.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/ProgramCards/ProgramCards.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.program-cards {\n  padding-top: 5px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/ProgramTable/ProgramTable.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/ProgramTable/ProgramTable.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.program-table {\n  overflow-x: auto;\n  padding-top: 10px; }\n  .program-table table {\n    border: 1px solid #bbbbbb; }\n    .program-table table tbody {\n      font-size: 12px; }\n    .program-table table tr th,\n    .program-table table tr td {\n      border-left: 0;\n      border-right: 0;\n      border-top: 0;\n      border-bottom: 1px solid #bbbbbb;\n      padding-top: 0;\n      padding-bottom: 0;\n      vertical-align: middle; }\n    .program-table table tr th {\n      line-height: 30px; }\n      .program-table table tr th span:last-child {\n        text-align: center; }\n    .program-table table tr td {\n      line-height: 40px; }\n      .program-table table tr td svg.program-type-icon {\n        margin-right: 5px; }\n      .program-table table tr td:first-child {\n        max-width: 150px;\n        overflow: hidden;\n        text-overflow: ellipsis;\n        white-space: nowrap; }\n      .program-table table tr td:last-child {\n        min-width: 103px;\n        padding-left: 0;\n        padding-right: 0; }\n      .program-table table tr td .fast-actions-container h4 {\n        margin: 0; }\n        .program-table table tr td .fast-actions-container h4 > span {\n          border: 0; }\n      .program-table table tr td .fast-actions-container .btn-link {\n        color: #4f5050;\n        margin-left: 5px;\n        padding: 5px;\n        border: 0; }\n        .program-table table tr td .fast-actions-container .btn-link > span {\n          vertical-align: top; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PropertiesEditor/AddPropertyModal/AddPropertyModal.scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PropertiesEditor/AddPropertyModal/AddPropertyModal.scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.add-property-modal.modal-dialog {\n  margin-top: 100px; }\n\n.add-property-modal .modal-header {\n  padding: 0;\n  background: #464a57;\n  color: white;\n  border: 0;\n  height: 40px; }\n  .add-property-modal .modal-header h4 {\n    font-weight: normal;\n    font-size: 14px; }\n    .add-property-modal .modal-header h4 span {\n      line-height: 40px;\n      padding: 5px 10px; }\n    .add-property-modal .modal-header h4 .close-section {\n      cursor: pointer; }\n      .add-property-modal .modal-header h4 .close-section span {\n        padding: 0 20px; }\n\n.add-property-modal .modal-body .input-properties {\n  margin-bottom: 15px; }\n\n.add-property-modal .modal-footer {\n  padding: 0;\n  text-align: left;\n  border-top: 0; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PropertiesEditor/PropertiesEditor.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PropertiesEditor/PropertiesEditor.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.properties-editor-container .table td,\n.properties-editor-container .table th {\n  border-bottom: 1px solid #cccccc; }\n\n.properties-editor-container .table .key {\n  width: 20%; }\n\n.properties-editor-container .table .scope {\n  width: 10%; }\n\n.properties-editor-container .table .actions {\n  width: 15%; }\n  .properties-editor-container .table .actions .fa {\n    margin-right: 15px;\n    cursor: pointer; }\n\n.properties-editor-container .table th {\n  border-top: 0; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SortableTable/SortableTable.scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SortableTable/SortableTable.scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.table th span {\n  cursor: pointer; }\n  .table th span .text-underline {\n    text-decoration: underline; }\n  .table th span i {\n    margin-left: 3px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016-2019 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.modal-dialog.search-results-modal {\n  margin-top: 95px;\n  width: 700px; }\n  .modal-dialog.search-results-modal .modal-content {\n    border-radius: 0; }\n  .modal-dialog.search-results-modal .modal-header {\n    background-color: #464a57;\n    color: white;\n    padding: 10px 15px;\n    border-bottom: 0;\n    border-radius: 0; }\n    .modal-dialog.search-results-modal .modal-header .close-section .dropdown {\n      display: inline-block;\n      margin-right: 26px; }\n      .modal-dialog.search-results-modal .modal-header .close-section .dropdown .current-page {\n        margin-left: 5px; }\n      .modal-dialog.search-results-modal .modal-header .close-section .dropdown .fa-caret-down {\n        margin-top: 4px;\n        margin-left: 10px; }\n      .modal-dialog.search-results-modal .modal-header .close-section .dropdown .dropdown-menu {\n        min-width: 65px;\n        outline: 0; }\n      .modal-dialog.search-results-modal .modal-header .close-section .dropdown .dropdown-item {\n        border: none;\n        display: block;\n        color: black;\n        background-color: white;\n        width: 100%;\n        text-align: left;\n        outline: 0; }\n        .modal-dialog.search-results-modal .modal-header .close-section .dropdown .dropdown-item:hover {\n          background-color: #2e323b;\n          color: white; }\n    .modal-dialog.search-results-modal .modal-header .tag-title {\n      width: 100%;\n      text-overflow: ellipsis;\n      overflow: hidden;\n      white-space: nowrap; }\n    .modal-dialog.search-results-modal .modal-header .modal-title {\n      font-size: 14px;\n      font-weight: 500;\n      width: 100%;\n      display: grid;\n      grid-template-columns: repeat(2, minmax(auto, auto)); }\n      .modal-dialog.search-results-modal .modal-header .modal-title .search-results-total {\n        color: #cccccc;\n        font-size: 13px;\n        margin-right: 26px; }\n      .modal-dialog.search-results-modal .modal-header .modal-title span.fa.fa-times {\n        cursor: pointer; }\n  .modal-dialog.search-results-modal .modal-body {\n    padding: 0;\n    min-height: 550px;\n    max-height: 550px;\n    overflow-y: auto; }\n    .modal-dialog.search-results-modal .modal-body a {\n      color: inherit; }\n      .modal-dialog.search-results-modal .modal-body a:nth-of-type(odd) .search-results-item {\n        background-color: #eeeeee; }\n      .modal-dialog.search-results-modal .modal-body a.search-results-item-link:hover {\n        text-decoration: none; }\n      .modal-dialog.search-results-modal .modal-body a .search-results-item {\n        padding: 5px 15px;\n        margin-right: 0;\n        margin-left: 0;\n        min-height: 55px; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .entity-title,\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .tag {\n          white-space: nowrap;\n          overflow-x: hidden;\n          text-overflow: ellipsis; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .entity-title {\n          font-size: 16px;\n          font-weight: 500; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .entity-icon {\n          margin-right: 10px;\n          vertical-align: middle;\n          color: #464a57; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .entity-description {\n          color: #666666;\n          margin-top: 3px; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .entity-tags-container .badge {\n          margin-right: 3px; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .tag {\n          max-width: 200px;\n          display: inline-block;\n          padding: 2px 5px;\n          margin-right: 3px;\n          margin-top: 3px;\n          font-size: 10px;\n          background-color: #464a57;\n          color: white;\n          border-radius: 3px;\n          cursor: pointer;\n          line-height: 13px;\n          font-weight: normal; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item:hover {\n          background-color: #dbdbdb;\n          text-decoration: none; }\n    .modal-dialog.search-results-modal .modal-body .pagination .page-item.active .page-link {\n      background-color: #464a57;\n      border-color: #464a57;\n      color: white; }\n    .modal-dialog.search-results-modal .modal-body .pagination .page-item:not(:last-child):not(:first-child) .page-link {\n      border: none; }\n    .modal-dialog.search-results-modal .modal-body .pagination .page-item:first-child > .page-link {\n      margin-right: 10px; }\n    .modal-dialog.search-results-modal .modal-body .pagination .page-item:last-child > .page-link {\n      margin-left: 10px; }\n    .modal-dialog.search-results-modal .modal-body .pagination .page-item.disabled > .page-link {\n      cursor: not-allowed; }\n    .modal-dialog.search-results-modal .modal-body .pagination .page-link {\n      cursor: pointer;\n      color: #464a57;\n      border-radius: 4px; }\n    .modal-dialog.search-results-modal .modal-body .search-results-container .no-search-results {\n      margin-top: 5px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Tags/Tag/Tag.scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Tags/Tag/Tag.scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.tags-holder .btn.tag-btn {\n  margin: 3px; }\n  .tags-holder .btn.tag-btn .tag-content {\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-align: center;\n            align-items: center;\n    white-space: nowrap; }\n  .tags-holder .btn.tag-btn .icon-close {\n    font-size: 12px;\n    margin-left: 5px; }\n  .tags-holder .btn.tag-btn.user-tag {\n    background-color: #eeeeee;\n    border: 1px solid #dce0ea;\n    color: #666666; }\n    .tags-holder .btn.tag-btn.user-tag:hover {\n      background-color: #dbdbdb;\n      color: #333333; }\n  .tags-holder .btn.tag-btn.system-tag {\n    background-color: white;\n    color: #5d6789;\n    border: 1px solid #dce0ea; }\n    .tags-holder .btn.tag-btn.system-tag:hover {\n      border-color: #5d6789;\n      color: #454a57; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Tags/Tags.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Tags/Tags.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.tags-holder {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center; }\n  .tags-holder > span {\n    display: inline-block; }\n  .tags-holder .tags-list {\n    /* 120px width of input box + 10px padding + 50px width of All Tags label + 10px padding + 15px width of loading icon */\n    max-width: calc(100% - 120px - 10px - 50px - 10px - 15px);\n    overflow: hidden;\n    white-space: nowrap; }\n    .tags-holder .tags-list .tag-btn:first-child {\n      margin-left: 0; }\n  .tags-holder .btn {\n    padding: 3px 5px;\n    font-size: 12px;\n    display: -webkit-inline-box;\n    display: inline-flex;\n    -webkit-box-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n            justify-content: center;\n    line-height: 1;\n    height: 18px; }\n    .tags-holder .btn.plus-button-container {\n      margin-left: 3px;\n      height: 18px;\n      background-color: #bbbbbb;\n      border-radius: 4px;\n      border-color: white; }\n      .tags-holder .btn.plus-button-container .icon-plus {\n        font-size: 7px; }\n  .tags-holder .tag-input {\n    height: 20px;\n    line-height: 20px;\n    width: 120px;\n    display: inline-block;\n    padding: 0 5px;\n    margin-left: 5px;\n    margin-right: 3px;\n    vertical-align: middle;\n    font-size: 12px; }\n  .tags-holder .tags-popover {\n    margin: 0 5px; }\n    .tags-holder .tags-popover .all-tags-label {\n      color: #0099ff;\n      cursor: pointer; }\n    .tags-holder .tags-popover .popper {\n      z-index: 1000;\n      padding: 10px;\n      text-align: left;\n      width: inherit;\n      max-height: 240px;\n      overflow-y: auto; }\n      .tags-holder .tags-popover .popper .tags-popover-header {\n        display: -webkit-box;\n        display: flex;\n        -webkit-box-align: center;\n                align-items: center;\n        margin-bottom: 10px; }\n        .tags-holder .tags-popover .popper .tags-popover-header .icon-close {\n          font-size: 13px;\n          margin-left: auto;\n          cursor: pointer; }\n      .tags-holder .tags-popover .popper .tag-btn {\n        display: table;\n        margin-left: 0; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/ViewSwitch/ViewSwitch.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/ViewSwitch/ViewSwitch.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.view-switch {\n  height: inherit; }\n  .view-switch .nav.nav-tabs .nav-item {\n    margin: 0; }\n    .view-switch .nav.nav-tabs .nav-item .nav-link {\n      margin: 0;\n      border: 0;\n      border-radius: 0;\n      fill: #373a3c; }\n      .view-switch .nav.nav-tabs .nav-item .nav-link.active {\n        font-weight: bold;\n        background: darkgray;\n        border: 0;\n        fill: #55595c; }\n      .view-switch .nav.nav-tabs .nav-item .nav-link.active:hover {\n        border-bottom: 0; }\n      .view-switch .nav.nav-tabs .nav-item .nav-link:not(.active):hover {\n        background-color: #eeeeee; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/react-timeago/lib/index.js":
/*!*************************************************************************************************!*\
  !*** delegated ../../../node_modules/react-timeago/lib/index.js from dll-reference cdap_vendor ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = (__webpack_require__(/*! dll-reference cdap_vendor */ "dll-reference cdap_vendor"))("./node_modules/react-timeago/lib/index.js");

/***/ }),

/***/ "../../node_modules/redux-thunk/es/index.js":
/*!**********************************************************************************************!*\
  !*** delegated ../../../node_modules/redux-thunk/es/index.js from dll-reference cdap_vendor ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, exports, __webpack_require__) {

module.exports = (__webpack_require__(/*! dll-reference cdap_vendor */ "dll-reference cdap_vendor"))("./node_modules/redux-thunk/es/index.js");

/***/ }),

/***/ "./api/app.js":
/*!********************!*\
  !*** ./api/app.js ***!
  \********************/
/*! exports provided: MyAppApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyAppApi", function() { return MyAppApi; });
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__["default"].getInstance();
var basepath = '/namespaces/:namespace/apps';
var appPath = "".concat(basepath, "/:appId");
var MyAppApi = {
  list: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  deployApp: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'PUT', 'REQUEST', appPath),
  get: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', appPath),
  getVersions: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(appPath, "/versions")),
  getDeployedApp: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  batchStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'POLL', '/namespaces/:namespace/status'),
  batchAppDetail: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', '/namespaces/:namespace/appdetail'),
  "delete": Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', appPath)
};

/***/ }),

/***/ "./api/explore.js":
/*!************************!*\
  !*** ./api/explore.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_0__["default"].getInstance();
var basepath = '/namespaces/:namespace/data/explore/tables';
var queriesPath = '/namespaces/:namespace/data/explore/queries';
var queryHandleApi = '/data/explore/queries/:queryHandle';
var myExploreApi = {
  fetchTables: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  fetchQueries: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'POLL', queriesPath),
  submitQuery: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', queriesPath),
  getQuerySchema: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', queryHandleApi + '/schema'),
  getQueryPreview: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', queryHandleApi + '/preview'),
  pollQueryStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'POLL', queryHandleApi + '/status'),
  download: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', queryHandleApi + '/download')
};
/* harmony default export */ __webpack_exports__["default"] = (myExploreApi);

/***/ }),

/***/ "./api/metadata.js":
/*!*************************!*\
  !*** ./api/metadata.js ***!
  \*************************/
/*! exports provided: MyMetadataApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyMetadataApi", function() { return MyMetadataApi; });
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__["default"].getInstance();
var basepath = '/namespaces/:namespace/:entityType/:entityId/metadata';
var lineagePath = '/namespaces/:namespace/datasets/:entityId/lineage/fields';
var fieldLineagePath = '/namespaces/:namespace/datasets/:entityId/lineage/allfieldlineage';
var MyMetadataApi = {
  getMetadata: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  getProperties: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/properties?responseFormat=v6")),
  addProperties: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/properties")),
  deleteProperty: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(basepath, "/properties/:key")),
  getTags: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/tags?responseFormat=v6")),
  addTags: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/tags")),
  deleteTags: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(basepath, "/tags/:key")),
  // Field Level Lineage
  getFields: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', lineagePath),
  getFieldLineage: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(lineagePath, "/:fieldName")),
  getFieldOperations: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(lineagePath, "/:fieldName/operations")),
  getAllFieldLineage: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', fieldLineagePath)
};

/***/ }),

/***/ "./api/program.js":
/*!************************!*\
  !*** ./api/program.js ***!
  \************************/
/*! exports provided: MyProgramApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyProgramApi", function() { return MyProgramApi; });
/* harmony import */ var services_datasource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/datasource */ "./services/datasource/index.js");
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = new services_datasource__WEBPACK_IMPORTED_MODULE_0__["default"]();
var basepath = '/namespaces/:namespace/apps/:appId/:programType/:programId';
var MyProgramApi = {
  get: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  status: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/status")),
  runs: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/runs")),
  pollRuns: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'POLL', "".concat(basepath, "/runs")),
  pollStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'POLL', "".concat(basepath, "/status")),
  action: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/:action")),
  stopRun: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/runs/:runId/stop"))
};

/***/ }),

/***/ "./components/BreadCrumb/BreadCrumb.scss":
/*!***********************************************!*\
  !*** ./components/BreadCrumb/BreadCrumb.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./BreadCrumb.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/BreadCrumb/BreadCrumb.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/BreadCrumb/index.js":
/*!****************************************!*\
  !*** ./components/BreadCrumb/index.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return BreadCrumb; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





__webpack_require__(/*! ./BreadCrumb.scss */ "./components/BreadCrumb/BreadCrumb.scss");

function BreadCrumb(_ref) {
  var previousPaths = _ref.previousPaths,
      currentStateIcon = _ref.currentStateIcon,
      currentStateLabel = _ref.currentStateLabel;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "bread-crumb"
  }, previousPaths.map(function (previousPath) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"], {
      to: previousPath.pathname,
      key: previousPath.pathname
    }, previousPath.label);
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
    name: currentStateIcon
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, currentStateLabel));
}
BreadCrumb.propTypes = {
  previousPaths: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    pathname: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    label: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  })),
  currentStateIcon: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  currentStateLabel: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/DatasetDetailedView/DatasetDetailedView.scss":
/*!*****************************************************************!*\
  !*** ./components/DatasetDetailedView/DatasetDetailedView.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./DatasetDetailedView.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/DatasetDetailedView/DatasetDetailedView.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/DatasetDetailedView/Tabs/LineageTab.js":
/*!***********************************************************!*\
  !*** ./components/DatasetDetailedView/Tabs/LineageTab.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return LineageTab; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




function LineageTab(_ref) {
  var entity = _ref.entity;
  var namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__["default"].getState().selectedNamespace;
  var url = window.getTrackerUrl({
    stateName: 'tracker.detail.entity.lineage',
    stateParams: {
      namespace: namespace,
      entityType: 'datasets',
      entityId: entity.id,
      iframe: true
    }
  });
  var encodedSource = encodeURIComponent(url);
  url += "&sourceUrl=".concat(encodedSource);
  var fllUrl = "/ns/".concat(namespace, "/datasets/").concat(entity.id, "/fields");
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "dataset-lineage-tab embed-responsive embed-responsive-16by9"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("iframe", {
    src: url,
    frameBorder: "0",
    width: "100%",
    height: "100%",
    className: "embed-responsive-item"
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "field-lineage-link"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"], {
    className: "btn btn-secondary",
    to: fllUrl
  }, "Field Level Lineage")));
}
LineageTab.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
};

/***/ }),

/***/ "./components/DatasetDetailedView/Tabs/PropertiesTab.js":
/*!**************************************************************!*\
  !*** ./components/DatasetDetailedView/Tabs/PropertiesTab.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PropertiesTab; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_PropertiesEditor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PropertiesEditor */ "./components/PropertiesEditor/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_3__);
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




function PropertiesTab(_ref) {
  var entity = _ref.entity;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "properties-container"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "message-section"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate('features.DetailView.PropertiesTab.title', {
    entityType: 'dataset',
    entityId: entity.id
  }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PropertiesEditor__WEBPACK_IMPORTED_MODULE_2__["default"], {
    entityType: "datasets",
    entityId: entity.id
  }));
}
PropertiesTab.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
};

/***/ }),

/***/ "./components/DatasetDetailedView/Tabs/index.js":
/*!******************************************************!*\
  !*** ./components/DatasetDetailedView/Tabs/index.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return DatasetDetailedViewTabs; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/isNil */ "../../node_modules/lodash/isNil.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_isNil__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var components_Overview_Tabs_ProgramTab__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Overview/Tabs/ProgramTab */ "./components/Overview/Tabs/ProgramTab/index.js");
/* harmony import */ var components_Overview_Tabs_SchemaTab__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Overview/Tabs/SchemaTab */ "./components/Overview/Tabs/SchemaTab/index.js");
/* harmony import */ var components_DatasetDetailedView_Tabs_LineageTab__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/DatasetDetailedView/Tabs/LineageTab */ "./components/DatasetDetailedView/Tabs/LineageTab.js");
/* harmony import */ var components_DatasetDetailedView_Tabs_PropertiesTab__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/DatasetDetailedView/Tabs/PropertiesTab */ "./components/DatasetDetailedView/Tabs/PropertiesTab.js");
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_11__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */












var PREFIX = 'features.DatasetDetailedView.Tabs';

var DatasetDetailedViewTabs =
/*#__PURE__*/
function (_Component) {
  _inherits(DatasetDetailedViewTabs, _Component);

  function DatasetDetailedViewTabs(props) {
    var _this;

    _classCallCheck(this, DatasetDetailedViewTabs);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(DatasetDetailedViewTabs).call(this, props));
    _this.state = {
      entity: _this.props.entity
    };
    return _this;
  }

  _createClass(DatasetDetailedViewTabs, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (!lodash_isNil__WEBPACK_IMPORTED_MODULE_3___default()(nextProps.entity)) {
        this.setState({
          entity: nextProps.entity
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var baseLinkPath = "/ns/".concat(this.props.params.namespace, "/datasets/").concat(this.props.params.datasetId);
      var baseMatchPath = "/ns/:namespace/datasets/:datasetId";
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "overview-tab"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Nav"], {
        tabs: true
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["NavItem"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "nav-link"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["NavLink"], {
        to: "".concat(baseLinkPath, "/schema"),
        activeClassName: "active",
        isActive: function isActive(match, location) {
          var basepath = "^".concat(baseLinkPath, "(/schema)?$");
          return location.pathname.match(basepath);
        }
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".schema"))))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["NavItem"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "nav-link"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["NavLink"], {
        to: "".concat(baseLinkPath, "/programs"),
        activeClassName: "active"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".programsWithCount"), {
        count: this.state.entity.programs.length
      })))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_10__["default"], {
        condition: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_9__["Theme"].showLineage !== false
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["NavItem"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "nav-link"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["NavLink"], {
        to: "".concat(baseLinkPath, "/lineage"),
        activeClassName: "active"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".lineage")))))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["NavItem"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "nav-link"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["NavLink"], {
        to: "".concat(baseLinkPath, "/properties"),
        activeClassName: "active"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".properties")))))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["TabContent"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Switch"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
        exact: true,
        path: "".concat(baseMatchPath, "/"),
        render: function render() {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Overview_Tabs_SchemaTab__WEBPACK_IMPORTED_MODULE_6__["default"], {
            entity: _this2.state.entity
          });
        }
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
        exact: true,
        path: "".concat(baseMatchPath, "/schema"),
        render: function render() {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Overview_Tabs_SchemaTab__WEBPACK_IMPORTED_MODULE_6__["default"], {
            entity: _this2.state.entity
          });
        }
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
        exact: true,
        path: "".concat(baseMatchPath, "/programs"),
        render: function render() {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Overview_Tabs_ProgramTab__WEBPACK_IMPORTED_MODULE_5__["default"], {
            entity: _this2.state.entity
          });
        }
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
        exact: true,
        path: "".concat(baseMatchPath, "/lineage"),
        render: function render() {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_DatasetDetailedView_Tabs_LineageTab__WEBPACK_IMPORTED_MODULE_7__["default"], {
            entity: _this2.state.entity
          });
        }
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
        exact: true,
        path: "".concat(baseMatchPath, "/properties"),
        render: function render() {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_DatasetDetailedView_Tabs_PropertiesTab__WEBPACK_IMPORTED_MODULE_8__["default"], {
            entity: _this2.state.entity
          });
        }
      }))));
    }
  }]);

  return DatasetDetailedViewTabs;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


DatasetDetailedViewTabs.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  params: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    datasetId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    namespace: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  }),
  pathname: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/DatasetDetailedView/index.js":
/*!*************************************************!*\
  !*** ./components/DatasetDetailedView/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return DatasetDetailedView; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Overview_OverviewMetaSection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Overview/OverviewMetaSection */ "./components/Overview/OverviewMetaSection/index.js");
/* harmony import */ var services_ExploreTables_ExploreTablesStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/ExploreTables/ExploreTablesStore */ "./services/ExploreTables/ExploreTablesStore.js");
/* harmony import */ var services_ExploreTables_ActionCreator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/ExploreTables/ActionCreator */ "./services/ExploreTables/ActionCreator.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_dataset__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! api/dataset */ "./api/dataset.js");
/* harmony import */ var api_metadata__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! api/metadata */ "./api/metadata.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var components_DatasetDetailedView_Tabs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/DatasetDetailedView/Tabs */ "./components/DatasetDetailedView/Tabs/index.js");
/* harmony import */ var services_fast_action_message_helper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! services/fast-action-message-helper */ "./services/fast-action-message-helper.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var lodash_capitalize__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! lodash/capitalize */ "../../node_modules/lodash/capitalize.js");
/* harmony import */ var lodash_capitalize__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(lodash_capitalize__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var components_404__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! components/404 */ "./components/404/index.js");
/* harmony import */ var components_BreadCrumb__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! components/BreadCrumb */ "./components/BreadCrumb/index.js");
/* harmony import */ var components_PlusButton__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! components/PlusButton */ "./components/PlusButton/index.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! react-helmet */ "../../node_modules/react-helmet/lib/Helmet.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! query-string */ "../../node_modules/query-string/index.js");
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(query_string__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
























__webpack_require__(/*! ./DatasetDetailedView.scss */ "./components/DatasetDetailedView/DatasetDetailedView.scss");

var DatasetDetailedView =
/*#__PURE__*/
function (_Component) {
  _inherits(DatasetDetailedView, _Component);

  function DatasetDetailedView(props) {
    var _this;

    _classCallCheck(this, DatasetDetailedView);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(DatasetDetailedView).call(this, props));
    var searchObj = query_string__WEBPACK_IMPORTED_MODULE_19___default.a.parse(Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["objectQuery"])(_this.props, 'location', 'search'));
    _this.state = {
      entityDetail: Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["objectQuery"])(_this.props, 'location', 'state', 'entityDetail') | {
        schema: null,
        programs: []
      },
      loading: true,
      isInvalid: false,
      routeToHome: false,
      successMessage: null,
      notFound: false,
      modalToOpen: Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["objectQuery"])(searchObj, 'modalToOpen') || '',
      previousPathName: null
    };
    return _this;
  }

  _createClass(DatasetDetailedView, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var selectedNamespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_6__["default"].getState().selectedNamespace;
      var _this$props$match$par = this.props.match.params,
          namespace = _this$props$match$par.namespace,
          datasetId = _this$props$match$par.datasetId;
      var previousPathName = Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["objectQuery"])(this.props, 'location', 'state', 'previousPathname') || "/ns/".concat(selectedNamespace, "?overviewid=").concat(datasetId, "&overviewtype=dataset");

      if (!namespace) {
        namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_6__["default"].getState().selectedNamespace;
      }

      this.setState({
        previousPathName: previousPathName
      });
      services_ExploreTables_ExploreTablesStore__WEBPACK_IMPORTED_MODULE_3__["default"].dispatch(Object(services_ExploreTables_ActionCreator__WEBPACK_IMPORTED_MODULE_4__["fetchTables"])(namespace));
      this.fetchEntityDetails(namespace, datasetId);

      if (this.state.entityDetail.id) {
        this.setState({
          loading: false
        });
      }
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      var _this2 = this;

      var _this$props$match$par2 = this.props.match.params,
          currentNamespace = _this$props$match$par2.namespace,
          currentDatasetId = _this$props$match$par2.datasetId;
      var _nextProps$match$para = nextProps.match.params,
          nextNamespace = _nextProps$match$para.namespace,
          nextDatasetId = _nextProps$match$para.datasetId;

      if (currentNamespace === nextNamespace && currentDatasetId === nextDatasetId) {
        return;
      }

      var _nextProps$match$para2 = nextProps.match.params,
          namespace = _nextProps$match$para2.namespace,
          datasetId = _nextProps$match$para2.datasetId;

      if (!namespace) {
        namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_6__["default"].getState().selectedNamespace;
      }

      services_ExploreTables_ExploreTablesStore__WEBPACK_IMPORTED_MODULE_3__["default"].dispatch(Object(services_ExploreTables_ActionCreator__WEBPACK_IMPORTED_MODULE_4__["fetchTables"])(namespace));
      this.setState({
        entityDetail: {
          schema: null,
          programs: []
        },
        loading: true
      }, function () {
        _this2.fetchEntityDetails(namespace, datasetId);
      });
    }
  }, {
    key: "fetchEntityDetails",
    value: function fetchEntityDetails(namespace, datasetId) {
      var _this3 = this;

      if (!this.state.entityDetail.schema || this.state.entityDetail.programs.length === 0) {
        var datasetParams = {
          namespace: namespace,
          datasetId: datasetId
        };
        var metadataParams = {
          namespace: namespace,
          entityType: 'datasets',
          entityId: datasetId,
          scope: services_global_constants__WEBPACK_IMPORTED_MODULE_20__["SCOPES"].SYSTEM
        };
        api_metadata__WEBPACK_IMPORTED_MODULE_8__["MyMetadataApi"].getProperties(metadataParams).combineLatest(api_dataset__WEBPACK_IMPORTED_MODULE_7__["MyDatasetApi"].getPrograms(datasetParams)).subscribe(function (res) {
          var appId; // TO DO: Remove this check once backend properly returns a 404 error when dataset does not exist
          // JIRA to fix backend: CDAP-15909

          var datasetProps = res[0].properties; // all metadata properties with System scope

          if (datasetProps.length === 0) {
            _this3.setState({
              notFound: true,
              loading: false
            });

            return;
          }

          var programs = res[1].map(function (programObj) {
            programObj.uniqueId = uuid_v4__WEBPACK_IMPORTED_MODULE_9___default()();
            appId = programObj.application;
            programObj.app = appId;
            programObj.name = programObj.program;
            return programObj;
          });
          var properties = {};
          res[0].properties.forEach(function (property) {
            if (property.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_20__["SCOPES"].SYSTEM) {
              properties[property.name] = property.value;
            }
          });
          var entityDetail = {
            programs: programs,
            schema: properties.schema,
            name: appId,
            // FIXME: Finalize on entity detail for fast action
            app: appId,
            id: datasetId,
            type: 'dataset',
            properties: properties
          };

          _this3.setState({
            entityDetail: entityDetail
          }, function () {
            setTimeout(function () {
              _this3.setState({
                loading: false
              });
            }, 1000);
          });
        }, function (err) {
          if (err.statusCode === 404) {
            _this3.setState({
              notFound: true,
              loading: false
            });
          }
        });
      }
    }
  }, {
    key: "goToHome",
    value: function goToHome(action) {
      var _this4 = this;

      if (action === 'delete') {
        var selectedNamespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_6__["default"].getState().selectedNamespace;
        this.setState({
          selectedNamespace: selectedNamespace,
          routeToHome: true
        });
      }

      var successMessage;

      if (action === 'setPreferences') {
        successMessage = Object(services_fast_action_message_helper__WEBPACK_IMPORTED_MODULE_12__["default"])(action, {
          entityType: lodash_capitalize__WEBPACK_IMPORTED_MODULE_14___default()(this.state.entityDetail.type)
        });
      } else {
        successMessage = Object(services_fast_action_message_helper__WEBPACK_IMPORTED_MODULE_12__["default"])(action);
      }

      this.setState({
        successMessage: successMessage
      }, function () {
        setTimeout(function () {
          _this4.setState({
            successMessage: null
          });
        }, 3000);
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this5 = this;

      if (this.state.loading) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "app-detailed-view dataset-detailed-view loading"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "fa fa-spinner fa-spin fa-3x"
        }));
      }

      if (this.state.notFound) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_404__WEBPACK_IMPORTED_MODULE_15__["default"], {
          entityType: "dataset",
          entityName: this.props.match.params.datasetId
        });
      }

      var previousPaths = [{
        pathname: this.state.previousPathName,
        label: i18n_react__WEBPACK_IMPORTED_MODULE_10___default.a.translate('commons.back')
      }];
      var datasetId = this.props.match.params.datasetId;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "app-detailed-view dataset-detailed-view"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_helmet__WEBPACK_IMPORTED_MODULE_18___default.a, {
        title: i18n_react__WEBPACK_IMPORTED_MODULE_10___default.a.translate('features.DatasetDetailedView.Title', {
          datasetId: datasetId,
          productName: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_21__["Theme"].productName
        })
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "bread-crumb-wrapper"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_BreadCrumb__WEBPACK_IMPORTED_MODULE_16__["default"], {
        previousPaths: previousPaths,
        currentStateIcon: "icon-datasets",
        currentStateLabel: i18n_react__WEBPACK_IMPORTED_MODULE_10___default.a.translate('commons.dataset')
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PlusButton__WEBPACK_IMPORTED_MODULE_17__["default"], {
        mode: components_PlusButton__WEBPACK_IMPORTED_MODULE_17__["default"].MODE.resourcecenter
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Overview_OverviewMetaSection__WEBPACK_IMPORTED_MODULE_2__["default"], {
        entity: this.state.entityDetail,
        onFastActionSuccess: this.goToHome.bind(this),
        onFastActionUpdate: this.goToHome.bind(this),
        fastActionToOpen: this.state.modalToOpen,
        showFullCreationTime: true
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_13__["Route"], {
        path: "/ns/:namespace/datasets/:datasetId/",
        render: function render() {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_DatasetDetailedView_Tabs__WEBPACK_IMPORTED_MODULE_11__["default"], {
            params: _this5.props.match.params,
            pathname: _this5.props.location.pathname,
            entity: _this5.state.entityDetail
          });
        }
      }), this.state.routeToHome ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_13__["Redirect"], {
        to: "/ns/".concat(this.state.selectedNamespace)
      }) : null);
    }
  }]);

  return DatasetDetailedView;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


DatasetDetailedView.propTypes = {
  match: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  location: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
};

/***/ }),

/***/ "./components/Description/Description.scss":
/*!*************************************************!*\
  !*** ./components/Description/Description.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Description.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Description/Description.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Description/index.js":
/*!*****************************************!*\
  !*** ./components/Description/index.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Description; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_2__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */



__webpack_require__(/*! ./Description.scss */ "./components/Description/Description.scss");



var Description =
/*#__PURE__*/
function (_Component) {
  _inherits(Description, _Component);

  function Description(props) {
    var _this;

    _classCallCheck(this, Description);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(Description).call(this, props));
    _this.state = {
      description: _this.props.description
    };
    return _this;
  }

  _createClass(Description, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (nextProps.description !== this.state.description) {
        this.setState({
          description: nextProps.description
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "description-holder"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, " ", i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate('features.Description.label'), ": "), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.state.description), !this.state.description.length ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", null, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate('features.Description.nodescription')) : null);
    }
  }]);

  return Description;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


Description.defaultProps = {
  description: ''
};
Description.propTypes = {
  description: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/EntityCard/ApplicationMetrics/index.js":
/*!***********************************************************!*\
  !*** ./components/EntityCard/ApplicationMetrics/index.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ApplicationMetrics; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_3__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var ApplicationMetrics =
/*#__PURE__*/
function (_Component) {
  _inherits(ApplicationMetrics, _Component);

  function ApplicationMetrics(props) {
    _classCallCheck(this, ApplicationMetrics);

    return _possibleConstructorReturn(this, _getPrototypeOf(ApplicationMetrics).call(this, props));
  }

  _createClass(ApplicationMetrics, [{
    key: "render",
    value: function render() {
      var loading = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-spin fa-spinner"
      });
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metrics-container"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metric-item"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "metric-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate('commons.entity.metrics.programs')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, !this.props.extraInfo ? loading : Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["humanReadableNumber"])(this.props.extraInfo.numPrograms))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metric-item"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "metric-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate('commons.entity.metrics.running')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, !this.props.extraInfo ? loading : Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["humanReadableNumber"])(this.props.extraInfo.running))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metric-item"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "metric-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate('commons.entity.metrics.failed')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, !this.props.extraInfo ? loading : Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["humanReadableNumber"])(this.props.extraInfo.failed))));
    }
  }]);

  return ApplicationMetrics;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


ApplicationMetrics.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  extraInfo: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
};

/***/ }),

/***/ "./components/EntityCard/ArtifactMetrics/index.js":
/*!********************************************************!*\
  !*** ./components/EntityCard/ArtifactMetrics/index.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ArtifactMetrics; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_app__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/app */ "./api/app.js");
/* harmony import */ var api_artifact__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/artifact */ "./api/artifact.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */







var ArtifactMetrics =
/*#__PURE__*/
function (_Component) {
  _inherits(ArtifactMetrics, _Component);

  function ArtifactMetrics(props) {
    var _this;

    _classCallCheck(this, ArtifactMetrics);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ArtifactMetrics).call(this, props));
    _this.state = {
      extensions: 0,
      apps: 0,
      type: '-',
      loading: true
    };
    _this.unsub = null;
    return _this;
  }

  _createClass(ArtifactMetrics, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var _this2 = this;

      var extensionParams = {
        namespace: services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["default"].getState().selectedNamespace,
        artifactId: this.props.entity.id,
        version: this.props.entity.version,
        scope: this.props.entity.scope
      };
      var appsParams = {
        namespace: services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["default"].getState().selectedNamespace,
        artifactName: this.props.entity.id,
        artifactVersion: this.props.entity.version
      };
      this.unsub = api_artifact__WEBPACK_IMPORTED_MODULE_3__["MyArtifactApi"].listExtensions(extensionParams).combineLatest(api_app__WEBPACK_IMPORTED_MODULE_2__["MyAppApi"].getDeployedApp(appsParams), api_artifact__WEBPACK_IMPORTED_MODULE_3__["MyArtifactApi"].get(extensionParams)).subscribe(function (res) {
        _this2.setState({
          extensions: res[0].length,
          apps: res[1].length,
          type: res[2].classes.plugins.length > 0 ? 'Plugin' : 'App',
          loading: false
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.unsub.unsubscribe();
    }
  }, {
    key: "render",
    value: function render() {
      var loading = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-spin fa-spinner"
      });
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metrics-container"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metric-item"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "metric-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate('commons.entity.artifact.extensions')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, this.state.loading ? loading : this.state.extensions)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metric-item"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "metric-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate('commons.entity.artifact.applications')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, this.state.loading ? loading : this.state.apps)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metric-item"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "metric-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate('commons.entity.artifact.type')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, this.state.loading ? loading : this.state.type)));
    }
  }]);

  return ArtifactMetrics;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


ArtifactMetrics.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
};

/***/ }),

/***/ "./components/EntityCard/DatasetMetrics/index.js":
/*!*******************************************************!*\
  !*** ./components/EntityCard/DatasetMetrics/index.js ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return DatasetMetrics; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_metric__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/metric */ "./api/metric.js");
/* harmony import */ var api_dataset__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/dataset */ "./api/dataset.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








var DatasetMetrics =
/*#__PURE__*/
function (_Component) {
  _inherits(DatasetMetrics, _Component);

  function DatasetMetrics(props) {
    var _this;

    _classCallCheck(this, DatasetMetrics);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(DatasetMetrics).call(this, props));
    _this.state = {
      programs: 0,
      ops: 0,
      writes: 0,
      loading: true
    };
    return _this;
  }

  _createClass(DatasetMetrics, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var _this2 = this;

      var currentNamespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["default"].getState().selectedNamespace;
      var datasetParams = {
        namespace: currentNamespace,
        datasetId: this.props.entity.id
      };
      var metricsParams = {
        tag: ["namespace:".concat(currentNamespace), "dataset:".concat(this.props.entity.id)],
        metric: ['system.dataset.store.ops', 'system.dataset.store.writes'],
        aggregate: true
      };
      api_metric__WEBPACK_IMPORTED_MODULE_2__["MyMetricApi"].query(metricsParams).combineLatest(api_dataset__WEBPACK_IMPORTED_MODULE_3__["MyDatasetApi"].getPrograms(datasetParams)).subscribe(function (res) {
        var ops = 0,
            writes = 0;

        if (res[0].series.length > 0) {
          res[0].series.forEach(function (metric) {
            if (metric.metricName === 'system.dataset.store.ops') {
              ops = metric.data[0].value;
            } else if (metric.metricName === 'system.dataset.store.writes') {
              writes = metric.data[0].value;
            }
          });
        }

        _this2.setState({
          ops: ops,
          writes: writes,
          programs: res[1].length,
          loading: false
        });
      });
    }
  }, {
    key: "render",
    value: function render() {
      var loading = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-spin fa-spinner"
      });
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metrics-container"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metric-item"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "metric-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('commons.entity.dataset.programs')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, this.state.loading ? loading : Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["humanReadableNumber"])(this.state.programs))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metric-item"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "metric-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('commons.entity.dataset.operations')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, this.state.loading ? loading : Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["humanReadableNumber"])(this.state.ops))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metric-item"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "metric-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('commons.entity.dataset.writes')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, this.state.loading ? loading : Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["humanReadableNumber"])(this.state.writes))));
    }
  }]);

  return DatasetMetrics;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


DatasetMetrics.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
};

/***/ }),

/***/ "./components/EntityCard/EntityCard.scss":
/*!***********************************************!*\
  !*** ./components/EntityCard/EntityCard.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./EntityCard.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/EntityCard/EntityCard.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/EntityCard/EntityCardHeader/EntityCardHeader.scss":
/*!**********************************************************************!*\
  !*** ./components/EntityCard/EntityCardHeader/EntityCardHeader.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./EntityCardHeader.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/EntityCard/EntityCardHeader/EntityCardHeader.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/EntityCard/EntityCardHeader/index.js":
/*!*********************************************************!*\
  !*** ./components/EntityCard/EntityCardHeader/index.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EntityCardHeader; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash/isEmpty */ "../../node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var services_metadata_parser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/metadata-parser */ "./services/metadata-parser/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016-2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





__webpack_require__(/*! ./EntityCardHeader.scss */ "./components/EntityCard/EntityCardHeader/EntityCardHeader.scss");





var EntityCardHeader =
/*#__PURE__*/
function (_Component) {
  _inherits(EntityCardHeader, _Component);

  function EntityCardHeader(props) {
    _classCallCheck(this, EntityCardHeader);

    return _possibleConstructorReturn(this, _getPrototypeOf(EntityCardHeader).call(this, props));
  }

  _createClass(EntityCardHeader, [{
    key: "getEntityType",
    value: function getEntityType() {
      return Object(services_metadata_parser__WEBPACK_IMPORTED_MODULE_6__["getType"])(this.props.entity);
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "card-header-wrapper"
      }, !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_5___default()(this.props.successMessage) ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "entity-card-header success-message"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.props.successMessage))) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        onClick: this.props.onClick,
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()('entity-card-header', this.props.className)
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
        name: this.props.entity.icon,
        className: "entity-icon"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "entity-type"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate("commons.entity.".concat(this.getEntityType(), ".singular"))))));
    }
  }]);

  return EntityCardHeader;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


EntityCardHeader.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onClick: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  successMessage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/EntityCard/FastActions/index.js":
/*!****************************************************!*\
  !*** ./components/EntityCard/FastActions/index.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FastActions; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_FastAction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/FastAction */ "./components/FastAction/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/isNil */ "../../node_modules/lodash/isNil.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_isNil__WEBPACK_IMPORTED_MODULE_4__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var FastActions =
/*#__PURE__*/
function (_Component) {
  _inherits(FastActions, _Component);

  function FastActions(props) {
    _classCallCheck(this, FastActions);

    return _possibleConstructorReturn(this, _getPrototypeOf(FastActions).call(this, props));
  }

  _createClass(FastActions, [{
    key: "listOfFastActions",
    value: function listOfFastActions() {
      var fastActionTypes = [];

      switch (this.props.entity.type) {
        case 'artifact':
          fastActionTypes = ['delete'];
          break;

        case 'application':
          fastActionTypes = ['setPreferences', 'delete'];
          break;

        case 'dataset':
          fastActionTypes = ['truncate', 'delete', 'explore'];
          break;

        case 'program':
          fastActionTypes = ['setPreferences', 'startStop', 'log'];
          break;
      }

      return fastActionTypes;
    }
  }, {
    key: "onSuccess",
    value: function onSuccess(action) {
      if (action === 'startStop') {
        return;
      }

      if (action === 'setPreferences') {
        if (this.props.onSuccess) {
          this.props.onSuccess();
        }
      }

      if (action === 'delete') {
        if (this.props.onSuccess) {
          this.props.onSuccess(action);
        }
      }

      if (this.props.onUpdate) {
        this.props.onUpdate(action);
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this = this;

      var fastActions = this.listOfFastActions();
      var className = this.props.className || 'text-center';
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h4", {
        className: className
      }, fastActions.map(function (action) {
        if (_this.props.actionToOpen && _this.props.actionToOpen === action) {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_FastAction__WEBPACK_IMPORTED_MODULE_2__["default"], {
            key: action,
            type: action,
            entity: _this.props.entity,
            opened: true,
            onSuccess: _this.onSuccess.bind(_this, action),
            argsToAction: lodash_isNil__WEBPACK_IMPORTED_MODULE_4___default()(Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["objectQuery"])(_this.props.argsToActions, action)) ? {} : _this.props.argsToActions[action]
          });
        } else {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_FastAction__WEBPACK_IMPORTED_MODULE_2__["default"], {
            key: action,
            type: action,
            entity: _this.props.entity,
            onSuccess: _this.onSuccess.bind(_this, action),
            argsToAction: lodash_isNil__WEBPACK_IMPORTED_MODULE_4___default()(Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["objectQuery"])(_this.props.argsToActions, action)) ? {} : _this.props.argsToActions[action]
          });
        }
      }));
    }
  }]);

  return FastActions;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


FastActions.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  onUpdate: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onSuccess: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  actionToOpen: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  argsToActions: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    "delete": prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
    setPreferences: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
    truncate: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
    explore: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
    sendEvents: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
    viewEvents: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
    startStop: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
    log: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
  })
};

/***/ }),

/***/ "./components/EntityCard/ProgramMetrics/index.js":
/*!*******************************************************!*\
  !*** ./components/EntityCard/ProgramMetrics/index.js ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProgramMetrics; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_program__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/program */ "./api/program.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_program_api_converter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/program-api-converter */ "./services/program-api-converter/index.js");
/* harmony import */ var services_StatusMapper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/StatusMapper */ "./services/StatusMapper.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








var ProgramMetrics =
/*#__PURE__*/
function (_Component) {
  _inherits(ProgramMetrics, _Component);

  function ProgramMetrics(props) {
    var _this;

    _classCallCheck(this, ProgramMetrics);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ProgramMetrics).call(this, props));
    _this.state = {
      status: '',
      numRuns: 0,
      appName: _this.props.entity.applicationId,
      loading: true
    };
    _this.runsApi = '';
    return _this;
  }

  _createClass(ProgramMetrics, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var _this2 = this;

      var params = {
        namespace: services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["default"].getState().selectedNamespace,
        appId: this.props.entity.applicationId,
        programType: Object(services_program_api_converter__WEBPACK_IMPORTED_MODULE_4__["convertProgramToApi"])(this.props.entity.programType),
        programId: this.props.entity.id
      };

      if (this.props.poll) {
        this.runsApi = api_program__WEBPACK_IMPORTED_MODULE_2__["MyProgramApi"].pollRuns;
      } else {
        this.runsApi = api_program__WEBPACK_IMPORTED_MODULE_2__["MyProgramApi"].runs;
      }

      this.programMetrics$ = this.runsApi(params).combineLatest(api_program__WEBPACK_IMPORTED_MODULE_2__["MyProgramApi"].pollStatus(params)).subscribe(function (res) {
        _this2.setState({
          status: res[1].status,
          numRuns: res[0].length,
          loading: false
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.programMetrics$.unsubscribe();
    }
  }, {
    key: "render",
    value: function render() {
      var loading = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-spin fa-spinner"
      });
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metrics-container"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metric-item"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "metric-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('commons.entity.program.status')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, this.state.loading ? loading : services_StatusMapper__WEBPACK_IMPORTED_MODULE_5__["default"].lookupDisplayStatus(this.state.status))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metric-item"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "metric-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('commons.entity.program.runs')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, this.state.loading ? loading : this.state.numRuns)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "metric-item app-name"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "metric-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('commons.entity.program.application')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, this.state.loading ? loading : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        title: this.state.appName
      }, this.state.appName))));
    }
  }]);

  return ProgramMetrics;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


ProgramMetrics.defaultProps = {
  poll: false
};
ProgramMetrics.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    applicationId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    programType: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired
  }),
  poll: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
};

/***/ }),

/***/ "./components/EntityCard/index.js":
/*!****************************************!*\
  !*** ./components/EntityCard/index.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EntityCard; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Card */ "./components/Card/index.js");
/* harmony import */ var _EntityCardHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./EntityCardHeader */ "./components/EntityCard/EntityCardHeader/index.js");
/* harmony import */ var _ApplicationMetrics__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ApplicationMetrics */ "./components/EntityCard/ApplicationMetrics/index.js");
/* harmony import */ var _ArtifactMetrics__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ArtifactMetrics */ "./components/EntityCard/ArtifactMetrics/index.js");
/* harmony import */ var _DatasetMetrics__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./DatasetMetrics */ "./components/EntityCard/DatasetMetrics/index.js");
/* harmony import */ var _ProgramMetrics__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ProgramMetrics */ "./components/EntityCard/ProgramMetrics/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var components_EntityCard_FastActions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/EntityCard/FastActions */ "./components/EntityCard/FastActions/index.js");
/* harmony import */ var services_fast_action_message_helper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! services/fast-action-message-helper */ "./services/fast-action-message-helper.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! lodash/isNil */ "../../node_modules/lodash/isNil.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(lodash_isNil__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var lodash_capitalize__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! lodash/capitalize */ "../../node_modules/lodash/capitalize.js");
/* harmony import */ var lodash_capitalize__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(lodash_capitalize__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
















__webpack_require__(/*! ./EntityCard.scss */ "./components/EntityCard/EntityCard.scss");

var EntityCard =
/*#__PURE__*/
function (_Component) {
  _inherits(EntityCard, _Component);

  function EntityCard(props) {
    var _this;

    _classCallCheck(this, EntityCard);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(EntityCard).call(this, props));
    _this.state = {
      successMessage: null
    };
    _this.cardRef = null;
    _this.onSuccess = _this.onSuccess.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(EntityCard, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (nextProps.activeEntity !== this.props.entity.uniqueId) {
        this.setState({
          overviewMode: false
        });
      }
    }
  }, {
    key: "onSuccess",
    value: function onSuccess(successMessage) {
      var _this2 = this;

      this.setState({
        successMessage: successMessage
      });
      setTimeout(function () {
        _this2.setState({
          successMessage: null
        });
      }, 3000);
    }
  }, {
    key: "renderEntityStatus",
    value: function renderEntityStatus() {
      switch (this.props.entity.type) {
        case 'application':
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_ApplicationMetrics__WEBPACK_IMPORTED_MODULE_4__["default"], {
            entity: this.props.entity,
            extraInfo: this.props.extraInfo
          });

        case 'artifact':
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_ArtifactMetrics__WEBPACK_IMPORTED_MODULE_5__["default"], {
            entity: this.props.entity
          });

        case 'dataset':
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_DatasetMetrics__WEBPACK_IMPORTED_MODULE_6__["default"], {
            entity: this.props.entity
          });

        case 'program':
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_ProgramMetrics__WEBPACK_IMPORTED_MODULE_7__["default"], {
            entity: this.props.entity,
            poll: this.props.poll
          });

        case 'view':
        default:
          return null;
      }
    }
  }, {
    key: "onClick",
    value: function onClick() {
      if (this.props.entity.type === 'artifact' || this.props.entity.type === 'program' || this.props.entity.isHydrator) {
        return;
      }

      if (this.props.onClick) {
        this.props.onClick();
      }
    }
  }, {
    key: "onFastActionUpdate",
    value: function onFastActionUpdate(action) {
      var successMessage;

      if (action === 'setPreferences') {
        successMessage = Object(services_fast_action_message_helper__WEBPACK_IMPORTED_MODULE_10__["default"])(action, {
          entityType: lodash_capitalize__WEBPACK_IMPORTED_MODULE_12___default()(this.props.entity.type)
        });
      } else {
        successMessage = Object(services_fast_action_message_helper__WEBPACK_IMPORTED_MODULE_10__["default"])(action);
      }

      if (!lodash_isNil__WEBPACK_IMPORTED_MODULE_11___default()(successMessage)) {
        this.onSuccess(successMessage);
      }

      if (this.props.onUpdate) {
        this.props.onUpdate();
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      if (!this.props.entity) {
        return null;
      }

      var header = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_EntityCardHeader__WEBPACK_IMPORTED_MODULE_3__["default"], {
        className: this.props.entity.isHydrator ? 'datapipeline' : this.props.entity.type,
        entity: this.props.entity,
        successMessage: this.state.successMessage
      });
      var card = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Card__WEBPACK_IMPORTED_MODULE_2__["default"], {
        header: header,
        id: this.props.entity.isHydrator ? "entity-cards-datapipeline" : "entity-cards-".concat(this.props.entity.type),
        onClick: this.onClick.bind(this)
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "entity-information clearfix"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('entity-id-container', {
          'with-version': this.props.entity.version
        })
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h4", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()({
          'with-version': this.props.entity.version
        }),
        title: this.props.entity.id,
        "data-cy": "".concat(this.props.entity.id, "-header")
      }, this.props.entity.id), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("small", null, Object(services_helpers__WEBPACK_IMPORTED_MODULE_14__["objectQuery"])(this.props, 'entity', 'version')))), this.renderEntityStatus(), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "fast-actions-container text-center"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_EntityCard_FastActions__WEBPACK_IMPORTED_MODULE_9__["default"], {
        entity: this.props.entity,
        onUpdate: this.onFastActionUpdate.bind(this),
        onSuccess: this.props.onFastActionSuccess,
        className: "btn-group"
      })));

      if (this.props.entity.isHydrator) {
        var navObject = {
          stateName: 'hydrator.detail',
          stateParams: {
            namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_13__["getCurrentNamespace"])(),
            pipelineId: this.props.entity.id
          }
        };
        var link = window.getHydratorUrl(navObject);
        card = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
          href: link,
          title: this.props.entity.id
        }, card);
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('entity-cards', this.props.entity.isHydrator ? 'datapipeline' : this.props.entity.type, this.props.className),
        id: this.props.id,
        ref: function ref(_ref) {
          return _this3.cardRef = _ref;
        }
      }, card);
    }
  }]);

  return EntityCard;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


EntityCard.defaultProps = {
  onClick: function onClick() {},
  poll: false
};
EntityCard.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  poll: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  onUpdate: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  // FIXME: Remove??
  onFastActionSuccess: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onClick: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  activeEntity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  extraInfo: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
};

/***/ }),

/***/ "./components/FastAction/DeleteAction/index.js":
/*!*****************************************************!*\
  !*** ./components/FastAction/DeleteAction/index.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return DeleteAction; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/app */ "./api/app.js");
/* harmony import */ var api_artifact__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! api/artifact */ "./api/artifact.js");
/* harmony import */ var api_dataset__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! api/dataset */ "./api/dataset.js");
/* harmony import */ var _FastActionButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../FastActionButton */ "./components/FastAction/FastActionButton/index.js");
/* harmony import */ var components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/ConfirmationModal */ "./components/ConfirmationModal/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var event_emitter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! event-emitter */ "../../node_modules/event-emitter/index.js");
/* harmony import */ var event_emitter__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(event_emitter__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var services_global_events__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! services/global-events */ "./services/global-events.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_11__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016-2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */













var DeleteAction =
/*#__PURE__*/
function (_Component) {
  _inherits(DeleteAction, _Component);

  function DeleteAction(props) {
    var _this;

    _classCallCheck(this, DeleteAction);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(DeleteAction).call(this, props));
    _this.action = _this.action.bind(_assertThisInitialized(_this));
    _this.toggleModal = _this.toggleModal.bind(_assertThisInitialized(_this));
    _this.toggleTooltip = _this.toggleTooltip.bind(_assertThisInitialized(_this));
    _this.state = {
      modal: false,
      loading: false,
      tooltipOpen: false,
      errorMessage: '',
      extendedMessage: ''
    };
    _this.eventEmitter = event_emitter__WEBPACK_IMPORTED_MODULE_9___default()(event_emitter__WEBPACK_IMPORTED_MODULE_9___default.a);
    return _this;
  }

  _createClass(DeleteAction, [{
    key: "toggleModal",
    value: function toggleModal(event) {
      this.setState({
        modal: !this.state.modal,
        errorMessage: '',
        extendedMessage: ''
      });

      if (event) {
        event.stopPropagation();
        event.nativeEvent.stopImmediatePropagation();
      }
    }
  }, {
    key: "toggleTooltip",
    value: function toggleTooltip() {
      this.setState({
        tooltipOpen: !this.state.tooltipOpen
      });
    }
  }, {
    key: "action",
    value: function action() {
      var _this2 = this;

      this.setState({
        loading: true
      });
      var api;
      var params = {
        namespace: services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__["default"].getState().selectedNamespace
      };

      switch (this.props.entity.type) {
        case 'application':
          api = api_app__WEBPACK_IMPORTED_MODULE_3__["MyAppApi"]["delete"];
          params.appId = this.props.entity.id;
          break;

        case 'artifact':
          api = api_artifact__WEBPACK_IMPORTED_MODULE_4__["MyArtifactApi"]["delete"];
          params.artifactId = this.props.entity.id;
          params.version = this.props.entity.version;
          break;

        case 'dataset':
          api = api_dataset__WEBPACK_IMPORTED_MODULE_5__["MyDatasetApi"]["delete"];
          params.datasetId = this.props.entity.id;
          break;

        default:
          return;
      }

      api(params).subscribe(function (res) {
        // Adding a 1.5 second delay
        // Metadata gets flushed after 1 second, so giving extra time for the async processing to finish.
        setTimeout(function () {
          _this2.props.onSuccess(res);

          _this2.setState({
            loading: false,
            modal: false
          });

          _this2.eventEmitter.emit(services_global_events__WEBPACK_IMPORTED_MODULE_10__["default"].DELETEENTITY, params);
        }, 1500);
      }, function (err) {
        _this2.setState({
          loading: false,
          errorMessage: i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('features.FastAction.deleteFailed', {
            entityId: _this2.props.entity.id
          }),
          extendedMessage: err
        });
      });
    }
  }, {
    key: "render",
    value: function render() {
      var actionLabel = i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('features.FastAction.deleteLabel');
      var headerTitle = "".concat(actionLabel, " ").concat(this.props.entity.type);
      var tooltipID = "delete-".concat(this.props.entity.uniqueId);
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "btn btn-secondary btn-sm"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_FastActionButton__WEBPACK_IMPORTED_MODULE_6__["default"], {
        icon: "icon-trash",
        action: this.toggleModal,
        id: tooltipID
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Tooltip"], {
        placement: "top",
        className: "fast-action-tooltip",
        isOpen: this.state.tooltipOpen,
        target: tooltipID,
        toggle: this.toggleTooltip,
        delay: 0
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('features.FastAction.deleteLabel')), this.state.modal ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_7__["default"], {
        headerTitle: headerTitle,
        toggleModal: this.toggleModal,
        confirmationText: i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('features.FastAction.deleteConfirmation', {
          entityId: this.props.entity.id
        }),
        confirmButtonText: actionLabel,
        confirmFn: this.action,
        cancelFn: this.toggleModal,
        isOpen: this.state.modal,
        isLoading: this.state.loading,
        errorMessage: this.state.errorMessage,
        extendedMessage: this.state.extendedMessage
      }) : null);
    }
  }]);

  return DeleteAction;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


DeleteAction.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    uniqueId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    version: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf(['application', 'artifact', 'dataset']).isRequired
  }),
  onSuccess: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/***/ }),

/***/ "./components/FastAction/ExploreAction/ExploreAction.scss":
/*!****************************************************************!*\
  !*** ./components/FastAction/ExploreAction/ExploreAction.scss ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./ExploreAction.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/FastAction/ExploreAction/ExploreAction.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/FastAction/ExploreAction/ExploreModal.js":
/*!*************************************************************!*\
  !*** ./components/FastAction/ExploreAction/ExploreModal.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ExploreModal; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var api_explore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/explore */ "./api/explore.js");
/* harmony import */ var lodash_isObject__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/isObject */ "../../node_modules/lodash/isObject.js");
/* harmony import */ var lodash_isObject__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_isObject__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var whatwg_fetch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! whatwg-fetch */ "../../node_modules/whatwg-fetch/fetch.js");
/* harmony import */ var whatwg_fetch__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(whatwg_fetch__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/UncontrolledComponents */ "./components/UncontrolledComponents/index.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_11__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */










__webpack_require__(/*! ./ExploreModal.scss */ "./components/FastAction/ExploreAction/ExploreModal.scss");




var PREFIX = 'features.FastAction.Explore';

var ExploreModal =
/*#__PURE__*/
function (_Component) {
  _inherits(ExploreModal, _Component);

  function ExploreModal(props) {
    var _this;

    _classCallCheck(this, ExploreModal);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ExploreModal).call(this, props));
    _this.type = _this.props.entity.type;
    _this.state = {
      queryString: "SELECT * FROM ".concat(_this.props.entity.databaseName, ".").concat(_this.props.entity.tableName, " LIMIT 500"),
      queries: [],
      error: null,
      loading: false
    }; // Show any queries that were executed when the modal is open, like `show tables`.
    // This is maintained in the current session and when the modal is opened again it doesn't need to be surfaced.

    _this.sessionQueryHandles = [];
    _this.submitQuery = _this.submitQuery.bind(_assertThisInitialized(_this));
    _this.onQueryStringChange = _this.onQueryStringChange.bind(_assertThisInitialized(_this));
    _this.subscriptions = [];
    _this.updateState = _this.updateState.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(ExploreModal, [{
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this._mounted = false;
      this.subscriptions.map(function (subscriber) {
        return subscriber.unsubscribe();
      });
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      var _this$props$entity = this.props.entity,
          existingDatabaseName = _this$props$entity.databaseName,
          existingTableName = _this$props$entity.tableName;
      var _nextProps$entity = nextProps.entity,
          newDatabaseName = _nextProps$entity.databaseName,
          newTablename = _nextProps$entity.tableName;

      if (existingDatabaseName !== newDatabaseName || existingTableName !== newTablename) {
        this.setState({
          queryString: "SELECT * FROM ".concat(nextProps.entity.databaseName, ".").concat(nextProps.entity.tableName, " LIMIT 500")
        });
      }
    }
  }, {
    key: "updateState",
    value: function updateState() {
      if (!this._mounted) {
        return;
      }

      this.setState.apply(this, arguments);
    }
  }, {
    key: "onQueryStringChange",
    value: function onQueryStringChange(e) {
      this.updateState({
        queryString: e.target.value
      });
    }
  }, {
    key: "setQueryString",
    value: function setQueryString(query) {
      this.updateState({
        queryString: query.statement
      });
    }
  }, {
    key: "getValidQueries",
    value: function getValidQueries(queries) {
      var _this2 = this;

      var updatedQueries = queries.filter(function (q) {
        return q.statement.indexOf("".concat(_this2.props.entity.databaseName, ".").concat(_this2.props.entity.tableName)) !== -1 || q.statement.indexOf("".concat(_this2.props.entity.id)) !== -1 // For queries run before 4.1
        ;
      });

      var updatedStateQueries = _toConsumableArray(updatedQueries);

      var intersectingQueries = [];

      if (this.state.queries.length) {
        updatedStateQueries = this.state.queries.map(function (query) {
          var matchedQuery = updatedQueries.find(function (q) {
            return q.query_handle === query.query_handle;
          });

          if (matchedQuery) {
            return Object.assign(query, {}, matchedQuery);
          }

          return query;
        });
        intersectingQueries = updatedQueries.filter(function (q) {
          return !_this2.state.queries.filter(function (qq) {
            return qq.query_handle === q.query_handle;
          }).length;
        });
      }

      return [].concat(_toConsumableArray(intersectingQueries), _toConsumableArray(updatedStateQueries));
    }
  }, {
    key: "submitQuery",
    value: function submitQuery() {
      var _this3 = this;

      var _NamespaceStore$getSt = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_9__["default"].getState(),
          namespace = _NamespaceStore$getSt.selectedNamespace;

      this.setState({
        loading: true
      });
      var queriesSubscription$ = api_explore__WEBPACK_IMPORTED_MODULE_3__["default"].submitQuery({
        namespace: namespace
      }, {
        query: this.state.queryString
      }).mergeMap(function (res) {
        _this3.sessionQueryHandles.push(res.handle);

        return api_explore__WEBPACK_IMPORTED_MODULE_3__["default"].fetchQueries({
          namespace: namespace
        });
      }).subscribe(function (res) {
        _this3.updateState({
          queries: _this3.getValidQueries(res),
          loading: false,
          error: null
        });
      }, function (error) {
        _this3.updateState({
          error: lodash_isObject__WEBPACK_IMPORTED_MODULE_4___default()(error) ? error.response : error,
          loading: false
        });
      });
      this.subscriptions.push(queriesSubscription$);
    }
  }, {
    key: "fetchAndUpdateQueries",
    value: function fetchAndUpdateQueries() {
      var _this4 = this;

      if (!this._mounted) {
        return;
      }

      var _NamespaceStore$getSt2 = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_9__["default"].getState(),
          namespace = _NamespaceStore$getSt2.selectedNamespace;

      var queriesSubscription$ = api_explore__WEBPACK_IMPORTED_MODULE_3__["default"].fetchQueries({
        namespace: namespace
      }).subscribe(function () {
        var res = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];

        if (!res.length) {
          return;
        }

        var queries = _this4.getValidQueries(res);

        _this4.updateState({
          queries: queries
        });
      }, function (error) {
        _this4.updateState({
          error: lodash_isObject__WEBPACK_IMPORTED_MODULE_4___default()(error) ? error.response : error
        });
      });
      this.subscriptions.push(queriesSubscription$);
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      this._mounted = true;
      this.fetchAndUpdateQueries();
    }
  }, {
    key: "showPreview",
    value: function showPreview(query) {
      var _this5 = this;

      var queryHandle = query.query_handle;
      var queries = this.state.queries;
      var matchIndex;
      queries.forEach(function (q, index) {
        if (q.query_handle === queryHandle) {
          matchIndex = index;
        }

        return q;
      });

      if (queries[matchIndex + 1] && queries[matchIndex + 1].preview) {
        queries = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["removeAt"])(queries, matchIndex + 1);
        this.updateState({
          queries: queries
        });
        return;
      }

      var previewSubscription$ = api_explore__WEBPACK_IMPORTED_MODULE_3__["default"].getQuerySchema({
        queryHandle: queryHandle
      }).mergeMap(function (res) {
        queries = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["insertAt"])(queries, matchIndex, {
          schema: res.map(function (s) {
            if (s.name.indexOf('.') !== -1) {
              s.name = s.name.split('.')[1];
            }

            return s;
          })
        });

        _this5.updateState({
          queries: queries
        });

        return api_explore__WEBPACK_IMPORTED_MODULE_3__["default"].getQueryPreview({
          queryHandle: queryHandle
        });
      }).subscribe(function (res) {
        var matchIndex;
        queries.forEach(function (q, index) {
          if (q.query_handle === queryHandle) {
            matchIndex = index;
          }

          return q;
        });
        queries[matchIndex + 1] = Object.assign(queries[matchIndex + 1], {
          preview: res
        });

        _this5.updateState({
          queries: queries
        });
      });
      this.subscriptions.push(previewSubscription$);
    }
  }, {
    key: "getDownloadUrl",
    value: function getDownloadUrl(query) {
      var path = "/v3/data/explore/queries/".concat(query.query_handle, "/download");
      path = encodeURIComponent(path);
      var url = "/downloadLogs?backendPath=".concat(path, "&type=download&method=POST&filename=").concat(query.query_handle, ".csv");
      return url;
    }
  }, {
    key: "updateQueryState",
    value: function updateQueryState(currentQuery, event) {
      var _this6 = this;

      if (currentQuery.is_active === false) {
        event.preventDefault();
      } else {
        var queries = this.state.queries;
        queries.forEach(function (query, index) {
          if (currentQuery == query) {
            currentQuery.is_active = false;
            queries[index] = currentQuery;

            _this6.updateState(_this6.state.queries);
          }
        });
      }
    }
  }, {
    key: "onModalToggle",
    value: function onModalToggle() {
      var runningQueries = this.state.queries.filter(function (query) {
        return query.status === 'RUNNING';
      });
      this.props.onClose(runningQueries.length);
    }
  }, {
    key: "render",
    value: function render() {
      var _this7 = this;

      var renderQueryRow = function renderQueryRow(query) {
        var id = "explore-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()());
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
          key: id
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, " ", Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["humanReadableDate"])(query.timestamp, true), " "), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, " ", query.statement, " "), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, query.status === 'RUNNING' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "query-status-value"
        }, query.status), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
          className: "fa fa-spinner fa-spin"
        })) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, query.status)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "btn-group"
        }, !query.is_active || query.status !== 'FINISHED' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "btn btn-secondary",
          disabled: "disabled"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
          id: "download-".concat(id),
          className: "fa fa-download"
        }), !query.is_active ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_8__["UncontrolledTooltip"], {
          target: "download-".concat(id),
          placement: "left",
          delay: 300
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "text-left"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('features.FastAction.downloadDisabledMessage'))) : null) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
          href: _this7.getDownloadUrl(query),
          onClick: _this7.updateQueryState.bind(_this7, query),
          className: "btn btn-secondary"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
          className: "fa fa-download"
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "btn btn-secondary",
          onClick: _this7.showPreview.bind(_this7, query),
          disabled: !query.is_active || query.status !== 'FINISHED' ? 'disabled' : null
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
          className: "fa fa-eye",
          id: "explore-".concat(id),
          delay: 300
        }), !query.is_active ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_8__["UncontrolledTooltip"], {
          target: "explore-".concat(id),
          placement: "top"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "text-left"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('features.FastAction.previewDisabledMessage'))) : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "btn btn-secondary",
          onClick: _this7.setQueryString.bind(_this7, query)
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
          className: "fa fa-clone"
        })))));
      };

      var renderPreviewRow = function renderPreviewRow(query) {
        var previewContent = function previewContent(query) {
          return query.preview.length ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("table", {
            className: "table table-bordered"
          }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("thead", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, query.schema.map(function (s) {
            return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
              key: "A-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()())
            }, s.name);
          }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tbody", null, query.preview.map(function (row) {
            return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
              key: "A-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()())
            }, !row.columns ? i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('features.FastAction.viewEvents.noResults') : row.columns.map(function (column) {
              var content = column;

              if (content === null) {
                content = 'null';
              } else if (typeof content === 'boolean') {
                content = content === true ? 'true' : 'false';
              }

              return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", {
                key: "A-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()())
              }, content);
            }));
          })))) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
            className: "text-center"
          }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".noResults")));
        };

        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
          key: "A-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()())
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", {
          colSpan: "4",
          className: "preview-cell"
        }, query.schema && !query.preview ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "fa fa-spinner fa-spin text-center"
        }) : previewContent(query)));
      };

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Modal"], {
        className: "explore-modal confirmation-modal cdap-modal",
        toggle: this.onModalToggle.bind(this),
        isOpen: this.props.isOpen,
        backdrop: "static"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalHeader"], null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".label")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        onClick: this.onModalToggle.bind(this),
        className: "float-right"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-times"
      }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalBody"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "explore-modal-body"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("textarea", {
        rows: "5",
        className: "form-control",
        value: this.state.queryString,
        onChange: this.onQueryStringChange
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "clearfix"
      }, this.state.error ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "float-left text-danger"
      }, this.state.error) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
        className: "btn btn-primary float-right",
        onClick: this.submitQuery,
        disabled: this.state.loading ? 'disabled' : null
      }, this.state.loading ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-spinner fa-spin"
      }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, "Execute"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "queries-table-wrapper"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("table", {
        className: "table table-bordered queries-table"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("thead", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
        className: "query-timestamp"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".startTime"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".SQLQuery"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
        className: "query-status"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".status"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
        className: "query-actions"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".actions"))))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tbody", null, !this.state.queries.length ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", {
        colSpan: "4",
        className: "text-center"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".noResults")))) : this.state.queries.map(function (query) {
        if (query.preview || query.schema) {
          return renderPreviewRow(query);
        }

        return renderQueryRow(query);
      })))))));
    }
  }]);

  return ExploreModal;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


ExploreModal.contextTypes = {
  params: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    namespace: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  })
};
ExploreModal.propTypes = {
  isOpen: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  onClose: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    version: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    scope: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf([services_global_constants__WEBPACK_IMPORTED_MODULE_10__["SCOPES"].SYSTEM, services_global_constants__WEBPACK_IMPORTED_MODULE_10__["SCOPES"].USER]),
    type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf(['application', 'artifact', 'dataset']).isRequired,
    databaseName: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    tableName: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  })
};

/***/ }),

/***/ "./components/FastAction/ExploreAction/ExploreModal.scss":
/*!***************************************************************!*\
  !*** ./components/FastAction/ExploreAction/ExploreModal.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./ExploreModal.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/FastAction/ExploreAction/ExploreModal.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/FastAction/ExploreAction/index.js":
/*!******************************************************!*\
  !*** ./components/FastAction/ExploreAction/index.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ExploreAction; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_ExploreTables_ExploreTablesStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/ExploreTables/ExploreTablesStore */ "./services/ExploreTables/ExploreTablesStore.js");
/* harmony import */ var _FastActionButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../FastActionButton */ "./components/FastAction/FastActionButton/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var components_FastAction_ExploreAction_ExploreModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/FastAction/ExploreAction/ExploreModal */ "./components/FastAction/ExploreAction/ExploreModal.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var api_explore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! api/explore */ "./api/explore.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2016-2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */













__webpack_require__(/*! ./ExploreAction.scss */ "./components/FastAction/ExploreAction/ExploreAction.scss");

var ExploreAction =
/*#__PURE__*/
function (_Component) {
  _inherits(ExploreAction, _Component);

  function ExploreAction(props) {
    var _this;

    _classCallCheck(this, ExploreAction);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ExploreAction).call(this, props));
    _this.state = {
      disabled: true,
      showModal: false,
      tooltipOpen: false,
      entity: _this.props.entity || {},
      runningQueries: null,
      showRunningQueriesDoneLabel: false
    };
    _this.subscription = null;
    _this.toggleTooltip = _this.toggleTooltip.bind(_assertThisInitialized(_this));
    _this.toggleModal = _this.toggleModal.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(ExploreAction, [{
    key: "toggleModal",
    value: function toggleModal(runningQueries) {
      var _this2 = this;

      var showRunningQueriesDoneLabel = false;

      if (runningQueries && this.state.showModal) {
        showRunningQueriesDoneLabel = true;
      }

      this.setState({
        showModal: !this.state.showModal,
        showRunningQueriesDoneLabel: showRunningQueriesDoneLabel,
        runningQueries: !showRunningQueriesDoneLabel ? null : runningQueries
      }, function () {
        if (typeof _this2.props.onClose === 'function') {
          _this2.props.onClose();
        }
      });
    }
  }, {
    key: "toggleTooltip",
    value: function toggleTooltip() {
      this.setState({
        tooltipOpen: !this.state.tooltipOpen
      });
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      if (this.props.opened) {
        this.setState({
          showModal: true
        });
      }
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this3 = this;

      var updateDisabledProp = function updateDisabledProp() {
        var _ExploreTablesStore$g = services_ExploreTables_ExploreTablesStore__WEBPACK_IMPORTED_MODULE_2__["default"].getState(),
            explorableTables = _ExploreTablesStore$g.tables;

        var entityId = _this3.props.entity.id.replace(/[\.\-]/g, '_');

        var type = _this3.props.entity.type;
        var match = explorableTables.filter(function (db) {
          return db.table === "".concat(type, "_").concat(entityId.toLowerCase()) || db.table === entityId.toLowerCase();
        });

        if (match.length) {
          _this3.setState({
            entity: Object.assign({}, _this3.props.entity, {
              tableName: match[0].table,
              databaseName: match[0].database
            }),
            disabled: false
          });
        }
      };

      this.subscription = services_ExploreTables_ExploreTablesStore__WEBPACK_IMPORTED_MODULE_2__["default"].subscribe(updateDisabledProp.bind(this));
      updateDisabledProp();

      if (Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(this.props.argsToAction, 'showQueriesCount')) {
        var namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_9__["default"].getState().selectedNamespace;
        this.explroeQueriesSubscription$ = api_explore__WEBPACK_IMPORTED_MODULE_8__["default"].fetchQueries({
          namespace: namespace
        }).subscribe(function (res) {
          var runningQueries = res.filter(function (q) {
            var tablename = "".concat(_this3.state.entity.databaseName, ".").concat(_this3.state.entity.tableName);
            return (q.statement.indexOf(tablename) !== -1 || q.statement.indexOf(_this3.props.entity.id) !== -1) && q.status === 'RUNNING';
          }).length;

          if (runningQueries) {
            _this3.setState({
              runningQueries: runningQueries
            });

            return;
          }

          if (_this3.state.runningQueries) {
            _this3.setState({
              runningQueries: i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.FastAction.doneLabel')
            });
          }
        });
      }
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (nextProps.opened !== this.state.showModal) {
        this.setState({
          showModal: nextProps.opened
        });
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.subscription();

      if (this.explroeQueriesSubscription$) {
        this.explroeQueriesSubscription$.unsubscribe();
      }
    }
  }, {
    key: "render",
    value: function render() {
      var tooltipID = "explore-".concat(this.props.entity.uniqueId);
      var showRunningQueriesNotification = this.state.showRunningQueriesDoneLabel && this.state.runningQueries && Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(this.props.argsToAction, 'showQueriesCount');
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: classnames__WEBPACK_IMPORTED_MODULE_10___default()('btn btn-secondary btn-sm', {
          'fast-action-with-popover': showRunningQueriesNotification
        })
      }, this.props.renderActionButton ? this.props.renderActionButton(tooltipID) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_FastActionButton__WEBPACK_IMPORTED_MODULE_3__["default"], {
        icon: "icon-eye",
        action: this.toggleModal,
        disabled: this.state.disabled,
        id: tooltipID
      }), showRunningQueriesNotification ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fast-action-popover-container"
      }, this.state.runningQueries) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_4__["Tooltip"], {
        placement: "top",
        className: "fast-action-tooltip",
        isOpen: this.state.tooltipOpen,
        target: tooltipID,
        toggle: this.toggleTooltip,
        delay: 0
      }, this.props.customTooltip ? this.props.customTooltip : i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.FastAction.Explore.label')), this.state.showModal ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_FastAction_ExploreAction_ExploreModal__WEBPACK_IMPORTED_MODULE_5__["default"], {
        isOpen: this.state.showModal,
        onClose: this.toggleModal,
        entity: this.state.entity
      }) : null);
    }
  }]);

  return ExploreAction;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(ExploreAction, "propTypes", {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    version: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    uniqueId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    scope: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf([services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SCOPES"].SYSTEM, services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SCOPES"].USER]),
    type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf(['application', 'artifact', 'dataset']).isRequired
  }),
  opened: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  renderActionButton: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  argsToAction: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  customTooltip: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onClose: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
});



/***/ }),

/***/ "./components/FastAction/LogAction/index.js":
/*!**************************************************!*\
  !*** ./components/FastAction/LogAction/index.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return LogAction; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var api_program__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/program */ "./api/program.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_program_api_converter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/program-api-converter */ "./services/program-api-converter/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_7__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









var LogAction =
/*#__PURE__*/
function (_Component) {
  _inherits(LogAction, _Component);

  function LogAction(props) {
    var _this;

    _classCallCheck(this, LogAction);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(LogAction).call(this, props));
    _this.state = {
      isDisabled: false,
      runId: props.entity.runId,
      tooltipOpen: false
    };
    _this.toggleTooltip = _this.toggleTooltip.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(LogAction, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var _this2 = this;

      if (this.state.runId) {
        return;
      }

      var namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["default"].getState().selectedNamespace;
      this.pollRuns$ = api_program__WEBPACK_IMPORTED_MODULE_3__["MyProgramApi"].pollRuns({
        namespace: namespace,
        appId: this.props.entity.applicationId,
        programType: Object(services_program_api_converter__WEBPACK_IMPORTED_MODULE_5__["convertProgramToApi"])(this.props.entity.programType),
        programId: this.props.entity.id
      }).subscribe(function (res) {
        if (res.length > 0) {
          _this2.setState({
            runId: res[0].runid
          });
        }
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.pollRuns$) {
        this.pollRuns$.unsubscribe();
      }
    }
  }, {
    key: "generateLink",
    value: function generateLink() {
      if (!this.state.runId) {
        return null;
      }

      var namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["default"].getState().selectedNamespace,
          appId = this.props.entity.applicationId,
          programType = Object(services_program_api_converter__WEBPACK_IMPORTED_MODULE_5__["convertProgramToApi"])(this.props.entity.programType),
          programId = this.props.entity.id,
          runId = this.state.runId;
      var path = "/logviewer/view?namespace=".concat(namespace, "&appId=").concat(appId, "&programType=").concat(programType, "&programId=").concat(programId, "&runId=").concat(runId);
      return path;
    }
  }, {
    key: "toggleTooltip",
    value: function toggleTooltip() {
      this.setState({
        tooltipOpen: !this.state.tooltipOpen
      });
    }
  }, {
    key: "render",
    value: function render() {
      // have to do this because ID cannot start with a number
      var tooltipID = "logs-".concat(this.props.entity.uniqueId);
      var renderDisabled = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
        className: "btn btn-link",
        disabled: true
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
        name: "icon-file-text-o"
      }));
      var link = this.generateLink();
      var renderLog = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
        href: link,
        target: "_blank",
        className: "btn btn-link",
        rel: "noopener noreferrer"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
        name: "icon-file-text"
      }));
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "btn btn-secondary btn-sm"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        id: tooltipID
      }, this.state.runId ? renderLog : renderDisabled), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_6__["Tooltip"], {
        placement: "top",
        className: "fast-action-tooltip",
        isOpen: this.state.tooltipOpen,
        target: tooltipID,
        toggle: this.toggleTooltip,
        delay: 0
      }, this.state.runId ? i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('features.FastAction.logLabel') : i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('features.FastAction.logNotAvailable')));
    }
  }]);

  return LogAction;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


LogAction.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    uniqueId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    applicationId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    programType: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    runId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  })
};

/***/ }),

/***/ "./components/FastAction/StartStopAction/index.js":
/*!********************************************************!*\
  !*** ./components/FastAction/StartStopAction/index.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return StartStopAction; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_program__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/program */ "./api/program.js");
/* harmony import */ var _FastActionButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../FastActionButton */ "./components/FastAction/FastActionButton/index.js");
/* harmony import */ var services_program_api_converter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/program-api-converter */ "./services/program-api-converter/index.js");
/* harmony import */ var components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/ConfirmationModal */ "./components/ConfirmationModal/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_9__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2016-2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */











var StartStopAction =
/*#__PURE__*/
function (_Component) {
  _inherits(StartStopAction, _Component);

  function StartStopAction(props) {
    var _this;

    _classCallCheck(this, StartStopAction);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(StartStopAction).call(this, props));

    _defineProperty(_assertThisInitialized(_this), "tooltipID", "A-".concat(_this.props.entity.uniqueId));

    _this.params = {
      namespace: services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__["default"].getState().selectedNamespace,
      appId: _this.props.entity.applicationId,
      programType: Object(services_program_api_converter__WEBPACK_IMPORTED_MODULE_5__["convertProgramToApi"])(_this.props.entity.programType),
      programId: _this.props.entity.id
    };
    _this.state = {
      programStatus: '',
      actionStatus: '',
      modal: false,
      tooltipOpen: false,
      errorMessage: '',
      extendedMessage: ''
    };
    _this.startStop;
    _this.toggleTooltip = _this.toggleTooltip.bind(_assertThisInitialized(_this));
    _this.doStartStop = _this.doStartStop.bind(_assertThisInitialized(_this));
    _this.toggleModal = _this.toggleModal.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(StartStopAction, [{
    key: "toggleTooltip",
    value: function toggleTooltip() {
      this.setState({
        tooltipOpen: !this.state.tooltipOpen
      });
    }
  }, {
    key: "toggleModal",
    value: function toggleModal() {
      this.setState({
        modal: !this.state.modal,
        errorMessage: '',
        extendedMessage: ''
      });
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      var _this2 = this;

      this.statusPoll$ = api_program__WEBPACK_IMPORTED_MODULE_3__["MyProgramApi"].pollStatus(this.params).subscribe(function (res) {
        var programStatus = res.status;

        if (!_this2.state.modal) {
          if (programStatus === 'STOPPED') {
            _this2.startStop = 'start';
          } else {
            _this2.startStop = 'stop';
          }
        }

        _this2.setState({
          programStatus: programStatus,
          actionStatus: ''
        });
      });
    }
  }, {
    key: "componentWillUpdate",
    value: function componentWillUpdate() {
      // don't update the modal if it's already open
      if (!this.state.modal) {
        if (this.state.programStatus === 'STOPPED') {
          this.startStop = 'start';
        } else {
          this.startStop = 'stop';
        }
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.statusPoll$.unsubscribe();
    }
  }, {
    key: "doStartStop",
    value: function doStartStop() {
      var _this3 = this;

      var params = Object.assign({}, this.params);
      params.action = this.startStop;
      this.setState({
        actionStatus: 'loading'
      });
      api_program__WEBPACK_IMPORTED_MODULE_3__["MyProgramApi"].action(params).subscribe(function (res) {
        _this3.setState({
          errorMessage: '',
          extendedMessage: '',
          modal: false
        });

        _this3.props.onSuccess(res);
      }, function (err) {
        _this3.setState({
          errorMessage: "Program ".concat(_this3.props.entity.id, " failed to ").concat(params.action),
          extendedMessage: err.response,
          actionStatus: ''
        });
      });
    }
  }, {
    key: "render",
    value: function render() {
      var confirmBtnText;
      var headerText;
      var confirmationText;
      var icon;
      var iconClass;

      if (this.startStop === 'start') {
        confirmBtnText = 'startConfirmLabel';
        headerText = i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate('features.FastAction.startProgramHeader');
        confirmationText = i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate('features.FastAction.startConfirmation', {
          entityId: this.props.entity.id
        });
      } else {
        confirmBtnText = 'stopConfirmLabel';
        headerText = i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate('features.FastAction.stopProgramHeader');
        confirmationText = i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate('features.FastAction.stopConfirmation', {
          entityId: this.props.entity.id
        });
      } // icon can change in the background, so using state instead of this.startStop


      if (this.state.programStatus === '') {
        icon = 'icon-spinner';
        iconClass = 'fa-spin';
      } else {
        if (this.state.programStatus === 'STOPPED') {
          icon = 'icon-play';
          iconClass = 'text-success';
        } else {
          icon = 'icon-stop';
          iconClass = 'text-danger';
        }
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "btn btn-secondary btn-sm"
      }, this.state.modal ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_6__["default"], {
        headerTitle: headerText,
        toggleModal: this.toggleModal,
        confirmationText: confirmationText,
        confirmButtonText: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate('features.FastAction.' + confirmBtnText),
        confirmFn: this.doStartStop,
        cancelFn: this.toggleModal,
        isLoading: this.state.actionStatus === 'loading',
        isOpen: this.state.modal,
        errorMessage: this.state.errorMessage,
        disableAction: !!this.state.errorMessage,
        extendedMessage: this.state.extendedMessage
      }) : null, this.state.actionStatus === 'loading' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
        className: "btn btn-link",
        disabled: true
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_7__["default"], {
        name: "icon-spinner",
        className: "fa-spin"
      })) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_FastActionButton__WEBPACK_IMPORTED_MODULE_4__["default"], {
        icon: icon,
        iconClasses: iconClass,
        action: this.toggleModal,
        id: this.tooltipID
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Tooltip"], {
        placement: "top",
        isOpen: this.state.tooltipOpen,
        target: this.tooltipID,
        toggle: this.toggleTooltip,
        delay: 0
      }, i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("features.FastAction.".concat(this.startStop)))));
    }
  }]);

  return StartStopAction;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


StartStopAction.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    uniqueId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    applicationId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    programType: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired
  }),
  onSuccess: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/***/ }),

/***/ "./components/FastAction/TruncateAction/index.js":
/*!*******************************************************!*\
  !*** ./components/FastAction/TruncateAction/index.js ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TruncateAction; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_dataset__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/dataset */ "./api/dataset.js");
/* harmony import */ var _FastActionButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../FastActionButton */ "./components/FastAction/FastActionButton/index.js");
/* harmony import */ var components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/ConfirmationModal */ "./components/ConfirmationModal/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var services_metadata_parser__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! services/metadata-parser */ "./services/metadata-parser/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016-2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */











var TruncateAction =
/*#__PURE__*/
function (_Component) {
  _inherits(TruncateAction, _Component);

  function TruncateAction(props) {
    var _this;

    _classCallCheck(this, TruncateAction);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(TruncateAction).call(this, props));
    _this.action = _this.action.bind(_assertThisInitialized(_this));
    _this.toggleModal = _this.toggleModal.bind(_assertThisInitialized(_this));
    _this.state = {
      modal: false,
      loading: false,
      errorMessage: '',
      success: false,
      extendedMessage: '',
      tooltipOpen: false
    };
    _this.toggleTooltip = _this.toggleTooltip.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(TruncateAction, [{
    key: "toggleModal",
    value: function toggleModal(event) {
      this.setState({
        modal: !this.state.modal
      });

      if (event) {
        event.stopPropagation();
        event.nativeEvent.stopImmediatePropagation();
      }
    }
  }, {
    key: "toggleTooltip",
    value: function toggleTooltip() {
      this.setState({
        tooltipOpen: !this.state.tooltipOpen
      });
    }
  }, {
    key: "onSuccess",
    value: function onSuccess(res) {
      var _this2 = this;

      this.setState({
        success: true
      }, function () {
        if (_this2.props.onSuccess) {
          _this2.props.onSuccess(res);
        }

        setTimeout(function () {
          _this2.setState({
            success: false
          });
        }, 3000);
      });
    }
  }, {
    key: "action",
    value: function action() {
      var _this3 = this;

      this.setState({
        loading: true
      });
      var api;
      var params = {
        namespace: services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__["default"].getState().selectedNamespace
      };

      switch (this.props.entity.type) {
        case 'dataset':
          api = api_dataset__WEBPACK_IMPORTED_MODULE_3__["MyDatasetApi"].truncate;
          params.datasetId = this.props.entity.id;
          break;

        default:
          return;
      }

      api(params).subscribe(function (res) {
        _this3.onSuccess(res);

        _this3.setState({
          loading: false,
          modal: false
        });
      }, function (err) {
        _this3.setState({
          loading: false,
          errorMessage: i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('features.FastAction.truncateFailed', {
            entityId: _this3.props.entity.id
          }),
          extendedMessage: err
        });
      });
    }
  }, {
    key: "render",
    value: function render() {
      var actionLabel = i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('features.FastAction.truncateLabel');
      var type = Object(services_metadata_parser__WEBPACK_IMPORTED_MODULE_9__["getType"])(this.props.entity);
      var headerTitle = "".concat(actionLabel, " ").concat(type);
      var tooltipID = "truncate-".concat(this.props.entity.uniqueId);
      var truncateActionClassNames = 'icon-cut';
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "btn btn-secondary btn-sm"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_FastActionButton__WEBPACK_IMPORTED_MODULE_4__["default"], {
        icon: truncateActionClassNames,
        action: this.toggleModal,
        id: tooltipID,
        iconClasses: classnames__WEBPACK_IMPORTED_MODULE_8___default()({
          'text-success': this.state.success
        })
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_6__["Tooltip"], {
        placement: "top",
        isOpen: this.state.tooltipOpen,
        target: tooltipID,
        toggle: this.toggleTooltip,
        delay: 0
      }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('features.FastAction.truncateLabel')), this.state.modal ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_5__["default"], {
        headerTitle: headerTitle,
        toggleModal: this.toggleModal,
        confirmationText: i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('features.FastAction.truncateConfirmation', {
          entityId: this.props.entity.id
        }),
        confirmButtonText: actionLabel,
        confirmFn: this.action,
        cancelFn: this.toggleModal,
        isOpen: this.state.modal,
        isLoading: this.state.loading,
        errorMessage: this.state.errorMessage,
        extendedMessage: this.state.extendedMessage
      }) : null);
    }
  }]);

  return TruncateAction;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


TruncateAction.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    uniqueId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf(['dataset']).isRequired
  }),
  onSuccess: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/***/ }),

/***/ "./components/FastAction/index.js":
/*!****************************************!*\
  !*** ./components/FastAction/index.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FastAction; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_FastAction_DeleteAction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/FastAction/DeleteAction */ "./components/FastAction/DeleteAction/index.js");
/* harmony import */ var components_FastAction_TruncateAction__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/FastAction/TruncateAction */ "./components/FastAction/TruncateAction/index.js");
/* harmony import */ var components_FastAction_StartStopAction__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/FastAction/StartStopAction */ "./components/FastAction/StartStopAction/index.js");
/* harmony import */ var components_FastAction_ExploreAction__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/FastAction/ExploreAction */ "./components/FastAction/ExploreAction/index.js");
/* harmony import */ var components_FastAction_SetPreferenceAction__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/FastAction/SetPreferenceAction */ "./components/FastAction/SetPreferenceAction/index.js");
/* harmony import */ var components_FastAction_LogAction__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/FastAction/LogAction */ "./components/FastAction/LogAction/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */










var FastAction =
/*#__PURE__*/
function (_Component) {
  _inherits(FastAction, _Component);

  function FastAction(props) {
    _classCallCheck(this, FastAction);

    return _possibleConstructorReturn(this, _getPrototypeOf(FastAction).call(this, props));
  } // This function is using switch statement because just using const mapping,
  // react already creating virtual DOM element for it, so it was failing the
  // Props validation.


  _createClass(FastAction, [{
    key: "renderFastAction",
    value: function renderFastAction(type) {
      switch (type) {
        case 'delete':
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_FastAction_DeleteAction__WEBPACK_IMPORTED_MODULE_2__["default"], {
            entity: this.props.entity,
            onSuccess: this.props.onSuccess,
            argsToAction: Object(services_helpers__WEBPACK_IMPORTED_MODULE_8__["objectQuery"])(this.props.argsToAction)
          });

        case 'truncate':
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_FastAction_TruncateAction__WEBPACK_IMPORTED_MODULE_3__["default"], {
            entity: this.props.entity,
            onSuccess: this.props.onSuccess,
            argsToAction: Object(services_helpers__WEBPACK_IMPORTED_MODULE_8__["objectQuery"])(this.props.argsToAction)
          });

        case 'startStop':
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_FastAction_StartStopAction__WEBPACK_IMPORTED_MODULE_4__["default"], {
            entity: this.props.entity,
            onSuccess: this.props.onSuccess,
            argsToAction: Object(services_helpers__WEBPACK_IMPORTED_MODULE_8__["objectQuery"])(this.props.argsToAction)
          });

        case 'explore':
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_FastAction_ExploreAction__WEBPACK_IMPORTED_MODULE_5__["default"], {
            entity: this.props.entity,
            opened: this.props.opened,
            argsToAction: Object(services_helpers__WEBPACK_IMPORTED_MODULE_8__["objectQuery"])(this.props.argsToAction)
          });

        case 'setPreferences':
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_FastAction_SetPreferenceAction__WEBPACK_IMPORTED_MODULE_6__["default"], {
            entity: this.props.entity,
            onSuccess: this.props.onSuccess,
            argsToAction: Object(services_helpers__WEBPACK_IMPORTED_MODULE_8__["objectQuery"])(this.props.argsToAction)
          });

        case 'log':
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_FastAction_LogAction__WEBPACK_IMPORTED_MODULE_7__["default"], {
            entity: this.props.entity,
            argsToAction: Object(services_helpers__WEBPACK_IMPORTED_MODULE_8__["objectQuery"])(this.props.argsToAction)
          });

        default:
          return null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      return this.renderFastAction(this.props.type);
    }
  }]);

  return FastAction;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


FastAction.propTypes = {
  type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf(['delete', 'truncate', 'startStop', 'explore', 'setPreferences', 'log']),
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  onSuccess: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  opened: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  argsToAction: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
};

/***/ }),

/***/ "./components/Overview/OverviewMetaSection/OverviewMetaSection.scss":
/*!**************************************************************************!*\
  !*** ./components/Overview/OverviewMetaSection/OverviewMetaSection.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./OverviewMetaSection.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Overview/OverviewMetaSection/OverviewMetaSection.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Overview/OverviewMetaSection/index.js":
/*!**********************************************************!*\
  !*** ./components/Overview/OverviewMetaSection/index.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return OverviewMetaSection; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_EntityCard_FastActions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/EntityCard/FastActions */ "./components/EntityCard/FastActions/index.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/isNil */ "../../node_modules/lodash/isNil.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_isNil__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_Description__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Description */ "./components/Description/index.js");
/* harmony import */ var react_timeago__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-timeago */ "../../node_modules/react-timeago/lib/index.js");
/* harmony import */ var react_timeago__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_timeago__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_Tags__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Tags */ "./components/Tags/index.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! moment */ "../../node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_10__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */












__webpack_require__(/*! ./OverviewMetaSection.scss */ "./components/Overview/OverviewMetaSection/OverviewMetaSection.scss");

var OverviewMetaSection =
/*#__PURE__*/
function (_Component) {
  _inherits(OverviewMetaSection, _Component);

  function OverviewMetaSection(props) {
    var _this;

    _classCallCheck(this, OverviewMetaSection);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(OverviewMetaSection).call(this, props));
    _this.state = {
      entity: _this.props.entity
    };
    return _this;
  }

  _createClass(OverviewMetaSection, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      var entity = nextProps.entity;

      if (!lodash_isNil__WEBPACK_IMPORTED_MODULE_4___default()(entity) && entity.id !== Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(this.state, 'entity', 'id')) {
        this.setState({
          entity: entity
        });
      }
    }
  }, {
    key: "getFullCreationTime",
    value: function getFullCreationTime(creationTime) {
      // Sample formatted time string: Deployed on 02/16/2017, at 03:40 pm
      var formattedTime = moment__WEBPACK_IMPORTED_MODULE_8___default()(parseInt(creationTime)).format('[ on] MM/DD/YYYY, [at] hh:mm a');
      return formattedTime;
    }
  }, {
    key: "renderDatasetInfo",
    value: function renderDatasetInfo() {
      if (this.props.entity.type !== 'dataset') {
        return null;
      }

      var type = Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(this.props, 'entity', 'properties', 'type');
      type = type.split('.');
      type = type[type.length - 1];
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "entity-info"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_10___default.a.translate('features.Overview.Metadata.type')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, type));
    }
  }, {
    key: "onFastActionSuccess",
    value: function onFastActionSuccess(action) {
      if (this.props.onFastActionSuccess) {
        this.props.onFastActionSuccess(action);
      }
    }
  }, {
    key: "onFastActionUpdate",
    value: function onFastActionUpdate(action) {
      if (this.props.onFastActionUpdate) {
        this.props.onFastActionUpdate(action);
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var creationTime = Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(this.props, 'entity', 'properties', 'creation-time');

      var renderCreationTime = function renderCreationTime(creationTime) {
        return _this2.props.showFullCreationTime ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, _this2.getFullCreationTime(creationTime)) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_timeago__WEBPACK_IMPORTED_MODULE_6___default.a, {
          date: parseInt(creationTime, 10)
        });
      };

      var description = Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(this.props, 'entity', 'properties', 'description'); // have to generate new uniqueId here, because we don't want the fast actions here to
      // trigger the tooltips on the card view

      var entity = Object.assign({}, this.props.entity, {
        uniqueId: "meta-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_9___default()())
      });
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "overview-meta-section"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h2", {
        title: this.props.entity.id
      }, this.props.entity.id), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "fast-actions-container text-center"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, this.props.entity.type === 'application' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.props.entity.properties.version === '-SNAPSHOT' ? '1.0.0-SNAPSHOT' : this.props.entity.properties.version) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("small", null, ['dataset'].indexOf(this.props.entity.type) !== -1 ? i18n_react__WEBPACK_IMPORTED_MODULE_10___default.a.translate('features.Overview.deployedLabel.data') : i18n_react__WEBPACK_IMPORTED_MODULE_10___default.a.translate('features.Overview.deployedLabel.app'), !lodash_isNil__WEBPACK_IMPORTED_MODULE_4___default()(creationTime) ? renderCreationTime(creationTime) : null)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_EntityCard_FastActions__WEBPACK_IMPORTED_MODULE_3__["default"], {
        className: "overview-fast-actions btn-group",
        entity: entity,
        onSuccess: this.onFastActionSuccess.bind(this),
        onUpdate: this.onFastActionUpdate.bind(this),
        actionToOpen: this.props.fastActionToOpen,
        argsToActions: {
          explore: {
            showQueriesCount: true
          }
        }
      })), this.props.showSeparator ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("hr", null) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Description__WEBPACK_IMPORTED_MODULE_5__["default"], {
        description: description
      }), this.renderDatasetInfo(), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Tags__WEBPACK_IMPORTED_MODULE_7__["default"], {
        entity: this.props.entity
      }));
    }
  }]);

  return OverviewMetaSection;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


OverviewMetaSection.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  onFastActionSuccess: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  onFastActionUpdate: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  fastActionToOpen: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  showFullCreationTime: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  showSeparator: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
};

/***/ }),

/***/ "./components/Overview/Tabs/ProgramTab/ProgramTab.scss":
/*!*************************************************************!*\
  !*** ./components/Overview/Tabs/ProgramTab/ProgramTab.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./ProgramTab.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Overview/Tabs/ProgramTab/ProgramTab.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Overview/Tabs/ProgramTab/index.js":
/*!******************************************************!*\
  !*** ./components/Overview/Tabs/ProgramTab/index.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProgramsTab; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/isNil */ "../../node_modules/lodash/isNil.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_isNil__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var api_program__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! api/program */ "./api/program.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_program_api_converter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/program-api-converter */ "./services/program-api-converter/index.js");
/* harmony import */ var components_ViewSwitch__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/ViewSwitch */ "./components/ViewSwitch/index.js");
/* harmony import */ var components_ProgramCards__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/ProgramCards */ "./components/ProgramCards/index.js");
/* harmony import */ var components_ProgramTable__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/ProgramTable */ "./components/ProgramTable/index.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! lodash/isEmpty */ "../../node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_11__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */













__webpack_require__(/*! ./ProgramTab.scss */ "./components/Overview/Tabs/ProgramTab/ProgramTab.scss");

var ProgramsTab =
/*#__PURE__*/
function (_Component) {
  _inherits(ProgramsTab, _Component);

  function ProgramsTab(props) {
    var _this;

    _classCallCheck(this, ProgramsTab);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ProgramsTab).call(this, props));
    _this.state = {
      entity: _this.props.entity,
      runningPrograms: []
    };
    _this.statusSubscriptions = [];

    if (!lodash_isNil__WEBPACK_IMPORTED_MODULE_3___default()(_this.props.entity) && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_11___default()(_this.props.entity)) {
      _this.setRunningPrograms();
    }

    return _this;
  }

  _createClass(ProgramsTab, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      var entitiesMatch = Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(nextProps, 'entity', 'name') === Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(this.props, 'entity', 'name');

      if (!entitiesMatch) {
        this.setState({
          entity: nextProps.entity,
          runningPrograms: []
        });
        this.statusSubscriptions.forEach(function (sub) {
          return sub.unsubscribe();
        });
        this.setRunningPrograms();
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.statusSubscriptions.forEach(function (sub) {
        return sub.unsubscribe();
      });
    }
  }, {
    key: "setRunningPrograms",
    value: function setRunningPrograms() {
      var _this2 = this;

      var namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_6__["default"].getState().selectedNamespace;
      this.state.entity.programs.forEach(function (program) {
        var params = {
          namespace: namespace,
          appId: program.app,
          programType: Object(services_program_api_converter__WEBPACK_IMPORTED_MODULE_7__["convertProgramToApi"])(program.type),
          programId: program.name
        };
        var subscription = api_program__WEBPACK_IMPORTED_MODULE_5__["MyProgramApi"].pollRuns(params).combineLatest(api_program__WEBPACK_IMPORTED_MODULE_5__["MyProgramApi"].pollStatus(params)).subscribe(function (res) {
          var runningPrograms = _this2.state.runningPrograms;
          var programState = runningPrograms.filter(function (prog) {
            return prog.name === program.name && prog.app === program.app;
          });

          if (programState.length) {
            runningPrograms = runningPrograms.filter(function (prog) {
              return prog.name !== program.name || prog.name === program.name && prog.app !== program.app;
            });
          }

          runningPrograms.push(Object.assign({}, !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_11___default()(programState) ? programState[0] : {}, {
            latestRun: Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(res, 0, 0) || {},
            status: res[1].status === 'RUNNING' ? 1 : 0,
            backendStatus: res[1].status,
            name: program.name,
            app: program.app
          }));

          _this2.setState({
            runningPrograms: runningPrograms
          });
        });

        _this2.statusSubscriptions.push(subscription);
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var runningProgramsCount = 0;
      var programsForTable = this.state.entity.programs;

      if (this.state.runningPrograms.length) {
        runningProgramsCount = this.state.runningPrograms.map(function (runningProgram) {
          return runningProgram.status;
        }).reduce(function (prev, curr) {
          return prev + curr;
        });
        programsForTable = this.state.entity.programs.map(function (program) {
          var matchedProg = _this3.state.runningPrograms.find(function (prog) {
            return prog.name === program.name && prog.app === program.app;
          }) || null;
          return !matchedProg ? program : Object.assign({}, program, {
            status: matchedProg.backendStatus,
            latestRun: matchedProg.latestRun
          });
        });
      }

      if (!lodash_isNil__WEBPACK_IMPORTED_MODULE_3___default()(this.state.entity)) {
        if (this.state.entity.programs.length) {
          var title = i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate('features.Overview.ProgramTab.title', {
            appId: this.state.entity.name
          });

          if (['dataset'].indexOf(this.state.entity.type) !== -1) {
            title = i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate('features.Overview.ProgramTab.altTitle', {
              entityId: this.state.entity.id,
              entityType: this.state.entity.type
            });
          }

          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
            className: "program-tab clearfix"
          }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
            className: "message-section float-left"
          }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, " ", title, " "), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate('features.Overview.ProgramTab.runningProgramLabel', {
            programCount: runningProgramsCount
          }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_ViewSwitch__WEBPACK_IMPORTED_MODULE_8__["default"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_ProgramCards__WEBPACK_IMPORTED_MODULE_9__["default"], {
            programs: this.state.entity.programs
          }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_ProgramTable__WEBPACK_IMPORTED_MODULE_10__["default"], {
            programs: programsForTable
          })));
        } else {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
            className: "program-tab clearfix"
          }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate('features.Overview.ProgramTab.emptyMessage')));
        }
      }

      return null;
    }
  }]);

  return ProgramsTab;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


ProgramsTab.defaultProps = {
  entity: {
    programs: []
  }
};
ProgramsTab.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    programs: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
      app: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
      id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
      type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
    })),
    type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  })
};

/***/ }),

/***/ "./components/Overview/Tabs/SchemaTab/SchemaTab.scss":
/*!***********************************************************!*\
  !*** ./components/Overview/Tabs/SchemaTab/SchemaTab.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./SchemaTab.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Overview/Tabs/SchemaTab/SchemaTab.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Overview/Tabs/SchemaTab/index.js":
/*!*****************************************************!*\
  !*** ./components/Overview/Tabs/SchemaTab/index.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SchemaTab; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_SchemaEditor_SchemaStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/SchemaEditor/SchemaStore */ "./components/SchemaEditor/SchemaStore.js");
/* harmony import */ var components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/LoadingSVGCentered */ "./components/LoadingSVGCentered/index.js");
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-loadable */ "../../node_modules/react-loadable/lib/index.js");
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_loadable__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








__webpack_require__(/*! ./SchemaTab.scss */ "./components/Overview/Tabs/SchemaTab/SchemaTab.scss");

var SchemaEditor = react_loadable__WEBPACK_IMPORTED_MODULE_4___default()({
  loader: function loader() {
    return __webpack_require__.e(/*! import() | SchemaEditor */ "SchemaEditor").then(__webpack_require__.bind(null, /*! components/SchemaEditor */ "./components/SchemaEditor/index.js"));
  },
  loading: components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_3__["default"]
});

var SchemaTab =
/*#__PURE__*/
function (_Component) {
  _inherits(SchemaTab, _Component);

  function SchemaTab(props) {
    var _this;

    _classCallCheck(this, SchemaTab);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(SchemaTab).call(this, props));
    _this.state = {
      entity: _this.props.entity,
      tooltipOpen: false
    };
    _this.toggleTooltip = _this.toggleTooltip.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(SchemaTab, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      if (!this.props.entity.schema) {
        return;
      }

      var schema;

      try {
        schema = JSON.parse(this.props.entity.schema);
      } catch (e) {
        console.error('Error parsing schema: ', e);
        schema = {
          fields: []
        };
      }

      this.setSchema({
        fields: schema.fields
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      components_SchemaEditor_SchemaStore__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
        type: 'RESET'
      });
    }
  }, {
    key: "setSchema",
    value: function setSchema(schema) {
      components_SchemaEditor_SchemaStore__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
        type: 'FIELD_UPDATE',
        payload: {
          schema: schema
        }
      });
    }
  }, {
    key: "toggleTooltip",
    value: function toggleTooltip() {
      this.setState({
        tooltipOpen: !this.state.tooltipOpen
      });
    }
  }, {
    key: "render",
    value: function render() {
      var infoIconId = 'schema-tab-title-info';
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "schema-tab"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "message-section"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, ' ', i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.Overview.SchemaTab.title', {
        entityType: this.state.entity.type,
        entityId: this.state.entity.id
      }), ' '), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "message-section-tooltip"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
        className: "fa fa-info-circle",
        id: infoIconId
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_5__["Tooltip"], {
        isOpen: this.state.tooltipOpen,
        target: infoIconId,
        toggle: this.toggleTooltip,
        placement: "bottom"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.Overview.SchemaTab.tooltip')))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("fieldset", {
        className: "disable-schema",
        disabled: true
      }, this.state.entity.schema ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(SchemaEditor, null) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "empty-schema"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.Overview.SchemaTab.emptyMessage')))));
    }
  }]);

  return SchemaTab;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


SchemaTab.propTypes = {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    schema: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object])
  })
};

/***/ }),

/***/ "./components/Pagination/Pagination.scss":
/*!***********************************************!*\
  !*** ./components/Pagination/Pagination.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Pagination.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Pagination/Pagination.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Pagination/PaginationDropdown.js":
/*!*****************************************************!*\
  !*** ./components/Pagination/PaginationDropdown.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PaginationDropdown; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_4__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./Pagination.scss */ "./components/Pagination/Pagination.scss");

__webpack_require__(/*! ./PaginationDropdown.scss */ "./components/Pagination/PaginationDropdown.scss");

var PaginationDropdown =
/*#__PURE__*/
function (_Component) {
  _inherits(PaginationDropdown, _Component);

  function PaginationDropdown(props) {
    var _this;

    _classCallCheck(this, PaginationDropdown);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(PaginationDropdown).call(this, props));
    _this.state = {
      isPaginationExpanded: false
    };
    _this.handleExpansionToggle = _this.handleExpansionToggle.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(PaginationDropdown, [{
    key: "handleExpansionToggle",
    value: function handleExpansionToggle() {
      this.setState({
        isPaginationExpanded: !this.state.isPaginationExpanded
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var dropdownItems = [];

      for (var i = 0; i < this.props.numberOfPages; i++) {
        dropdownItems.push(react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "dropdownItems clearfix"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "page-number float-left"
        }, i + 1), this.props.currentPage === i + 1 ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "fa fa-check float-right"
        }) : null));
      }

      if (this.props.numberOfPages === 1) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
        className: "pagination-dropdown",
        isOpen: this.state.isPaginationExpanded,
        toggle: this.handleExpansionToggle
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["DropdownToggle"], {
        tag: "div"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate('features.Pagination.dropdown-label')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "current-page"
      }, this.props.currentPage), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-caret-down float-right"
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["DropdownMenu"], {
        onClick: function onClick(e) {
          return e.stopPropagation();
        }
      }, dropdownItems.map(function (item, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["DropdownItem"], {
          key: uuid_v4__WEBPACK_IMPORTED_MODULE_4___default()(),
          onClick: _this2.props.onPageChange.bind(_this2, index + 1)
        }, item);
      })));
    }
  }]);

  return PaginationDropdown;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


PaginationDropdown.propTypes = {
  numberOfPages: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  currentPage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  onPageChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/***/ }),

/***/ "./components/Pagination/PaginationDropdown.scss":
/*!*******************************************************!*\
  !*** ./components/Pagination/PaginationDropdown.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./PaginationDropdown.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Pagination/PaginationDropdown.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Pagination/index.js":
/*!****************************************!*\
  !*** ./components/Pagination/index.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Pagination; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! mousetrap */ "../../node_modules/mousetrap/mousetrap.js");
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(mousetrap__WEBPACK_IMPORTED_MODULE_3__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./Pagination.scss */ "./components/Pagination/Pagination.scss");

var Pagination =
/*#__PURE__*/
function (_Component) {
  _inherits(Pagination, _Component);

  function Pagination(props) {
    var _this;

    _classCallCheck(this, Pagination);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(Pagination).call(this, props));
    _this.state = {
      numResults: 0,
      leftPressed: false,
      rightPressed: false,
      currentPage: props.currentPage,
      totalPages: props.totalPages
    };
    _this.goToNext = _this.goToNext.bind(_assertThisInitialized(_this));
    _this.goToPrev = _this.goToPrev.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(Pagination, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_3___default.a.bind('right', this.goToNext);
      mousetrap__WEBPACK_IMPORTED_MODULE_3___default.a.bind('left', this.goToPrev);
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.setState({
        currentPage: nextProps.currentPage,
        totalPages: nextProps.totalPages
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_3___default.a.unbind('left');
      mousetrap__WEBPACK_IMPORTED_MODULE_3___default.a.unbind('right');
    }
  }, {
    key: "goToPrev",
    value: function goToPrev() {
      var _this2 = this;

      if (this.state.currentPage - 1 === 0) {
        return;
      } // Highlight the side that is pressed


      this.setState({
        leftPressed: true
      });
      setTimeout(function () {
        _this2.setState({
          leftPressed: false
        });
      }, 250);

      if (this.props.setDirection) {
        this.props.setDirection('prev');
      }

      this.props.setCurrentPage(this.state.currentPage - 1);
    }
  }, {
    key: "goToNext",
    value: function goToNext() {
      var _this3 = this;

      if (this.state.currentPage + 1 > this.state.totalPages) {
        return;
      } // Highlight the side that is pressed


      this.setState({
        rightPressed: true
      });
      setTimeout(function () {
        _this3.setState({
          rightPressed: false
        });
      }, 250);

      if (this.props.setDirection) {
        this.props.setDirection('next');
      }

      this.props.setCurrentPage(this.state.currentPage + 1);
    }
  }, {
    key: "render",
    value: function render() {
      var pageChangeRightClass = classnames__WEBPACK_IMPORTED_MODULE_2___default()('change-page-panel', 'change-page-panel-right', {
        pressed: this.state.rightPressed,
        'last-page': this.state.currentPage + 1 > this.state.totalPages
      });
      var pageChangeLeftClass = classnames__WEBPACK_IMPORTED_MODULE_2___default()('change-page-panel', 'change-page-panel-left', {
        pressed: this.state.leftPressed,
        'first-page': this.state.currentPage - 1 === 0
      });
      mousetrap__WEBPACK_IMPORTED_MODULE_3___default.a.bind('right', this.goToNext);
      mousetrap__WEBPACK_IMPORTED_MODULE_3___default.a.bind('left', this.goToPrev);
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()('pagination-container', this.props.className)
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        onClick: this.goToPrev,
        className: pageChangeLeftClass
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "pagination-content"
      }, this.props.children), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        onClick: this.goToNext,
        className: pageChangeRightClass
      }));
    }
  }]);

  return Pagination;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


Pagination.propTypes = {
  currentPage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  totalPages: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  children: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.node,
  setCurrentPage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  setDirection: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/ProgramCards/ProgramCards.scss":
/*!***************************************************!*\
  !*** ./components/ProgramCards/ProgramCards.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./ProgramCards.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/ProgramCards/ProgramCards.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/ProgramCards/index.js":
/*!******************************************!*\
  !*** ./components/ProgramCards/index.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProgramCards; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_EntityCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/EntityCard */ "./components/EntityCard/index.js");
/* harmony import */ var services_metadata_parser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/metadata-parser */ "./services/metadata-parser/index.js");
/* harmony import */ var services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/metadata-parser/EntityType */ "./services/metadata-parser/EntityType.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */







__webpack_require__(/*! ./ProgramCards.scss */ "./components/ProgramCards/ProgramCards.scss");

function ProgramCards(_ref) {
  var programs = _ref.programs;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "program-cards"
  }, programs.map(function (program) {
    var entity = {
      entity: {
        details: {
          application: program.app,
          program: program.name,
          type: program.type
        },
        type: services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_4__["default"].program
      },
      metadata: {
        tags: [],
        properties: []
      }
    };
    entity = Object(services_metadata_parser__WEBPACK_IMPORTED_MODULE_3__["parseMetadata"])(entity);
    var uniqueId = uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()();
    entity.uniqueId = uniqueId;
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_EntityCard__WEBPACK_IMPORTED_MODULE_2__["default"], {
      className: "entity-card-container",
      entity: entity,
      key: uniqueId
    });
  }));
}
ProgramCards.propTypes = {
  programs: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object)
};

/***/ }),

/***/ "./components/ProgramTable/ProgramTable.scss":
/*!***************************************************!*\
  !*** ./components/ProgramTable/ProgramTable.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./ProgramTable.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/ProgramTable/ProgramTable.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/ProgramTable/index.js":
/*!******************************************!*\
  !*** ./components/ProgramTable/index.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProgramTable; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_EntityCard_FastActions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/EntityCard/FastActions */ "./components/EntityCard/FastActions/index.js");
/* harmony import */ var components_SortableTable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/SortableTable */ "./components/SortableTable/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_entity_icon_map__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/entity-icon-map */ "./services/entity-icon-map/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash/isEmpty */ "../../node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! moment */ "../../node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var services_StatusMapper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! services/StatusMapper */ "./services/StatusMapper.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */













__webpack_require__(/*! ./ProgramTable.scss */ "./components/ProgramTable/ProgramTable.scss");

var tableHeaders = [{
  property: 'name',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate('features.ViewSwitch.nameLabel')
}, {
  property: 'programType',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate('features.ViewSwitch.typeLabel')
}, // have to convert latestRun back from string to seconds from epoch
{
  property: 'latestRun',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate('features.ViewSwitch.ProgramTable.lastStartedLabel'),
  sortFunc: function sortFunc(entity) {
    return moment__WEBPACK_IMPORTED_MODULE_10___default()(entity.latestRun.starting).valueOf();
  }
}, {
  property: 'status',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate('features.ViewSwitch.ProgramTable.statusLabel')
}, // empty header label for Actions column
{
  label: ''
}];

var ProgramTable =
/*#__PURE__*/
function (_Component) {
  _inherits(ProgramTable, _Component);

  function ProgramTable() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ProgramTable);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ProgramTable)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      entities: []
    });

    _defineProperty(_assertThisInitialized(_this), "renderTableBody", function (entities) {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tbody", null, entities.map(function (program) {
        var icon = services_entity_icon_map__WEBPACK_IMPORTED_MODULE_7__["default"][program.programType];
        var statusClass = program.status === 'RUNNING' ? 'text-success' : '';
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
          key: program.uniqueId
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          title: program.name
        }, program.name)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
          name: icon,
          className: "program-type-icon"
        }), program.programType), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9___default()(program.latestRun) ? Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["humanReadableDate"])(program.latestRun.starting) : 'n/a'), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", {
          className: statusClass
        }, !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9___default()(program.status) ? services_StatusMapper__WEBPACK_IMPORTED_MODULE_11__["default"].lookupDisplayStatus(program.status) : 'n/a'), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "fast-actions-container text-center"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_EntityCard_FastActions__WEBPACK_IMPORTED_MODULE_2__["default"], {
          className: "text-left btn-group",
          entity: program
        }))));
      }));
    });

    return _this;
  }

  _createClass(ProgramTable, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var entities = this.updateEntities(this.props.programs);
      this.setState({
        entities: entities
      });
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      var entities = this.updateEntities(nextProps.programs);
      this.setState({
        entities: entities
      });
    }
  }, {
    key: "updateEntities",
    value: function updateEntities(programs) {
      return programs.map(function (prog) {
        return Object.assign({}, prog, {
          latestRun: prog.latestRun || {},
          applicationId: prog.app,
          programType: prog.type,
          type: 'program',
          id: prog.name,
          uniqueId: "program-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()())
        });
      });
    }
  }, {
    key: "render",
    value: function render() {
      if (this.state.entities && Array.isArray(this.state.entities)) {
        if (this.state.entities.length) {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
            className: "program-table"
          }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SortableTable__WEBPACK_IMPORTED_MODULE_3__["default"], {
            entities: this.state.entities,
            tableHeaders: tableHeaders,
            renderTableBody: this.renderTableBody
          }));
        } else {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
            className: "history-tab"
          }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", null, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate('features.Overview.ProgramTab.emptyMessage')));
        }
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "program-table"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h3", {
        className: "text-center"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-spinner fa-spin fa-2x loading-spinner"
      })));
    }
  }]);

  return ProgramTable;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(ProgramTable, "propTypes", {
  programs: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object)
});



/***/ }),

/***/ "./components/PropertiesEditor/AddPropertyModal/AddPropertyModal.scss":
/*!****************************************************************************!*\
  !*** ./components/PropertiesEditor/AddPropertyModal/AddPropertyModal.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./AddPropertyModal.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PropertiesEditor/AddPropertyModal/AddPropertyModal.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PropertiesEditor/AddPropertyModal/index.js":
/*!***************************************************************!*\
  !*** ./components/PropertiesEditor/AddPropertyModal/index.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AddPropertyModal; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var components_CardActionFeedback__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/CardActionFeedback */ "./components/CardActionFeedback/index.js");
/* harmony import */ var api_metadata__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! api/metadata */ "./api/metadata.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








__webpack_require__(/*! ./AddPropertyModal.scss */ "./components/PropertiesEditor/AddPropertyModal/AddPropertyModal.scss");

var AddPropertyModal =
/*#__PURE__*/
function (_Component) {
  _inherits(AddPropertyModal, _Component);

  function AddPropertyModal(props) {
    var _this;

    _classCallCheck(this, AddPropertyModal);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(AddPropertyModal).call(this, props));
    _this.state = {
      isOpen: false,
      keyInput: '',
      valueInput: '',
      error: null
    };
    _this.toggleModal = _this.toggleModal.bind(_assertThisInitialized(_this));
    _this.handleKeyChange = _this.handleKeyChange.bind(_assertThisInitialized(_this));
    _this.handleValueChange = _this.handleValueChange.bind(_assertThisInitialized(_this));
    _this.onSave = _this.onSave.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(AddPropertyModal, [{
    key: "toggleModal",
    value: function toggleModal() {
      this.setState({
        isOpen: !this.state.isOpen,
        keyInput: '',
        valueInput: '',
        error: null
      });
    }
  }, {
    key: "handleKeyChange",
    value: function handleKeyChange(e) {
      this.setState({
        keyInput: e.target.value
      });
    }
  }, {
    key: "handleValueChange",
    value: function handleValueChange(e) {
      this.setState({
        valueInput: e.target.value
      });
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      if (this.state.isOpen && this.state.keyInput.length === 0 && this.state.valueInput.length === 0) {
        document.getElementById('add-property-modal-key-input').focus();
      }
    }
  }, {
    key: "onSave",
    value: function onSave() {
      var _this2 = this;

      var uniqueCheck = this.props.existingProperties.filter(function (row) {
        return row.name === _this2.state.keyInput;
      });

      if (uniqueCheck.length > 0) {
        this.setState({
          error: i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.PropertiesEditor.AddProperty.propertyExistError', {
            key: this.state.keyInput
          })
        });
        return;
      }

      var reqObj = {};
      var key = this.state.keyInput;
      reqObj[key] = this.state.valueInput;
      var namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__["default"].getState().selectedNamespace;
      var params = {
        namespace: namespace,
        entityType: this.props.entityType,
        entityId: this.props.entityId
      };
      api_metadata__WEBPACK_IMPORTED_MODULE_4__["MyMetadataApi"].addProperties(params, reqObj).subscribe(function () {
        _this2.toggleModal();

        _this2.props.onSave({
          name: key
        });
      }, function (err) {
        _this2.setState({
          error: err
        });
      });
    }
  }, {
    key: "renderFeedback",
    value: function renderFeedback() {
      if (!this.state.error) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalFooter"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_CardActionFeedback__WEBPACK_IMPORTED_MODULE_3__["default"], {
        type: "DANGER",
        message: i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.PropertiesEditor.AddProperty.shortError'),
        extendedMessage: this.state.error
      }));
    }
  }, {
    key: "renderModal",
    value: function renderModal() {
      if (!this.state.isOpen) {
        return null;
      }

      var disabled = this.state.keyInput.length === 0 || this.state.valueInput.length === 0;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Modal"], {
        isOpen: this.state.isOpen,
        toggle: this.toggleModal,
        backdrop: "static",
        size: "lg",
        className: "add-property-modal cdap-modal"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalHeader"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.PropertiesEditor.AddProperty.modalHeader', {
        entityId: this.props.entityId
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "close-section float-right",
        onClick: this.toggleModal
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-times"
      }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalBody"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "row input-properties"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "col-3"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("input", {
        type: "text",
        id: "add-property-modal-key-input",
        className: "form-control",
        placeholder: i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.PropertiesEditor.AddProperty.keyPlaceholder'),
        value: this.state.keyInput,
        onChange: this.handleKeyChange
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "col-9"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("input", {
        type: "text",
        className: "form-control",
        placeholder: i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.PropertiesEditor.AddProperty.valuePlaceholder'),
        value: this.state.valueInput,
        onChange: this.handleValueChange
      }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "text-right"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
        className: "btn btn-primary",
        onClick: this.onSave,
        disabled: disabled
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.PropertiesEditor.AddProperty.button')))), this.renderFeedback());
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
        className: "btn btn-secondary",
        onClick: this.toggleModal
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.PropertiesEditor.AddProperty.button')), this.renderModal());
    }
  }]);

  return AddPropertyModal;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


AddPropertyModal.propTypes = {
  entityId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  entityType: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf(['datasets', 'apps']),
  existingProperties: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.array,
  onSave: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/***/ }),

/***/ "./components/PropertiesEditor/DeleteConfirmation/index.js":
/*!*****************************************************************!*\
  !*** ./components/PropertiesEditor/DeleteConfirmation/index.js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return DeleteConfirmation; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/ConfirmationModal */ "./components/ConfirmationModal/index.js");
/* harmony import */ var api_metadata__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/metadata */ "./api/metadata.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */







var DeleteConfirmation =
/*#__PURE__*/
function (_Component) {
  _inherits(DeleteConfirmation, _Component);

  function DeleteConfirmation(props) {
    var _this;

    _classCallCheck(this, DeleteConfirmation);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(DeleteConfirmation).call(this, props));
    _this.state = {
      isOpen: false,
      error: null,
      loading: false
    };
    _this.toggleModal = _this.toggleModal.bind(_assertThisInitialized(_this));
    _this.deleteProperty = _this.deleteProperty.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(DeleteConfirmation, [{
    key: "toggleModal",
    value: function toggleModal() {
      this.setState({
        isOpen: !this.state.isOpen
      });
    }
  }, {
    key: "deleteProperty",
    value: function deleteProperty() {
      var _this2 = this;

      this.setState({
        loading: true
      });
      var namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["default"].getState().selectedNamespace;
      var params = {
        namespace: namespace,
        key: this.props.property.name,
        entityType: this.props.entityType,
        entityId: this.props.entityId
      };
      api_metadata__WEBPACK_IMPORTED_MODULE_3__["MyMetadataApi"].deleteProperty(params).subscribe(function () {
        _this2.setState({
          isOpen: false,
          error: null,
          loading: false
        });

        _this2.props.onDelete();
      }, function (err) {
        _this2.setState({
          error: err,
          loading: false
        });
      });
    }
  }, {
    key: "render",
    value: function render() {
      var error;

      if (this.state.error) {
        error = i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate('features.PropertiesEditor.DeleteConfirmation.shortError');
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-trash",
        onClick: this.toggleModal
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_2__["default"], {
        headerTitle: i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate('features.PropertiesEditor.DeleteConfirmation.headerTitle'),
        toggleModal: this.toggleModal,
        confirmationText: i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate('features.PropertiesEditor.DeleteConfirmation.confirmationText', {
          key: this.props.property.name
        }),
        confirmButtonText: i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate('features.PropertiesEditor.DeleteConfirmation.confirmButton'),
        confirmFn: this.deleteProperty,
        cancelFn: this.toggleModal,
        isOpen: this.state.isOpen,
        isLoading: this.state.loading,
        errorMessage: error,
        extendedMessage: this.state.error
      }));
    }
  }]);

  return DeleteConfirmation;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


DeleteConfirmation.propTypes = {
  property: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  onDelete: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  entityType: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  entityId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/PropertiesEditor/EditProperty/index.js":
/*!***********************************************************!*\
  !*** ./components/PropertiesEditor/EditProperty/index.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EditProperty; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var components_CardActionFeedback__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/CardActionFeedback */ "./components/CardActionFeedback/index.js");
/* harmony import */ var api_metadata__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! api/metadata */ "./api/metadata.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_7__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









var EditProperty =
/*#__PURE__*/
function (_Component) {
  _inherits(EditProperty, _Component);

  function EditProperty(props) {
    var _this;

    _classCallCheck(this, EditProperty);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(EditProperty).call(this, props));
    _this.state = {
      isOpen: false,
      valueInput: '',
      error: null
    };
    _this.toggleModal = _this.toggleModal.bind(_assertThisInitialized(_this));
    _this.saveProperty = _this.saveProperty.bind(_assertThisInitialized(_this));
    _this.handleValueChange = _this.handleValueChange.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(EditProperty, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      if (this.state.isOpen && this.state.valueInput.length === 0) {
        document.getElementById('edit-property-modal-value-input').focus();
      }
    }
  }, {
    key: "toggleModal",
    value: function toggleModal() {
      this.setState({
        isOpen: !this.state.isOpen
      });
    }
  }, {
    key: "saveProperty",
    value: function saveProperty() {
      var _this2 = this;

      if (!this.state.valueInput) {
        return;
      }

      var namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__["default"].getState().selectedNamespace;
      var params = {
        namespace: namespace,
        entityType: this.props.entityType,
        entityId: this.props.entityId,
        scope: services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].USER
      };
      var requestBody = {};
      requestBody[this.props.property.name] = this.state.valueInput;
      api_metadata__WEBPACK_IMPORTED_MODULE_4__["MyMetadataApi"].addProperties(params, requestBody).subscribe(function () {
        _this2.setState({
          isOpen: false,
          valueInput: ''
        });

        _this2.props.onSave();
      }, function (err) {
        _this2.setState({
          error: err
        });
      });
    }
  }, {
    key: "handleValueChange",
    value: function handleValueChange(e) {
      this.setState({
        valueInput: e.target.value
      });
    }
  }, {
    key: "renderFeedback",
    value: function renderFeedback() {
      if (!this.state.error) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalFooter"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_CardActionFeedback__WEBPACK_IMPORTED_MODULE_3__["default"], {
        type: "DANGER",
        message: i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('features.PropertiesEditor.EditProperty.shortError'),
        extendedMessage: this.state.error
      }));
    }
  }, {
    key: "renderModal",
    value: function renderModal() {
      if (!this.state.isOpen) {
        return null;
      }

      var disabled = this.state.valueInput.length === 0;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Modal"], {
        isOpen: this.state.isOpen,
        toggle: this.toggleModal,
        size: "md",
        className: "add-property-modal cdap-modal"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalHeader"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('features.PropertiesEditor.EditProperty.modalHeader', {
        key: this.props.property.name
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "close-section float-right",
        onClick: this.toggleModal
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-times"
      }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalBody"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "row input-properties"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "col-12"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("input", {
        type: "text",
        id: "edit-property-modal-value-input",
        className: "form-control",
        placeholder: i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('features.PropertiesEditor.EditProperty.valuePlaceholder'),
        value: this.state.valueInput,
        onChange: this.handleValueChange
      }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "text-right"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
        className: "btn btn-primary",
        onClick: this.saveProperty,
        disabled: disabled
      }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('features.PropertiesEditor.EditProperty.button')))), this.renderFeedback());
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-pencil",
        onClick: this.toggleModal
      }), this.renderModal());
    }
  }]);

  return EditProperty;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


EditProperty.propTypes = {
  property: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  entityType: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  entityId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onSave: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/***/ }),

/***/ "./components/PropertiesEditor/PropertiesEditor.scss":
/*!***********************************************************!*\
  !*** ./components/PropertiesEditor/PropertiesEditor.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./PropertiesEditor.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PropertiesEditor/PropertiesEditor.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PropertiesEditor/index.js":
/*!**********************************************!*\
  !*** ./components/PropertiesEditor/index.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PropertiesEditor; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_metadata__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/metadata */ "./api/metadata.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_PropertiesEditor_AddPropertyModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/PropertiesEditor/AddPropertyModal */ "./components/PropertiesEditor/AddPropertyModal/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_PropertiesEditor_DeleteConfirmation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/PropertiesEditor/DeleteConfirmation */ "./components/PropertiesEditor/DeleteConfirmation/index.js");
/* harmony import */ var components_PropertiesEditor_EditProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/PropertiesEditor/EditProperty */ "./components/PropertiesEditor/EditProperty/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */












__webpack_require__(/*! ./PropertiesEditor.scss */ "./components/PropertiesEditor/PropertiesEditor.scss");

var PropertiesEditor =
/*#__PURE__*/
function (_Component) {
  _inherits(PropertiesEditor, _Component);

  function PropertiesEditor(props) {
    var _this;

    _classCallCheck(this, PropertiesEditor);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(PropertiesEditor).call(this, props));

    _defineProperty(_assertThisInitialized(_this), "fetchProperties", function () {
      var params = {
        namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])(),
        entityType: _this.props.entityType,
        entityId: _this.props.entityId
      };
      api_metadata__WEBPACK_IMPORTED_MODULE_2__["MyMetadataApi"].getProperties(params).map(function (res) {
        return res.properties.map(function (property) {
          property.id = uuid_v4__WEBPACK_IMPORTED_MODULE_4___default()();
          return property;
        });
      }).subscribe(function (res) {
        _this.setState({
          systemProperties: res.filter(function (property) {
            return property.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_10__["SCOPES"].SYSTEM;
          }),
          userProperties: res.filter(function (property) {
            return property.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_10__["SCOPES"].USER;
          }),
          activeEdit: null,
          newValue: ''
        });
      });
    });

    _this.state = {
      systemProperties: [],
      userProperties: [],
      activeEdit: null,
      newValue: '',
      editedKey: null
    };
    return _this;
  }

  _createClass(PropertiesEditor, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      this.fetchProperties();
    }
  }, {
    key: "renderSystemProperties",
    value: function renderSystemProperties() {
      return this.state.systemProperties.map(function (row) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
          key: row.id
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, row.name), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, row.value), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.PropertiesEditor.system')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null));
      });
    }
  }, {
    key: "renderActions",
    value: function renderActions(row) {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PropertiesEditor_EditProperty__WEBPACK_IMPORTED_MODULE_8__["default"], {
        property: row,
        onSave: this.setEditProperty.bind(this, row),
        entityType: this.props.entityType,
        entityId: this.props.entityId
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PropertiesEditor_DeleteConfirmation__WEBPACK_IMPORTED_MODULE_7__["default"], {
        property: row,
        onDelete: this.fetchProperties,
        entityType: this.props.entityType,
        entityId: this.props.entityId
      }));
    }
  }, {
    key: "renderUserProperties",
    value: function renderUserProperties() {
      var _this2 = this;

      return this.state.userProperties.map(function (row) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
          key: row.id,
          className: classnames__WEBPACK_IMPORTED_MODULE_9___default()({
            'text-success': row.name === _this2.state.editedKey
          })
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, row.name), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, row.value), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.PropertiesEditor.user')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", {
          className: "actions"
        }, _this2.renderActions(row)));
      });
    }
  }, {
    key: "setEditProperty",
    value: function setEditProperty(row) {
      var _this3 = this;

      this.setState({
        editedKey: row.name
      });
      this.fetchProperties();
      setTimeout(function () {
        _this3.setState({
          editedKey: null
        });
      }, 3000);
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "properties-editor-container"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PropertiesEditor_AddPropertyModal__WEBPACK_IMPORTED_MODULE_5__["default"], {
        entityId: this.props.entityId,
        entityType: this.props.entityType,
        existingProperties: this.state.userProperties,
        onSave: this.setEditProperty.bind(this)
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("table", {
        className: "table"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("thead", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
        className: "key"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.PropertiesEditor.name')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
        className: "value"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.PropertiesEditor.value')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
        className: "scope"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.PropertiesEditor.scope')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
        className: "actions"
      }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tbody", null, this.renderUserProperties(), this.renderSystemProperties())));
    }
  }]);

  return PropertiesEditor;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


PropertiesEditor.propTypes = {
  entityId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  entityType: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf(['datasets', 'apps'])
};

/***/ }),

/***/ "./components/SchemaEditor/SchemaStore.js":
/*!************************************************!*\
  !*** ./components/SchemaEditor/SchemaStore.js ***!
  \************************************************/
/*! exports provided: createStoreInstance, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createStoreInstance", function() { return createStoreInstance; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

var defaultAction = {
  type: '',
  payload: {}
};
var defaultState = {
  name: 'etlSchemabody',
  type: 'record',
  fields: [{
    name: '',
    type: {},
    displayType: 'string'
  }]
};

var schema = function schema() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultState;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : defaultAction;

  switch (action.type) {
    case 'FIELD_UPDATE':
      {
        return Object.assign({}, state, {
          fields: action.payload.schema.fields
        });
      }

    case 'RESET':
      {
        return defaultState;
      }

    default:
      return state;
  }
};

var createStoreInstance = function createStoreInstance() {
  return Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
    schema: schema
  }), window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__());
};


var SchemaStore = createStoreInstance();
/* harmony default export */ __webpack_exports__["default"] = (SchemaStore);

/***/ }),

/***/ "./components/SortableTable/SortableTable.scss":
/*!*****************************************************!*\
  !*** ./components/SortableTable/SortableTable.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./SortableTable.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SortableTable/SortableTable.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SortableTable/index.js":
/*!*******************************************!*\
  !*** ./components/SortableTable/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SortableTable; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash/orderBy */ "../../node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





__webpack_require__(/*! ./SortableTable.scss */ "./components/SortableTable/SortableTable.scss");

var SortableTable =
/*#__PURE__*/
function (_Component) {
  _inherits(SortableTable, _Component);

  function SortableTable() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SortableTable);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SortableTable)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      entities: _this.props.entities,
      sortByHeader: '',
      sortOrder: 'asc',
      sortOnInitialLoad: typeof _this.props.sortOnInitialLoad !== 'boolean' ? true : _this.props.sortOnInitialLoad
    });

    return _this;
  }

  _createClass(SortableTable, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      if (!this.state.sortOnInitialLoad) {
        return;
      }

      var entities = this.state.entities;
      var sortByHeader = this.getDefaultSortedHeader();
      entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default()(entities, [sortByHeader], [this.state.sortOrder]);
      this.setState({
        entities: entities,
        sortByHeader: sortByHeader
      });
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.setState({
        entities: nextProps.entities
      });
    }
  }, {
    key: "getDefaultSortedHeader",
    value: function getDefaultSortedHeader() {
      var defaultHeader = '';

      for (var i = 0; i < this.props.tableHeaders.length; i++) {
        if (this.props.tableHeaders[i].defaultSortby) {
          defaultHeader = this.props.tableHeaders[i].property;
          break;
        }
      }

      return defaultHeader || this.props.tableHeaders[0].property;
    }
  }, {
    key: "sortBy",
    value: function sortBy(header) {
      var headerProp = header.property;
      var entities = this.state.entities;
      var sortOrder = this.state.sortOrder;
      var sortByHeader = this.state.sortByHeader;

      if (sortByHeader === headerProp) {
        if (sortOrder === 'asc') {
          // already sorting in this column, sort the other way
          sortOrder = 'desc';
        } else {
          sortOrder = 'asc';
        }
      } else {
        // a new sort, so start with ascending sort
        sortByHeader = headerProp;
        sortOrder = 'asc';
      }

      if (header.sortFunc) {
        entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default()(entities, [header.sortFunc], [sortOrder]);
      } else {
        entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default()(entities, [sortByHeader], [sortOrder]);
      }

      this.setState({
        entities: entities,
        sortOrder: sortOrder,
        sortByHeader: sortByHeader
      });
    }
  }, {
    key: "renderSortableTableHeader",
    value: function renderSortableTableHeader(header) {
      if (this.state.sortByHeader !== header.property) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          onClick: this.sortBy.bind(this, header)
        }, header.label);
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        onClick: this.sortBy.bind(this, header)
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "text-underline"
      }, header.label), this.state.sortOrder === 'asc' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
        className: "fa fa-caret-down fa-lg"
      }) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
        className: "fa fa-caret-up fa-lg"
      }));
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var tableClasses = classnames__WEBPACK_IMPORTED_MODULE_3___default()('table', this.props.className);
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("table", {
        className: tableClasses
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("thead", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, this.props.tableHeaders.map(function (tableHeader, i) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
          key: i
        }, tableHeader.property ? _this2.renderSortableTableHeader(tableHeader) : tableHeader.label);
      }))), this.props.renderTableBody(this.state.entities));
    }
  }]);

  return SortableTable;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


SortableTable.propTypes = {
  tableHeaders: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    label: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    property: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    defaultSortby: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
  })),
  renderTableBody: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  entities: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object),
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  sortOnInitialLoad: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
};

/***/ }),

/***/ "./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss":
/*!***********************************************************************!*\
  !*** ./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./SpotlightModal.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SpotlightSearch/SpotlightModal/SpotlightModalHeader.js":
/*!***************************************************************************!*\
  !*** ./components/SpotlightSearch/SpotlightModal/SpotlightModalHeader.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SpotlightModalHeader; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_Pagination_PaginationDropdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Pagination/PaginationDropdown */ "./components/Pagination/PaginationDropdown.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./SpotlightModal.scss */ "./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss");

var SpotlightModalHeader =
/*#__PURE__*/
function (_Component) {
  _inherits(SpotlightModalHeader, _Component);

  function SpotlightModalHeader(props) {
    var _this;

    _classCallCheck(this, SpotlightModalHeader);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(SpotlightModalHeader).call(this, props));
    _this.state = {
      isDropdownExpanded: false
    };
    _this.toggleExpansion = _this.toggleExpansion.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(SpotlightModalHeader, [{
    key: "toggleExpansion",
    value: function toggleExpansion() {
      this.setState({
        isDropdownExpanded: !this.state.isDropdownExpanded
      });
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_4__["ModalHeader"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "tag-title"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate('features.SpotlightSearch.SpotlightModal.headerTagResults', {
        tag: this.props.tag
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "close-section text-right"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "search-results-total"
      }, this.props.total === 1 ? i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate('features.SpotlightSearch.SpotlightModal.numResult', {
        total: this.props.total
      }) : i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate('features.SpotlightSearch.SpotlightModal.numResults', {
        total: this.props.total
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Pagination_PaginationDropdown__WEBPACK_IMPORTED_MODULE_3__["default"], {
        numberOfPages: this.props.numPages,
        currentPage: this.props.currentPage,
        onPageChange: this.props.handleSearch.bind(this)
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-times",
        onClick: this.props.toggle
      })));
    }
  }]);

  return SpotlightModalHeader;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


SpotlightModalHeader.propTypes = {
  toggle: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  handleSearch: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  currentPage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  tag: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  numPages: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  total: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number
};

/***/ }),

/***/ "./components/SpotlightSearch/SpotlightModal/index.js":
/*!************************************************************!*\
  !*** ./components/SpotlightSearch/SpotlightModal/index.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SpotlightModal; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_search__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/search */ "./api/search.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_metadata_parser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/metadata-parser */ "./services/metadata-parser/index.js");
/* harmony import */ var services_entity_type_api_converter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/entity-type-api-converter */ "./services/entity-type-api-converter/index.js");
/* harmony import */ var components_NavLinkWrapper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/NavLinkWrapper */ "./components/NavLinkWrapper/index.js");
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! mousetrap */ "../../node_modules/mousetrap/mousetrap.js");
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(mousetrap__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var components_Pagination__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/Pagination */ "./components/Pagination/index.js");
/* harmony import */ var components_SpotlightSearch_SpotlightModal_SpotlightModalHeader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/SpotlightSearch/SpotlightModal/SpotlightModalHeader */ "./components/SpotlightSearch/SpotlightModal/SpotlightModalHeader.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

















__webpack_require__(/*! ./SpotlightModal.scss */ "./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss");

var PREFIX = 'features.SpotlightSearch.SpotlightModal';
var PAGE_SIZE = 10;

var SpotlightModal =
/*#__PURE__*/
function (_Component) {
  _inherits(SpotlightModal, _Component);

  function SpotlightModal() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SpotlightModal);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SpotlightModal)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      searchResults: {
        results: []
      },
      currentPage: 1,
      numPages: 1,
      focusIndex: 0,
      isPaginationExpanded: false
    });

    _defineProperty(_assertThisInitialized(_this), "handlePaginationToggle", function () {
      _this.setState({
        isPaginationExpanded: !_this.state.isPaginationExpanded
      });
    });

    return _this;
  }

  _createClass(SpotlightModal, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_7___default.a.bind('up', this.handleUpDownArrow.bind(this, 'UP'));
      mousetrap__WEBPACK_IMPORTED_MODULE_7___default.a.bind('down', this.handleUpDownArrow.bind(this, 'DOWN'));
      mousetrap__WEBPACK_IMPORTED_MODULE_7___default.a.bind('enter', this.handleEnter.bind(this));
      this.handleSearch(1);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_7___default.a.unbind('up');
      mousetrap__WEBPACK_IMPORTED_MODULE_7___default.a.unbind('down');
      mousetrap__WEBPACK_IMPORTED_MODULE_7___default.a.unbind('enter');
    }
  }, {
    key: "handleUpDownArrow",
    value: function handleUpDownArrow(direction) {
      if (direction === 'UP') {
        var focusIndex = this.state.focusIndex === 0 ? 0 : this.state.focusIndex - 1;
        this.setState({
          focusIndex: focusIndex
        });
      } else if (direction === 'DOWN') {
        var totalResults = this.state.searchResults.results.length;

        var _focusIndex = this.state.focusIndex === totalResults - 1 ? this.state.focusIndex : this.state.focusIndex + 1;

        this.setState({
          focusIndex: _focusIndex
        });
      }
    }
  }, {
    key: "handleEnter",
    value: function handleEnter() {
      var entity = Object(services_metadata_parser__WEBPACK_IMPORTED_MODULE_4__["parseMetadata"])(this.state.searchResults.results[this.state.focusIndex]); // Redirect to entity once we have entity detail page
      // Right now console logging entity for identification purposes

      console.log('ENTER on:', entity.id);
    }
  }, {
    key: "handleSearch",
    value: function handleSearch(page) {
      var _this2 = this;

      if (page === 0 || page > this.state.numPages) {
        return;
      }

      var offset = (page - 1) * PAGE_SIZE;
      var query = 'tags:' + this.props.tag;
      var target = this.props.target ? this.props.target : []; // removed sort, cannot search and sort at the same time

      api_search__WEBPACK_IMPORTED_MODULE_2__["MySearchApi"].search({
        namespace: services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["default"].getState().selectedNamespace,
        query: query,
        target: target,
        limit: PAGE_SIZE,
        offset: offset,
        responseFormat: 'v6'
      }).subscribe(function (res) {
        _this2.setState({
          searchResults: res,
          currentPage: page,
          numPages: Math.ceil(res.totalResults / PAGE_SIZE),
          focusIndex: 0
        });
      });
    }
  }, {
    key: "renderBodyContent",
    value: function renderBodyContent() {
      var _this3 = this;

      if (!this.state.searchResults.results.length) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "text-center no-search-results"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate("".concat(PREFIX, ".noResults"), {
          tag: this.props.tag
        }));
      }

      var currentNamespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["default"].getState().selectedNamespace;
      var searchResultsToBeRendered = this.state.searchResults.results.map(services_metadata_parser__WEBPACK_IMPORTED_MODULE_4__["parseMetadata"]).map(function (entity, index) {
        var entityTypeLabel = Object(services_entity_type_api_converter__WEBPACK_IMPORTED_MODULE_5__["convertEntityTypeToApi"])(entity.type);
        var entityUrl = "/ns/".concat(currentNamespace, "/").concat(entityTypeLabel, "/").concat(entity.id);

        if (entityTypeLabel === 'apps') {
          entityUrl = "/pipelines/ns/".concat(currentNamespace, "/view/").concat(entity.id);
        }

        if (_this3.props.isNativeLink && entityTypeLabel !== 'apps') {
          entityUrl = "/cdap".concat(entityUrl);
        } // (CDAP-16788) We have removed app detailed view. So if it is not a pipeline don't
        // navigate anywhere.


        if ([services_global_constants__WEBPACK_IMPORTED_MODULE_13__["GLOBALS"].etlDataPipeline, services_global_constants__WEBPACK_IMPORTED_MODULE_13__["GLOBALS"].etlDataStreams].indexOf(Object(services_metadata_parser__WEBPACK_IMPORTED_MODULE_4__["getType"])(entity)) === -1) {
          entityUrl = '';
        }

        var description = entity.metadata.metadata.properties.find(function (property) {
          return property.name === 'description';
        });
        description = description ? description.value : null;
        var entityTags = entity.metadata.metadata.tags || [];
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_NavLinkWrapper__WEBPACK_IMPORTED_MODULE_6__["default"], {
          key: entity.id,
          to: entityUrl,
          isNativeLink: _this3.props.isNativeLink,
          className: "search-results-item-link"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          key: uuid_v4__WEBPACK_IMPORTED_MODULE_9___default()(),
          className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('row search-results-item', {
            active: index === _this3.state.focusIndex
          })
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_14__["Col"], {
          xs: "6"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "entity-title"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "entity-icon"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: entity.icon
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "entity-name"
        }, entity.id)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "entity-description"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, description))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_14__["Col"], {
          xs: "6"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "entity-tags-container text-right"
        }, entityTags.map(function (tag) {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_14__["Badge"], {
            key: uuid_v4__WEBPACK_IMPORTED_MODULE_9___default()()
          }, tag.name);
        })))));
      });
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, searchResultsToBeRendered);
    }
  }, {
    key: "render",
    value: function render() {
      var results = Object(services_helpers__WEBPACK_IMPORTED_MODULE_15__["objectQuery"])(this.state.searchResults, 'results') || [];
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_14__["Modal"], {
        isOpen: this.props.isOpen,
        toggle: this.props.toggle,
        className: "search-results-modal",
        size: "lg",
        backdrop: "static"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SpotlightSearch_SpotlightModal_SpotlightModalHeader__WEBPACK_IMPORTED_MODULE_11__["default"], {
        toggle: this.props.toggle,
        handleSearch: this.handleSearch.bind(this),
        currentPage: this.state.currentPage,
        query: this.props.query,
        tag: this.props.tag,
        numPages: this.state.numPages,
        total: results.length
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_14__["ModalBody"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "search-results-container"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Pagination__WEBPACK_IMPORTED_MODULE_10__["default"], {
        setCurrentPage: this.handleSearch.bind(this),
        currentPage: this.state.currentPage
      }, this.renderBodyContent()))));
    }
  }]);

  return SpotlightModal;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(SpotlightModal, "propTypes", {
  query: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  tag: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  target: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.array,
  isOpen: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  toggle: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  isNativeLink: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});

_defineProperty(SpotlightModal, "defaultProps", {
  isNativeLink: false
});



/***/ }),

/***/ "./components/Tags/Tag/Tag.scss":
/*!**************************************!*\
  !*** ./components/Tags/Tag/Tag.scss ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./Tag.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Tags/Tag/Tag.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Tags/Tag/index.js":
/*!**************************************!*\
  !*** ./components/Tags/Tag/index.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Tag; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_SpotlightSearch_SpotlightModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/SpotlightSearch/SpotlightModal */ "./components/SpotlightSearch/SpotlightModal/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */







__webpack_require__(/*! ./Tag.scss */ "./components/Tags/Tag/Tag.scss");

var Tag =
/*#__PURE__*/
function (_Component) {
  _inherits(Tag, _Component);

  function Tag() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, Tag);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(Tag)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      searchModalOpen: false
    });

    _defineProperty(_assertThisInitialized(_this), "toggleSearchModal", function (e) {
      if (_this.props.preventDefault) {
        e.preventDefault();
      }

      _this.setState({
        searchModalOpen: !_this.state.searchModalOpen
      });
    });

    return _this;
  }

  _createClass(Tag, [{
    key: "render",
    value: function render() {
      var tagClasses = classnames__WEBPACK_IMPORTED_MODULE_3___default()('btn btn-secondary tag-btn', {
        'system-tag': this.props.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_5__["SCOPES"].SYSTEM,
        'user-tag': this.props.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_5__["SCOPES"].USER
      });
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: tagClasses
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        onClick: this.toggleSearchModal,
        className: "tag-content"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.props.value), this.props.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_5__["SCOPES"].USER && !this.props.viewOnly ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-close",
        onClick: this.props.onDelete
      }) : null), this.state.searchModalOpen ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SpotlightSearch_SpotlightModal__WEBPACK_IMPORTED_MODULE_2__["default"], {
        tag: this.props.value,
        target: ['application', 'dataset'],
        isOpen: this.state.searchModalOpen,
        toggle: this.toggleSearchModal,
        isNativeLink: this.props.isNativeLink
      }) : null);
    }
  }]);

  return Tag;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(Tag, "propTypes", {
  value: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  scope: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onDelete: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  isNativeLink: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  viewOnly: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  preventDefault: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});

_defineProperty(Tag, "defaultProps", {
  isNativeLink: false,
  viewOnly: false
});



/***/ }),

/***/ "./components/Tags/Tags.scss":
/*!***********************************!*\
  !*** ./components/Tags/Tags.scss ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Tags.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Tags/Tags.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Tags/index.js":
/*!**********************************!*\
  !*** ./components/Tags/index.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Tags; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_metadata__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/metadata */ "./api/metadata.js");
/* harmony import */ var lodash_isObject__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/isObject */ "../../node_modules/lodash/isObject.js");
/* harmony import */ var lodash_isObject__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_isObject__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! mousetrap */ "../../node_modules/mousetrap/mousetrap.js");
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(mousetrap__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_entity_type_api_converter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/entity-type-api-converter */ "./services/entity-type-api-converter/index.js");
/* harmony import */ var components_Tags_Tag__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Tags/Tag */ "./components/Tags/Tag/index.js");
/* harmony import */ var components_Alert__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/Alert */ "./components/Alert/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */












__webpack_require__(/*! ./Tags.scss */ "./components/Tags/Tags.scss");



var PREFIX = 'features.Tags';

var Tags =
/*#__PURE__*/
function (_Component) {
  _inherits(Tags, _Component);

  function Tags() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, Tags);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(Tags)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      systemTags: [],
      userTags: [],
      showInputField: false,
      loading: false,
      currentInputTag: '',
      showAllTagsLabel: false,
      showAllTagsPopover: false
    });

    _defineProperty(_assertThisInitialized(_this), "params", {
      namespace: services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__["default"].getState().selectedNamespace,
      entityType: Object(services_entity_type_api_converter__WEBPACK_IMPORTED_MODULE_6__["convertEntityTypeToApi"])(_this.props.entity.type),
      entityId: _this.props.entity.id
    });

    _defineProperty(_assertThisInitialized(_this), "subscriptions", []);

    _defineProperty(_assertThisInitialized(_this), "getTags", function () {
      _this.setState({
        loading: false
      });

      var tagsSubscription = api_metadata__WEBPACK_IMPORTED_MODULE_2__["MyMetadataApi"].getTags(_this.params).subscribe(function (res) {
        _this.setState({
          systemTags: res.tags.filter(function (tag) {
            return tag.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_12__["SCOPES"].SYSTEM;
          }).map(function (tag) {
            return tag.name;
          }).sort(),
          userTags: res.tags.filter(function (tag) {
            return tag.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_12__["SCOPES"].USER;
          }).map(function (tag) {
            return tag.name;
          }).sort(),
          loading: false
        }, _this.isTagsOverflowing);

        if (_this.state.showInputField) {
          _this.toggleInputField();
        }
      }, function (err) {
        _this.setState({
          error: lodash_isObject__WEBPACK_IMPORTED_MODULE_3___default()(err) ? err.response : err,
          loading: false
        });
      });

      _this.subscriptions.push(tagsSubscription);
    });

    _defineProperty(_assertThisInitialized(_this), "toggleInputField", function () {
      if (!_this.state.loading) {
        if (_this.state.showInputField) {
          _this.setState({
            currentInputTag: '',
            error: false
          });
        }

        _this.setState({
          showInputField: !_this.state.showInputField
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "closeInputFieldIfEmpty", function () {
      if (_this.state.currentInputTag === '' && _this.state.showInputField) {
        _this.setState({
          showInputField: false,
          error: false
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "onInputTagChange", function (e) {
      _this.setState({
        currentInputTag: e.target.value
      });
    });

    _defineProperty(_assertThisInitialized(_this), "addTag", function () {
      if (_this.state.currentInputTag !== '') {
        _this.setState({
          loading: true
        });

        var addTagsSubscription = api_metadata__WEBPACK_IMPORTED_MODULE_2__["MyMetadataApi"].addTags(_this.params, [_this.state.currentInputTag]).subscribe(function () {
          _this.getTags();
        }, function (err) {
          _this.setState({
            error: lodash_isObject__WEBPACK_IMPORTED_MODULE_3___default()(err) ? err.response : err,
            loading: false
          });
        });

        _this.subscriptions.push(addTagsSubscription);
      }
    });

    _defineProperty(_assertThisInitialized(_this), "isTagsOverflowing", function () {
      if (_this.props.displayAll) {
        return;
      }

      var tagsListElem = document.getElementsByClassName('tags-list')[0];

      if (!tagsListElem) {
        return;
      }

      var tagsAreOverflowing = tagsListElem.clientWidth < tagsListElem.scrollWidth;

      if (tagsAreOverflowing && _this.state.showAllTagsLabel || !tagsAreOverflowing && !_this.state.showAllTagsLabel) {
        return;
      }

      _this.setState({
        showAllTagsLabel: tagsAreOverflowing
      });
    });

    _defineProperty(_assertThisInitialized(_this), "toggleAllTagsPopover", function () {
      _this.setState({
        showAllTagsPopover: !_this.state.showAllTagsPopover
      });
    });

    return _this;
  }

  _createClass(Tags, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_4___default.a.bind('return', this.addTag);
      mousetrap__WEBPACK_IMPORTED_MODULE_4___default.a.bind('escape', this.closeInputFieldIfEmpty);
      this.getTags();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_4___default.a.unbind('return');
      mousetrap__WEBPACK_IMPORTED_MODULE_4___default.a.unbind('escape');
      this.subscriptions.map(function (subscriber) {
        return subscriber.unsubscribe();
      });
    }
  }, {
    key: "deleteTag",
    value: function deleteTag(tag, event) {
      var _this2 = this;

      event.preventDefault();
      event.stopPropagation();
      event.nativeEvent.stopImmediatePropagation();
      var params = Object.assign({}, this.params, {
        key: tag
      });
      var deleteTagsSubscription = api_metadata__WEBPACK_IMPORTED_MODULE_2__["MyMetadataApi"].deleteTags(params).subscribe(function () {
        _this2.getTags();
      }, function (err) {
        _this2.setState({
          error: lodash_isObject__WEBPACK_IMPORTED_MODULE_3___default()(err) ? err.response : err
        });
      });
      this.subscriptions.push(deleteTagsSubscription);
    }
  }, {
    key: "renderSystemTags",
    value: function renderSystemTags() {
      var _this3 = this;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.state.systemTags.map(function (tag) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Tags_Tag__WEBPACK_IMPORTED_MODULE_7__["default"], {
          value: tag,
          scope: services_global_constants__WEBPACK_IMPORTED_MODULE_12__["SCOPES"].SYSTEM,
          isNativeLink: _this3.props.isNativeLink,
          preventDefault: _this3.props.preventDefault,
          key: tag
        });
      }));
    }
  }, {
    key: "renderUserTags",
    value: function renderUserTags() {
      var _this4 = this;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.state.userTags.map(function (tag) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Tags_Tag__WEBPACK_IMPORTED_MODULE_7__["default"], {
          value: tag,
          onDelete: _this4.deleteTag.bind(_this4, tag),
          scope: services_global_constants__WEBPACK_IMPORTED_MODULE_12__["SCOPES"].USER,
          isNativeLink: _this4.props.isNativeLink,
          viewOnly: _this4.props.viewOnly,
          preventDefault: _this4.props.preventDefault,
          key: tag
        });
      }));
    }
  }, {
    key: "renderTagsPopover",
    value: function renderTagsPopover() {
      var labelElem = function labelElem() {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "all-tags-label"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".allTags")));
      };

      var tagsCount = this.state.systemTags.length + this.state.userTags.length;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_10__["default"], {
        target: labelElem,
        className: "tags-popover",
        placement: "bottom",
        bubbleEvent: false,
        enableInteractionInPopover: true,
        showPopover: this.state.showAllTagsPopover
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "tags-popover-header"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".labelWithCount"), {
        count: tagsCount
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_9__["default"], {
        name: "icon-close",
        onClick: this.toggleAllTagsPopover
      })), this.renderSystemTags(), this.renderUserTags());
    }
  }, {
    key: "renderInputField",
    value: function renderInputField() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("input", {
        type: "text",
        className: "tag-input form-control mousetrap",
        value: this.state.currentInputTag,
        onChange: this.onInputTagChange,
        onBlur: this.toggleInputField,
        autoFocus: true,
        disabled: this.state.loading ? 'disabled' : null,
        "data-testid": "tag-input"
      }));
    }
  }, {
    key: "renderPlusButton",
    value: function renderPlusButton() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "btn btn-primary plus-button-container",
        onClick: this.toggleInputField,
        "data-testid": "tag-plus-button"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_9__["default"], {
        name: "icon-plus",
        className: "text-white"
      }));
    }
  }, {
    key: "renderAddTag",
    value: function renderAddTag() {
      if (this.props.viewOnly) {
        return null;
      }

      return this.state.showInputField ? this.renderInputField() : this.renderPlusButton();
    }
  }, {
    key: "render",
    value: function render() {
      var _this5 = this;

      var tagsCount = this.state.systemTags.length + this.state.userTags.length;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "tags-holder"
      }, this.props.showCountLabel ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, "".concat(i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".labelWithCount"), {
        count: tagsCount
      }), ":")) : null, !tagsCount && !this.state.loading ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".notags"))) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "tags-list"
      }, this.renderSystemTags(), this.renderUserTags()), this.state.showAllTagsLabel ? this.renderTagsPopover() : null, this.renderAddTag(), this.state.loading ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_9__["default"], {
        name: "icon-spinner",
        className: "fa-lg fa-spin",
        "data-testid": "loading-icon"
      }) : null, this.state.error ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Alert__WEBPACK_IMPORTED_MODULE_8__["default"], {
        message: this.state.error,
        type: "error",
        showAlert: true,
        onClose: function onClose() {
          return _this5.setState({
            error: false
          });
        }
      }) : null);
    }
  }]);

  return Tags;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(Tags, "defaultProps", {
  showCountLabel: true,
  isNativeLink: false,
  viewOnly: false,
  displayAll: false,
  preventDefault: false
});

_defineProperty(Tags, "propTypes", {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  showCountLabel: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  isNativeLink: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  viewOnly: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  displayAll: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  preventDefault: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});



/***/ }),

/***/ "./components/ViewSwitch/ViewSwitch.scss":
/*!***********************************************!*\
  !*** ./components/ViewSwitch/ViewSwitch.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./ViewSwitch.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/ViewSwitch/ViewSwitch.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/ViewSwitch/index.js":
/*!****************************************!*\
  !*** ./components/ViewSwitch/index.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ViewSwitch; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal-cookie */ "../../node_modules/universal-cookie/es6/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./ViewSwitch.scss */ "./components/ViewSwitch/ViewSwitch.scss");


var cookie = new universal_cookie__WEBPACK_IMPORTED_MODULE_5__["default"]();

var ViewSwitch =
/*#__PURE__*/
function (_Component) {
  _inherits(ViewSwitch, _Component);

  function ViewSwitch(props) {
    var _this;

    _classCallCheck(this, ViewSwitch);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ViewSwitch).call(this, props));
    var defaultView = cookie.get('ViewSwitchDefault');
    _this.state = {
      list: _this.props.list,
      activeTab: defaultView || 'card'
    };
    return _this;
  }

  _createClass(ViewSwitch, [{
    key: "toggleView",
    value: function toggleView(tab) {
      if (this.state.activeTab !== tab) {
        cookie.set('ViewSwitchDefault', tab);
        this.setState({
          activeTab: tab
        });

        if (this.props.onSwitch) {
          this.props.onSwitch();
        }
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "view-switch"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "clearfix"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Nav"], {
        className: "float-right",
        tabs: true
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["NavItem"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["NavLink"], {
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()({
          active: this.state.activeTab === 'card'
        }),
        onClick: function onClick() {
          _this2.toggleView('card');
        }
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-th-large"
      }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["NavItem"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["NavLink"], {
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()({
          active: this.state.activeTab === 'list'
        }),
        onClick: function onClick() {
          _this2.toggleView('list');
        }
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-list"
      }))))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["TabContent"], {
        activeTab: this.state.activeTab
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["TabPane"], {
        tabId: "card"
      }, this.state.activeTab === 'card' ? this.props.children[0] : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["TabPane"], {
        tabId: "list"
      }, this.state.activeTab === 'list' ? this.props.children[1] : null)));
    }
  }]);

  return ViewSwitch;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


ViewSwitch.propTypes = {
  list: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object),
  children: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.node,
  onSwitch: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/***/ }),

/***/ "./services/ExploreTables/ActionCreator.js":
/*!*************************************************!*\
  !*** ./services/ExploreTables/ActionCreator.js ***!
  \*************************************************/
/*! exports provided: fetchTables */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchTables", function() { return fetchTables; });
/* harmony import */ var api_explore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! api/explore */ "./api/explore.js");
/* harmony import */ var api_dataset__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! api/dataset */ "./api/dataset.js");
/* harmony import */ var services_ExploreTables_ExploreTablesActions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/ExploreTables/ExploreTablesActions */ "./services/ExploreTables/ExploreTablesActions.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__);
/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
*/





var fetchTables = function fetchTables(namespace) {
  return function (dispatch) {
    var exploreTables$ = api_explore__WEBPACK_IMPORTED_MODULE_0__["default"].fetchTables({
      namespace: namespace
    });
    var datasetsSpec$ = api_dataset__WEBPACK_IMPORTED_MODULE_1__["MyDatasetApi"].list({
      namespace: namespace
    });
    return rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__["Observable"].combineLatest(exploreTables$, datasetsSpec$).subscribe(function (res) {
      dispatch({
        type: services_ExploreTables_ExploreTablesActions__WEBPACK_IMPORTED_MODULE_2__["default"].SET_TABLES,
        payload: {
          exploreTables: res[0],
          datasetsSpec: res[1]
        }
      });
    });
  };
};



/***/ }),

/***/ "./services/ExploreTables/ExploreTablesActions.js":
/*!********************************************************!*\
  !*** ./services/ExploreTables/ExploreTablesActions.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var ExploreTablesActions = {
  FETCH_TABLES: 'FETCH_TABLES',
  SET_TABLES: 'SET_TABLES'
};
/* harmony default export */ __webpack_exports__["default"] = (ExploreTablesActions);

/***/ }),

/***/ "./services/ExploreTables/ExploreTablesStore.js":
/*!******************************************************!*\
  !*** ./services/ExploreTables/ExploreTablesStore.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux-thunk */ "../../node_modules/redux-thunk/es/index.js");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_ExploreTables_ExploreTablesActions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/ExploreTables/ExploreTablesActions */ "./services/ExploreTables/ExploreTablesActions.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_findIndex__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/findIndex */ "../../node_modules/lodash/findIndex.js");
/* harmony import */ var lodash_findIndex__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_findIndex__WEBPACK_IMPORTED_MODULE_4__);
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var defaultAction = {
  type: '',
  payload: {},
  uniqueId: uuid_v4__WEBPACK_IMPORTED_MODULE_3___default()()
};
var defaultInitialState = {
  tables: []
};
/*
  TL;DR -
  conditions to determine if a dataset is explorable =
    dataset spec properties (explore.table.name & explore.database.name)
  +
    /explore/tables

  - UI will query dataset service endpoint .../<namespace>/data/datasets. This returns all dataset specs
  - UI will query the explore endpoint .../<namespace>/explore/tables. This returns a TableNameInfo all tables in the default database for that namespace (but not the ones that have a custom database)
    - for each dataset:
      - the explore table name is either given as property explore.table.name or defaults to dataset_<name>.
      - if the dataset spec's properties contain explore.database.name, then the table is explorable with that database name and the above table name
      - otherwise, determine whether the dataset is explorable by finding the TableNameInfo for the explore table name.
        - if that entry exists, the table is explorable, and the database name is in the TableNameInfo
        - otherwise the dataset is not explorable
*/

var tables = function tables() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultInitialState.tables;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : defaultAction;

  switch (action.type) {
    case services_ExploreTables_ExploreTablesActions__WEBPACK_IMPORTED_MODULE_2__["default"].SET_TABLES:
      {
        var datasetsSpec = action.payload.datasetsSpec.filter(function (dSpec) {
          return dSpec.properties['explore.database.name'] || dSpec.properties['explore.table.name'];
        }).map(function (dSpec) {
          return {
            datasetName: dSpec.name,
            database: dSpec.properties['explore.database.name'] || 'default',
            table: dSpec.properties['explore.table.name'] || ''
          };
        });
        var exploreTables = action.payload.exploreTables;

        var _tables = exploreTables.map(function (tb) {
          var tableIndex = tb.table.indexOf('_');
          var dbIndex = tb.database.indexOf('_');
          var matchingSpec = datasetsSpec.find(function (dspec) {
            var isSameTable = dspec.table === (tableIndex !== -1 ? tb.table.slice(tableIndex) : tb.table);
            var isSameDB = dspec.database === (dbIndex !== -1 ? tb.database.slice(dbIndex) : tb.table);
            return isSameTable || isSameDB;
          });

          if (matchingSpec) {
            var matchingSpecIndex = lodash_findIndex__WEBPACK_IMPORTED_MODULE_4___default()(datasetsSpec, matchingSpec);
            datasetsSpec.splice(matchingSpecIndex, 1);
            return {
              table: matchingSpec.table || tb.table,
              database: matchingSpec.database || tb.database
            };
          }

          return tb;
        });

        if (datasetsSpec.length) {
          _tables = [].concat(_toConsumableArray(_tables), _toConsumableArray(datasetsSpec));
        }

        return _toConsumableArray(_tables || []);
      }

    default:
      return state;
  }
};

var composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || redux__WEBPACK_IMPORTED_MODULE_1__["compose"];
var ExploreTablesStore = Object(redux__WEBPACK_IMPORTED_MODULE_1__["createStore"])(Object(redux__WEBPACK_IMPORTED_MODULE_1__["combineReducers"])({
  tables: tables
}), defaultInitialState, composeEnhancers(Object(redux__WEBPACK_IMPORTED_MODULE_1__["applyMiddleware"])(redux_thunk__WEBPACK_IMPORTED_MODULE_0__["default"])));
/* harmony default export */ __webpack_exports__["default"] = (ExploreTablesStore);

/***/ }),

/***/ "./services/StatusMapper.js":
/*!**********************************!*\
  !*** ./services/StatusMapper.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
var _statusMap;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
*/

var statusMap = (_statusMap = {}, _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].DEPLOYED, 'Deployed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUBMITTING, 'Submitting'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].RUNNING, 'Running'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUCCEEDED, 'Succeeded'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].FAILED, 'Failed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].REJECTED, 'Rejected'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].DRAFT, 'Draft'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STOPPED, 'Stopped'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].COMPLETED, 'Succeeded'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].KILLED, 'Stopped'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].KILLED_BY_TIMER, 'Succeeded'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].DEPLOY_FAILED, 'Failed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].RUN_FAILED, 'Failed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUSPENDED, 'Deployed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SCHEDULED, 'Scheduled'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STARTING, 'Starting'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SCHEDULING, 'Scheduling'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STOPPING, 'Stopping'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUSPENDING, 'Suspending'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].PENDING, 'Provisioning'), _statusMap);

function lookupDisplayStatus(systemStatus) {
  if (systemStatus in statusMap) {
    return statusMap[systemStatus];
  } else {
    return systemStatus;
  }
}

function getStatusIndicatorClass(displayStatus) {
  if (displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].RUNNING] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STARTING] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].PENDING]) {
    return 'status-blue';
  } else if (displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUCCEEDED] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SCHEDULING] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STOPPING]) {
    return 'status-light-green';
  } else if (displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].FAILED] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].REJECTED]) {
    return 'status-light-red';
  } else {
    return 'status-light-grey';
  }
}

function getStatusIndicatorIcon(displayStatus) {
  if (displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].PENDING] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].DRAFT]) {
    return 'icon-circle-o';
  }

  return 'icon-circle';
}

/* harmony default export */ __webpack_exports__["default"] = ({
  statusMap: statusMap,
  lookupDisplayStatus: lookupDisplayStatus,
  getStatusIndicatorClass: getStatusIndicatorClass,
  getStatusIndicatorIcon: getStatusIndicatorIcon
});

/***/ }),

/***/ "./services/entity-icon-map/index.js":
/*!*******************************************!*\
  !*** ./services/entity-icon-map/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var EntityIconMap = {
  'cdap-data-pipeline': 'icon-ETLBatch',
  'cdap-data-streams': 'icon-sparkstreaming',
  mapreduce: 'icon-mapreduce',
  service: 'icon-service',
  spark: 'icon-spark',
  worker: 'icon-worker',
  workflow: 'icon-workflow',
  application: 'icon-fist',
  artifact: 'icon-archive',
  dataset: 'icon-datasets',
  view: 'icon-streamview'
};
/* harmony default export */ __webpack_exports__["default"] = (EntityIconMap);

/***/ }),

/***/ "./services/entity-type-api-converter/index.js":
/*!*****************************************************!*\
  !*** ./services/entity-type-api-converter/index.js ***!
  \*****************************************************/
/*! exports provided: convertEntityTypeToApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convertEntityTypeToApi", function() { return convertEntityTypeToApi; });
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var apiEntityTypeConvert = {
  application: 'apps',
  dataset: 'datasets'
};
function convertEntityTypeToApi(entityType) {
  return apiEntityTypeConvert[entityType.toLowerCase()];
}

/***/ }),

/***/ "./services/fast-action-message-helper.js":
/*!************************************************!*\
  !*** ./services/fast-action-message-helper.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FastActionToMessage; });
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_0__);
/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

function FastActionToMessage(action, options) {
  switch (action) {
    case 'setPreferences':
      return i18n_react__WEBPACK_IMPORTED_MODULE_0___default.a.translate('features.FastAction.SetPreferences.success', {
        entityType: options.entityType
      });

    case 'truncate':
      return i18n_react__WEBPACK_IMPORTED_MODULE_0___default.a.translate('features.FastAction.truncateSuccess');

    default:
      return '';
  }
}

/***/ }),

/***/ "./services/metadata-parser/index.js":
/*!*******************************************!*\
  !*** ./services/metadata-parser/index.js ***!
  \*******************************************/
/*! exports provided: parseMetadata, getType, getCustomAppPipelineDatasetCounts */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseMetadata", function() { return parseMetadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getType", function() { return getType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCustomAppPipelineDatasetCounts", function() { return getCustomAppPipelineDatasetCounts; });
/* harmony import */ var services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/entity-icon-map */ "./services/entity-icon-map/index.js");
/* harmony import */ var lodash_intersection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash/intersection */ "../../node_modules/lodash/intersection.js");
/* harmony import */ var lodash_intersection__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_intersection__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/metadata-parser/EntityType */ "./services/metadata-parser/EntityType.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var SYSTEM_SCOPE = 'SYSTEM';
function parseMetadata(entityObj) {
  var type = entityObj.entity.type;

  switch (type) {
    case services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].artifact:
      return createArtifactObj(entityObj);

    case services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].application:
      return createApplicationObj(entityObj);

    case services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].dataset:
      return createDatasetObj(entityObj);

    case services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].program:
      return createProgramObj(entityObj);
  }
}
function getType(entity) {
  if (entity.type === 'program') {
    return entity.programType.toLowerCase();
  }

  if (entity.type === 'dataset') {
    return 'dataset';
  } else if (entity.type !== 'application') {
    return entity.type;
  }

  if (entity.metadata.metadata.tags.find(function (tag) {
    return tag.name === services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline && tag.scope === SYSTEM_SCOPE;
  })) {
    return services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline;
  } else if (entity.metadata.metadata.tags.find(function (tag) {
    return tag.name === services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams && tag.scope === SYSTEM_SCOPE;
  })) {
    return services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams;
  } else {
    return entity.type;
  }
}
/**
 * TODO:
 * This function should be refactored. It should just return the entities count, and not care about the entity types.
 *
 * https://issues.cask.co/browse/CDAP-14639
 */

function getCustomAppPipelineDatasetCounts(entities) {
  var apps = entities.results.filter(function (entity) {
    return entityIsApp(entity);
  });
  var pipelineCount = apps.filter(function (entity) {
    return entityIsPipeline(entity);
  }).length;
  var customAppCount = apps.length - pipelineCount;
  var datasetCount = entities.results.length - apps.length;
  return {
    pipelineCount: pipelineCount,
    customAppCount: customAppCount,
    datasetCount: datasetCount
  };
}

function entityIsApp(entityObj) {
  return Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(entityObj, 'entity', 'type') === services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].application;
}

function entityIsPipeline(entityObj) {
  return lodash_intersection__WEBPACK_IMPORTED_MODULE_1___default()(services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlPipelineTypes, Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(entityObj, 'metadata', 'tags').map(function (tag) {
    return tag.name;
  })).length > 0;
}

function createArtifactObj(entityObj) {
  return {
    id: entityObj.entity.details.artifact,
    type: entityObj.entity.type.toLowerCase(),
    version: entityObj.entity.details.version,
    metadata: entityObj,
    icon: services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"]['artifact']
  };
}

function createApplicationObj(entityObj) {
  var version = entityObj.entity.details.version;

  if (version === '-SNAPSHOT') {
    version = '1.0.0-SNAPSHOT';
  }

  var icon = services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"]['application'];

  if (entityObj.metadata.tags.find(function (tag) {
    return tag.name === services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline && tag.scope === SYSTEM_SCOPE;
  })) {
    icon = services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"][services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline];
  } else if (entityObj.metadata.tags.find(function (tag) {
    return tag.name === services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams && tag.scope === SYSTEM_SCOPE;
  })) {
    icon = services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"][services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams];
  }

  return {
    id: entityObj.entity.details.application,
    type: entityObj.entity.type.toLowerCase(),
    metadata: entityObj,
    version: version,
    icon: icon,
    isHydrator: entityIsPipeline(entityObj)
  };
}

function createDatasetObj(entityObj) {
  return {
    id: entityObj.entity.details.dataset,
    type: entityObj.entity.type.toLowerCase(),
    metadata: entityObj,
    icon: services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"]['dataset']
  };
}

function createProgramObj(entityObj) {
  return {
    id: entityObj.entity.details.program,
    applicationId: entityObj.entity.details.application,
    type: entityObj.entity.type.toLowerCase(),
    programType: entityObj.entity.details.type,
    metadata: entityObj,
    icon: services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"][entityObj.entity.details.type.toLowerCase()]
  };
}

/***/ })

}]);
//# sourceMappingURL=DatasetDetailedView.0dfb37696fc8e4cc8dbd.js.map