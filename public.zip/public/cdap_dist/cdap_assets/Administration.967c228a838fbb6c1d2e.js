(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Administration"],{

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminConfigTabContent/AdminConfigTabContent.scss":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminConfigTabContent/AdminConfigTabContent.scss ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.admin-config-tab-content .btn.btn-secondary {\n  color: #0099ff;\n  border-color: #999999;\n  font-size: 12px;\n  padding: 5px 20px; }\n\n.admin-config-tab-content .action-buttons {\n  margin-bottom: 10px; }\n  .admin-config-tab-content .action-buttons .btn:first-child {\n    margin-right: 15px; }\n\n.admin-config-tab-content .admin-config-container {\n  border-top: 1px solid #999999;\n  border-bottom: 1px solid #999999;\n  padding: 0 20px; }\n  .admin-config-tab-content .admin-config-container .admin-config-container-toggle {\n    cursor: pointer;\n    height: 70px;\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-align: center;\n            align-items: center; }\n    .admin-config-tab-content .admin-config-container .admin-config-container-toggle .admin-config-container-label {\n      width: 250px;\n      display: -webkit-inline-box;\n      display: inline-flex; }\n      .admin-config-tab-content .admin-config-container .admin-config-container-toggle .admin-config-container-label .icon-svg {\n        font-size: 1.25rem;\n        margin-left: -15px;\n        margin-right: 5px; }\n        .admin-config-tab-content .admin-config-container .admin-config-container-toggle .admin-config-container-label .icon-svg.icon-spinner {\n          margin-left: 0; }\n    .admin-config-tab-content .admin-config-container .admin-config-container-toggle .admin-config-container-description {\n      color: #999999; }\n  .admin-config-tab-content .admin-config-container .admin-config-container-content .btn.btn-secondary {\n    margin-top: -10px; }\n  .admin-config-tab-content .admin-config-container .admin-config-container-content .grid-wrapper {\n    margin-bottom: 20px; }\n    .admin-config-tab-content .admin-config-container .admin-config-container-content .grid-wrapper .grid.grid-container {\n      max-height: none; }\n      .admin-config-tab-content .admin-config-container .admin-config-container-content .grid-wrapper .grid.grid-container .grid-header {\n        background-color: #f5f5f5; }\n  .admin-config-tab-content .admin-config-container:hover, .admin-config-tab-content .admin-config-container.expanded {\n    background-color: #f5f5f5; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminConfigTabContent/NamespacesAccordion/NamespacesAccordion.scss":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminConfigTabContent/NamespacesAccordion/NamespacesAccordion.scss ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.namespaces-container-content .grid.grid-container .grid-body .grid-row.grid-link {\n  color: #333333; }\n\n.namespaces-container-content .grid.grid-container .grid-body .grid-row:hover {\n  background-color: white; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminConfigTabContent/SystemProfilesAccordion/SystemProfilesAccordion.scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminConfigTabContent/SystemProfilesAccordion/SystemProfilesAccordion.scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.system-profiles-container .system-profiles-container-content .profiles-list-view .grid.grid-container .grid-row.sub-header {\n  color: #999999; }\n\n.system-profiles-container .system-profiles-container-content .profiles-list-view .grid.grid-container .grid-body .grid-row:hover {\n  background-color: white; }\n\n.system-profiles-container .system-profiles-container-content .create-import-profile {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center; }\n  .system-profiles-container .system-profiles-container-content .create-import-profile .btn.btn-secondary.create-profile-button {\n    margin-top: 0; }\n  .system-profiles-container .system-profiles-container-content .create-import-profile .import-profile-label {\n    margin-bottom: 0;\n    margin-left: 10px; }\n\n.system-profiles-container .system-profiles-container-content .view-all-label-container:first-child {\n  margin-bottom: 0; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminManagementTabContent/AdminManagementTabContent.scss":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminManagementTabContent/AdminManagementTabContent.scss ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.admin-management-tab-content .services-details {\n  display: -webkit-box;\n  display: flex;\n  width: 100%;\n  background: #f5f5f5;\n  padding: 10px; }\n  .admin-management-tab-content .services-details > div {\n    width: calc(50% - 20px);\n    margin: 10px; }\n  .admin-management-tab-content .services-details .services-table-section.full-width {\n    width: 100%; }\n    .admin-management-tab-content .services-details .services-table-section.full-width .services-table {\n      height: inherit; }\n  .admin-management-tab-content .services-details .services-table-section strong {\n    font-size: 18px;\n    display: block;\n    color: #333333; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminManagementTabContent/PlatformsDetails/Genericdetails.scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminManagementTabContent/PlatformsDetails/Genericdetails.scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.generic-details {\n  display: -webkit-box;\n  display: flex;\n  flex-wrap: wrap;\n  font-size: 15px; }\n  .generic-details > div {\n    width: 50%;\n    margin: 0;\n    margin-bottom: 10px; }\n    .generic-details > div strong {\n      display: inline-block;\n      border-bottom: 2px solid #cccccc;\n      width: 90%;\n      padding-bottom: 5px; }\n    .generic-details > div table {\n      width: 80%; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminManagementTabContent/PlatformsDetails/PlatformDetails.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminManagementTabContent/PlatformsDetails/PlatformDetails.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n* Copyright © 2019 Cask Data, Inc.\n*\n* Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n* use this file except in compliance with the License. You may obtain a copy of\n* the License at\n*\n* http://www.apache.org/licenses/LICENSE-2.0\n*\n* Unless required by applicable law or agreed to in writing, software\n* distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n* License for the specific language governing permissions and limitations under\n* the License.\n*/\n.platform-details {\n  height: 100%;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n  -webkit-box-align: center;\n          align-items: center; }\n  .platform-details.loading {\n    height: 435px;\n    background: #eeeeee;\n    margin-top: 27px; }\n  .platform-details .platform-header {\n    font-size: 18px;\n    width: 100%;\n    color: #333333; }\n  .platform-details .platform-content {\n    background: white;\n    padding: 25px;\n    width: 100%;\n    height: 435px;\n    border: 1px solid lightgray;\n    overflow: auto; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminManagementTabContent/ServicesTable/ServicesTable.scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminManagementTabContent/ServicesTable/ServicesTable.scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n* Copyright © 2017-2018 Cask Data, Inc.\n*\n* Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n* use this file except in compliance with the License. You may obtain a copy of\n* the License at\n*\n* http://www.apache.org/licenses/LICENSE-2.0\n*\n* Unless required by applicable law or agreed to in writing, software\n* distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n* License for the specific language governing permissions and limitations under\n* the License.\n*/\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n* Copyright © 2019 Cask Data, Inc.\n*\n* Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n* use this file except in compliance with the License. You may obtain a copy of\n* the License at\n*\n* http://www.apache.org/licenses/LICENSE-2.0\n*\n* Unless required by applicable law or agreed to in writing, software\n* distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n* License for the specific language governing permissions and limitations under\n* the License.\n*/\n.services-table-section.full-width .services-table .table-container {\n  height: calc(100% - 50px); }\n  .services-table-section.full-width .services-table .table-container .table,\n  .services-table-section.full-width .services-table .table-container .table-sm {\n    margin: 0;\n    background: transparent; }\n    .services-table-section.full-width .services-table .table-container .table thead th:nth-child(1),\n    .services-table-section.full-width .services-table .table-container .table thead tr td:nth-child(1),\n    .services-table-section.full-width .services-table .table-container .table tbody th:nth-child(1),\n    .services-table-section.full-width .services-table .table-container .table tbody tr td:nth-child(1),\n    .services-table-section.full-width .services-table .table-container .table-sm thead th:nth-child(1),\n    .services-table-section.full-width .services-table .table-container .table-sm thead tr td:nth-child(1),\n    .services-table-section.full-width .services-table .table-container .table-sm tbody th:nth-child(1),\n    .services-table-section.full-width .services-table .table-container .table-sm tbody tr td:nth-child(1) {\n      width: 6%; }\n    .services-table-section.full-width .services-table .table-container .table thead th:nth-child(2),\n    .services-table-section.full-width .services-table .table-container .table thead tr td:nth-child(2),\n    .services-table-section.full-width .services-table .table-container .table tbody th:nth-child(2),\n    .services-table-section.full-width .services-table .table-container .table tbody tr td:nth-child(2),\n    .services-table-section.full-width .services-table .table-container .table-sm thead th:nth-child(2),\n    .services-table-section.full-width .services-table .table-container .table-sm thead tr td:nth-child(2),\n    .services-table-section.full-width .services-table .table-container .table-sm tbody th:nth-child(2),\n    .services-table-section.full-width .services-table .table-container .table-sm tbody tr td:nth-child(2) {\n      width: 34%; }\n    .services-table-section.full-width .services-table .table-container .table thead th:nth-child(3),\n    .services-table-section.full-width .services-table .table-container .table thead tr td:nth-child(3),\n    .services-table-section.full-width .services-table .table-container .table tbody th:nth-child(3),\n    .services-table-section.full-width .services-table .table-container .table tbody tr td:nth-child(3),\n    .services-table-section.full-width .services-table .table-container .table-sm thead th:nth-child(3),\n    .services-table-section.full-width .services-table .table-container .table-sm thead tr td:nth-child(3),\n    .services-table-section.full-width .services-table .table-container .table-sm tbody th:nth-child(3),\n    .services-table-section.full-width .services-table .table-container .table-sm tbody tr td:nth-child(3) {\n      width: 20%; }\n    .services-table-section.full-width .services-table .table-container .table thead th:nth-child(4),\n    .services-table-section.full-width .services-table .table-container .table thead tr td:nth-child(4),\n    .services-table-section.full-width .services-table .table-container .table tbody th:nth-child(4),\n    .services-table-section.full-width .services-table .table-container .table tbody tr td:nth-child(4),\n    .services-table-section.full-width .services-table .table-container .table-sm thead th:nth-child(4),\n    .services-table-section.full-width .services-table .table-container .table-sm thead tr td:nth-child(4),\n    .services-table-section.full-width .services-table .table-container .table-sm tbody th:nth-child(4),\n    .services-table-section.full-width .services-table .table-container .table-sm tbody tr td:nth-child(4) {\n      width: 20%; }\n    .services-table-section.full-width .services-table .table-container .table thead th:nth-child(5),\n    .services-table-section.full-width .services-table .table-container .table thead tr td:nth-child(5),\n    .services-table-section.full-width .services-table .table-container .table tbody th:nth-child(5),\n    .services-table-section.full-width .services-table .table-container .table tbody tr td:nth-child(5),\n    .services-table-section.full-width .services-table .table-container .table-sm thead th:nth-child(5),\n    .services-table-section.full-width .services-table .table-container .table-sm thead tr td:nth-child(5),\n    .services-table-section.full-width .services-table .table-container .table-sm tbody th:nth-child(5),\n    .services-table-section.full-width .services-table .table-container .table-sm tbody tr td:nth-child(5) {\n      width: 20%; }\n    .services-table-section.full-width .services-table .table-container .table tbody tr td:not(:nth-child(1)),\n    .services-table-section.full-width .services-table .table-container .table-sm tbody tr td:not(:nth-child(1)) {\n      padding-left: 0; }\n    .services-table-section.full-width .services-table .table-container .table tbody tr td a:hover,\n    .services-table-section.full-width .services-table .table-container .table-sm tbody tr td a:hover {\n      border-bottom: 1px solid; }\n    .services-table-section.full-width .services-table .table-container .table thead,\n    .services-table-section.full-width .services-table .table-container .table-sm thead {\n      background: transparent; }\n      .services-table-section.full-width .services-table .table-container .table thead tr th:not(:first-child),\n      .services-table-section.full-width .services-table .table-container .table-sm thead tr th:not(:first-child) {\n        padding-left: 0; }\n  .services-table-section.full-width .services-table .table-container .table-scroll {\n    overflow-y: auto;\n    height: calc(100% - 55px); }\n\n.services-table {\n  background: white;\n  padding: 25px;\n  font-weight: 500;\n  height: 435px;\n  width: 100%;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n  border: 1px solid lightgray; }\n  .services-table .table-sm td,\n  .services-table .table-sm th {\n    border-bottom: 2px solid lightgray;\n    padding-bottom: 0.2rem;\n    padding-top: 0.2rem; }\n  .services-table .table-sm tbody tr:last-child td {\n    border-bottom: 0; }\n  .services-table .table-container {\n    height: calc(100% - 50px); }\n    .services-table .table-container .table,\n    .services-table .table-container .table-sm {\n      margin: 0;\n      background: transparent; }\n      .services-table .table-container .table thead th:nth-child(1),\n      .services-table .table-container .table thead tr td:nth-child(1),\n      .services-table .table-container .table tbody th:nth-child(1),\n      .services-table .table-container .table tbody tr td:nth-child(1),\n      .services-table .table-container .table-sm thead th:nth-child(1),\n      .services-table .table-container .table-sm thead tr td:nth-child(1),\n      .services-table .table-container .table-sm tbody th:nth-child(1),\n      .services-table .table-container .table-sm tbody tr td:nth-child(1) {\n        width: 10%; }\n      .services-table .table-container .table thead th:nth-child(2),\n      .services-table .table-container .table thead tr td:nth-child(2),\n      .services-table .table-container .table tbody th:nth-child(2),\n      .services-table .table-container .table tbody tr td:nth-child(2),\n      .services-table .table-container .table-sm thead th:nth-child(2),\n      .services-table .table-container .table-sm thead tr td:nth-child(2),\n      .services-table .table-container .table-sm tbody th:nth-child(2),\n      .services-table .table-container .table-sm tbody tr td:nth-child(2) {\n        width: 30%; }\n      .services-table .table-container .table thead th:nth-child(3),\n      .services-table .table-container .table thead tr td:nth-child(3),\n      .services-table .table-container .table tbody th:nth-child(3),\n      .services-table .table-container .table tbody tr td:nth-child(3),\n      .services-table .table-container .table-sm thead th:nth-child(3),\n      .services-table .table-container .table-sm thead tr td:nth-child(3),\n      .services-table .table-container .table-sm tbody th:nth-child(3),\n      .services-table .table-container .table-sm tbody tr td:nth-child(3) {\n        width: 20%; }\n      .services-table .table-container .table thead th:nth-child(4),\n      .services-table .table-container .table thead tr td:nth-child(4),\n      .services-table .table-container .table tbody th:nth-child(4),\n      .services-table .table-container .table tbody tr td:nth-child(4),\n      .services-table .table-container .table-sm thead th:nth-child(4),\n      .services-table .table-container .table-sm thead tr td:nth-child(4),\n      .services-table .table-container .table-sm tbody th:nth-child(4),\n      .services-table .table-container .table-sm tbody tr td:nth-child(4) {\n        width: 20%; }\n      .services-table .table-container .table thead th:nth-child(5),\n      .services-table .table-container .table thead tr td:nth-child(5),\n      .services-table .table-container .table tbody th:nth-child(5),\n      .services-table .table-container .table tbody tr td:nth-child(5),\n      .services-table .table-container .table-sm thead th:nth-child(5),\n      .services-table .table-container .table-sm thead tr td:nth-child(5),\n      .services-table .table-container .table-sm tbody th:nth-child(5),\n      .services-table .table-container .table-sm tbody tr td:nth-child(5) {\n        width: 20%; }\n      .services-table .table-container .table tbody tr td:not(:nth-child(1)),\n      .services-table .table-container .table-sm tbody tr td:not(:nth-child(1)) {\n        padding-left: 0; }\n      .services-table .table-container .table tbody tr td a:hover,\n      .services-table .table-container .table-sm tbody tr td a:hover {\n        border-bottom: 1px solid; }\n      .services-table .table-container .table thead,\n      .services-table .table-container .table-sm thead {\n        background: transparent; }\n        .services-table .table-container .table thead tr th:not(:first-child),\n        .services-table .table-container .table-sm thead tr th:not(:first-child) {\n          padding-left: 0; }\n    .services-table .table-container .table-scroll {\n      overflow-y: auto;\n      height: calc(100% - 55px); }\n  .services-table .table-container {\n    height: 100%;\n    width: 100%; }\n    .services-table .table-container > .table.table-sm tr th {\n      border-top: 0; }\n      .services-table .table-container > .table.table-sm tr th span {\n        font-size: 14px; }\n    .services-table .table-container .table-scroll {\n      height: calc(100% - white);\n      width: 100%; }\n      .services-table .table-container .table-scroll .table thead tr th:not(:first-child) {\n        padding-left: 0; }\n    .services-table .table-container .table,\n    .services-table .table-container .table-sm {\n      width: 100%; }\n      .services-table .table-container .table thead tr th:nth-child(2),\n      .services-table .table-container .table thead tr td:nth-child(2),\n      .services-table .table-container .table tbody tr th:nth-child(2),\n      .services-table .table-container .table tbody tr td:nth-child(2),\n      .services-table .table-container .table-sm thead tr th:nth-child(2),\n      .services-table .table-container .table-sm thead tr td:nth-child(2),\n      .services-table .table-container .table-sm tbody tr th:nth-child(2),\n      .services-table .table-container .table-sm tbody tr td:nth-child(2) {\n        padding-left: 10px; }\n      .services-table .table-container .table tbody tr,\n      .services-table .table-container .table-sm tbody tr {\n        cursor: pointer; }\n        .services-table .table-container .table tbody tr:hover,\n        .services-table .table-container .table-sm tbody tr:hover {\n          background: #f5f5f5; }\n        .services-table .table-container .table tbody tr td a,\n        .services-table .table-container .table tbody tr td a:hover,\n        .services-table .table-container .table-sm tbody tr td a,\n        .services-table .table-container .table-sm tbody tr td a:hover {\n          text-decoration: none;\n          border-bottom: 0; }\n    .services-table .table-container tr td .status-circle {\n      font-size: 15px; }\n    .services-table .table-container tr td .request-instances input {\n      width: 50%;\n      padding-top: 0;\n      padding-bottom: 0;\n      line-height: 1;\n      display: inline-block; }\n    .services-table .table-container tr td .request-instances .requested-instances-holder {\n      padding: 1px 5px 3px; }\n      .services-table .table-container tr td .request-instances .requested-instances-holder:hover {\n        border: 1px solid #cccccc;\n        background: white; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminTabSwitch/AdminTabSwitch.scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminTabSwitch/AdminTabSwitch.scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.administration .tab-title-and-version {\n  padding: 0 10px;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n          align-items: center; }\n  .administration .tab-title-and-version .tab-title h5 {\n    display: inline;\n    font-weight: initial; }\n    .administration .tab-title-and-version .tab-title h5 a {\n      color: #333333; }\n    .administration .tab-title-and-version .tab-title h5:hover {\n      font-weight: bold; }\n    .administration .tab-title-and-version .tab-title h5.active {\n      pointer-events: none;\n      font-weight: bold; }\n      .administration .tab-title-and-version .tab-title h5.active a {\n        text-decoration: underline; }\n  .administration .tab-title-and-version .tab-title .divider {\n    font-size: 1.25rem;\n    padding: 0 5px; }\n  .administration .tab-title-and-version .uptime-version-container {\n    color: #999999; }\n    .administration .tab-title-and-version .uptime-version-container > span {\n      margin: 0 10px; }\n    .administration .tab-title-and-version .uptime-version-container .cdap-version {\n      font-weight: 500; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/Administration.scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Administration/Administration.scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.administration {\n  height: 100%;\n  padding: 20px 20px 0 20px;\n  overflow: auto; }\n  .administration > div {\n    padding: 10px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Cloud/Profiles/ActionsPopover/ActionsPopover.scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Cloud/Profiles/ActionsPopover/ActionsPopover.scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.profile-actions-popover {\n  cursor: pointer; }\n  .profile-actions-popover .icon-cog-empty {\n    fill: white;\n    font-size: 23px;\n    stroke: #bbbbbb; }\n  .profile-actions-popover .popper {\n    width: 90px;\n    min-width: 90px;\n    z-index: 1; }\n    .profile-actions-popover .popper ul hr {\n      height: 1px;\n      margin: 5px 8px;\n      border-top: 0;\n      background-color: #999999; }\n    .profile-actions-popover .popper ul li.delete-action {\n      color: #d40001; }\n    .profile-actions-popover .popper ul li.disabled {\n      cursor: not-allowed;\n      color: #333333;\n      opacity: 0.5; }\n    .profile-actions-popover .popper .popper__arrow {\n      border-right-color: #cccccc;\n      border-bottom-color: #cccccc; }\n  .profile-actions-popover:hover .icon-cog-empty {\n    stroke: #0099ff; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Cloud/Profiles/ListView/ListView.scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Cloud/Profiles/ListView/ListView.scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2015 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.profiles-list-view .grid-wrapper {\n  max-height: none; }\n\n.profiles-list-view .grid.grid-container {\n  max-height: none; }\n  .profiles-list-view .grid.grid-container .grid-row {\n    grid-template-columns: 70px 1.5fr 1.5fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 30px; }\n    .profiles-list-view .grid.grid-container .grid-row .sortable-header {\n      cursor: pointer; }\n      .profiles-list-view .grid.grid-container .grid-row .sortable-header.active {\n        text-decoration: underline; }\n      .profiles-list-view .grid.grid-container .grid-row .sortable-header .icon-svg {\n        font-size: 1.3rem; }\n    .profiles-list-view .grid.grid-container .grid-row.sub-header {\n      border: 0;\n      padding: 0;\n      color: #cccccc;\n      grid-template-columns: 70px 1.5fr 1.5fr 1fr 1fr 2fr 0fr 1fr 1fr 1fr 30px; }\n      .profiles-list-view .grid.grid-container .grid-row.sub-header .sub-title {\n        border-bottom: 2px solid gray; }\n      .profiles-list-view .grid.grid-container .grid-row.sub-header .sub-title + div {\n        margin-left: -25px; }\n      .profiles-list-view .grid.grid-container .grid-row.sub-header > div {\n        padding: 0 5px 0 0;\n        margin-right: 20px;\n        margin-left: 10px;\n        border: 0; }\n  .profiles-list-view .grid.grid-container .grid-header .grid-row {\n    padding-top: 0; }\n  .profiles-list-view .grid.grid-container .grid-body .grid-row {\n    padding: 0;\n    color: #333333; }\n    .profiles-list-view .grid.grid-container .grid-body .grid-row.native-profile {\n      cursor: not-allowed; }\n      .profiles-list-view .grid.grid-container .grid-body .grid-row.native-profile .default-star {\n        cursor: pointer; }\n      .profiles-list-view .grid.grid-container .grid-body .grid-row.native-profile .profile-actions-popover {\n        cursor: not-allowed; }\n        .profiles-list-view .grid.grid-container .grid-body .grid-row.native-profile .profile-actions-popover:hover .icon-cog-empty {\n          stroke: #bbbbbb; }\n    .profiles-list-view .grid.grid-container .grid-body .grid-row:last-child:not(.highlighted) {\n      border-bottom: 0; }\n    .profiles-list-view .grid.grid-container .grid-body .grid-row:hover:not(.native-profile) .profile-actions-popover .icon-cog-empty {\n      stroke: #0099ff; }\n    .profiles-list-view .grid.grid-container .grid-body .grid-row:hover .default-star .not-default-profile {\n      display: inline-block; }\n    .profiles-list-view .grid.grid-container .grid-body .grid-row .default-star .default-profile {\n      color: var(--brand-primary-color); }\n    .profiles-list-view .grid.grid-container .grid-body .grid-row .default-star .not-default-profile {\n      display: none; }\n    .profiles-list-view .grid.grid-container .grid-body .grid-row .profile-label {\n      white-space: nowrap; }\n    .profiles-list-view .grid.grid-container .grid-body .grid-row .enabled-label {\n      color: #3cc801; }\n    .profiles-list-view .grid.grid-container .grid-body .grid-row .disabled-label {\n      color: #d40001; }\n\n.profiles-list-view a {\n  color: #0099ff; }\n\n.import-profile-label {\n  color: #0099ff;\n  cursor: pointer;\n  font-size: 13px; }\n  .import-profile-label #import-profile {\n    display: none; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SortableStickyGrid/SortableStickyGrid.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SortableStickyGrid/SortableStickyGrid.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.sortable-sticky-grid .grid.grid-container .grid-header .sortable-header {\n  cursor: pointer; }\n  .sortable-sticky-grid .grid.grid-container .grid-header .sortable-header.active {\n    text-decoration: underline; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SortableTable/SortableTable.scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SortableTable/SortableTable.scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.table th span {\n  cursor: pointer; }\n  .table th span .text-underline {\n    text-decoration: underline; }\n  .table th span i {\n    margin-left: 3px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/ViewAllLabel/ViewAllLabel.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/ViewAllLabel/ViewAllLabel.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.view-all-label-container {\n  margin: 5px 0; }\n  .view-all-label-container .view-all-label {\n    color: #0099ff;\n    cursor: pointer; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/lodash/_arrayReduce.js":
/*!*****************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/_arrayReduce.js ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * A specialized version of `_.reduce` for arrays without support for
 * iteratee shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @param {*} [accumulator] The initial value.
 * @param {boolean} [initAccum] Specify using the first element of `array` as
 *  the initial value.
 * @returns {*} Returns the accumulated value.
 */
function arrayReduce(array, iteratee, accumulator, initAccum) {
  var index = -1,
      length = array == null ? 0 : array.length;

  if (initAccum && length) {
    accumulator = array[++index];
  }
  while (++index < length) {
    accumulator = iteratee(accumulator, array[index], index, array);
  }
  return accumulator;
}

module.exports = arrayReduce;


/***/ }),

/***/ "../../node_modules/lodash/_asciiWords.js":
/*!****************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/_asciiWords.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used to match words composed of alphanumeric characters. */
var reAsciiWord = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;

/**
 * Splits an ASCII `string` into an array of its words.
 *
 * @private
 * @param {string} The string to inspect.
 * @returns {Array} Returns the words of `string`.
 */
function asciiWords(string) {
  return string.match(reAsciiWord) || [];
}

module.exports = asciiWords;


/***/ }),

/***/ "../../node_modules/lodash/_createCompounder.js":
/*!**********************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/_createCompounder.js ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayReduce = __webpack_require__(/*! ./_arrayReduce */ "../../node_modules/lodash/_arrayReduce.js"),
    deburr = __webpack_require__(/*! ./deburr */ "../../node_modules/lodash/deburr.js"),
    words = __webpack_require__(/*! ./words */ "../../node_modules/lodash/words.js");

/** Used to compose unicode capture groups. */
var rsApos = "['\u2019]";

/** Used to match apostrophes. */
var reApos = RegExp(rsApos, 'g');

/**
 * Creates a function like `_.camelCase`.
 *
 * @private
 * @param {Function} callback The function to combine each word.
 * @returns {Function} Returns the new compounder function.
 */
function createCompounder(callback) {
  return function(string) {
    return arrayReduce(words(deburr(string).replace(reApos, '')), callback, '');
  };
}

module.exports = createCompounder;


/***/ }),

/***/ "../../node_modules/lodash/_hasUnicodeWord.js":
/*!********************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/_hasUnicodeWord.js ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used to detect strings that need a more robust regexp to match words. */
var reHasUnicodeWord = /[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;

/**
 * Checks if `string` contains a word composed of Unicode symbols.
 *
 * @private
 * @param {string} string The string to inspect.
 * @returns {boolean} Returns `true` if a word is found, else `false`.
 */
function hasUnicodeWord(string) {
  return reHasUnicodeWord.test(string);
}

module.exports = hasUnicodeWord;


/***/ }),

/***/ "../../node_modules/lodash/_unicodeWords.js":
/*!******************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/_unicodeWords.js ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used to compose unicode character classes. */
var rsAstralRange = '\\ud800-\\udfff',
    rsComboMarksRange = '\\u0300-\\u036f',
    reComboHalfMarksRange = '\\ufe20-\\ufe2f',
    rsComboSymbolsRange = '\\u20d0-\\u20ff',
    rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange,
    rsDingbatRange = '\\u2700-\\u27bf',
    rsLowerRange = 'a-z\\xdf-\\xf6\\xf8-\\xff',
    rsMathOpRange = '\\xac\\xb1\\xd7\\xf7',
    rsNonCharRange = '\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf',
    rsPunctuationRange = '\\u2000-\\u206f',
    rsSpaceRange = ' \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000',
    rsUpperRange = 'A-Z\\xc0-\\xd6\\xd8-\\xde',
    rsVarRange = '\\ufe0e\\ufe0f',
    rsBreakRange = rsMathOpRange + rsNonCharRange + rsPunctuationRange + rsSpaceRange;

/** Used to compose unicode capture groups. */
var rsApos = "['\u2019]",
    rsBreak = '[' + rsBreakRange + ']',
    rsCombo = '[' + rsComboRange + ']',
    rsDigits = '\\d+',
    rsDingbat = '[' + rsDingbatRange + ']',
    rsLower = '[' + rsLowerRange + ']',
    rsMisc = '[^' + rsAstralRange + rsBreakRange + rsDigits + rsDingbatRange + rsLowerRange + rsUpperRange + ']',
    rsFitz = '\\ud83c[\\udffb-\\udfff]',
    rsModifier = '(?:' + rsCombo + '|' + rsFitz + ')',
    rsNonAstral = '[^' + rsAstralRange + ']',
    rsRegional = '(?:\\ud83c[\\udde6-\\uddff]){2}',
    rsSurrPair = '[\\ud800-\\udbff][\\udc00-\\udfff]',
    rsUpper = '[' + rsUpperRange + ']',
    rsZWJ = '\\u200d';

/** Used to compose unicode regexes. */
var rsMiscLower = '(?:' + rsLower + '|' + rsMisc + ')',
    rsMiscUpper = '(?:' + rsUpper + '|' + rsMisc + ')',
    rsOptContrLower = '(?:' + rsApos + '(?:d|ll|m|re|s|t|ve))?',
    rsOptContrUpper = '(?:' + rsApos + '(?:D|LL|M|RE|S|T|VE))?',
    reOptMod = rsModifier + '?',
    rsOptVar = '[' + rsVarRange + ']?',
    rsOptJoin = '(?:' + rsZWJ + '(?:' + [rsNonAstral, rsRegional, rsSurrPair].join('|') + ')' + rsOptVar + reOptMod + ')*',
    rsOrdLower = '\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])',
    rsOrdUpper = '\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])',
    rsSeq = rsOptVar + reOptMod + rsOptJoin,
    rsEmoji = '(?:' + [rsDingbat, rsRegional, rsSurrPair].join('|') + ')' + rsSeq;

/** Used to match complex or compound words. */
var reUnicodeWord = RegExp([
  rsUpper + '?' + rsLower + '+' + rsOptContrLower + '(?=' + [rsBreak, rsUpper, '$'].join('|') + ')',
  rsMiscUpper + '+' + rsOptContrUpper + '(?=' + [rsBreak, rsUpper + rsMiscLower, '$'].join('|') + ')',
  rsUpper + '?' + rsMiscLower + '+' + rsOptContrLower,
  rsUpper + '+' + rsOptContrUpper,
  rsOrdUpper,
  rsOrdLower,
  rsDigits,
  rsEmoji
].join('|'), 'g');

/**
 * Splits a Unicode `string` into an array of its words.
 *
 * @private
 * @param {string} The string to inspect.
 * @returns {Array} Returns the words of `string`.
 */
function unicodeWords(string) {
  return string.match(reUnicodeWord) || [];
}

module.exports = unicodeWords;


/***/ }),

/***/ "../../node_modules/lodash/deburr.js":
/*!***********************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/deburr.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * This method returns the first argument it receives.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Util
 * @param {*} value Any value.
 * @returns {*} Returns `value`.
 * @example
 *
 * var object = { 'a': 1 };
 *
 * console.log(_.identity(object) === object);
 * // => true
 */
function identity(value) {
  return value;
}

module.exports = identity;


/***/ }),

/***/ "../../node_modules/lodash/startCase.js":
/*!**************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/startCase.js ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var createCompounder = __webpack_require__(/*! ./_createCompounder */ "../../node_modules/lodash/_createCompounder.js"),
    upperFirst = __webpack_require__(/*! ./upperFirst */ "../../node_modules/lodash/upperFirst.js");

/**
 * Converts `string` to
 * [start case](https://en.wikipedia.org/wiki/Letter_case#Stylistic_or_specialised_usage).
 *
 * @static
 * @memberOf _
 * @since 3.1.0
 * @category String
 * @param {string} [string=''] The string to convert.
 * @returns {string} Returns the start cased string.
 * @example
 *
 * _.startCase('--foo-bar--');
 * // => 'Foo Bar'
 *
 * _.startCase('fooBar');
 * // => 'Foo Bar'
 *
 * _.startCase('__FOO_BAR__');
 * // => 'FOO BAR'
 */
var startCase = createCompounder(function(result, word, index) {
  return result + (index ? ' ' : '') + upperFirst(word);
});

module.exports = startCase;


/***/ }),

/***/ "../../node_modules/lodash/words.js":
/*!**********************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/words.js ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var asciiWords = __webpack_require__(/*! ./_asciiWords */ "../../node_modules/lodash/_asciiWords.js"),
    hasUnicodeWord = __webpack_require__(/*! ./_hasUnicodeWord */ "../../node_modules/lodash/_hasUnicodeWord.js"),
    toString = __webpack_require__(/*! ./toString */ "../../node_modules/lodash/toString.js"),
    unicodeWords = __webpack_require__(/*! ./_unicodeWords */ "../../node_modules/lodash/_unicodeWords.js");

/**
 * Splits `string` into an array of its words.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to inspect.
 * @param {RegExp|string} [pattern] The pattern to match words.
 * @param- {Object} [guard] Enables use as an iteratee for methods like `_.map`.
 * @returns {Array} Returns the words of `string`.
 * @example
 *
 * _.words('fred, barney, & pebbles');
 * // => ['fred', 'barney', 'pebbles']
 *
 * _.words('fred, barney, & pebbles', /[^, ]+/g);
 * // => ['fred', 'barney', '&', 'pebbles']
 */
function words(string, pattern, guard) {
  string = toString(string);
  pattern = guard ? undefined : pattern;

  if (pattern === undefined) {
    return hasUnicodeWord(string) ? unicodeWords(string) : asciiWords(string);
  }
  return string.match(pattern) || [];
}

module.exports = words;


/***/ }),

/***/ "./api/app.js":
/*!********************!*\
  !*** ./api/app.js ***!
  \********************/
/*! exports provided: MyAppApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyAppApi", function() { return MyAppApi; });
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__["default"].getInstance();
var basepath = '/namespaces/:namespace/apps';
var appPath = "".concat(basepath, "/:appId");
var MyAppApi = {
  list: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  deployApp: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'PUT', 'REQUEST', appPath),
  get: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', appPath),
  getVersions: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(appPath, "/versions")),
  getDeployedApp: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  batchStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'POLL', '/namespaces/:namespace/status'),
  batchAppDetail: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', '/namespaces/:namespace/appdetail'),
  "delete": Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', appPath)
};

/***/ }),

/***/ "./api/cloud.js":
/*!**********************!*\
  !*** ./api/cloud.js ***!
  \**********************/
/*! exports provided: MyCloudApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyCloudApi", function() { return MyCloudApi; });
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_0__["default"].getInstance();
var basepath = '/namespaces/:namespace';
var profilesPath = "".concat(basepath, "/profiles");
var systemProfilesPath = "/profiles";
var provisionersPath = '/provisioners';
var MyCloudApi = {
  list: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', profilesPath),
  getSystemProfiles: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(systemProfilesPath)),
  create: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'PUT', 'REQUEST', "".concat(profilesPath, "/:profile")),
  createSystemProfile: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'PUT', 'REQUEST', "".concat(systemProfilesPath, "/:profile")),
  get: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(profilesPath, "/:profile")),
  getSystemProfile: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(systemProfilesPath, "/:profile")),
  deleteSystemProfile: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(systemProfilesPath, "/:profile")),
  "delete": Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(profilesPath, "/:profile")),
  toggleSystemProfileStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(systemProfilesPath, "/:profile/:action")),
  toggleProfileStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(profilesPath, "/:profile/:action")),
  getProvisioners: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(provisionersPath)),
  getProvisionerDetailSpec: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(provisionersPath, "/:provisioner"))
};

/***/ }),

/***/ "./components/Administration/AdminConfigTabContent/AdminConfigTabContent.scss":
/*!************************************************************************************!*\
  !*** ./components/Administration/AdminConfigTabContent/AdminConfigTabContent.scss ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./AdminConfigTabContent.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminConfigTabContent/AdminConfigTabContent.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Administration/AdminConfigTabContent/NamespacesAccordion/NamespacesAccordion.scss":
/*!******************************************************************************************************!*\
  !*** ./components/Administration/AdminConfigTabContent/NamespacesAccordion/NamespacesAccordion.scss ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./NamespacesAccordion.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminConfigTabContent/NamespacesAccordion/NamespacesAccordion.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Administration/AdminConfigTabContent/NamespacesAccordion/index.js":
/*!**************************************************************************************!*\
  !*** ./components/Administration/AdminConfigTabContent/NamespacesAccordion/index.js ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NamespacesAccordion; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_search__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/search */ "./api/search.js");
/* harmony import */ var api_namespace__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/namespace */ "./api/namespace.js");
/* harmony import */ var services_metadata_parser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/metadata-parser */ "./services/metadata-parser/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_LoadingSVG__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/LoadingSVG */ "./components/LoadingSVG/index.js");
/* harmony import */ var components_CaskWizards_AddNamespace__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/CaskWizards/AddNamespace */ "./components/CaskWizards/AddNamespace/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var services_global_events__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! services/global-events */ "./services/global-events.js");
/* harmony import */ var event_emitter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! event-emitter */ "../../node_modules/event-emitter/index.js");
/* harmony import */ var event_emitter__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(event_emitter__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var components_ViewAllLabel__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/ViewAllLabel */ "./components/ViewAllLabel/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! lodash/isEqual */ "../../node_modules/lodash/isEqual.js");
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(lodash_isEqual__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var components_SortableStickyGrid__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! components/SortableStickyGrid */ "./components/SortableStickyGrid/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




















__webpack_require__(/*! ./NamespacesAccordion.scss */ "./components/Administration/AdminConfigTabContent/NamespacesAccordion/NamespacesAccordion.scss");

var PREFIX = 'features.Administration.Accordions.Namespace';
var GRID_HEADERS = [{
  property: 'name',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate('commons.nameLabel')
}, {
  property: 'customAppCount',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate("".concat(PREFIX, ".customApps"))
}, {
  property: 'pipelineCount',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate('commons.pipelines')
}, {
  property: 'datasetCount',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate('commons.entity.dataset.plural')
}];

if (services_ThemeHelper__WEBPACK_IMPORTED_MODULE_17__["Theme"].showApplicationUpload === false) {
  GRID_HEADERS.splice(1, 1);
}

var NUM_NS_TO_SHOW = 5;

var NamespacesAccordion =
/*#__PURE__*/
function (_Component) {
  _inherits(NamespacesAccordion, _Component);

  function NamespacesAccordion() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, NamespacesAccordion);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(NamespacesAccordion)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      loading: _this.props.loading,
      namespaceWizardOpen: false,
      namespacesInfo: [],
      viewAll: false
    });

    _defineProperty(_assertThisInitialized(_this), "eventEmitter", event_emitter__WEBPACK_IMPORTED_MODULE_10___default()(event_emitter__WEBPACK_IMPORTED_MODULE_10___default.a));

    _defineProperty(_assertThisInitialized(_this), "fetchNamespacesAndGetData", function () {
      api_namespace__WEBPACK_IMPORTED_MODULE_3__["MyNamespaceApi"].list().subscribe(function (res) {
        return _this.getNamespaceData(res);
      }, function (err) {
        return console.log(err);
      });
    });

    _defineProperty(_assertThisInitialized(_this), "toggleNamespaceWizard", function () {
      _this.setState({
        namespaceWizardOpen: !_this.state.namespaceWizardOpen
      });
    });

    _defineProperty(_assertThisInitialized(_this), "toggleViewAll", function () {
      _this.setState({
        viewAll: !_this.state.viewAll
      });
    });

    _defineProperty(_assertThisInitialized(_this), "renderGridBody", function (namespaces) {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-body"
      }, namespaces.map(function (namespace) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_15__["Link"], {
          to: "/ns/".concat(namespace.name, "/details"),
          className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('grid-row grid-link', {
            highlighted: namespace.highlighted
          }),
          key: uuid_v4__WEBPACK_IMPORTED_MODULE_16___default()()
        }, GRID_HEADERS.map(function (header) {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
            key: uuid_v4__WEBPACK_IMPORTED_MODULE_16___default()()
          }, namespace[header.property]);
        }));
      }));
    });

    return _this;
  }

  _createClass(NamespacesAccordion, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.eventEmitter.on(services_global_events__WEBPACK_IMPORTED_MODULE_9__["default"].NAMESPACECREATED, this.fetchNamespacesAndGetData);
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (!lodash_isEqual__WEBPACK_IMPORTED_MODULE_13___default()(this.props.namespaces, nextProps.namespaces)) {
        this.getNamespaceData(nextProps.namespaces);
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.eventEmitter.off(services_global_events__WEBPACK_IMPORTED_MODULE_9__["default"].NAMESPACECREATED, this.fetchNamespacesAndGetData);
    }
  }, {
    key: "getNamespaceData",
    value: function getNamespaceData(namespaces) {
      var _this2 = this;

      var searchParams = {
        target: ['dataset', 'application'],
        query: '*',
        sort: 'entity-name asc',
        responseFormat: 'v6'
      };
      var currentNamespaces = this.state.namespacesInfo.map(function (namespace) {
        return namespace.name;
      });
      var namespacesInfo = [];
      var hasNewNamespaces = false;
      namespaces.forEach(function (namespace) {
        searchParams.namespace = namespace.name;
        api_search__WEBPACK_IMPORTED_MODULE_2__["MySearchApi"].search(searchParams).subscribe(function (entities) {
          var _getCustomAppPipeline = Object(services_metadata_parser__WEBPACK_IMPORTED_MODULE_4__["getCustomAppPipelineDatasetCounts"])(entities),
              pipelineCount = _getCustomAppPipeline.pipelineCount,
              customAppCount = _getCustomAppPipeline.customAppCount,
              datasetCount = _getCustomAppPipeline.datasetCount;

          var namespaceIsHighlighted = false;

          if (currentNamespaces.length && currentNamespaces.indexOf(namespace.name) === -1) {
            namespaceIsHighlighted = true;
            hasNewNamespaces = true;
          }

          namespacesInfo.push({
            name: namespace.name,
            pipelineCount: pipelineCount,
            customAppCount: customAppCount,
            datasetCount: datasetCount,
            highlighted: namespaceIsHighlighted
          });

          _this2.setState({
            namespacesInfo: namespacesInfo,
            loading: false,
            viewAll: hasNewNamespaces || _this2.state.viewAll
          }, function () {
            if (hasNewNamespaces) {
              setTimeout(function () {
                namespacesInfo = namespacesInfo.map(function (namespace) {
                  return _objectSpread({}, namespace, {
                    highlighted: false
                  });
                });

                _this2.setState({
                  namespacesInfo: namespacesInfo
                });
              }, 4000);
            }
          });
        }, function (err) {
          return console.log(err);
        });
      });
    }
  }, {
    key: "renderLabel",
    value: function renderLabel() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "admin-config-container-toggle",
        onClick: this.props.onExpand
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "admin-config-container-label"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_5__["default"], {
        name: this.props.expanded ? 'icon-caret-down' : 'icon-caret-right'
      }), this.state.loading ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", null, i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate("".concat(PREFIX, ".label")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_5__["default"], {
        name: "icon-spinner",
        className: "fa-spin"
      })) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", null, i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate("".concat(PREFIX, ".labelWithCount"), {
        count: this.state.namespacesInfo.length
      }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "admin-config-container-description"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate("".concat(PREFIX, ".description"))));
    }
  }, {
    key: "renderGrid",
    value: function renderGrid() {
      if (this.state.loading) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "text-center"
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_LoadingSVG__WEBPACK_IMPORTED_MODULE_6__["default"], null));
      }

      var namespacesInfo = _toConsumableArray(this.state.namespacesInfo);

      if (!this.state.viewAll && namespacesInfo.length > NUM_NS_TO_SHOW) {
        namespacesInfo = namespacesInfo.slice(0, NUM_NS_TO_SHOW);
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_SortableStickyGrid__WEBPACK_IMPORTED_MODULE_14__["default"], {
        entities: namespacesInfo,
        renderGridBody: this.renderGridBody,
        gridHeaders: GRID_HEADERS
      });
    }
  }, {
    key: "renderContent",
    value: function renderContent() {
      if (!this.props.expanded) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "admin-config-container-content namespaces-container-content"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_18__["default"], {
        condition: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_17__["Theme"].showAddNamespace
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("button", {
        className: "btn btn-secondary",
        onClick: this.toggleNamespaceWizard
      }, i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate("".concat(PREFIX, ".create")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_ViewAllLabel__WEBPACK_IMPORTED_MODULE_11__["default"], {
        arrayToLimit: this.state.namespacesInfo,
        limit: NUM_NS_TO_SHOW,
        viewAllState: this.state.viewAll,
        toggleViewAll: this.toggleViewAll
      }), this.renderGrid(), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_ViewAllLabel__WEBPACK_IMPORTED_MODULE_11__["default"], {
        arrayToLimit: this.state.namespacesInfo,
        limit: NUM_NS_TO_SHOW,
        viewAllState: this.state.viewAll,
        toggleViewAll: this.toggleViewAll
      }), this.state.namespaceWizardOpen ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_CaskWizards_AddNamespace__WEBPACK_IMPORTED_MODULE_7__["default"], {
        isOpen: this.state.namespaceWizardOpen,
        onClose: this.toggleNamespaceWizard
      }) : null);
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('admin-config-container namespaces-container', {
          expanded: this.props.expanded
        })
      }, this.renderLabel(), this.renderContent());
    }
  }]);

  return NamespacesAccordion;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(NamespacesAccordion, "propTypes", {
  namespaces: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array,
  loading: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  expanded: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  onExpand: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
});



/***/ }),

/***/ "./components/Administration/AdminConfigTabContent/ReloadSystemArtifacts.js":
/*!**********************************************************************************!*\
  !*** ./components/Administration/AdminConfigTabContent/ReloadSystemArtifacts.js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ReloadSystemArtifacts; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/ConfirmationModal */ "./components/ConfirmationModal/index.js");
/* harmony import */ var api_artifact__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/artifact */ "./api/artifact.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var PREFIX = 'features.Administration.Configure.buttons.ReloadSystemArtifacts';

var ReloadSystemArtifacts =
/*#__PURE__*/
function (_Component) {
  _inherits(ReloadSystemArtifacts, _Component);

  function ReloadSystemArtifacts() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ReloadSystemArtifacts);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ReloadSystemArtifacts)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      openConfirmation: false,
      loading: false,
      errorMessage: null,
      extendedMessage: null
    });

    _defineProperty(_assertThisInitialized(_this), "onClick", function () {
      _this.setState({
        openConfirmation: !_this.state.openConfirmation,
        loading: false,
        errorMessage: null,
        extendedMessage: null
      });
    });

    _defineProperty(_assertThisInitialized(_this), "reload", function () {
      _this.setState({
        loading: true
      });

      api_artifact__WEBPACK_IMPORTED_MODULE_2__["MyArtifactApi"].reloadSystemArtifacts().subscribe(function () {
        _this.onClick();
      }, function (err) {
        _this.setState({
          loading: false,
          errorMessage: i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate("".concat(PREFIX, ".errorMessage")),
          extendedMessage: err
        });
      });
    });

    return _this;
  }

  _createClass(ReloadSystemArtifacts, [{
    key: "render",
    value: function render() {
      if (services_ThemeHelper__WEBPACK_IMPORTED_MODULE_4__["Theme"].showReloadSystemArtifacts === false) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("button", {
        className: "btn btn-secondary",
        onClick: this.onClick
      }, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate("".concat(PREFIX, ".label"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__["default"], {
        headerTitle: i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate("".concat(PREFIX, ".confirmationHeader")),
        toggleModal: this.onClick,
        confirmationText: i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate("".concat(PREFIX, ".confirmationText")),
        confirmButtonText: i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate("".concat(PREFIX, ".confirmationButton")),
        confirmFn: this.reload,
        cancelFn: this.onClick,
        isOpen: this.state.openConfirmation,
        isLoading: this.state.loading,
        errorMessage: this.state.errorMessage,
        extendedMessage: this.state.extendedMessage
      }));
    }
  }]);

  return ReloadSystemArtifacts;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);



/***/ }),

/***/ "./components/Administration/AdminConfigTabContent/SystemPrefsAccordion/index.js":
/*!***************************************************************************************!*\
  !*** ./components/Administration/AdminConfigTabContent/SystemPrefsAccordion/index.js ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SystemPrefsAccordion; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_FastAction_SetPreferenceAction_SetPreferenceModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/FastAction/SetPreferenceAction/SetPreferenceModal */ "./components/FastAction/SetPreferenceAction/SetPreferenceModal.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var api_preference__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! api/preference */ "./api/preference.js");
/* harmony import */ var components_ViewAllLabel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/ViewAllLabel */ "./components/ViewAllLabel/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var components_SortableStickyGrid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/SortableStickyGrid */ "./components/SortableStickyGrid/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */











var PREFIX = 'features.Administration.Accordions.SystemPrefs';
var GRID_HEADERS = [{
  property: 'key',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate('commons.keyValPairs.keyLabel')
}, {
  property: 'value',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate('commons.keyValPairs.valueLabel')
}];
var NUM_PREFS_TO_SHOW = 5;

var SystemPrefsAccordion =
/*#__PURE__*/
function (_Component) {
  _inherits(SystemPrefsAccordion, _Component);

  function SystemPrefsAccordion() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SystemPrefsAccordion);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SystemPrefsAccordion)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      prefsModalOpen: false,
      prefsForDisplay: [],
      loading: true,
      viewAll: false
    });

    _defineProperty(_assertThisInitialized(_this), "fetchNewPrefs", function () {
      api_preference__WEBPACK_IMPORTED_MODULE_6__["MyPreferenceApi"].getSystemPreferences().subscribe(function (prefs) {
        var currentPrefs = Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["convertKeyValuePairsToMap"])(_this.state.prefsForDisplay);
        var hasNewPrefs = false;
        var newPrefsForDisplay = Object.entries(prefs).map(function (_ref) {
          var _ref2 = _slicedToArray(_ref, 2),
              key = _ref2[0],
              value = _ref2[1];

          var prefIsHighlighted = false;

          if (!(key in currentPrefs) || key in currentPrefs && currentPrefs[key] !== value) {
            hasNewPrefs = true;
            prefIsHighlighted = true;
          }

          return {
            key: key,
            value: value,
            highlighted: prefIsHighlighted
          };
        });

        _this.setState({
          prefsForDisplay: newPrefsForDisplay,
          viewAll: hasNewPrefs || _this.state.viewAll
        }, function () {
          if (hasNewPrefs) {
            setTimeout(function () {
              newPrefsForDisplay = newPrefsForDisplay.map(function (pref) {
                return {
                  key: pref.key,
                  value: pref.value,
                  highlighted: false
                };
              });

              _this.setState({
                prefsForDisplay: newPrefsForDisplay
              });
            }, 4000);
          }
        });
      }, function (err) {
        return console.log(err);
      });
    });

    _defineProperty(_assertThisInitialized(_this), "togglePrefsModal", function () {
      _this.setState({
        prefsModalOpen: !_this.state.prefsModalOpen
      });
    });

    _defineProperty(_assertThisInitialized(_this), "toggleViewAll", function () {
      _this.setState({
        viewAll: !_this.state.viewAll
      });
    });

    return _this;
  }

  _createClass(SystemPrefsAccordion, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.getPrefs();
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (nextProps.expanded) {
        this.getPrefs();
      }
    }
  }, {
    key: "getPrefs",
    value: function getPrefs() {
      var _this2 = this;

      api_preference__WEBPACK_IMPORTED_MODULE_6__["MyPreferenceApi"].getSystemPreferences().subscribe(function (res) {
        _this2.setState({
          prefsForDisplay: Object(services_helpers__WEBPACK_IMPORTED_MODULE_5__["convertMapToKeyValuePairs"])(res, false),
          loading: false
        });
      }, function (err) {
        return console.log(err);
      });
    }
  }, {
    key: "renderLabel",
    value: function renderLabel() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "admin-config-container-toggle",
        onClick: this.props.onExpand
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "admin-config-container-label"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
        name: this.props.expanded ? 'icon-caret-down' : 'icon-caret-right'
      }), this.state.loading ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", null, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".label")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
        name: "icon-spinner",
        className: "fa-spin"
      })) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", null, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".labelWithCount"), {
        count: this.state.prefsForDisplay.length
      }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "admin-config-container-description"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".description"))));
    }
  }, {
    key: "renderGrid",
    value: function renderGrid() {
      if (!this.state.prefsForDisplay.length) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "grid-wrapper text-center"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".noPrefs")));
      }

      var prefs = _toConsumableArray(this.state.prefsForDisplay);

      if (!this.state.viewAll && prefs.length > NUM_PREFS_TO_SHOW) {
        prefs = prefs.slice(0, NUM_PREFS_TO_SHOW);
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_SortableStickyGrid__WEBPACK_IMPORTED_MODULE_9__["default"], {
        entities: prefs,
        gridHeaders: GRID_HEADERS
      });
    }
  }, {
    key: "renderContent",
    value: function renderContent() {
      if (!this.props.expanded) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "admin-config-container-content system-prefs-container-content"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("button", {
        className: "btn btn-secondary",
        onClick: this.togglePrefsModal
      }, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".create"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_ViewAllLabel__WEBPACK_IMPORTED_MODULE_7__["default"], {
        arrayToLimit: this.state.prefsForDisplay,
        limit: NUM_PREFS_TO_SHOW,
        viewAllState: this.state.viewAll,
        toggleViewAll: this.toggleViewAll
      }), this.renderGrid(), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_ViewAllLabel__WEBPACK_IMPORTED_MODULE_7__["default"], {
        arrayToLimit: this.state.prefsForDisplay,
        limit: NUM_PREFS_TO_SHOW,
        viewAllState: this.state.viewAll,
        toggleViewAll: this.toggleViewAll
      }), this.state.prefsModalOpen ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FastAction_SetPreferenceAction_SetPreferenceModal__WEBPACK_IMPORTED_MODULE_3__["default"], {
        isOpen: this.state.prefsModalOpen,
        toggleModal: this.togglePrefsModal,
        onSuccess: this.fetchNewPrefs,
        setAtLevel: components_FastAction_SetPreferenceAction_SetPreferenceModal__WEBPACK_IMPORTED_MODULE_3__["PREFERENCES_LEVEL"].SYSTEM
      }) : null);
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()('admin-config-container system-prefs-container', {
          expanded: this.props.expanded
        })
      }, this.renderLabel(), this.renderContent());
    }
  }]);

  return SystemPrefsAccordion;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(SystemPrefsAccordion, "propTypes", {
  expanded: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  onExpand: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
});



/***/ }),

/***/ "./components/Administration/AdminConfigTabContent/SystemProfilesAccordion/SystemProfilesAccordion.scss":
/*!**************************************************************************************************************!*\
  !*** ./components/Administration/AdminConfigTabContent/SystemProfilesAccordion/SystemProfilesAccordion.scss ***!
  \**************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./SystemProfilesAccordion.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminConfigTabContent/SystemProfilesAccordion/SystemProfilesAccordion.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Administration/AdminConfigTabContent/SystemProfilesAccordion/index.js":
/*!******************************************************************************************!*\
  !*** ./components/Administration/AdminConfigTabContent/SystemProfilesAccordion/index.js ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SystemProfilesAccordionFn; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var components_Cloud_Profiles_ListView__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Cloud/Profiles/ListView */ "./components/Cloud/Profiles/ListView/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Cloud/Profiles/Store */ "./components/Cloud/Profiles/Store/index.js");
/* harmony import */ var components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/Cloud/Profiles/Store/ActionCreator */ "./components/Cloud/Profiles/Store/ActionCreator.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
















__webpack_require__(/*! ./SystemProfilesAccordion.scss */ "./components/Administration/AdminConfigTabContent/SystemProfilesAccordion/SystemProfilesAccordion.scss");

var PREFIX = 'features.Administration.Accordions.SystemProfiles';

var SystemProfilesAccordion =
/*#__PURE__*/
function (_Component) {
  _inherits(SystemProfilesAccordion, _Component);

  function SystemProfilesAccordion() {
    _classCallCheck(this, SystemProfilesAccordion);

    return _possibleConstructorReturn(this, _getPrototypeOf(SystemProfilesAccordion).apply(this, arguments));
  }

  _createClass(SystemProfilesAccordion, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      Object(components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_8__["getProfiles"])(services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SYSTEM_NAMESPACE"]);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      Object(components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_8__["resetProfiles"])();
    }
  }, {
    key: "renderLabel",
    value: function renderLabel() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "admin-config-container-toggle",
        onClick: this.props.onExpand
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "admin-config-container-label"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_5__["default"], {
        name: this.props.expanded ? 'icon-caret-down' : 'icon-caret-right'
      }), this.props.loading ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".label")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_5__["default"], {
        name: "icon-spinner",
        className: "fa-spin"
      })) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".labelWithCount"), {
        count: this.props.profilesCount
      }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "admin-config-container-description"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".description"))));
    }
  }, {
    key: "renderContent",
    value: function renderContent() {
      if (!this.props.expanded) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "admin-config-container-content system-profiles-container-content"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_13__["default"], {
        condition: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_12__["Theme"].showCreateProfile !== false
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "create-import-profile"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Link"], {
        className: "btn btn-secondary create-profile-button",
        to: "/ns/system/profiles/create"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".create"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_10__["Label"], {
        className: "import-profile-label",
        "for": "import-profile"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".import")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_10__["Input"], {
        type: "file",
        accept: ".json",
        id: "import-profile",
        onChange: components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_8__["importProfile"].bind(this, services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SYSTEM_NAMESPACE"]),
        onClick: function onClick(e) {
          return e.target.value = null;
        }
      })))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Cloud_Profiles_ListView__WEBPACK_IMPORTED_MODULE_3__["default"], {
        namespace: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SYSTEM_NAMESPACE"]
      }));
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()('admin-config-container system-profiles-container', {
          expanded: this.props.expanded
        })
      }, this.renderLabel(), this.renderContent());
    }
  }]);

  return SystemProfilesAccordion;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(SystemProfilesAccordion, "propTypes", {
  profilesCount: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  loading: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  expanded: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  onExpand: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
});

var mapStateToProps = function mapStateToProps(state) {
  return {
    profilesCount: state.profiles.length,
    loading: state.loading
  };
};

var ConnectedSystemProfilesAccordion = Object(react_redux__WEBPACK_IMPORTED_MODULE_9__["connect"])(mapStateToProps)(SystemProfilesAccordion);
function SystemProfilesAccordionFn(props) {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_redux__WEBPACK_IMPORTED_MODULE_9__["Provider"], {
    store: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_7__["default"]
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(ConnectedSystemProfilesAccordion, props));
}

/***/ }),

/***/ "./components/Administration/AdminConfigTabContent/index.js":
/*!******************************************************************!*\
  !*** ./components/Administration/AdminConfigTabContent/index.js ***!
  \******************************************************************/
/*! exports provided: ADMIN_CONFIG_ACCORDIONS, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ADMIN_CONFIG_ACCORDIONS", function() { return ADMIN_CONFIG_ACCORDIONS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AdminConfigTabContent; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Administration_AdminConfigTabContent_ReloadSystemArtifacts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Administration/AdminConfigTabContent/ReloadSystemArtifacts */ "./components/Administration/AdminConfigTabContent/ReloadSystemArtifacts.js");
/* harmony import */ var components_Administration_AdminConfigTabContent_NamespacesAccordion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Administration/AdminConfigTabContent/NamespacesAccordion */ "./components/Administration/AdminConfigTabContent/NamespacesAccordion/index.js");
/* harmony import */ var components_Administration_AdminConfigTabContent_SystemProfilesAccordion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Administration/AdminConfigTabContent/SystemProfilesAccordion */ "./components/Administration/AdminConfigTabContent/SystemProfilesAccordion/index.js");
/* harmony import */ var components_Administration_AdminConfigTabContent_SystemPrefsAccordion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Administration/AdminConfigTabContent/SystemPrefsAccordion */ "./components/Administration/AdminConfigTabContent/SystemPrefsAccordion/index.js");
/* harmony import */ var api_namespace__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! api/namespace */ "./api/namespace.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-helmet */ "../../node_modules/react-helmet/lib/Helmet.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_10__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */












__webpack_require__(/*! ./AdminConfigTabContent.scss */ "./components/Administration/AdminConfigTabContent/AdminConfigTabContent.scss");

var I18N_PREFIX = 'features.Administration.Configure';
var ADMIN_CONFIG_ACCORDIONS = {
  namespaces: 'NAMESPACES',
  systemProfiles: 'SYSTEM_PROFILES',
  systemPrefs: 'SYSTEM_PREFS'
};

var AdminConfigTabContent =
/*#__PURE__*/
function (_Component) {
  _inherits(AdminConfigTabContent, _Component);

  function AdminConfigTabContent() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, AdminConfigTabContent);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(AdminConfigTabContent)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      namespaces: [],
      namespacesCountLoading: true,
      expandedAccordion: _this.props.accordionToExpand || ADMIN_CONFIG_ACCORDIONS.namespaces
    });

    _defineProperty(_assertThisInitialized(_this), "expandAccordion", function (accordion) {
      if (_this.state.expandedAccordion === accordion) {
        _this.setState({
          expandedAccordion: null
        });
      } else {
        _this.setState({
          expandedAccordion: accordion
        });
      }
    });

    return _this;
  }

  _createClass(AdminConfigTabContent, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.getNamespaces();
    }
  }, {
    key: "getNamespaces",
    value: function getNamespaces() {
      var _this2 = this;

      api_namespace__WEBPACK_IMPORTED_MODULE_6__["MyNamespaceApi"].list().subscribe(function (res) {
        _this2.setState({
          namespaces: res,
          namespacesCountLoading: false
        });
      }, function (err) {
        return console.log(err);
      });
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "admin-config-tab-content"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_helmet__WEBPACK_IMPORTED_MODULE_8___default.a, {
        title: i18n_react__WEBPACK_IMPORTED_MODULE_10___default.a.translate("".concat(I18N_PREFIX, ".pageTitle"), {
          productName: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_9__["Theme"].productName
        })
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "action-buttons"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Administration_AdminConfigTabContent_ReloadSystemArtifacts__WEBPACK_IMPORTED_MODULE_2__["default"], null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_7__["Link"], {
        to: "/httpexecutor",
        className: "btn btn-secondary"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_10___default.a.translate("".concat(I18N_PREFIX, ".buttons.MakeRESTCalls.label")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Administration_AdminConfigTabContent_NamespacesAccordion__WEBPACK_IMPORTED_MODULE_3__["default"], {
        namespaces: this.state.namespaces,
        loading: this.state.namespacesCountLoading,
        expanded: this.state.expandedAccordion === ADMIN_CONFIG_ACCORDIONS.namespaces,
        onExpand: this.expandAccordion.bind(this, ADMIN_CONFIG_ACCORDIONS.namespaces)
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Administration_AdminConfigTabContent_SystemProfilesAccordion__WEBPACK_IMPORTED_MODULE_4__["default"], {
        expanded: this.state.expandedAccordion === ADMIN_CONFIG_ACCORDIONS.systemProfiles,
        onExpand: this.expandAccordion.bind(this, ADMIN_CONFIG_ACCORDIONS.systemProfiles)
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Administration_AdminConfigTabContent_SystemPrefsAccordion__WEBPACK_IMPORTED_MODULE_5__["default"], {
        expanded: this.state.expandedAccordion === ADMIN_CONFIG_ACCORDIONS.systemPrefs,
        onExpand: this.expandAccordion.bind(this, ADMIN_CONFIG_ACCORDIONS.systemPrefs)
      }));
    }
  }]);

  return AdminConfigTabContent;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(AdminConfigTabContent, "propTypes", {
  accordionToExpand: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
});

_defineProperty(AdminConfigTabContent, "defaultProps", {
  accordionToExpand: ADMIN_CONFIG_ACCORDIONS.namespaces
});



/***/ }),

/***/ "./components/Administration/AdminManagementTabContent/AdminManagementTabContent.scss":
/*!********************************************************************************************!*\
  !*** ./components/Administration/AdminManagementTabContent/AdminManagementTabContent.scss ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./AdminManagementTabContent.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminManagementTabContent/AdminManagementTabContent.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Administration/AdminManagementTabContent/PlatformsDetails/Genericdetails.js":
/*!************************************************************************************************!*\
  !*** ./components/Administration/AdminManagementTabContent/PlatformsDetails/Genericdetails.js ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return GenericDetails; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_RenderObjectAsTable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/RenderObjectAsTable */ "./components/RenderObjectAsTable/index.js");
/* harmony import */ var lodash_capitalize__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/capitalize */ "../../node_modules/lodash/capitalize.js");
/* harmony import */ var lodash_capitalize__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_capitalize__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./Genericdetails.scss */ "./components/Administration/AdminManagementTabContent/PlatformsDetails/Genericdetails.scss");

function GenericDetails(_ref) {
  var details = _ref.details,
      className = _ref.className;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()(className, 'generic-details')
  }, Object.keys(details).filter(function (detail) {
    return ['name', 'url', 'version', 'logs'].indexOf(detail) === -1;
  }).map(function (detail, i) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
      key: i
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, lodash_capitalize__WEBPACK_IMPORTED_MODULE_3___default()(detail)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_RenderObjectAsTable__WEBPACK_IMPORTED_MODULE_2__["default"], {
      obj: details[detail]
    }));
  }));
}
GenericDetails.propTypes = {
  details: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/Administration/AdminManagementTabContent/PlatformsDetails/Genericdetails.scss":
/*!**************************************************************************************************!*\
  !*** ./components/Administration/AdminManagementTabContent/PlatformsDetails/Genericdetails.scss ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./Genericdetails.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminManagementTabContent/PlatformsDetails/Genericdetails.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Administration/AdminManagementTabContent/PlatformsDetails/PlatformDetails.scss":
/*!***************************************************************************************************!*\
  !*** ./components/Administration/AdminManagementTabContent/PlatformsDetails/PlatformDetails.scss ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./PlatformDetails.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminManagementTabContent/PlatformsDetails/PlatformDetails.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Administration/AdminManagementTabContent/PlatformsDetails/index.js":
/*!***************************************************************************************!*\
  !*** ./components/Administration/AdminManagementTabContent/PlatformsDetails/index.js ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PlatformsDetails; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_Administration_AdminManagementTabContent_PlatformsDetails_Genericdetails__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Administration/AdminManagementTabContent/PlatformsDetails/Genericdetails */ "./components/Administration/AdminManagementTabContent/PlatformsDetails/Genericdetails.js");
/* harmony import */ var components_LoadingSVG__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/LoadingSVG */ "./components/LoadingSVG/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./PlatformDetails.scss */ "./components/Administration/AdminManagementTabContent/PlatformsDetails/PlatformDetails.scss");

var PlatformsDetails =
/*#__PURE__*/
function (_Component) {
  _inherits(PlatformsDetails, _Component);

  function PlatformsDetails() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, PlatformsDetails);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(PlatformsDetails)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      platformDetails: _this.props.platformDetails
    });

    return _this;
  }

  _createClass(PlatformsDetails, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.setState({
        platformDetails: nextProps.platformDetails
      });
    }
  }, {
    key: "render",
    value: function render() {
      if (!Object.keys(this.state.platformDetails).length) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "platform-details loading"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_LoadingSVG__WEBPACK_IMPORTED_MODULE_4__["default"], null));
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "platform-details"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "platform-header"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate('features.Administration.systemMetrics'))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "platform-content"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Administration_AdminManagementTabContent_PlatformsDetails_Genericdetails__WEBPACK_IMPORTED_MODULE_3__["default"], {
        details: this.state.platformDetails
      })));
    }
  }]);

  return PlatformsDetails;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(PlatformsDetails, "propTypes", {
  platformDetails: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
});

_defineProperty(PlatformsDetails, "defaultProps", {
  platformDetails: {}
});



/***/ }),

/***/ "./components/Administration/AdminManagementTabContent/ServicesTable/ServicesTable.scss":
/*!**********************************************************************************************!*\
  !*** ./components/Administration/AdminManagementTabContent/ServicesTable/ServicesTable.scss ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./ServicesTable.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminManagementTabContent/ServicesTable/ServicesTable.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Administration/AdminManagementTabContent/ServicesTable/index.js":
/*!************************************************************************************!*\
  !*** ./components/Administration/AdminManagementTabContent/ServicesTable/index.js ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ServicesTable; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var services_SystemServicesStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/SystemServicesStore */ "./services/SystemServicesStore.js");
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash/isEqual */ "../../node_modules/lodash/isEqual.js");
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_isEqual__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_SortableStickyTable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/SortableStickyTable */ "./components/SortableStickyTable/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_LoadingSVG__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/LoadingSVG */ "./components/LoadingSVG/index.js");
/* harmony import */ var api_serviceproviders__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! api/serviceproviders */ "./api/serviceproviders/index.js");
/* harmony import */ var components_TextboxOnValium__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/TextboxOnValium */ "./components/TextboxOnValium/index.js");
/* harmony import */ var components_Alert__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/Alert */ "./components/Alert/index.js");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! moment */ "../../node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var api_app__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! api/app */ "./api/app.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var lodash_sortBy__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! lodash/sortBy */ "../../node_modules/lodash/sortBy.js");
/* harmony import */ var lodash_sortBy__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(lodash_sortBy__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var lodash_startCase__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash/startCase */ "../../node_modules/lodash/startCase.js");
/* harmony import */ var lodash_startCase__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(lodash_startCase__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var services_program_api_converter__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! services/program-api-converter */ "./services/program-api-converter/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




















__webpack_require__(/*! ./ServicesTable.scss */ "./components/Administration/AdminManagementTabContent/ServicesTable/ServicesTable.scss");

var WAITTIME_FOR_ALTERNATE_STATUS = 10000;
var ADMINPREFIX = 'features.Administration.Services';
var DEFAULTSERVICES = ['appfabric', 'dataset.executor', 'explore.service', 'log.saver', 'messaging.service', 'metadata.service', 'metrics', 'metrics.processor', 'transaction'];
var tableHeaders = [{
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(ADMINPREFIX, ".headers.status")),
  property: 'status'
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(ADMINPREFIX, ".headers.name")),
  property: 'name',
  defaultSortby: true
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(ADMINPREFIX, ".headers.provisioned")),
  property: 'provisioned'
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(ADMINPREFIX, ".headers.requested")),
  property: 'requested'
}, {
  label: '',
  property: ''
}];

if (services_ThemeHelper__WEBPACK_IMPORTED_MODULE_12__["Theme"].showSystemServicesInstance === false) {
  tableHeaders.splice(2, 2);
}

var ServicesTable =
/*#__PURE__*/
function (_Component) {
  _inherits(ServicesTable, _Component);

  function ServicesTable() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ServicesTable);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ServicesTable)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      services: services_SystemServicesStore__WEBPACK_IMPORTED_MODULE_1__["default"].getState().services.list,
      systemProgramsStatus: [],
      showAlert: false,
      alertType: null,
      alertMessage: null
    });

    _defineProperty(_assertThisInitialized(_this), "servicePolls", []);

    _defineProperty(_assertThisInitialized(_this), "resetEditInstances", function () {
      var services = _toConsumableArray(_this.state.services);

      services = services.map(function (service) {
        service.editInstance = false;
        return service;
      });

      _this.setState({
        services: services
      });
    });

    _defineProperty(_assertThisInitialized(_this), "editRequestedServiceInstance", function (service) {
      if (service.editInstance || service.isSystemProgram) {
        return;
      }

      var serviceName = service.name;

      var services = _toConsumableArray(_this.state.services);

      services = services.map(function (service) {
        if (serviceName === service.name) {
          return Object.assign({}, service, {
            editInstance: true
          });
        }

        return service;
      });

      _this.setState({
        services: services
      });
    });

    _defineProperty(_assertThisInitialized(_this), "resetAlert", function () {
      _this.setState({
        showAlert: false,
        alertType: null,
        alertMessage: null
      });
    });

    _defineProperty(_assertThisInitialized(_this), "serviceInstanceRequested", function (serviceid, index, value) {
      var currentRequested = _this.state.services[index].requested;

      if (currentRequested === value) {
        _this.resetEditInstances();

        return;
      }

      api_serviceproviders__WEBPACK_IMPORTED_MODULE_8__["MyServiceProviderApi"].setProvisions({
        serviceid: serviceid
      }, {
        instances: value
      }).subscribe(function () {}, function (err) {
        _this.resetEditInstances();

        _this.setState({
          showAlert: true,
          alertType: 'error',
          alertMessage: err.response
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "fetchServiceStatus", function (serviceid) {
      var setDefaultStatus = function setDefaultStatus(serviceid) {
        var services = _toConsumableArray(_this.state.services);

        var isServiceAlreadyExist = _this.state.services.find(function (service) {
          return service.name === serviceid;
        });

        if (!isServiceAlreadyExist) {
          services.push({
            name: serviceid,
            status: 'NOTOK'
          });
        } else {
          services = services.map(function (service) {
            if (service.name === serviceid) {
              service.status = 'NOTOK';
            }

            return service;
          });
        }

        _this.setState({
          services: services
        });
      };

      var setDefaultInstance = function setDefaultInstance(serviceid) {
        var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
            _ref$requested = _ref.requested,
            requested = _ref$requested === void 0 ? '--' : _ref$requested,
            _ref$provisioned = _ref.provisioned,
            provisioned = _ref$provisioned === void 0 ? '--' : _ref$provisioned;

        var services = _toConsumableArray(_this.state.services);

        var isServiceAlreadyExist = _this.state.services.find(function (service) {
          return service.name === serviceid;
        });

        if (!isServiceAlreadyExist) {
          services.push({
            name: serviceid,
            requested: requested,
            provisioned: provisioned
          });
        } else {
          services = services.map(function (service) {
            if (service.name === serviceid) {
              service.requested = requested;
              service.provisioned = provisioned;
            }

            return service;
          });
        }

        _this.setState({
          services: services
        });
      };

      var serviceTimeout = setTimeout(function () {
        return setDefaultStatus(serviceid);
      }, WAITTIME_FOR_ALTERNATE_STATUS);

      _this.servicePolls.forEach(function (servicePoll) {
        return servicePoll.unsubscribe();
      });

      _this.servicePolls.push(api_serviceproviders__WEBPACK_IMPORTED_MODULE_8__["MyServiceProviderApi"].pollServiceStatus({
        serviceid: serviceid
      }).subscribe(function (res) {
        clearTimeout(serviceTimeout);

        var services = _toConsumableArray(_this.state.services);

        services = services.map(function (service) {
          if (service.name == serviceid) {
            service.status = res.staus;
          }

          return service;
        });

        _this.setState({
          services: services
        });
      }, function () {
        setDefaultStatus(serviceid);
      }));

      api_serviceproviders__WEBPACK_IMPORTED_MODULE_8__["MyServiceProviderApi"].getInstances({
        serviceid: serviceid
      }).subscribe(function (res) {
        setDefaultInstance(serviceid, res);
      }, function () {
        setDefaultInstance(serviceid);
      });
    });

    _defineProperty(_assertThisInitialized(_this), "fetchStatusFromIndividualServices", function () {
      DEFAULTSERVICES.forEach(function (service) {
        return _this.fetchServiceStatus(service);
      });
    });

    _defineProperty(_assertThisInitialized(_this), "fetchSystemApps", function () {
      var programs = [];
      api_app__WEBPACK_IMPORTED_MODULE_14__["MyAppApi"].list({
        namespace: 'system'
      }).subscribe(function (apps) {
        var requestPrograms = [];
        apps.forEach(function (app) {
          requestPrograms.push(api_app__WEBPACK_IMPORTED_MODULE_14__["MyAppApi"].get({
            namespace: 'system',
            appId: app.name
          }));
        });
        rxjs_Observable__WEBPACK_IMPORTED_MODULE_15__["Observable"].combineLatest(requestPrograms).subscribe(function (res) {
          res.forEach(function (appResponse) {
            appResponse.programs.forEach(function (program) {
              programs.push(program);
            });
          });

          _this.fetchSystemProgramsStatus(programs);
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "fetchSystemProgramsStatus", function (programs) {
      var requestBody = programs.map(function (program) {
        return {
          appId: program.app,
          programType: program.type,
          programId: program.name
        };
      });
      api_app__WEBPACK_IMPORTED_MODULE_14__["MyAppApi"].batchStatus({
        namespace: 'system'
      }, requestBody).subscribe(function (res) {
        var statuses = []; // CDAP-15254: We need to make this rename until backend changes
        // the name of the app from dataprep to wrangler

        var getAppId = function getAppId(appId) {
          return appId === 'dataprep' ? 'wrangler' : appId;
        };

        res.forEach(function (program) {
          var systemProgram = {
            name: "".concat(getAppId(program.appId), ".").concat(program.programId),
            provisioned: '--',
            requested: '--',
            status: program.status,
            isSystemProgram: true,
            programId: program.programId,
            programType: program.programType,
            appId: program.appId
          };
          statuses.push(systemProgram);
        });

        _this.setState({
          systemProgramsStatus: statuses
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "renderTableBody", function (services) {
      var start = moment__WEBPACK_IMPORTED_MODULE_13___default()().subtract(7, 'days').format('X');
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("table", {
        className: "table-sm"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tbody", null, services.map(function (service, i) {
        var logUrl = "/v3/system/services/".concat(service.name, "/logs");

        if (service.isSystemProgram) {
          logUrl = "/v3/namespaces/system/apps/".concat(service.appId, "/").concat(Object(services_program_api_converter__WEBPACK_IMPORTED_MODULE_18__["convertProgramToApi"])(service.programType), "/").concat(service.programId, "/logs");
        }

        logUrl = "".concat(logUrl, "?start=").concat(start);
        logUrl = "/test1/downloadLogs?type=raw&backendPath=".concat(encodeURIComponent(logUrl));
        var displayName = service.isSystemProgram ? lodash_startCase__WEBPACK_IMPORTED_MODULE_17___default()(service.name) : i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(ADMINPREFIX, ".").concat(service.name.replace(/\./g, '_')));
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tr", {
          key: service.name
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
          className: "status-circle"
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_5__["default"], {
          name: "icon-circle",
          className: classnames__WEBPACK_IMPORTED_MODULE_6___default()({
            'text-success': ['OK', 'RUNNING'].indexOf(service.status) !== -1,
            'text-warning': service.status === 'STARTING',
            'text-danger': ['OK', 'NOTOK', 'RUNNING', 'STARTING'].indexOf(service.status) === -1
          })
        }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, displayName)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_11__["default"], {
          condition: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_12__["Theme"].showSystemServicesInstance !== false
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, service.provisioned || '--')), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
          onClick: _this.editRequestedServiceInstance.bind(_assertThisInitialized(_this), service),
          className: "request-instances"
        }, service.editInstance ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_TextboxOnValium__WEBPACK_IMPORTED_MODULE_9__["default"], {
          className: "form-control",
          value: service.requested,
          onBlur: _this.resetEditInstances,
          onChange: _this.serviceInstanceRequested.bind(_assertThisInitialized(_this), service.name, i)
        }) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
          className: "requested-instances-holder"
        }, service.requested || '--')))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
          href: logUrl,
          target: "_blank",
          rel: "noopener noreferrer"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(ADMINPREFIX, ".viewlogs")))));
      })));
    });

    return _this;
  }

  _createClass(ServicesTable, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      this.systemServicesSubscription = services_SystemServicesStore__WEBPACK_IMPORTED_MODULE_1__["default"].subscribe(function () {
        var _SystemServicesStore$ = services_SystemServicesStore__WEBPACK_IMPORTED_MODULE_1__["default"].getState().services,
            services = _SystemServicesStore$.list,
            __error = _SystemServicesStore$.__error;

        if (__error) {
          _this2.fetchStatusFromIndividualServices();

          return;
        }

        if (!lodash_isEqual__WEBPACK_IMPORTED_MODULE_2___default()(services, _this2.state.services)) {
          _this2.setState({
            services: services
          });

          _this2.servicePolls.forEach(function (servicePoll) {
            return servicePoll.unsubscribe();
          });
        }
      });
      this.fetchSystemApps();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.systemServicesSubscription) {
        this.systemServicesSubscription();
      }
    }
  }, {
    key: "render",
    value: function render() {
      if (!Object.keys(this.state.services).length) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "services-table"
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_LoadingSVG__WEBPACK_IMPORTED_MODULE_7__["default"], null));
      }

      var combinedSystemServices = lodash_sortBy__WEBPACK_IMPORTED_MODULE_16___default()(this.state.services.concat(this.state.systemProgramsStatus), ['name']);
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "services-table"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_SortableStickyTable__WEBPACK_IMPORTED_MODULE_3__["default"], {
        className: "table-sm",
        entities: combinedSystemServices,
        tableHeaders: tableHeaders,
        renderTableBody: this.renderTableBody
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Alert__WEBPACK_IMPORTED_MODULE_10__["default"], {
        showAlert: this.state.showAlert,
        type: this.state.alertType,
        message: this.state.alertMessage,
        onClose: this.resetAlert
      }));
    }
  }]);

  return ServicesTable;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);



/***/ }),

/***/ "./components/Administration/AdminManagementTabContent/index.js":
/*!**********************************************************************!*\
  !*** ./components/Administration/AdminManagementTabContent/index.js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AdminManagementTabContent; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_Administration_AdminManagementTabContent_PlatformsDetails__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Administration/AdminManagementTabContent/PlatformsDetails */ "./components/Administration/AdminManagementTabContent/PlatformsDetails/index.js");
/* harmony import */ var components_Administration_AdminManagementTabContent_ServicesTable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Administration/AdminManagementTabContent/ServicesTable */ "./components/Administration/AdminManagementTabContent/ServicesTable/index.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-helmet */ "../../node_modules/react-helmet/lib/Helmet.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









var PREFIX = 'features.Administration';
var I18NPREFIX = "".concat(PREFIX, ".Management");

__webpack_require__(/*! ./AdminManagementTabContent.scss */ "./components/Administration/AdminManagementTabContent/AdminManagementTabContent.scss");

function AdminManagementTabContent(props) {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "admin-management-tab-content"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_helmet__WEBPACK_IMPORTED_MODULE_5___default.a, {
    title: i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(I18NPREFIX, ".pageTitle"), {
      productName: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_6__["Theme"].productName
    })
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "services-details"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('services-table-section', {
      'full-width': services_ThemeHelper__WEBPACK_IMPORTED_MODULE_6__["Theme"].showSystemMetrics === false
    })
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", null, " ", i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Services.title")), " "), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Administration_AdminManagementTabContent_ServicesTable__WEBPACK_IMPORTED_MODULE_4__["default"], null)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_7__["default"], {
    condition: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_6__["Theme"].showSystemMetrics !== false
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "platform-section"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Administration_AdminManagementTabContent_PlatformsDetails__WEBPACK_IMPORTED_MODULE_3__["default"], {
    platformDetails: props.platformsDetails
  })))));
}
AdminManagementTabContent.propTypes = {
  platformsDetails: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};

/***/ }),

/***/ "./components/Administration/AdminTabSwitch/AdminTabSwitch.scss":
/*!**********************************************************************!*\
  !*** ./components/Administration/AdminTabSwitch/AdminTabSwitch.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./AdminTabSwitch.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/AdminTabSwitch/AdminTabSwitch.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Administration/AdminTabSwitch/index.js":
/*!***********************************************************!*\
  !*** ./components/Administration/AdminTabSwitch/index.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AdminTabSwitch; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_VersionStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/VersionStore */ "./services/VersionStore/index.js");
/* harmony import */ var services_VersionStore_VersionActions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/VersionStore/VersionActions */ "./services/VersionStore/VersionActions.js");
/* harmony import */ var api_version__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! api/version */ "./api/version.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash/isNil */ "../../node_modules/lodash/isNil.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_isNil__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_9__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */











__webpack_require__(/*! ./AdminTabSwitch.scss */ "./components/Administration/AdminTabSwitch/AdminTabSwitch.scss");

var PREFIX = 'features.Administration';

var AdminTabSwitch =
/*#__PURE__*/
function (_Component) {
  _inherits(AdminTabSwitch, _Component);

  function AdminTabSwitch() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, AdminTabSwitch);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(AdminTabSwitch)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      version: null
    });

    return _this;
  }

  _createClass(AdminTabSwitch, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (!services_VersionStore__WEBPACK_IMPORTED_MODULE_4__["default"].getState().version) {
        this.getCDAPVersion();
      } else {
        this.setState({
          version: services_VersionStore__WEBPACK_IMPORTED_MODULE_4__["default"].getState().version
        });
      }
    }
  }, {
    key: "getCDAPVersion",
    value: function getCDAPVersion() {
      var _this2 = this;

      api_version__WEBPACK_IMPORTED_MODULE_6__["default"].get().subscribe(function (res) {
        _this2.setState({
          version: res.version
        });

        services_VersionStore__WEBPACK_IMPORTED_MODULE_4__["default"].dispatch({
          type: services_VersionStore_VersionActions__WEBPACK_IMPORTED_MODULE_5__["default"].updateVersion,
          payload: {
            version: res.version
          }
        });
      });
    }
  }, {
    key: "renderTabTitle",
    value: function renderTabTitle() {
      var isManagement = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "tab-title"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()({
          active: isManagement
        })
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Link"], {
        to: "/administration"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".Tabs.management")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "divider"
      }, " | "), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()({
          active: !isManagement
        })
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Link"], {
        to: "/administration/configuration"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".Tabs.config")))));
    }
  }, {
    key: "renderUptimeVersion",
    value: function renderUptimeVersion() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "uptime-version-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, this.props.uptime ? i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".uptimeLabel"), {
        time: Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableDuration"])(Math.ceil(this.props.uptime / 1000))
      }) : null), lodash_isNil__WEBPACK_IMPORTED_MODULE_7___default()(this.state.version) ? null : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", {
        className: "cdap-version"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".Top.version-label")), " - ", this.state.version));
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Switch"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Route"], {
        exact: true,
        path: "/administration",
        render: function render() {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
            className: "tab-title-and-version"
          }, _this3.renderTabTitle(), _this3.renderUptimeVersion());
        }
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Route"], {
        exact: true,
        path: "/administration/configuration",
        render: function render() {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
            className: "tab-title-and-version"
          }, _this3.renderTabTitle(false));
        }
      }));
    }
  }]);

  return AdminTabSwitch;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(AdminTabSwitch, "propTypes", {
  uptime: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
});



/***/ }),

/***/ "./components/Administration/Administration.scss":
/*!*******************************************************!*\
  !*** ./components/Administration/Administration.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Administration.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Administration/Administration.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Administration/index.js":
/*!********************************************!*\
  !*** ./components/Administration/index.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_serviceproviders__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/serviceproviders */ "./api/serviceproviders/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_Administration_AdminManagementTabContent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Administration/AdminManagementTabContent */ "./components/Administration/AdminManagementTabContent/index.js");
/* harmony import */ var components_Administration_AdminConfigTabContent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Administration/AdminConfigTabContent */ "./components/Administration/AdminConfigTabContent/index.js");
/* harmony import */ var components_Administration_AdminTabSwitch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Administration/AdminTabSwitch */ "./components/Administration/AdminTabSwitch/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









__webpack_require__(/*! ./Administration.scss */ "./components/Administration/Administration.scss");

var WAITTIME_FOR_ALTERNATE_STATUS = 10000;

var Administration =
/*#__PURE__*/
function (_Component) {
  _inherits(Administration, _Component);

  function Administration() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, Administration);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(Administration)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      platformsDetails: {},
      uptime: 0,
      accordionToExpand: _typeof(_this.props.location.state) === 'object' ? _this.props.location.state.accordionToExpand : null
    });

    return _this;
  }

  _createClass(Administration, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.getUptime();
      this.getPlatformDetails();
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (nextProps.location.state !== this.props.location.state) {
        var accordionToExpand = _typeof(nextProps.location.state) === 'object' ? nextProps.location.state.accordionToExpand : null;
        this.setState({
          accordionToExpand: accordionToExpand
        });
      }
    }
  }, {
    key: "getUptime",
    value: function getUptime() {
      var _this2 = this;

      api_serviceproviders__WEBPACK_IMPORTED_MODULE_2__["MyServiceProviderApi"].pollList().subscribe(function (res) {
        var uptime = Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["objectQuery"])(res, 'cdap', 'Uptime');

        _this2.setState({
          uptime: uptime
        });
      }, function () {
        setTimeout(function () {
          _this2.getUptime();
        }, WAITTIME_FOR_ALTERNATE_STATUS);
      });
    }
  }, {
    key: "prettifyPlatformDetails",
    value: function prettifyPlatformDetails(details) {
      delete details.transactions.WritePointer;
      delete details.transactions.ReadPointer;
      return Object.assign({}, details, {
        lasthourload: _objectSpread({}, details.lasthourload, {
          Successful: Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableNumber"])(details.lasthourload.Successful),
          TotalRequests: Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableNumber"])(details.lasthourload.TotalRequests)
        })
      });
    }
  }, {
    key: "getPlatformDetails",
    value: function getPlatformDetails() {
      var _this3 = this;

      api_serviceproviders__WEBPACK_IMPORTED_MODULE_2__["MyServiceProviderApi"].get({
        serviceprovider: 'cdap'
      }).subscribe(function (res) {
        var platformsDetails = _objectSpread({}, _this3.prettifyPlatformDetails(res));

        _this3.setState({
          platformsDetails: platformsDetails
        });
      }, function () {
        setTimeout(function () {
          _this3.getUptime();
        }, WAITTIME_FOR_ALTERNATE_STATUS);
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this4 = this;

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "administration"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Administration_AdminTabSwitch__WEBPACK_IMPORTED_MODULE_6__["default"], {
        uptime: this.state.uptime
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_7__["Switch"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_7__["Route"], {
        exact: true,
        path: "/administration",
        render: function render() {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Administration_AdminManagementTabContent__WEBPACK_IMPORTED_MODULE_4__["default"], {
            platformsDetails: _this4.state.platformsDetails
          });
        }
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_7__["Route"], {
        exact: true,
        path: "/administration/configuration",
        render: function render() {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Administration_AdminConfigTabContent__WEBPACK_IMPORTED_MODULE_5__["default"], {
            accordionToExpand: _this4.state.accordionToExpand
          });
        }
      })));
    }
  }]);

  return Administration;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(Administration, "propTypes", {
  location: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
});

/* harmony default export */ __webpack_exports__["default"] = (Administration);

/***/ }),

/***/ "./components/Cloud/Profiles/ActionsPopover/ActionsPopover.scss":
/*!**********************************************************************!*\
  !*** ./components/Cloud/Profiles/ActionsPopover/ActionsPopover.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./ActionsPopover.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Cloud/Profiles/ActionsPopover/ActionsPopover.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Cloud/Profiles/ActionsPopover/index.js":
/*!***********************************************************!*\
  !*** ./components/Cloud/Profiles/ActionsPopover/index.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProfileActionsPopover; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Cloud/Profiles/Store/ActionCreator */ "./components/Cloud/Profiles/Store/ActionCreator.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */







__webpack_require__(/*! ./ActionsPopover.scss */ "./components/Cloud/Profiles/ActionsPopover/ActionsPopover.scss");

function ProfileActionsPopover(_ref) {
  var target = _ref.target,
      namespace = _ref.namespace,
      profile = _ref.profile,
      onDeleteClick = _ref.onDeleteClick,
      className = _ref.className;
  var isProfileDisabled = false;

  if (profile && profile.status === 'DISABLED') {
    isProfileDisabled = true;
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_2__["default"], {
    target: target,
    className: "profile-actions-popover ".concat(className),
    placement: "bottom",
    bubbleEvent: false,
    enableInteractionInPopover: true
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("ul", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", {
    onClick: components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_3__["exportProfile"].bind(this, namespace, profile)
  }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate('features.Cloud.Profiles.common.export')), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("hr", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()('delete-action', {
      disabled: !isProfileDisabled
    }),
    title: !isProfileDisabled ? i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate('features.Cloud.Profiles.common.disabledDeleteProfile') : '',
    onClick: !isProfileDisabled ? null : onDeleteClick
  }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate('commons.delete'))));
}
ProfileActionsPopover.propTypes = {
  target: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.node, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func]),
  namespace: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  profile: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  onDeleteClick: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func,
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
};

/***/ }),

/***/ "./components/Cloud/Profiles/ListView/ListView.scss":
/*!**********************************************************!*\
  !*** ./components/Cloud/Profiles/ListView/ListView.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./ListView.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Cloud/Profiles/ListView/ListView.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Cloud/Profiles/ListView/index.js":
/*!*****************************************************!*\
  !*** ./components/Cloud/Profiles/ListView/index.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProfilesListViewFn; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_LoadingSVG__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/LoadingSVG */ "./components/LoadingSVG/index.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash/orderBy */ "../../node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var components_ViewAllLabel__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/ViewAllLabel */ "./components/ViewAllLabel/index.js");
/* harmony import */ var components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/ConfirmationModal */ "./components/ConfirmationModal/index.js");
/* harmony import */ var components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/Cloud/Profiles/Store */ "./components/Cloud/Profiles/Store/index.js");
/* harmony import */ var components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! components/Cloud/Profiles/Store/ActionCreator */ "./components/Cloud/Profiles/Store/ActionCreator.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Alert__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! components/Alert */ "./components/Alert/index.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var components_Cloud_Profiles_ActionsPopover__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! components/Cloud/Profiles/ActionsPopover */ "./components/Cloud/Profiles/ActionsPopover/index.js");
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash/isEqual */ "../../node_modules/lodash/isEqual.js");
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(lodash_isEqual__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var components_Cloud_Profiles_Store_Provisioners__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! components/Cloud/Profiles/Store/Provisioners */ "./components/Cloud/Profiles/Store/Provisioners.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var lodash_findIndex__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! lodash/findIndex */ "../../node_modules/lodash/findIndex.js");
/* harmony import */ var lodash_findIndex__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(lodash_findIndex__WEBPACK_IMPORTED_MODULE_21__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
























__webpack_require__(/*! ./ListView.scss */ "./components/Cloud/Profiles/ListView/ListView.scss");

var PREFIX = 'features.Cloud.Profiles';
var PROFILES_TABLE_HEADERS = [{
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".ListView.default"))
}, {
  property: 'name',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".ListView.profileName"))
}, {
  property: function property(profile) {
    return profile.provisioner.label;
  },
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".common.provisioner"))
}, {
  property: 'scope',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate('commons.scope')
}, {
  property: 'last24HrRuns',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".common.last24HrRuns"))
}, {
  property: 'last24HrNodeHr',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".common.last24HrNodeHr"))
}, {
  property: 'totalNodeHr',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".common.totalNodeHr"))
}, {
  property: 'schedulesCount',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".ListView.schedules"))
}, {
  property: 'triggersCount',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".ListView.triggers"))
}, {
  property: 'status',
  label: 'Status'
}, {
  label: ''
}];
var SORT_METHODS = {
  asc: 'asc',
  desc: 'desc'
};
var NUM_PROFILES_TO_SHOW = 5;

var ProfilesListView =
/*#__PURE__*/
function (_Component) {
  _inherits(ProfilesListView, _Component);

  function ProfilesListView() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ProfilesListView);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ProfilesListView)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      profiles: _this.props.profiles,
      provisionersMap: {},
      viewAll: false,
      sortMethod: SORT_METHODS.asc,
      sortColumn: PROFILES_TABLE_HEADERS[1].property,
      profileToDelete: null,
      deleteErrMsg: '',
      extendedDeleteErrMsg: ''
    });

    _defineProperty(_assertThisInitialized(_this), "toggleViewAll", function () {
      _this.setState({
        viewAll: !_this.state.viewAll
      });
    });

    _defineProperty(_assertThisInitialized(_this), "handleProfilesSort", function (field) {
      var newSortColumn, newSortMethod;

      if (_this.state.sortColumn === field) {
        newSortColumn = _this.state.sortColumn;
        newSortMethod = _this.state.sortMethod === SORT_METHODS.asc ? SORT_METHODS.desc : SORT_METHODS.asc;
      } else {
        newSortColumn = field;
        newSortMethod = SORT_METHODS.asc;
      }

      _this.setState({
        sortColumn: newSortColumn,
        sortMethod: newSortMethod,
        profiles: lodash_orderBy__WEBPACK_IMPORTED_MODULE_8___default()(_this.state.profiles, [newSortColumn], [newSortMethod])
      });
    });

    _defineProperty(_assertThisInitialized(_this), "deleteProfile", function (profile) {
      var namespace = profile.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_19__["SCOPES"].SYSTEM ? services_global_constants__WEBPACK_IMPORTED_MODULE_19__["SYSTEM_NAMESPACE"] : _this.props.namespace;
      Object(components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_12__["deleteProfile"])(namespace, profile.name, _this.props.namespace).subscribe(function () {
        _this.setState({
          profileToDelete: null,
          deleteErrMsg: '',
          extendedDeleteErrMsg: ''
        });
      }, function (err) {
        _this.setState({
          deleteErrMsg: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".common.deleteError")),
          extendedDeleteErrMsg: err
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "toggleDeleteConfirmationModal", function () {
      var profileToDelete = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

      _this.setState({
        profileToDelete: profileToDelete,
        deleteErrMsg: '',
        extendedDeleteErrMsg: ''
      });
    });

    _defineProperty(_assertThisInitialized(_this), "setProfileAsDefault", function (profileName, e) {
      if (profileName !== _this.props.defaultProfile) {
        Object(components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_12__["setDefaultProfile"])(_this.props.namespace, profileName);
      }

      Object(services_helpers__WEBPACK_IMPORTED_MODULE_20__["preventPropagation"])(e);
    });

    _defineProperty(_assertThisInitialized(_this), "renderProfilerow", function (profile) {
      var namespace = profile.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_19__["SCOPES"].SYSTEM ? services_global_constants__WEBPACK_IMPORTED_MODULE_19__["SYSTEM_NAMESPACE"] : _this.props.namespace;
      var provisionerName = profile.provisioner.name;
      profile.provisioner.label = _this.state.provisionersMap[provisionerName] || provisionerName;
      var profileStatus = components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_11__["PROFILE_STATUSES"][profile.status];
      var Tag = react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"];
      var profileName = Object(components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_12__["getProfileNameWithScope"])(profile.name, profile.scope);
      var isNativeProfile = profileName === services_global_constants__WEBPACK_IMPORTED_MODULE_19__["CLOUD"].DEFAULT_PROFILE_NAME;
      var profileIsDefault = profileName === _this.props.defaultProfile;

      var actionsElem = function actionsElem() {
        if (isNativeProfile) {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
            name: "icon-cog-empty",
            onClick: function onClick(e) {
              Object(services_helpers__WEBPACK_IMPORTED_MODULE_20__["preventPropagation"])(e);
              return false;
            }
          });
        }

        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
          name: "icon-cog-empty"
        });
      };

      if (isNativeProfile) {
        Tag = 'div';
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Tag, {
        to: "/ns/".concat(namespace, "/profiles/details/").concat(profile.name),
        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()('grid-row grid-link', {
          'native-profile': isNativeProfile,
          highlighted: profileName === _this.props.newProfile
        }),
        key: uuid_v4__WEBPACK_IMPORTED_MODULE_15___default()()
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "default-star",
        onClick: _this.setProfileAsDefault.bind(_assertThisInitialized(_this), profileName)
      }, profileIsDefault ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
        name: "icon-star",
        className: "default-profile"
      }) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
        name: "icon-star-o",
        className: "not-default-profile"
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "profile-label",
        title: profile.label || profile.name
      }, profile.label || profile.name), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, profile.provisioner.label), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, profile.scope), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, profile.oneDayMetrics.runs || '--'), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, Object(components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_12__["getNodeHours"])(profile.oneDayMetrics.minutes || '--')), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, Object(components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_12__["getNodeHours"])(profile.overAllMetrics.minutes || '--')), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, profile.schedulesCount), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, profile.triggersCount), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "".concat(profileStatus, "-label")
      }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".common.").concat(profileStatus))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-item-sm"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Cloud_Profiles_ActionsPopover__WEBPACK_IMPORTED_MODULE_16__["default"], {
        target: actionsElem,
        namespace: _this.props.namespace,
        profile: profile,
        disabled: isNativeProfile,
        onDeleteClick: _this.toggleDeleteConfirmationModal.bind(_assertThisInitialized(_this), profile)
      })));
    });

    return _this;
  }

  _createClass(ProfilesListView, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      Object(components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_12__["getProfiles"])(this.props.namespace);
      Object(components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_12__["getDefaultProfile"])(this.props.namespace);
      this.getProvisioners();
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (!lodash_isEqual__WEBPACK_IMPORTED_MODULE_17___default()(nextProps.profiles, this.props.profiles)) {
        var orderedProfiles = lodash_orderBy__WEBPACK_IMPORTED_MODULE_8___default()(nextProps.profiles, this.state.sortColumn, this.state.sortMethod);
        var viewAll = this.state.viewAll;

        if (this.props.newProfile && orderedProfiles.length > NUM_PROFILES_TO_SHOW && !this.state.viewAll) {
          var newProfileName = Object(components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_12__["extractProfileName"])(this.props.newProfile);
          var newProfileIndex = lodash_findIndex__WEBPACK_IMPORTED_MODULE_21___default()(orderedProfiles, {
            name: newProfileName
          });

          if (newProfileIndex >= NUM_PROFILES_TO_SHOW) {
            viewAll = true;
          }
        }

        this.setState({
          profiles: orderedProfiles,
          viewAll: viewAll
        });
      }
    }
  }, {
    key: "getProvisioners",
    value: function getProvisioners() {
      var _this2 = this;

      Object(components_Cloud_Profiles_Store_Provisioners__WEBPACK_IMPORTED_MODULE_18__["getProvisionersMap"])().subscribe(function (state) {
        _this2.setState({
          provisionersMap: state.nameToLabelMap
        });
      });
    }
  }, {
    key: "renderProfilesTable",
    value: function renderProfilesTable() {
      if (!this.state.profiles.length) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "text-center"
        }, this.props.namespace === services_global_constants__WEBPACK_IMPORTED_MODULE_19__["SYSTEM_NAMESPACE"] ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".ListView.noProfilesSystem")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"], {
          to: '/ns/system/profiles/create'
        }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".ListView.createOne")))) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".ListView.noProfiles")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"], {
          to: "/ns/".concat(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__["getCurrentNamespace"])(), "/profiles/create")
        }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".ListView.createOne")))));
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-wrapper"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid grid-container"
      }, this.renderProfilesTableHeader(), this.renderProfilesTableBody()));
    }
  }, {
    key: "renderSortIcon",
    value: function renderSortIcon(field) {
      if (field !== this.state.sortColumn) {
        return null;
      }

      return this.state.sortMethod === SORT_METHODS.asc ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
        name: "icon-caret-down"
      }) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
        name: "icon-caret-up"
      });
    }
  }, {
    key: "renderProfilesTableHeader",
    value: function renderProfilesTableHeader() {
      var _this3 = this;

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-header"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-row sub-header"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "sub-title"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".ListView.pipelineUsage"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-row"
      }, PROFILES_TABLE_HEADERS.map(function (header, i) {
        if (header.property) {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", {
            className: classnames__WEBPACK_IMPORTED_MODULE_5___default()('sortable-header', {
              active: _this3.state.sortColumn === header.property
            }),
            key: i,
            onClick: _this3.handleProfilesSort.bind(_this3, header.property)
          }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, header.label), _this3.renderSortIcon(header.property));
        }

        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", {
          key: i
        }, header.label);
      })));
    }
  }, {
    key: "renderProfilesTableBody",
    value: function renderProfilesTableBody() {
      var profiles = _toConsumableArray(this.state.profiles);

      if (!this.state.viewAll && profiles.length > NUM_PROFILES_TO_SHOW) {
        profiles = profiles.slice(0, NUM_PROFILES_TO_SHOW);
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-body"
      }, profiles.map(this.renderProfilerow));
    }
  }, {
    key: "renderDeleteConfirmationModal",
    value: function renderDeleteConfirmationModal() {
      if (!this.state.profileToDelete) {
        return null;
      }

      var confirmationText = i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".common.deleteConfirmation"), {
        profile: this.state.profileToDelete.name
      });
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_10__["default"], {
        headerTitle: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".common.deleteTitle")),
        toggleModal: this.toggleDeleteConfirmationModal.bind(this, null),
        confirmationText: confirmationText,
        confirmButtonText: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate('commons.delete'),
        confirmFn: this.deleteProfile.bind(this, this.state.profileToDelete),
        cancelFn: this.toggleDeleteConfirmationModal.bind(this, null),
        isOpen: this.state.profileToDelete !== null,
        errorMessage: this.state.deleteErrMsg,
        extendedMessage: this.state.extendedDeleteErrMsg
      });
    }
  }, {
    key: "renderError",
    value: function renderError() {
      if (!this.props.error) {
        return null;
      }

      var error = this.props.error.response || this.props.error;
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Alert__WEBPACK_IMPORTED_MODULE_14__["default"], {
        message: error,
        type: "error",
        showAlert: true,
        onClose: components_Cloud_Profiles_Store_ActionCreator__WEBPACK_IMPORTED_MODULE_12__["setError"]
      });
    }
  }, {
    key: "render",
    value: function render() {
      if (this.props.loading) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "text-center"
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_LoadingSVG__WEBPACK_IMPORTED_MODULE_7__["default"], null));
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "profiles-list-view"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_ViewAllLabel__WEBPACK_IMPORTED_MODULE_9__["default"], {
        arrayToLimit: this.state.profiles,
        limit: NUM_PROFILES_TO_SHOW,
        viewAllState: this.state.viewAll,
        toggleViewAll: this.toggleViewAll
      }), this.renderProfilesTable(), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_ViewAllLabel__WEBPACK_IMPORTED_MODULE_9__["default"], {
        arrayToLimit: this.state.profiles,
        limit: NUM_PROFILES_TO_SHOW,
        viewAllState: this.state.viewAll,
        toggleViewAll: this.toggleViewAll
      }), this.renderDeleteConfirmationModal(), this.renderError());
    }
  }]);

  return ProfilesListView;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(ProfilesListView, "propTypes", {
  namespace: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  profiles: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array,
  defaultProfile: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  newProfile: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  error: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.any,
  loading: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
});

var mapStateToProps = function mapStateToProps(state) {
  return {
    profiles: state.profiles,
    defaultProfile: state.defaultProfile,
    newProfile: state.newProfile,
    loading: state.loading,
    error: state.error
  };
};

var ConnectedProfilesListView = Object(react_redux__WEBPACK_IMPORTED_MODULE_13__["connect"])(mapStateToProps)(ProfilesListView);
function ProfilesListViewFn(props) {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_redux__WEBPACK_IMPORTED_MODULE_13__["Provider"], {
    store: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_11__["default"]
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(ConnectedProfilesListView, props));
}

/***/ }),

/***/ "./components/Cloud/Profiles/Store/ActionCreator.js":
/*!**********************************************************!*\
  !*** ./components/Cloud/Profiles/Store/ActionCreator.js ***!
  \**********************************************************/
/*! exports provided: getProfileMetricsBody, ONEDAYMETRICKEY, OVERALLMETRICKEY, fetchAggregateProfileMetrics, getProfiles, exportProfile, deleteProfile, importProfile, setError, resetProfiles, getProvisionerLabel, extractProfileName, getProfileNameWithScope, isSystemProfile, getDefaultProfile, setDefaultProfile, highlightNewProfile, getNodeHours */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getProfileMetricsBody", function() { return getProfileMetricsBody; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ONEDAYMETRICKEY", function() { return ONEDAYMETRICKEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OVERALLMETRICKEY", function() { return OVERALLMETRICKEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchAggregateProfileMetrics", function() { return fetchAggregateProfileMetrics; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getProfiles", function() { return getProfiles; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportProfile", function() { return exportProfile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deleteProfile", function() { return deleteProfile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "importProfile", function() { return importProfile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setError", function() { return setError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetProfiles", function() { return resetProfiles; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getProvisionerLabel", function() { return getProvisionerLabel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "extractProfileName", function() { return extractProfileName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getProfileNameWithScope", function() { return getProfileNameWithScope; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSystemProfile", function() { return isSystemProfile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDefaultProfile", function() { return getDefaultProfile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setDefaultProfile", function() { return setDefaultProfile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "highlightNewProfile", function() { return highlightNewProfile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getNodeHours", function() { return getNodeHours; });
/* harmony import */ var components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! components/Cloud/Profiles/Store */ "./components/Cloud/Profiles/Store/index.js");
/* harmony import */ var api_cloud__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! api/cloud */ "./api/cloud.js");
/* harmony import */ var api_preference__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/preference */ "./api/preference.js");
/* harmony import */ var js_file_download__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! js-file-download */ "../../node_modules/js-file-download/file-download.js");
/* harmony import */ var js_file_download__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(js_file_download__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var api_metric__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! api/metric */ "./api/metric.js");
/* harmony import */ var api_search__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! api/search */ "./api/search.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash/isNil */ "../../node_modules/lodash/isNil.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_isNil__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */













var getProfileMetricsBody = function getProfileMetricsBody(queryId, namespace, profilescope, startTime, endTime) {
  var extraTags = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : {};

  var tags = _objectSpread({
    profilescope: profilescope
  }, extraTags);

  if (namespace !== services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SYSTEM_NAMESPACE"]) {
    tags.namespace = namespace;
  }

  var metricBody = _defineProperty({}, queryId, {
    tags: tags,
    metrics: ['system.program.completed.runs', 'system.program.failed.runs', 'system.program.killed.runs', 'system.program.node.minutes'],
    timeRange: {
      start: startTime,
      end: endTime,
      resolution: 'auto'
    },
    groupBy: ['profile']
  });

  if (!startTime && !endTime) {
    metricBody = _objectSpread({}, metricBody, _defineProperty({}, queryId, _objectSpread({}, metricBody[queryId], {
      timeRange: _objectSpread({}, metricBody[queryId].timeRange, {
        resolution: '1h',
        aggregate: true
      })
    })));
  }

  return metricBody;
};

var convertMetadataToAssociations = function convertMetadataToAssociations(metadata) {
  var schedulesCount = 0,
      triggersCount = 0;
  metadata.forEach(function (m) {
    var schedule = Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(m, 'entity', 'details', 'schedule');

    if (schedule) {
      // fixed name for time based schedule.
      if (schedule === services_global_constants__WEBPACK_IMPORTED_MODULE_6__["GLOBALS"].defaultScheduleId) {
        schedulesCount += 1;
      } else {
        triggersCount += 1;
      }
    }
  });
  return {
    schedulesCount: schedulesCount,
    triggersCount: triggersCount
  };
};

var updateScheduleAndTriggersToStore = function updateScheduleAndTriggersToStore(profileName, metadata) {
  var _convertMetadataToAss = convertMetadataToAssociations(metadata),
      schedulesCount = _convertMetadataToAss.schedulesCount,
      triggersCount = _convertMetadataToAss.triggersCount;

  components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["PROFILES_ACTIONS"].SET_SCHEDULES_TRIGGERS_COUNT,
    payload: {
      profile: profileName,
      schedulesCount: schedulesCount,
      triggersCount: triggersCount
    }
  });
};

var ONEDAYMETRICKEY = 'oneDayMetrics';
var OVERALLMETRICKEY = 'overAllMetrics';
var fetchAggregateProfileMetrics = function fetchAggregateProfileMetrics(namespace, profile, extraTags) {
  var oneDayMetricsRequestBody = getProfileMetricsBody(ONEDAYMETRICKEY, namespace, profile.scope, 'now-24h', 'now', extraTags);
  var overAllMetricsRequestBody = getProfileMetricsBody(OVERALLMETRICKEY, namespace, profile.scope, 0, 0, extraTags);
  return api_metric__WEBPACK_IMPORTED_MODULE_7__["MyMetricApi"].query(null, _objectSpread({}, oneDayMetricsRequestBody, {}, overAllMetricsRequestBody)).flatMap(function (metrics) {
    var _metricsMap;

    var metricsMap = (_metricsMap = {}, _defineProperty(_metricsMap, ONEDAYMETRICKEY, {
      runs: '--',
      minutes: '--'
    }), _defineProperty(_metricsMap, OVERALLMETRICKEY, {
      runs: '--',
      minutes: '--'
    }), _metricsMap);
    Object.keys(metrics).forEach(function (query) {
      metrics[query].series.forEach(function (metric) {
        var metricName = metric.metricName.split('.').pop();
        var metricValue;

        if (!metric.data.length) {
          metricValue = 0;
        } else {
          if (metric.data.length === 1) {
            metricValue = metric.data[0].value;
          } else {
            metricValue = metric.data.reduce(function (prev, curr) {
              return prev + curr.value;
            }, 0);
          }
        }

        if (!Object.prototype.hasOwnProperty.call(metricsMap, query)) {
          metricsMap[query] = {};
        }

        if (metricsMap[query][metricName] !== '--' && !lodash_isNil__WEBPACK_IMPORTED_MODULE_9___default()(metricsMap[query][metricName])) {
          metricsMap[query][metricName] += metricValue;
        } else {
          metricsMap[query] = _objectSpread({}, metricsMap[query], _defineProperty({}, metricName, metricValue));
        }
      });
    });
    return rxjs_Observable__WEBPACK_IMPORTED_MODULE_5__["Observable"].create(function (observer) {
      observer.next(metricsMap);
    });
  });
};
var getProfiles = function getProfiles(namespace) {
  components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["PROFILES_ACTIONS"].SET_LOADING,
    payload: {
      loading: true
    }
  });
  var profileObservable = api_cloud__WEBPACK_IMPORTED_MODULE_1__["MyCloudApi"].getSystemProfiles();

  if (namespace !== services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SYSTEM_NAMESPACE"]) {
    profileObservable = profileObservable.combineLatest(api_cloud__WEBPACK_IMPORTED_MODULE_1__["MyCloudApi"].list({
      namespace: namespace
    }));
  } else {
    profileObservable = profileObservable.combineLatest(rxjs_Observable__WEBPACK_IMPORTED_MODULE_5__["Observable"].of([]));
  }

  profileObservable.subscribe(function (_ref) {
    var _ref2 = _slicedToArray(_ref, 2),
        _ref2$ = _ref2[0],
        systemProfiles = _ref2$ === void 0 ? [] : _ref2$,
        _ref2$2 = _ref2[1],
        namespaceProfiles = _ref2$2 === void 0 ? [] : _ref2$2;

    var filteredSystemProfiles = systemProfiles;

    if (services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__["Theme"].showNativeProfile === false) {
      filteredSystemProfiles = systemProfiles.filter(function (profile) {
        return profile.name !== 'native';
      });
    }

    var profiles = namespaceProfiles.concat(filteredSystemProfiles).map(function (profile) {
      return _objectSpread({}, profile, {
        oneDayMetrics: {},
        overAllMetrics: {},
        schedulesCount: '--',
        triggersCount: '--'
      });
    });
    components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["PROFILES_ACTIONS"].SET_PROFILES,
      payload: {
        profiles: profiles
      }
    });
    /*
          One metric call with 4 different queries
            Context: namespace, profile scope
            Groupby: profile
            TimeRange:
              - USER scope
                - 24hrs
                - full entirety
              - SYSTEM scope
                - 24hrs
                - full entirety
             One metadata call for entityScope=USER for schedules and triggers count
        */

    var extraTags = {
      programtype: 'Workflow'
    };
    var oneDayUSERMetricsBody = getProfileMetricsBody('oneDayUSERMetrics', namespace, services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].USER, 'now-24h', 'now', extraTags);
    var overAllUSERMetricsBody = getProfileMetricsBody('overAllUSERMetrics', namespace, services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].USER, 0, 0, extraTags);
    var oneDaySYSTEMMetricsBody = getProfileMetricsBody('oneDaySYSTEMMetrics', namespace, services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].SYSTEM, 'now-24h', 'now', extraTags);
    var overAllSYSTEMMetricsBody = getProfileMetricsBody('overAllSYSTEMMetrics', namespace, services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].SYSTEM, 0, 0, extraTags);
    api_metric__WEBPACK_IMPORTED_MODULE_7__["MyMetricApi"].query(null, _objectSpread({}, oneDayUSERMetricsBody, {}, overAllUSERMetricsBody, {}, oneDaySYSTEMMetricsBody, {}, overAllSYSTEMMetricsBody)).subscribe(function (metrics) {
      var profilesToMetricsMap = {};
      Object.keys(metrics).forEach(function (query) {
        // oneDayMetrics, overMetrics are the keys for metrics for each profile.
        var profileScope = query.indexOf(services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].USER) !== -1 ? services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].USER : services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].SYSTEM;
        var metricsKey = query.replace(/USER|SYSTEM/, '');
        metrics[query].series.forEach(function (metric) {
          var profileName = metric.grouping.profile;
          /*
                  The map index cannot be just profile name as
                  two different profiles (in user and system scopes)
                  can have the same name. This will overwrite the one from the other scope.
                  Hence the addition of scope to make sure the metrics are not overwritten.
                */

          var profileKey = "".concat(profileScope, ":").concat(profileName);
          var metricName = metric.metricName.split('.').pop();
          var metricValue;

          if (!metric.data.length) {
            metricValue = 0;
          } else {
            if (metric.data.length === 1) {
              metricValue = metric.data[0].value;
            } else {
              metricValue = metric.data.reduce(function (prev, curr) {
                return prev + curr.value;
              }, 0);
            }
          }

          if (!Object.prototype.hasOwnProperty.call(profilesToMetricsMap, profileKey)) {
            profilesToMetricsMap[profileKey] = _defineProperty({}, metricsKey, {});
          }

          if (!lodash_isNil__WEBPACK_IMPORTED_MODULE_9___default()(Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(profilesToMetricsMap, profileKey, metricsKey, metricName))) {
            metricValue += profilesToMetricsMap[profileKey][metricsKey][metricName];
          }
          /*
                  {
                    SYSTEM:profile1: {
                      oneDayMetrics: {
                        runs: 1,
                        minutes: 2
                      },
                      overAllMetrics: {
                        runs: 2,
                        minutes: 4
                      }
                    }
                  }
                */


          profilesToMetricsMap[profileKey] = _objectSpread({}, profilesToMetricsMap[profileKey], _defineProperty({}, metricsKey, _objectSpread({}, profilesToMetricsMap[profileKey][metricsKey], _defineProperty({}, metricName, metricValue))));
        });
      });
      components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
        type: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["PROFILES_ACTIONS"].SET_PROFILE_METRICS,
        payload: {
          profilesToMetricsMap: profilesToMetricsMap
        }
      });
    });
    profiles.forEach(function (profile) {
      var scope = profile.scope;
      var profileName = "profile:".concat(scope, ":").concat(profile.name);
      var apiObservable$;

      if (namespace === services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SYSTEM_NAMESPACE"]) {
        apiObservable$ = api_search__WEBPACK_IMPORTED_MODULE_8__["MySearchApi"].searchSystem({
          query: profileName,
          responseFormat: 'v6'
        });
      } else {
        apiObservable$ = api_search__WEBPACK_IMPORTED_MODULE_8__["MySearchApi"].search({
          namespace: namespace,
          query: profileName,
          responseFormat: 'v6'
        });
      }

      apiObservable$.subscribe(function (res) {
        return updateScheduleAndTriggersToStore(profile.name, res.results);
      });
    });
  }, setError);
};
var exportProfile = function exportProfile(namespace, profile) {
  var apiObservable$ = api_cloud__WEBPACK_IMPORTED_MODULE_1__["MyCloudApi"].get({
    namespace: namespace,
    profile: profile.name
  });

  if (namespace === services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SYSTEM_NAMESPACE"]) {
    apiObservable$ = api_cloud__WEBPACK_IMPORTED_MODULE_1__["MyCloudApi"].getSystemProfile({
      profile: profile.name
    });
  }

  apiObservable$.subscribe(function (res) {
    var json = JSON.stringify(res, null, 2);
    var fileName = "".concat(profile.name, "-").concat(profile.provisioner.name, "-profile.json");
    js_file_download__WEBPACK_IMPORTED_MODULE_3___default()(json, fileName);
  }, setError);
};
var deleteProfile = function deleteProfile(namespace, profile, currentNamespace) {
  var deleteObservable$;

  if (namespace === services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SYSTEM_NAMESPACE"]) {
    deleteObservable$ = api_cloud__WEBPACK_IMPORTED_MODULE_1__["MyCloudApi"].deleteSystemProfile({
      profile: profile
    });
  } else {
    deleteObservable$ = api_cloud__WEBPACK_IMPORTED_MODULE_1__["MyCloudApi"]["delete"]({
      namespace: namespace,
      profile: profile
    });
  }

  deleteObservable$.subscribe(function () {
    getProfiles(currentNamespace);
  }, function (err) {
    rxjs_Observable__WEBPACK_IMPORTED_MODULE_5__["Observable"]["throw"](err);
  });
  return deleteObservable$;
};
var importProfile = function importProfile(namespace, e) {
  if (!Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(e, 'target', 'files', 0)) {
    return;
  }

  var uploadedFile = e.target.files[0];
  var reader = new FileReader();
  reader.readAsText(uploadedFile, 'UTF-8');

  reader.onload = function (evt) {
    var jsonSpec = evt.target.result;

    try {
      jsonSpec = JSON.parse(jsonSpec);
    } catch (error) {
      components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
        type: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["PROFILES_ACTIONS"].SET_ERROR,
        payload: {
          error: error.message || error
        }
      });
      return;
    }

    var apiObservable$ = api_cloud__WEBPACK_IMPORTED_MODULE_1__["MyCloudApi"].create({
      namespace: namespace,
      profile: jsonSpec.name
    }, jsonSpec);

    if (namespace === services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SYSTEM_NAMESPACE"]) {
      apiObservable$ = api_cloud__WEBPACK_IMPORTED_MODULE_1__["MyCloudApi"].createSystemProfile({
        profile: jsonSpec.name
      }, jsonSpec);
    }

    apiObservable$.subscribe(function () {
      getProfiles(namespace);
      var profilePrefix = namespace === services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SYSTEM_NAMESPACE"] ? services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].SYSTEM : services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].USER;
      var profileName = "".concat(profilePrefix, ":").concat(jsonSpec.name);
      highlightNewProfile(profileName);
    }, function (error) {
      components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
        type: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["PROFILES_ACTIONS"].SET_ERROR,
        payload: {
          error: error.response || error
        }
      });
    });
  };
};
var setError = function setError() {
  var error = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
  components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["PROFILES_ACTIONS"].SET_ERROR,
    payload: {
      error: error
    }
  });
};
var resetProfiles = function resetProfiles() {
  components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["PROFILES_ACTIONS"].RESET
  });
};
var getProvisionerLabel = function getProvisionerLabel(profile, provisioners) {
  if (provisioners.length) {
    var matchingProvisioner = provisioners.find(function (prov) {
      return prov.name === profile.provisioner.name;
    });

    if (matchingProvisioner) {
      return matchingProvisioner.label;
    }
  }

  return profile.provisioner.name;
};
var extractProfileName = function extractProfileName() {
  var name = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  return name.replace(/(USER|SYSTEM):/g, '');
};
var getProfileNameWithScope = function getProfileNameWithScope() {
  var name = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  var scope = arguments.length > 1 ? arguments[1] : undefined;

  if (name && scope) {
    if (scope === services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].SYSTEM) {
      return "".concat(services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].SYSTEM, ":").concat(name);
    }

    return "".concat(services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SCOPES"].USER, ":").concat(name);
  }

  return name;
};
var isSystemProfile = function isSystemProfile() {
  var name = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  return name.indexOf('SYSTEM:') === 0;
};
var getDefaultProfile = function getDefaultProfile(namespace) {
  var preferenceApi;

  if (namespace === services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SYSTEM_NAMESPACE"]) {
    preferenceApi = api_preference__WEBPACK_IMPORTED_MODULE_2__["MyPreferenceApi"].getSystemPreferences();
  } else {
    preferenceApi = api_preference__WEBPACK_IMPORTED_MODULE_2__["MyPreferenceApi"].getNamespacePreferences({
      namespace: namespace
    });
  }

  preferenceApi.subscribe(function () {
    var preferences = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var defaultProfile = preferences[services_global_constants__WEBPACK_IMPORTED_MODULE_6__["CLOUD"].PROFILE_NAME_PREFERENCE_PROPERTY];

    if (!defaultProfile && namespace === services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SYSTEM_NAMESPACE"]) {
      defaultProfile = services_global_constants__WEBPACK_IMPORTED_MODULE_6__["CLOUD"].DEFAULT_PROFILE_NAME;
    }

    if (defaultProfile) {
      components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
        type: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["PROFILES_ACTIONS"].SET_DEFAULT_PROFILE,
        payload: {
          defaultProfile: defaultProfile
        }
      });
    }
  }, setError);
};
var setDefaultProfile = function setDefaultProfile(namespace, profileName) {
  function successCallback() {
    components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["PROFILES_ACTIONS"].SET_DEFAULT_PROFILE,
      payload: {
        defaultProfile: profileName
      }
    });
  }

  function createPostBody() {
    var existingPreferences = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    var postBody = _defineProperty({}, services_global_constants__WEBPACK_IMPORTED_MODULE_6__["CLOUD"].PROFILE_NAME_PREFERENCE_PROPERTY, profileName);

    return _objectSpread({}, existingPreferences, {}, postBody);
  }

  if (namespace === services_global_constants__WEBPACK_IMPORTED_MODULE_6__["SYSTEM_NAMESPACE"]) {
    api_preference__WEBPACK_IMPORTED_MODULE_2__["MyPreferenceApi"].getSystemPreferences().subscribe(function () {
      var preferences = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      api_preference__WEBPACK_IMPORTED_MODULE_2__["MyPreferenceApi"].setSystemPreferences({}, createPostBody(preferences)).subscribe(successCallback, setError);
    }, setError);
  } else {
    var params = {
      namespace: namespace
    };
    api_preference__WEBPACK_IMPORTED_MODULE_2__["MyPreferenceApi"].getNamespacePreferences(params).subscribe(function () {
      var preferences = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      api_preference__WEBPACK_IMPORTED_MODULE_2__["MyPreferenceApi"].setNamespacePreferences(params, createPostBody(preferences)).subscribe(successCallback, setError);
    });
  }
};
var highlightNewProfile = function highlightNewProfile(profileName) {
  components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["PROFILES_ACTIONS"].SET_NEW_PROFILE,
    payload: {
      newProfile: profileName
    }
  });
  setTimeout(function () {
    components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Cloud_Profiles_Store__WEBPACK_IMPORTED_MODULE_0__["PROFILES_ACTIONS"].SET_NEW_PROFILE,
      payload: {
        newProfile: null
      }
    });
  }, 3000);
};
var getNodeHours = function getNodeHours(nodeminutes) {
  if (typeof nodeminutes === 'number') {
    var nodeHours = nodeminutes / 60;
    return typeof nodeHours.toFixed === 'function' ? nodeHours.toFixed(2) : nodeHours;
  }

  return nodeminutes;
};

/***/ }),

/***/ "./components/Cloud/Profiles/Store/Provisioners.js":
/*!*********************************************************!*\
  !*** ./components/Cloud/Profiles/Store/Provisioners.js ***!
  \*********************************************************/
/*! exports provided: fetchProvisioners, getProvisionersMap, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchProvisioners", function() { return fetchProvisioners; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getProvisionersMap", function() { return getProvisionersMap; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var api_cloud__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/cloud */ "./api/cloud.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/isEmpty */ "../../node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_4__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var ACTIONS = {
  SAVE_PROVISIONERS: 'SAVE_PROVISIONERS'
};
var DEFAULT_STATE = {
  nameToLabelMap: {},
  list: []
};
var fetchProvisioners = function fetchProvisioners() {
  var returnObservable$ = api_cloud__WEBPACK_IMPORTED_MODULE_2__["MyCloudApi"].getProvisioners();
  returnObservable$.subscribe(function (provisioners) {
    store.dispatch({
      type: ACTIONS.SAVE_PROVISIONERS,
      payload: {
        provisioners: provisioners
      }
    });
  }, function (err) {
    console.log('Fetching provisioners failed: ', err);
  });
  return returnObservable$;
};

var provisioners = function provisioners() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_STATE;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ACTIONS.SAVE_PROVISIONERS:
      {
        var _provisioners = action.payload.provisioners;
        var provisionersMap = {};

        _provisioners.forEach(function (provisioner) {
          provisionersMap[provisioner.name] = provisioner.label;
        });

        return {
          nameToLabelMap: provisionersMap,
          list: _provisioners
        };
      }

    default:
      return state;
  }
};

var getProvisionersMap = function getProvisionersMap() {
  var _store$getState = store.getState(),
      list = _store$getState.list;

  var observableReturn = function observableReturn() {
    return rxjs_Observable__WEBPACK_IMPORTED_MODULE_4__["Observable"].create(function (observer) {
      observer.next(store.getState());
    });
  };

  if (lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default()(list)) {
    return fetchProvisioners().flatMap(observableReturn);
  } else {
    return observableReturn();
  }
};
var store = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(provisioners, DEFAULT_STATE, Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["composeEnhancers"])('ProvisionersMapStore')());
/* harmony default export */ __webpack_exports__["default"] = (store);

/***/ }),

/***/ "./components/Cloud/Profiles/Store/index.js":
/*!**************************************************!*\
  !*** ./components/Cloud/Profiles/Store/index.js ***!
  \**************************************************/
/*! exports provided: default, PROFILES_ACTIONS, PROFILE_STATUSES */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PROFILES_ACTIONS", function() { return PROFILES_ACTIONS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PROFILE_STATUSES", function() { return PROFILE_STATUSES; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var PROFILES_ACTIONS = {
  SET_PROFILES: 'SET_PROFILES',
  SET_DEFAULT_PROFILE: 'SET_DEFAULT_PROFILE',
  SET_NEW_PROFILE: 'SET_NEW_PROFILE',
  SET_PROFILE_METRICS: 'SET_PROFILE_METRICS',
  SET_SCHEDULES_TRIGGERS_COUNT: 'SET_SCHEDULES_TRIGGERS_COUNT',
  SET_LOADING: 'SET_LOADING',
  SET_ERROR: 'SET_ERROR',
  RESET: 'RESET'
};
var DEFAULT_PROFILES_STATE = {
  profiles: [],
  defaultProfile: null,
  newProfile: '',
  loading: false,
  error: null
};
var PROFILE_STATUSES = {
  ENABLED: 'enabled',
  DISABLED: 'disabled'
};

var profiles = function profiles() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_PROFILES_STATE;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case PROFILES_ACTIONS.SET_PROFILES:
      return _objectSpread({}, state, {
        profiles: action.payload.profiles,
        error: null,
        loading: false
      });

    case PROFILES_ACTIONS.SET_PROFILE_METRICS:
      {
        var profilesToMetricsMap = action.payload.profilesToMetricsMap;
        var _profiles = state.profiles;
        _profiles = _profiles.map(function (profile) {
          var metricObj = {
            runs: '--',
            minutes: '--'
          };
          var profileKey = "".concat(profile.scope, ":").concat(profile.name);
          var profileMetrics = profilesToMetricsMap[profileKey] || {};
          /*
            We are adding empty oneday and overall metrics AND metrics from backend
            as we are not sure UI will get all metrics from backend. This will give
            a default value of '--' for those that are unavailable.
          */

          return _objectSpread({}, profile, {
            oneDayMetrics: metricObj,
            overAllMetrics: metricObj
          }, profileMetrics);
        });
        return _objectSpread({}, state, {
          profiles: _profiles
        });
      }

    case PROFILES_ACTIONS.SET_SCHEDULES_TRIGGERS_COUNT:
      {
        var _action$payload = action.payload,
            profileToUpdate = _action$payload.profile,
            schedulesCount = _action$payload.schedulesCount,
            triggersCount = _action$payload.triggersCount;
        var _profiles2 = state.profiles;
        _profiles2 = _profiles2.map(function (profile) {
          if (profile.name === profileToUpdate) {
            return _objectSpread({}, profile, {
              schedulesCount: schedulesCount,
              triggersCount: triggersCount
            });
          }

          return profile;
        });
        return _objectSpread({}, state, {
          profiles: _profiles2
        });
      }

    case PROFILES_ACTIONS.SET_DEFAULT_PROFILE:
      return _objectSpread({}, state, {
        defaultProfile: action.payload.defaultProfile
      });

    case PROFILES_ACTIONS.SET_NEW_PROFILE:
      return _objectSpread({}, state, {
        newProfile: action.payload.newProfile
      });

    case PROFILES_ACTIONS.SET_LOADING:
      return _objectSpread({}, state, {
        error: null,
        loading: action.payload.loading
      });

    case PROFILES_ACTIONS.SET_ERROR:
      return _objectSpread({}, state, {
        error: action.payload.error,
        loading: false
      });

    case PROFILES_ACTIONS.RESET:
      return DEFAULT_PROFILES_STATE;

    default:
      return state;
  }
};

var ProfilesStore = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(profiles, DEFAULT_PROFILES_STATE, Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["composeEnhancers"])('ProfilesStore')());
/* harmony default export */ __webpack_exports__["default"] = (ProfilesStore);


/***/ }),

/***/ "./components/RenderObjectAsTable/index.js":
/*!*************************************************!*\
  !*** ./components/RenderObjectAsTable/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */



var RenderObjectAsTable = function RenderObjectAsTable(_ref) {
  var obj = _ref.obj;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("table", {
    className: "table-borderless"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tbody", null, Object.keys(obj).map(function (node, i) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
      key: i
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, node), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, obj[node]));
  })));
};

RenderObjectAsTable.propTypes = {
  obj: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
};
/* harmony default export */ __webpack_exports__["default"] = (RenderObjectAsTable);

/***/ }),

/***/ "./components/SortableStickyGrid/SortableStickyGrid.scss":
/*!***************************************************************!*\
  !*** ./components/SortableStickyGrid/SortableStickyGrid.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./SortableStickyGrid.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SortableStickyGrid/SortableStickyGrid.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SortableStickyGrid/index.js":
/*!************************************************!*\
  !*** ./components/SortableStickyGrid/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SortableStickyGrid; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash/orderBy */ "../../node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash/isEqual */ "../../node_modules/lodash/isEqual.js");
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_isEqual__WEBPACK_IMPORTED_MODULE_7__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









__webpack_require__(/*! ./SortableStickyGrid.scss */ "./components/SortableStickyGrid/SortableStickyGrid.scss");

var SORT_ORDERS = {
  asc: 'asc',
  desc: 'desc'
};

var SortableStickyGrid =
/*#__PURE__*/
function (_Component) {
  _inherits(SortableStickyGrid, _Component);

  function SortableStickyGrid(props) {
    var _this;

    _classCallCheck(this, SortableStickyGrid);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(SortableStickyGrid).call(this, props));

    _defineProperty(_assertThisInitialized(_this), "handleSort", function (property) {
      var newSortProperty, newSortOrder;

      if (_this.state.sortProperty === property) {
        newSortProperty = _this.state.sortProperty;
        newSortOrder = _this.state.sortOrder === SORT_ORDERS.asc ? SORT_ORDERS.desc : SORT_ORDERS.asc;
      } else {
        newSortProperty = property;
        newSortOrder = SORT_ORDERS.asc;
      }

      _this.setState({
        sortProperty: newSortProperty,
        sortOrder: newSortOrder,
        entities: lodash_orderBy__WEBPACK_IMPORTED_MODULE_5___default()(_this.state.entities, [newSortProperty], [newSortOrder])
      });
    });

    var sortProperty = props.defaultSortProperty || Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(props.gridHeaders, 0, 'property');
    var sortOrder = SORT_ORDERS.asc;
    _this.state = {
      entities: lodash_orderBy__WEBPACK_IMPORTED_MODULE_5___default()(props.entities, [sortProperty], [sortOrder]),
      sortProperty: sortProperty,
      sortOrder: sortOrder
    };
    return _this;
  }

  _createClass(SortableStickyGrid, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (!lodash_isEqual__WEBPACK_IMPORTED_MODULE_7___default()(this.props.entities, nextProps.entities)) {
        this.setState({
          entities: lodash_orderBy__WEBPACK_IMPORTED_MODULE_5___default()(nextProps.entities, [this.state.sortProperty], [this.state.sortOrder])
        });
      }
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      var highlightedElems = document.getElementsByClassName('highlighted');

      if (highlightedElems.length) {
        highlightedElems[0].scrollIntoView();
      }
    }
  }, {
    key: "renderSortIcon",
    value: function renderSortIcon(property) {
      if (property !== this.state.sortProperty) {
        return null;
      }

      return this.state.sortOrder === SORT_ORDERS.asc ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-caret-down"
      }) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-caret-up"
      });
    }
  }, {
    key: "renderGridHeader",
    value: function renderGridHeader() {
      var _this2 = this;

      if (this.props.renderGridHeader) {
        return this.props.renderGridHeader();
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-header"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-row"
      }, this.props.gridHeaders.map(function (header) {
        if (header.property) {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", {
            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('sortable-header', {
              active: _this2.state.sortProperty === header.property
            }),
            key: uuid_v4__WEBPACK_IMPORTED_MODULE_3___default()(),
            onClick: _this2.handleSort.bind(_this2, header.property)
          }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, header.label), _this2.renderSortIcon(header.property));
        }

        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", {
          key: uuid_v4__WEBPACK_IMPORTED_MODULE_3___default()()
        }, header.label);
      })));
    }
  }, {
    key: "renderGridBody",
    value: function renderGridBody() {
      var _this3 = this;

      if (this.props.renderGridBody) {
        return this.props.renderGridBody(this.state.entities);
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-body"
      }, this.state.entities.map(function (entity) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('grid-row', {
            'grid-link': _this3.props.cellIsClickable,
            highlighted: entity.highlighted
          }),
          key: uuid_v4__WEBPACK_IMPORTED_MODULE_3___default()()
        }, _this3.props.gridHeaders.map(function (header) {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
            key: uuid_v4__WEBPACK_IMPORTED_MODULE_3___default()()
          }, entity[header.property]);
        }));
      }));
    }
  }, {
    key: "render",
    value: function render() {
      var gridClasses = classnames__WEBPACK_IMPORTED_MODULE_1___default()('grid-wrapper sortable-sticky-grid', this.props.className);
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: gridClasses
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('grid grid-container', {
          'grid-sm': this.props.size === 'small'
        })
      }, this.renderGridHeader(), this.renderGridBody()));
    }
  }]);

  return SortableStickyGrid;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(SortableStickyGrid, "propTypes", {
  entities: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.object).isRequired,
  gridHeaders: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.shape({
    label: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    property: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string
  })),
  renderGridHeader: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func,
  renderGridBody: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func,
  className: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  cellIsClickable: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool,
  defaultSortProperty: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  size: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string
});

_defineProperty(SortableStickyGrid, "defaultProps", {
  cellIsClickable: false
});



/***/ }),

/***/ "./components/SortableStickyTable/index.js":
/*!*************************************************!*\
  !*** ./components/SortableStickyTable/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SortableStickyTable; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_SortableTable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/SortableTable */ "./components/SortableTable/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var SortableStickyTable =
/*#__PURE__*/
function (_SortableTable) {
  _inherits(SortableStickyTable, _SortableTable);

  function SortableStickyTable(props) {
    _classCallCheck(this, SortableStickyTable);

    return _possibleConstructorReturn(this, _getPrototypeOf(SortableStickyTable).call(this, props));
  }

  _createClass(SortableStickyTable, [{
    key: "renderTableHeader",
    value: function renderTableHeader() {
      var _this = this;

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("thead", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tr", null, this.props.tableHeaders.map(function (tableHeader, i) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("th", {
          key: i
        }, tableHeader.property ? _this.renderSortableTableHeader(tableHeader) : tableHeader.label);
      })));
    }
  }, {
    key: "render",
    value: function render() {
      var tableClasses = classnames__WEBPACK_IMPORTED_MODULE_2___default()('table', this.props.className);
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "table-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("table", {
        className: tableClasses
      }, this.renderTableHeader()), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "table-scroll"
      }, this.props.renderTableBody(this.state.entities)));
    }
  }]);

  return SortableStickyTable;
}(components_SortableTable__WEBPACK_IMPORTED_MODULE_1__["default"]);


SortableStickyTable.propTypes = _objectSpread({}, components_SortableTable__WEBPACK_IMPORTED_MODULE_1__["default"].propTypes);

/***/ }),

/***/ "./components/SortableTable/SortableTable.scss":
/*!*****************************************************!*\
  !*** ./components/SortableTable/SortableTable.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./SortableTable.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SortableTable/SortableTable.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SortableTable/index.js":
/*!*******************************************!*\
  !*** ./components/SortableTable/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SortableTable; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash/orderBy */ "../../node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





__webpack_require__(/*! ./SortableTable.scss */ "./components/SortableTable/SortableTable.scss");

var SortableTable =
/*#__PURE__*/
function (_Component) {
  _inherits(SortableTable, _Component);

  function SortableTable() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SortableTable);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SortableTable)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      entities: _this.props.entities,
      sortByHeader: '',
      sortOrder: 'asc',
      sortOnInitialLoad: typeof _this.props.sortOnInitialLoad !== 'boolean' ? true : _this.props.sortOnInitialLoad
    });

    return _this;
  }

  _createClass(SortableTable, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      if (!this.state.sortOnInitialLoad) {
        return;
      }

      var entities = this.state.entities;
      var sortByHeader = this.getDefaultSortedHeader();
      entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default()(entities, [sortByHeader], [this.state.sortOrder]);
      this.setState({
        entities: entities,
        sortByHeader: sortByHeader
      });
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.setState({
        entities: nextProps.entities
      });
    }
  }, {
    key: "getDefaultSortedHeader",
    value: function getDefaultSortedHeader() {
      var defaultHeader = '';

      for (var i = 0; i < this.props.tableHeaders.length; i++) {
        if (this.props.tableHeaders[i].defaultSortby) {
          defaultHeader = this.props.tableHeaders[i].property;
          break;
        }
      }

      return defaultHeader || this.props.tableHeaders[0].property;
    }
  }, {
    key: "sortBy",
    value: function sortBy(header) {
      var headerProp = header.property;
      var entities = this.state.entities;
      var sortOrder = this.state.sortOrder;
      var sortByHeader = this.state.sortByHeader;

      if (sortByHeader === headerProp) {
        if (sortOrder === 'asc') {
          // already sorting in this column, sort the other way
          sortOrder = 'desc';
        } else {
          sortOrder = 'asc';
        }
      } else {
        // a new sort, so start with ascending sort
        sortByHeader = headerProp;
        sortOrder = 'asc';
      }

      if (header.sortFunc) {
        entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default()(entities, [header.sortFunc], [sortOrder]);
      } else {
        entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default()(entities, [sortByHeader], [sortOrder]);
      }

      this.setState({
        entities: entities,
        sortOrder: sortOrder,
        sortByHeader: sortByHeader
      });
    }
  }, {
    key: "renderSortableTableHeader",
    value: function renderSortableTableHeader(header) {
      if (this.state.sortByHeader !== header.property) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          onClick: this.sortBy.bind(this, header)
        }, header.label);
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        onClick: this.sortBy.bind(this, header)
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "text-underline"
      }, header.label), this.state.sortOrder === 'asc' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
        className: "fa fa-caret-down fa-lg"
      }) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
        className: "fa fa-caret-up fa-lg"
      }));
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var tableClasses = classnames__WEBPACK_IMPORTED_MODULE_3___default()('table', this.props.className);
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("table", {
        className: tableClasses
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("thead", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, this.props.tableHeaders.map(function (tableHeader, i) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
          key: i
        }, tableHeader.property ? _this2.renderSortableTableHeader(tableHeader) : tableHeader.label);
      }))), this.props.renderTableBody(this.state.entities));
    }
  }]);

  return SortableTable;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


SortableTable.propTypes = {
  tableHeaders: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    label: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    property: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    defaultSortby: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
  })),
  renderTableBody: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  entities: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object),
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  sortOnInitialLoad: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
};

/***/ }),

/***/ "./components/ViewAllLabel/ViewAllLabel.scss":
/*!***************************************************!*\
  !*** ./components/ViewAllLabel/ViewAllLabel.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./ViewAllLabel.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/ViewAllLabel/ViewAllLabel.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/ViewAllLabel/index.js":
/*!******************************************!*\
  !*** ./components/ViewAllLabel/index.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ViewAllLabel; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_2__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




__webpack_require__(/*! ./ViewAllLabel.scss */ "./components/ViewAllLabel/ViewAllLabel.scss");

var PREFIX = 'features.ViewAllLabel';
function ViewAllLabel(_ref) {
  var arrayToLimit = _ref.arrayToLimit,
      limit = _ref.limit,
      viewAllState = _ref.viewAllState,
      toggleViewAll = _ref.toggleViewAll;

  if (arrayToLimit.length <= limit) {
    return null;
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "view-all-label-container"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "view-all-label",
    onClick: toggleViewAll
  }, viewAllState ? i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".viewLess")) : i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".viewAll"))));
}
ViewAllLabel.propTypes = {
  arrayToLimit: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array,
  limit: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  viewAllState: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  toggleViewAll: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
};

/***/ }),

/***/ "./services/entity-icon-map/index.js":
/*!*******************************************!*\
  !*** ./services/entity-icon-map/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var EntityIconMap = {
  'cdap-data-pipeline': 'icon-ETLBatch',
  'cdap-data-streams': 'icon-sparkstreaming',
  mapreduce: 'icon-mapreduce',
  service: 'icon-service',
  spark: 'icon-spark',
  worker: 'icon-worker',
  workflow: 'icon-workflow',
  application: 'icon-fist',
  artifact: 'icon-archive',
  dataset: 'icon-datasets',
  view: 'icon-streamview'
};
/* harmony default export */ __webpack_exports__["default"] = (EntityIconMap);

/***/ }),

/***/ "./services/metadata-parser/index.js":
/*!*******************************************!*\
  !*** ./services/metadata-parser/index.js ***!
  \*******************************************/
/*! exports provided: parseMetadata, getType, getCustomAppPipelineDatasetCounts */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseMetadata", function() { return parseMetadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getType", function() { return getType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCustomAppPipelineDatasetCounts", function() { return getCustomAppPipelineDatasetCounts; });
/* harmony import */ var services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/entity-icon-map */ "./services/entity-icon-map/index.js");
/* harmony import */ var lodash_intersection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash/intersection */ "../../node_modules/lodash/intersection.js");
/* harmony import */ var lodash_intersection__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_intersection__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/metadata-parser/EntityType */ "./services/metadata-parser/EntityType.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var SYSTEM_SCOPE = 'SYSTEM';
function parseMetadata(entityObj) {
  var type = entityObj.entity.type;

  switch (type) {
    case services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].artifact:
      return createArtifactObj(entityObj);

    case services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].application:
      return createApplicationObj(entityObj);

    case services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].dataset:
      return createDatasetObj(entityObj);

    case services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].program:
      return createProgramObj(entityObj);
  }
}
function getType(entity) {
  if (entity.type === 'program') {
    return entity.programType.toLowerCase();
  }

  if (entity.type === 'dataset') {
    return 'dataset';
  } else if (entity.type !== 'application') {
    return entity.type;
  }

  if (entity.metadata.metadata.tags.find(function (tag) {
    return tag.name === services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline && tag.scope === SYSTEM_SCOPE;
  })) {
    return services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline;
  } else if (entity.metadata.metadata.tags.find(function (tag) {
    return tag.name === services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams && tag.scope === SYSTEM_SCOPE;
  })) {
    return services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams;
  } else {
    return entity.type;
  }
}
/**
 * TODO:
 * This function should be refactored. It should just return the entities count, and not care about the entity types.
 *
 * https://issues.cask.co/browse/CDAP-14639
 */

function getCustomAppPipelineDatasetCounts(entities) {
  var apps = entities.results.filter(function (entity) {
    return entityIsApp(entity);
  });
  var pipelineCount = apps.filter(function (entity) {
    return entityIsPipeline(entity);
  }).length;
  var customAppCount = apps.length - pipelineCount;
  var datasetCount = entities.results.length - apps.length;
  return {
    pipelineCount: pipelineCount,
    customAppCount: customAppCount,
    datasetCount: datasetCount
  };
}

function entityIsApp(entityObj) {
  return Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(entityObj, 'entity', 'type') === services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].application;
}

function entityIsPipeline(entityObj) {
  return lodash_intersection__WEBPACK_IMPORTED_MODULE_1___default()(services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlPipelineTypes, Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(entityObj, 'metadata', 'tags').map(function (tag) {
    return tag.name;
  })).length > 0;
}

function createArtifactObj(entityObj) {
  return {
    id: entityObj.entity.details.artifact,
    type: entityObj.entity.type.toLowerCase(),
    version: entityObj.entity.details.version,
    metadata: entityObj,
    icon: services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"]['artifact']
  };
}

function createApplicationObj(entityObj) {
  var version = entityObj.entity.details.version;

  if (version === '-SNAPSHOT') {
    version = '1.0.0-SNAPSHOT';
  }

  var icon = services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"]['application'];

  if (entityObj.metadata.tags.find(function (tag) {
    return tag.name === services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline && tag.scope === SYSTEM_SCOPE;
  })) {
    icon = services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"][services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline];
  } else if (entityObj.metadata.tags.find(function (tag) {
    return tag.name === services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams && tag.scope === SYSTEM_SCOPE;
  })) {
    icon = services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"][services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams];
  }

  return {
    id: entityObj.entity.details.application,
    type: entityObj.entity.type.toLowerCase(),
    metadata: entityObj,
    version: version,
    icon: icon,
    isHydrator: entityIsPipeline(entityObj)
  };
}

function createDatasetObj(entityObj) {
  return {
    id: entityObj.entity.details.dataset,
    type: entityObj.entity.type.toLowerCase(),
    metadata: entityObj,
    icon: services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"]['dataset']
  };
}

function createProgramObj(entityObj) {
  return {
    id: entityObj.entity.details.program,
    applicationId: entityObj.entity.details.application,
    type: entityObj.entity.type.toLowerCase(),
    programType: entityObj.entity.details.type,
    metadata: entityObj,
    icon: services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"][entityObj.entity.details.type.toLowerCase()]
  };
}

/***/ })

}]);
//# sourceMappingURL=Administration.967c228a838fbb6c1d2e.js.map