(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["SampleTSXComponent"],{

/***/ "./components/SampleTSXComponent/index.tsx":
/*!*************************************************!*\
  !*** ./components/SampleTSXComponent/index.tsx ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SampleTSXComponent; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-loadable */ "../../node_modules/react-loadable/lib/index.js");
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_loadable__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/LoadingSVGCentered */ "./components/LoadingSVGCentered/index.js");
/* harmony import */ var components_CodeEditor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/CodeEditor */ "./components/CodeEditor/index.tsx");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();





var SubTSXComponent = react_loadable__WEBPACK_IMPORTED_MODULE_1__({
  loader: function loader() {
    return __webpack_require__.e(/*! import() | ChildTSXComponent */ "ChildTSXComponent").then(__webpack_require__.bind(null, /*! components/SampleTSXComponent/ChildTSXComponent */ "./components/SampleTSXComponent/ChildTSXComponent/index.tsx"));
  },
  loading: components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_2__["default"]
});

var FunctionalComponent = function FunctionalComponent(_a) {
  var prop1 = _a.prop1,
      prop2 = _a.prop2;
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h4", null, " Stateless component "), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null, " Props: "), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("pre", null, "" + prop1, " : ", prop2), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("hr", null), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](SubTSXComponent, null));
};

var StatefullComponent =
/** @class */
function (_super) {
  __extends(StatefullComponent, _super);

  function StatefullComponent() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  StatefullComponent.prototype.render = function () {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h4", null, " Stateful component "), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null, " Props: "), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("pre", null, this.props.prop3));
  };

  return StatefullComponent;
}(react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"]);

function SampleTSXComponent() {
  return [react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h1", {
    key: "super-title"
  }, " Hello from TSX! "), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_CodeEditor__WEBPACK_IMPORTED_MODULE_3__["default"], {
    key: "code-editor",
    rows: 20
  })];
}

/***/ })

}]);
//# sourceMappingURL=SampleTSXComponent.2623967d948e79b474a6.js.map