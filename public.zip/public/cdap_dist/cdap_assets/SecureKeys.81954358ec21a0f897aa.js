(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["SecureKeys"],{

/***/ "./components/SecureKeys/index.tsx":
/*!*****************************************!*\
  !*** ./components/SecureKeys/index.tsx ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_securekey__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/securekey */ "./api/securekey.js");
/* harmony import */ var _material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/TextField */ "../../node_modules/@material-ui/core/esm/TextField/index.js");
/* harmony import */ var _material_ui_core_Table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/Table */ "../../node_modules/@material-ui/core/esm/Table/index.js");
/* harmony import */ var _material_ui_core_TableBody__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/TableBody */ "../../node_modules/@material-ui/core/esm/TableBody/index.js");
/* harmony import */ var _material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/TableCell */ "../../node_modules/@material-ui/core/esm/TableCell/index.js");
/* harmony import */ var _material_ui_core_TableHead__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/TableHead */ "../../node_modules/@material-ui/core/esm/TableHead/index.js");
/* harmony import */ var _material_ui_core_TableRow__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/TableRow */ "../../node_modules/@material-ui/core/esm/TableRow/index.js");
/* harmony import */ var _material_ui_icons_Delete__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/icons/Delete */ "../../node_modules/@material-ui/icons/Delete.js");
/* harmony import */ var _material_ui_icons_Delete__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Delete__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/core/Button */ "../../node_modules/@material-ui/core/esm/Button/index.js");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @material-ui/core/IconButton */ "../../node_modules/@material-ui/core/esm/IconButton/index.js");
/* harmony import */ var _material_ui_core_Paper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @material-ui/core/Paper */ "../../node_modules/@material-ui/core/esm/Paper/index.js");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();













 // Currently a hidden link to internally manage secure keys

var SecureKeys =
/** @class */
function (_super) {
  __extends(SecureKeys, _super);

  function SecureKeys() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.state = {
      secureKeys: [],
      name: '',
      description: '',
      data: ''
    };

    _this.fetchSecureKeys = function () {
      var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__["getCurrentNamespace"])();
      api_securekey__WEBPACK_IMPORTED_MODULE_2__["MySecureKeyApi"].list({
        namespace: namespace
      }).subscribe(function (res) {
        _this.setState({
          secureKeys: res
        });
      });
    };

    _this.handleChange = function (property) {
      return function (e) {
        var _a; // @ts-ignore


        _this.setState((_a = {}, _a[property] = e.target.value, _a));
      };
    };

    _this.addKey = function () {
      var _a = _this.state,
          name = _a.name,
          description = _a.description,
          data = _a.data;

      if (!name || !data) {
        return;
      }

      var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__["getCurrentNamespace"])();
      var params = {
        namespace: namespace,
        key: name
      };
      var requestBody = {
        description: description,
        data: data
      };
      api_securekey__WEBPACK_IMPORTED_MODULE_2__["MySecureKeyApi"].add(params, requestBody).subscribe(function () {
        _this.setState({
          name: '',
          description: '',
          data: ''
        });

        _this.fetchSecureKeys();
      });
    };

    _this.deleteKey = function (key) {
      var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__["getCurrentNamespace"])();
      var params = {
        namespace: namespace,
        key: key
      };
      api_securekey__WEBPACK_IMPORTED_MODULE_2__["MySecureKeyApi"]["delete"](params).subscribe(_this.fetchSecureKeys);
    };

    return _this;
  }

  SecureKeys.prototype.componentDidMount = function () {
    this.fetchSecureKeys();
  };

  SecureKeys.prototype.render = function () {
    var _this = this;

    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "secure-keys-container container"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h1", null, "Secure Keys"), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "key-input"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_3__["default"], {
      label: "Name",
      value: this.state.name,
      onChange: this.handleChange('name'),
      margin: "normal",
      fullWidth: true,
      variant: "outlined"
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_3__["default"], {
      label: "Description",
      value: this.state.description,
      onChange: this.handleChange('description'),
      margin: "normal",
      fullWidth: true,
      variant: "outlined"
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_3__["default"], {
      label: "data",
      value: this.state.data,
      onChange: this.handleChange('data'),
      margin: "normal",
      fullWidth: true,
      multiline: true,
      variant: "outlined"
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_10__["default"], {
      variant: "contained",
      color: "primary",
      onClick: this.addKey
    }, "Add Secure Key")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("hr", null), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "key-lists"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_Paper__WEBPACK_IMPORTED_MODULE_12__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_Table__WEBPACK_IMPORTED_MODULE_4__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableHead__WEBPACK_IMPORTED_MODULE_7__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableRow__WEBPACK_IMPORTED_MODULE_8__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_6__["default"], null, "Key"), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_6__["default"], null, "Description"), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_6__["default"], null))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableBody__WEBPACK_IMPORTED_MODULE_5__["default"], null, this.state.secureKeys.map(function (key) {
      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableRow__WEBPACK_IMPORTED_MODULE_8__["default"], {
        key: key.name
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_6__["default"], null, key.name), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_6__["default"], null, key.description), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_TableCell__WEBPACK_IMPORTED_MODULE_6__["default"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_11__["default"], {
        color: "secondary",
        onClick: _this.deleteKey.bind(_this, key.name)
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_icons_Delete__WEBPACK_IMPORTED_MODULE_9___default.a, null))));
    }))))));
  };

  return SecureKeys;
}(react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"]);

/* harmony default export */ __webpack_exports__["default"] = (SecureKeys);

/***/ })

}]);
//# sourceMappingURL=SecureKeys.81954358ec21a0f897aa.js.map