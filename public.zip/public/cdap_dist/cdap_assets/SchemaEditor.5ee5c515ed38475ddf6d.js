(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["SchemaEditor"],{

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/AbstractSchemaRow/AbstractSchemaRow.scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/AbstractSchemaRow/AbstractSchemaRow.scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.abstract-schema-row {\n  border-bottom: 1px solid #cccccc;\n  padding-left: 5px; }\n  .abstract-schema-row:last-child {\n    border: 0; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/ArraySchemaRow/ArraySchemaRow.scss":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/ArraySchemaRow/ArraySchemaRow.scss ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.array-schema-row > .schema-row > .field-name {\n  position: relative; }\n  .array-schema-row > .schema-row > .field-name:after {\n    color: #3c4355;\n    content: \"\\f0d7\";\n    font-family: 'FontAwesome';\n    position: absolute;\n    top: 7px;\n    right: 10px;\n    z-index: 5; }\n\n.array-schema-row > .schema-row > .field-type {\n  visibility: hidden; }\n\n.array-schema-row .abstract-schema-row {\n  padding-left: 5px;\n  padding-top: 0; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/EnumSchemaRow/EnumSchemaRow.scss":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/EnumSchemaRow/EnumSchemaRow.scss ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.enum-schema-row .schema-row > .field-type {\n  visibility: hidden; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/MapSchemaRow/MapSchemaRow.scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/MapSchemaRow/MapSchemaRow.scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.map-schema-row .schema-row > .key-row > .field-name,\n.map-schema-row .schema-row > .value-row > .field-name {\n  width: calc(100% - 80px - 75px);\n  display: inline-block;\n  position: relative; }\n  .map-schema-row .schema-row > .key-row > .field-name .fa-caret-down,\n  .map-schema-row .schema-row > .key-row > .field-name .fa-caret-right,\n  .map-schema-row .schema-row > .value-row > .field-name .fa-caret-down,\n  .map-schema-row .schema-row > .value-row > .field-name .fa-caret-right {\n    position: absolute;\n    bottom: -2px;\n    left: 10px;\n    cursor: pointer; }\n  .map-schema-row .schema-row > .key-row > .field-name div:first-child,\n  .map-schema-row .schema-row > .value-row > .field-name div:first-child {\n    margin: 0 10px;\n    width: 30px;\n    display: inline-block; }\n\n.map-schema-row .schema-row > .key-row > .field-type,\n.map-schema-row .schema-row > .value-row > .field-type {\n  width: 80px; }\n\n.map-schema-row .schema-row > .key-row > .field-isnull,\n.map-schema-row .schema-row > .value-row > .field-isnull {\n  width: 75px; }\n  .map-schema-row .schema-row > .key-row > .field-isnull .btn.btn-link,\n  .map-schema-row .schema-row > .value-row > .field-isnull .btn.btn-link {\n    display: inline-block;\n    padding: 0 5px;\n    width: 24px; }\n\n.map-schema-row .schema-row > .key-row.nested,\n.map-schema-row .schema-row > .value-row.nested {\n  border: 0;\n  box-shadow: 0px 0px 3px 1px rgba(1, 0, 0, 0.2);\n  border-radius: 4px;\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0; }\n  .map-schema-row .schema-row > .key-row.nested > .abstract-schema-row,\n  .map-schema-row .schema-row > .value-row.nested > .abstract-schema-row {\n    box-shadow: 1px -2px 1px rgba(0, 0, 0, 0.25); }\n  .map-schema-row .schema-row > .key-row.nested > .field-name,\n  .map-schema-row .schema-row > .value-row.nested > .field-name {\n    box-shadow: rgba(1, 0, 0, 0.25) 1px -1px 7px;\n    border-radius: 4px;\n    position: relative;\n    width: 155px; }\n    .map-schema-row .schema-row > .key-row.nested > .field-name:before,\n    .map-schema-row .schema-row > .value-row.nested > .field-name:before {\n      position: absolute;\n      content: ' ';\n      top: 29px;\n      bottom: 0;\n      width: 100%;\n      background: white;\n      box-shadow: none;\n      height: 10px; }\n  .map-schema-row .schema-row > .key-row.nested > .field-type,\n  .map-schema-row .schema-row > .value-row.nested > .field-type {\n    width: calc(100% - 155px - 75px); }\n\n.map-schema-row .schema-row > .key-row > .field-name .form-control,\n.map-schema-row .schema-row > .value-row > .field-name .form-control {\n  width: 90px;\n  vertical-align: inherit;\n  display: inline-block; }\n\n.map-schema-row .schema-row > .key-row > .field-name:after,\n.map-schema-row .schema-row > .value-row > .field-name:after {\n  color: #3c4355;\n  content: \"\\f0d7\";\n  font-family: 'FontAwesome';\n  position: absolute;\n  top: 7px;\n  left: 130px;\n  z-index: 5; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/RecordSchemaRow/RecordSchemaRow.scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/RecordSchemaRow/RecordSchemaRow.scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.record-schema-row > .schema-row:only-child {\n  border: 0; }\n\n.record-schema-row .schema-row {\n  box-shadow: 3px -2px 5px rgba(0, 0, 0, 0.25), 0px 0px 0px white; }\n\n.record-schema-row .schema-row ~ .schema-row {\n  box-shadow: none; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/SchemaEditor.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/SchemaEditor.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2015 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.schema-editor .schema-header {\n  padding: 5px 0; }\n  .schema-editor .schema-header .field-name {\n    width: calc(100% - 105px - 75px); }\n  .schema-editor .schema-header .field-isnull {\n    width: calc(75px - 5px);\n    margin-left: 5px; }\n  .schema-editor .schema-header .field-type {\n    width: calc(105px - 5px);\n    margin-left: 5px; }\n  .schema-editor .schema-header .field-name,\n  .schema-editor .schema-header .field-type,\n  .schema-editor .schema-header .field-isnull {\n    font-weight: bolder;\n    display: inline-block; }\n\n.schema-editor .schema-body .schema-row {\n  border-top: 1px solid #cccccc; }\n  .schema-editor .schema-body .schema-row:first-child {\n    border-top: 1px solid #cccccc;\n    border-top: 0; }\n  .schema-editor .schema-body .schema-row:not(.nested) {\n    box-shadow: none; }\n    .schema-editor .schema-body .schema-row:not(.nested).borderless {\n      border-top: 0; }\n  .schema-editor .schema-body .schema-row > .abstract-schema-row {\n    box-shadow: 1px -2px 1px rgba(0, 0, 0, 0.25); }\n  .schema-editor .schema-body .schema-row > .field-name {\n    width: calc(100% - 105px - 75px); }\n  .schema-editor .schema-body .schema-row > .field-type {\n    width: 105px;\n    padding: 0 5px;\n    vertical-align: top;\n    position: relative; }\n    .schema-editor .schema-body .schema-row > .field-type:after {\n      color: #3c4355;\n      content: \"\\f0d7\";\n      font-family: 'FontAwesome';\n      position: absolute;\n      top: 25%;\n      right: 10px;\n      z-index: 5; }\n  .schema-editor .schema-body .schema-row > .field-isnull {\n    width: 75px; }\n    .schema-editor .schema-body .schema-row > .field-isnull .btn.btn-link {\n      display: inline-block;\n      padding: 0;\n      width: 24px; }\n      .schema-editor .schema-body .schema-row > .field-isnull .btn.btn-link [class*=\"fa-\"] {\n        padding: 0;\n        margin: 0;\n        border: 0;\n        background: transparent; }\n  .schema-editor .schema-body .schema-row .field-name,\n  .schema-editor .schema-body .schema-row .field-type,\n  .schema-editor .schema-body .schema-row .field-isnull {\n    display: inline-block;\n    vertical-align: middle; }\n  .schema-editor .schema-body .schema-row .form-control {\n    padding: 0 5px;\n    height: 25px;\n    margin: 5px 0 6px 0;\n    appearance: none;\n    border: 0;\n    box-shadow: none;\n    appearance: none;\n    -webkit-appearance: none;\n    -moz-appearance: none;\n    -o-appearance: none;\n    color: #666666;\n    font-weight: 500; }\n    .schema-editor .schema-body .schema-row .form-control ::-ms-expand {\n      display: none; }\n    .schema-editor .schema-body .schema-row .form-control:focus {\n      border-color: #dddddd;\n      outline: 1px solid #098cf9;\n      box-shadow: none; }\n  .schema-editor .schema-body .schema-row.nested {\n    border: 0;\n    box-shadow: -1px 0px 5px 1px rgba(1, 0, 0, 0.2);\n    border-radius: 4px;\n    border-bottom-left-radius: 0;\n    border-bottom-right-radius: 0;\n    border-top-right-radius: 0; }\n    .schema-editor .schema-body .schema-row.nested:first-child {\n      border: 0; }\n    .schema-editor .schema-body .schema-row.nested > .field-name {\n      box-shadow: rgba(1, 0, 0, 0.25) 1px -1px 7px;\n      border-radius: 4px;\n      position: relative; }\n      .schema-editor .schema-body .schema-row.nested > .field-name .fa-caret-down,\n      .schema-editor .schema-body .schema-row.nested > .field-name .fa-caret-right {\n        position: absolute;\n        bottom: -2px;\n        left: 5px;\n        cursor: pointer; }\n      .schema-editor .schema-body .schema-row.nested > .field-name:before {\n        position: absolute;\n        content: ' ';\n        top: 29px;\n        bottom: 0;\n        width: 100%;\n        background: white;\n        box-shadow: none;\n        height: 10px; }\n  .schema-editor .schema-body .schema-row .text-danger {\n    word-break: break-word; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/UnionSchemaRow/UnionSchemaRow.scss":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/UnionSchemaRow/UnionSchemaRow.scss ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.union-schema-row > .schema-row {\n  border: 0; }\n  .union-schema-row > .schema-row.nested > .field-name {\n    box-shadow: rgba(1, 0, 0, 0.25) 1px -1px 7px;\n    border-radius: 4px;\n    width: 155px; }\n  .union-schema-row > .schema-row > .field-type {\n    visibility: hidden; }\n  .union-schema-row > .schema-row > .field-name {\n    position: relative; }\n    .union-schema-row > .schema-row > .field-name:after {\n      color: #3c4355;\n      content: \"\\f0d7\";\n      font-family: 'FontAwesome';\n      position: absolute;\n      top: 7px;\n      right: 10px;\n      z-index: 5; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./components/SchemaEditor/AbstractSchemaRow/AbstractSchemaRow.scss":
/*!**************************************************************************!*\
  !*** ./components/SchemaEditor/AbstractSchemaRow/AbstractSchemaRow.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./AbstractSchemaRow.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/AbstractSchemaRow/AbstractSchemaRow.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SchemaEditor/AbstractSchemaRow/index.js":
/*!************************************************************!*\
  !*** ./components/SchemaEditor/AbstractSchemaRow/index.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AbstractSchemaRow; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_SchemaEditor_ArraySchemaRow__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/SchemaEditor/ArraySchemaRow */ "./components/SchemaEditor/ArraySchemaRow/index.js");
/* harmony import */ var components_SchemaEditor_MapSchemaRow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/SchemaEditor/MapSchemaRow */ "./components/SchemaEditor/MapSchemaRow/index.js");
/* harmony import */ var components_SchemaEditor_UnionSchemaRow__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/SchemaEditor/UnionSchemaRow */ "./components/SchemaEditor/UnionSchemaRow/index.js");
/* harmony import */ var components_SchemaEditor_EnumSchemaRow__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/SchemaEditor/EnumSchemaRow */ "./components/SchemaEditor/EnumSchemaRow/index.js");
/* harmony import */ var components_SchemaEditor_RecordSchemaRow__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/SchemaEditor/RecordSchemaRow */ "./components/SchemaEditor/RecordSchemaRow/index.js");
/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






 // import {parseType} from 'components/SchemaEditor/SchemaHelpers';

__webpack_require__(/*! ./AbstractSchemaRow.scss */ "./components/SchemaEditor/AbstractSchemaRow/AbstractSchemaRow.scss");

function AbstractSchemaRow(_ref) {
  var row = _ref.row,
      onChange = _ref.onChange;

  var renderSchemaRow = function renderSchemaRow(row) {
    switch (row.displayType) {
      case 'array':
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SchemaEditor_ArraySchemaRow__WEBPACK_IMPORTED_MODULE_2__["default"], {
          row: row.type,
          onChange: onChange
        });

      case 'map':
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SchemaEditor_MapSchemaRow__WEBPACK_IMPORTED_MODULE_3__["default"], {
          row: row.type,
          onChange: onChange
        });

      case 'union':
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SchemaEditor_UnionSchemaRow__WEBPACK_IMPORTED_MODULE_4__["default"], {
          row: row.type,
          onChange: onChange
        });

      case 'enum':
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SchemaEditor_EnumSchemaRow__WEBPACK_IMPORTED_MODULE_5__["default"], {
          row: row.type,
          onChange: onChange
        });

      case 'record':
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SchemaEditor_RecordSchemaRow__WEBPACK_IMPORTED_MODULE_6__["default"], {
          row: row.type,
          onChange: onChange
        });

      default:
        return null;
    }
  };

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "abstract-schema-row"
  }, renderSchemaRow(row));
}
AbstractSchemaRow.propTypes = {
  row: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.any,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func.isRequired
};

/***/ }),

/***/ "./components/SchemaEditor/ArraySchemaRow/ArraySchemaRow.scss":
/*!********************************************************************!*\
  !*** ./components/SchemaEditor/ArraySchemaRow/ArraySchemaRow.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./ArraySchemaRow.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/ArraySchemaRow/ArraySchemaRow.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SchemaEditor/ArraySchemaRow/index.js":
/*!*********************************************************!*\
  !*** ./components/SchemaEditor/ArraySchemaRow/index.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ArraySchemaRow; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/SchemaEditor/SchemaHelpers */ "./components/SchemaEditor/SchemaHelpers.js");
/* harmony import */ var components_SelectWithOptions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/SelectWithOptions */ "./components/SelectWithOptions/index.js");
/* harmony import */ var components_SchemaEditor_AbstractSchemaRow__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/SchemaEditor/AbstractSchemaRow */ "./components/SchemaEditor/AbstractSchemaRow/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash/cloneDeep */ "../../node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var services_cdapavscwrapper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/cdapavscwrapper */ "./services/cdapavscwrapper/index.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









__webpack_require__(/*! ./ArraySchemaRow.scss */ "./components/SchemaEditor/ArraySchemaRow/ArraySchemaRow.scss");

var ArraySchemaRow =
/*#__PURE__*/
function (_Component) {
  _inherits(ArraySchemaRow, _Component);

  function ArraySchemaRow(props) {
    var _this;

    _classCallCheck(this, ArraySchemaRow);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ArraySchemaRow).call(this, props));

    if (_typeof(props.row) === 'object') {
      var item = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["parseType"])(props.row);
      var itemsType = item.type.getItemsType();
      var parsedItemsType = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["parseType"])(itemsType);
      _this.state = {
        displayType: {
          type: parsedItemsType.displayType,
          nullable: parsedItemsType.nullable
        },
        showAbstractSchemaRow: true,
        error: ''
      };
      _this.parsedType = parsedItemsType.type;
    } else {
      _this.state = {
        displayType: {
          type: 'string',
          nullable: false
        },
        showAbstractSchemaRow: true,
        error: ''
      };
      _this.parsedType = 'string';
    }

    _this.onTypeChange = _this.onTypeChange.bind(_assertThisInitialized(_this));
    setTimeout(_this.updateParent.bind(_assertThisInitialized(_this)));
    return _this;
  }

  _createClass(ArraySchemaRow, [{
    key: "onTypeChange",
    value: function onTypeChange(e) {
      var selectedType = e.target.value;
      selectedType = services_cdapavscwrapper__WEBPACK_IMPORTED_MODULE_7__["default"].formatType(selectedType);

      if (this.state.displayType.nullable) {
        this.parsedType = [selectedType, 'null'];
      } else {
        this.parsedType = selectedType;
      }

      this.setState({
        displayType: {
          type: e.target.value,
          nullable: this.state.displayType.nullable
        },
        error: ''
      }, function () {
        if (!Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkComplexType"])(selectedType)) {
          this.updateParent();
        }
      }.bind(this));
    }
  }, {
    key: "onNullableChange",
    value: function onNullableChange(e) {
      var parsedType = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_6___default()(this.parsedType);
      parsedType = services_cdapavscwrapper__WEBPACK_IMPORTED_MODULE_7__["default"].formatType(parsedType);

      if (!e.target.checked) {
        this.parsedType = parsedType[0];
      } else {
        this.parsedType = [parsedType, 'null'];
      }

      this.setState({
        displayType: {
          type: this.state.displayType.type,
          nullable: e.target.checked
        },
        error: ''
      }, this.updateParent.bind(this));
    }
  }, {
    key: "onChildrenChange",
    value: function onChildrenChange(itemsState) {
      var updatedItemState = services_cdapavscwrapper__WEBPACK_IMPORTED_MODULE_7__["default"].formatType(itemsState);
      var error = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkParsedTypeForError"])({
        type: 'array',
        items: this.state.displayType.nullable ? [updatedItemState, 'null'] : updatedItemState
      });

      if (error) {
        this.setState({
          error: error
        });
        return;
      }

      this.parsedType = this.state.displayType.nullable ? [lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_6___default()(updatedItemState), 'null'] : lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_6___default()(updatedItemState);
      this.updateParent();
    }
  }, {
    key: "updateParent",
    value: function updateParent() {
      var error = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkParsedTypeForError"])({
        type: 'array',
        items: this.parsedType
      });

      if (error) {
        this.setState({
          error: error
        });
        return;
      }

      this.props.onChange({
        type: 'array',
        items: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_6___default()(this.parsedType)
      });
    }
  }, {
    key: "toggleAbstractSchemaRow",
    value: function toggleAbstractSchemaRow() {
      this.setState({
        showAbstractSchemaRow: !this.state.showAbstractSchemaRow
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var showArrows = function showArrows() {
        if (_this2.state.showAbstractSchemaRow) {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
            className: "fa fa-caret-down",
            onClick: _this2.toggleAbstractSchemaRow.bind(_this2)
          });
        }

        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "fa fa-caret-right",
          onClick: _this2.toggleAbstractSchemaRow.bind(_this2)
        });
      };

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "array-schema-row"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "text-danger"
      }, this.state.error), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()('schema-row', {
          nested: Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkComplexType"])(this.state.displayType.type)
        })
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "field-name"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SelectWithOptions__WEBPACK_IMPORTED_MODULE_3__["default"], {
        options: components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["SCHEMA_TYPES"].types,
        value: this.state.displayType.type,
        onChange: this.onTypeChange
      }), Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkComplexType"])(this.state.displayType.type) ? showArrows() : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "field-type"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "field-isnull"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "btn btn-link"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("input", {
        type: "checkbox",
        checked: this.state.displayType.nullable,
        onChange: this.onNullableChange.bind(this)
      }))), Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkComplexType"])(this.state.displayType.type) && this.state.showAbstractSchemaRow ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SchemaEditor_AbstractSchemaRow__WEBPACK_IMPORTED_MODULE_4__["default"], {
        row: {
          type: Array.isArray(this.parsedType) ? this.parsedType[0] : this.parsedType,
          displayType: this.state.displayType.type
        },
        onChange: this.onChildrenChange.bind(this)
      }) : null));
    }
  }]);

  return ArraySchemaRow;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


ArraySchemaRow.propTypes = {
  row: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.any,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func.isRequired
};

/***/ }),

/***/ "./components/SchemaEditor/EnumSchemaRow/EnumSchemaRow.scss":
/*!******************************************************************!*\
  !*** ./components/SchemaEditor/EnumSchemaRow/EnumSchemaRow.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./EnumSchemaRow.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/EnumSchemaRow/EnumSchemaRow.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SchemaEditor/EnumSchemaRow/index.js":
/*!********************************************************!*\
  !*** ./components/SchemaEditor/EnumSchemaRow/index.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnumSchemaRow; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/SchemaEditor/SchemaHelpers */ "./components/SchemaEditor/SchemaHelpers.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








__webpack_require__(/*! ./EnumSchemaRow.scss */ "./components/SchemaEditor/EnumSchemaRow/EnumSchemaRow.scss");

var EnumSchemaRow =
/*#__PURE__*/
function (_Component) {
  _inherits(EnumSchemaRow, _Component);

  function EnumSchemaRow(props) {
    var _this;

    _classCallCheck(this, EnumSchemaRow);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(EnumSchemaRow).call(this, props));

    if (_typeof(props.row) === 'object') {
      var rowType = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["parseType"])(props.row);
      var symbols = rowType.type.getSymbols().map(function (symbol) {
        return {
          symbol: symbol,
          id: uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()()
        };
      });
      _this.state = {
        symbols: symbols,
        error: '',
        refRequired: true
      };
    } else {
      _this.state = {
        symbols: [{
          symbol: '',
          id: uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()()
        }],
        error: ''
      };
    }

    return _this;
  }

  _createClass(EnumSchemaRow, [{
    key: "checkForErrors",
    value: function checkForErrors(symbols) {
      var parsedType = {
        type: 'enum',
        symbols: symbols.map(function (sobj) {
          return sobj.symbol;
        }).filter(function (symbol) {
          return symbol.length;
        })
      };
      return Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkParsedTypeForError"])(parsedType);
    }
  }, {
    key: "onSymbolChange",
    value: function onSymbolChange(index, e) {
      var _this2 = this;

      var symbols = this.state.symbols;
      symbols[index].symbol = e.target.value;
      var error = this.checkForErrors(symbols);

      if (error) {
        this.setState({
          error: error
        });
        return;
      }

      this.setState({
        symbols: symbols,
        error: ''
      }, function () {
        _this2.props.onChange({
          type: 'enum',
          symbols: _this2.state.symbols.map(function (sobj) {
            return sobj.symbol;
          }).filter(function (symbol) {
            return symbol.length;
          })
        });
      });
    }
  }, {
    key: "onSymbolAdd",
    value: function onSymbolAdd(index) {
      var _this3 = this;

      var symbols = this.state.symbols.map(function (sobj) {
        delete sobj.refRequired;
        return sobj;
      });
      symbols = Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["insertAt"])(symbols, index, {
        symbol: '',
        id: uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()(),
        refRequired: true
      });
      this.setState({
        symbols: symbols
      }, function () {
        if (_this3.inputToFocus) {
          _this3.inputToFocus.focus();
        }

        var error = _this3.checkForErrors(symbols);

        if (error) {
          return;
        }

        _this3.props.onChange({
          type: 'enum',
          symbols: _this3.state.symbols.map(function (sobj) {
            return sobj.symbol;
          }).filter(function (symbol) {
            return symbol.length;
          })
        });
      });
    }
  }, {
    key: "onSymbolRemove",
    value: function onSymbolRemove(index) {
      var _this4 = this;

      var symbols = this.state.symbols;
      symbols = Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["removeAt"])(symbols, index);
      this.setState({
        symbols: symbols,
        error: ''
      }, function () {
        var error = _this4.checkForErrors(_this4.state.symbols);

        if (error) {
          _this4.setState({
            error: error
          });

          return;
        }

        _this4.props.onChange({
          type: 'enum',
          symbols: _this4.state.symbols.map(function (sobj) {
            return sobj.symbol;
          }).filter(function (symbol) {
            return symbol.length;
          })
        });
      });
    }
  }, {
    key: "onKeyPress",
    value: function onKeyPress(index, e) {
      if (e.nativeEvent.keyCode === 13) {
        this.onSymbolChange(index, e);
        this.onSymbolAdd(index);
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this5 = this;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "enum-schema-row"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "text-danger"
      }, this.state.error), this.state.symbols.map(function (sobj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "schema-row",
          key: sobj.id
        }, sobj.refRequired ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
          className: "field-name",
          placeholder: i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.SchemaEditor.Labels.symbolName'),
          defaultValue: sobj.symbol,
          onFocus: function onFocus() {
            return sobj.symbol;
          },
          onBlur: _this5.onSymbolChange.bind(_this5, index),
          getRef: function getRef(ref) {
            return _this5.inputToFocus = ref;
          },
          onKeyPress: _this5.onKeyPress.bind(_this5, index)
        }) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
          className: "field-name",
          placeholder: i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate('features.SchemaEditor.Labels.symbolName'),
          defaultValue: sobj.symbol,
          onFocus: function onFocus() {
            return sobj.symbol;
          },
          onBlur: _this5.onSymbolChange.bind(_this5, index),
          onKeyPress: _this5.onKeyPress.bind(_this5, index)
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "field-type"
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "field-isnull"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "btn btn-link"
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "btn btn-link"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "fa fa-plus",
          onClick: _this5.onSymbolAdd.bind(_this5, index)
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "btn btn-link"
        }, _this5.state.symbols.length !== 1 ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "fa fa-trash text-danger",
          onClick: _this5.onSymbolRemove.bind(_this5, index)
        }) : null)));
      }));
    }
  }]);

  return EnumSchemaRow;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


EnumSchemaRow.propTypes = {
  row: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.any,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func.isRequired
};

/***/ }),

/***/ "./components/SchemaEditor/MapSchemaRow/MapSchemaRow.scss":
/*!****************************************************************!*\
  !*** ./components/SchemaEditor/MapSchemaRow/MapSchemaRow.scss ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./MapSchemaRow.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/MapSchemaRow/MapSchemaRow.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SchemaEditor/MapSchemaRow/index.js":
/*!*******************************************************!*\
  !*** ./components/SchemaEditor/MapSchemaRow/index.js ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MapSchemaRow; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_SelectWithOptions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/SelectWithOptions */ "./components/SelectWithOptions/index.js");
/* harmony import */ var components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/SchemaEditor/SchemaHelpers */ "./components/SchemaEditor/SchemaHelpers.js");
/* harmony import */ var components_SchemaEditor_AbstractSchemaRow__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/SchemaEditor/AbstractSchemaRow */ "./components/SchemaEditor/AbstractSchemaRow/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash/cloneDeep */ "../../node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









__webpack_require__(/*! ./MapSchemaRow.scss */ "./components/SchemaEditor/MapSchemaRow/MapSchemaRow.scss");

var MapSchemaRow =
/*#__PURE__*/
function (_Component) {
  _inherits(MapSchemaRow, _Component);

  function MapSchemaRow(props) {
    var _this;

    _classCallCheck(this, MapSchemaRow);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(MapSchemaRow).call(this, props));

    if (_typeof(props.row) === 'object') {
      var rowType = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["parseType"])(props.row);
      var parsedKeysType = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["parseType"])(rowType.type.getKeysType());
      var parsedValuesType = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["parseType"])(rowType.type.getValuesType());
      _this.state = {
        name: rowType.name,
        keysType: parsedKeysType.displayType,
        keysTypeNullable: parsedKeysType.nullable,
        valuesType: parsedValuesType.displayType,
        valuesTypeNullable: parsedValuesType.nullable,
        error: '',
        showKeysAbstractSchemaRow: true,
        showValuesAbstractSchemaRow: true
      };
      _this.parsedKeysType = rowType.type.getKeysType();
      _this.parsedValuesType = rowType.type.getValuesType();
    } else {
      _this.state = {
        name: props.row.name,
        keysType: 'string',
        keysTypeNullable: false,
        valuesType: 'string',
        valuesTypeNullable: false,
        error: '',
        showKeysAbstractSchemaRow: true,
        showValuesAbstractSchemaRow: true
      };
      _this.parsedKeysType = 'string';
      _this.parsedValuesType = 'string';
    }

    setTimeout(_this.updateParent.bind(_assertThisInitialized(_this)));
    _this.onKeysTypeChange = _this.onKeysTypeChange.bind(_assertThisInitialized(_this));
    _this.onValuesTypeChange = _this.onValuesTypeChange.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(MapSchemaRow, [{
    key: "onKeysTypeChange",
    value: function onKeysTypeChange(e) {
      this.parsedKeysType = this.state.keysTypeNullable ? [e.target.value, 'null'] : e.target.value;
      this.setState({
        keysType: e.target.value
      }, function () {
        if (!Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["checkComplexType"])(this.state.keysType)) {
          this.updateParent();
        }
      }.bind(this));
    }
  }, {
    key: "onValuesTypeChange",
    value: function onValuesTypeChange(e) {
      this.parsedValuesType = this.state.valuesTypeNullable ? [e.target.value, 'null'] : e.target.value;
      this.setState({
        valuesType: e.target.value
      }, function () {
        if (!Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["checkComplexType"])(this.state.valuesType)) {
          this.updateParent();
        }
      }.bind(this));
    }
  }, {
    key: "updateParent",
    value: function updateParent() {
      var error = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["checkParsedTypeForError"])(this.parsedValuesType) || Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["checkParsedTypeForError"])(this.parsedKeysType);

      if (error) {
        this.setState({
          error: error
        });
        return;
      }

      this.props.onChange({
        type: 'map',
        keys: this.parsedKeysType,
        values: this.parsedValuesType
      });
    }
  }, {
    key: "onKeysChildrenChange",
    value: function onKeysChildrenChange(keysState) {
      keysState = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7___default()(keysState);
      var error = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["checkParsedTypeForError"])(keysState);

      if (error) {
        this.setState({
          error: error
        });
        return;
      }

      this.parsedKeysType = this.state.keysTypeNullable ? [keysState, 'null'] : keysState;
      this.updateParent();
    }
  }, {
    key: "onValuesChildrenChange",
    value: function onValuesChildrenChange(valuesState) {
      valuesState = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7___default()(valuesState);
      var error = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["checkParsedTypeForError"])(valuesState);

      if (error) {
        this.setState({
          error: error
        });
        return;
      }

      this.parsedValuesType = this.state.valuesTypeNullable ? [valuesState, 'null'] : valuesState;
      this.updateParent();
    }
  }, {
    key: "onKeysTypeNullableChange",
    value: function onKeysTypeNullableChange(e) {
      if (e.target.checked) {
        this.parsedKeysType = [this.parsedKeysType, 'null'];
      } else {
        this.parsedKeysType = this.parsedKeysType[0];
      }

      this.setState({
        keysTypeNullable: e.target.checked,
        error: ''
      }, this.updateParent.bind(this));
    }
  }, {
    key: "onValuesTypeNullableChange",
    value: function onValuesTypeNullableChange(e) {
      if (e.target.checked) {
        this.parsedValuesType = [this.parsedValuesType, 'null'];
      } else {
        this.parsedValuesType = this.parsedValuesType[0];
      }

      this.setState({
        valuesTypeNullable: e.target.checked,
        error: ''
      }, this.updateParent.bind(this));
    }
  }, {
    key: "toggleKeysAbstractSchemaRow",
    value: function toggleKeysAbstractSchemaRow() {
      this.setState({
        showKeysAbstractSchemaRow: !this.state.showKeysAbstractSchemaRow
      });
    }
  }, {
    key: "toggleValuesAbstractSchemaRow",
    value: function toggleValuesAbstractSchemaRow() {
      this.setState({
        showValuesAbstractSchemaRow: !this.state.showValuesAbstractSchemaRow
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var showKeysArrow = function showKeysArrow() {
        if (_this2.state.showKeysAbstractSchemaRow) {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
            className: "fa fa-caret-down",
            onClick: _this2.toggleKeysAbstractSchemaRow.bind(_this2)
          });
        }

        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "fa fa-caret-right",
          onClick: _this2.toggleKeysAbstractSchemaRow.bind(_this2)
        });
      };

      var showValuesArrow = function showValuesArrow() {
        if (_this2.state.showValuesAbstractSchemaRow) {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
            className: "fa fa-caret-down",
            onClick: _this2.toggleValuesAbstractSchemaRow.bind(_this2)
          });
        }

        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "fa fa-caret-right",
          onClick: _this2.toggleValuesAbstractSchemaRow.bind(_this2)
        });
      };

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "map-schema-row"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "text-danger"
      }, this.state.error), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "schema-row"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()('key-row clearfix', {
          nested: Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["checkComplexType"])(this.state.keysType)
        })
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "field-name"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, " Key: "), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SelectWithOptions__WEBPACK_IMPORTED_MODULE_2__["default"], {
        options: components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["SCHEMA_TYPES"].types,
        value: this.state.keysType,
        onChange: this.onKeysTypeChange
      }), Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["checkComplexType"])(this.state.keysType) ? showKeysArrow() : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "field-type"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "field-isnull"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "btn btn-link"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_5__["Input"], {
        type: "checkbox",
        addon: true,
        checked: this.state.keysTypeNullable,
        onChange: this.onKeysTypeNullableChange.bind(this)
      }))), Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["checkComplexType"])(this.state.keysType) && this.state.showKeysAbstractSchemaRow ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SchemaEditor_AbstractSchemaRow__WEBPACK_IMPORTED_MODULE_4__["default"], {
        row: {
          type: this.parsedKeysType,
          displayType: this.state.keysType
        },
        onChange: this.onKeysChildrenChange.bind(this)
      }) : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()('value-row clearfix', {
          nested: Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["checkComplexType"])(this.state.valuesType)
        })
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "field-name"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, "Value: "), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SelectWithOptions__WEBPACK_IMPORTED_MODULE_2__["default"], {
        options: components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["SCHEMA_TYPES"].types,
        value: this.state.valuesType,
        onChange: this.onValuesTypeChange
      }), Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["checkComplexType"])(this.state.valuesType) ? showValuesArrow() : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "field-type"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "field-isnull"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "btn btn-link"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_5__["Input"], {
        type: "checkbox",
        addon: true,
        checked: this.state.valuesTypeNullable,
        onChange: this.onValuesTypeNullableChange.bind(this)
      }))), Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_3__["checkComplexType"])(this.state.valuesType) && this.state.showValuesAbstractSchemaRow ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SchemaEditor_AbstractSchemaRow__WEBPACK_IMPORTED_MODULE_4__["default"], {
        row: {
          type: Array.isArray(this.parsedValuesType) ? this.parsedValuesType[0] : this.parsedValuesType,
          displayType: this.state.valuesType
        },
        onChange: this.onValuesChildrenChange.bind(this)
      }) : null)));
    }
  }]);

  return MapSchemaRow;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


MapSchemaRow.propTypes = {
  row: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.any,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func.isRequired
};

/***/ }),

/***/ "./components/SchemaEditor/RecordSchemaRow/RecordSchemaRow.scss":
/*!**********************************************************************!*\
  !*** ./components/SchemaEditor/RecordSchemaRow/RecordSchemaRow.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./RecordSchemaRow.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/RecordSchemaRow/RecordSchemaRow.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SchemaEditor/RecordSchemaRow/index.js":
/*!**********************************************************!*\
  !*** ./components/SchemaEditor/RecordSchemaRow/index.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RecordSchemaRow; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/SchemaEditor/SchemaHelpers */ "./components/SchemaEditor/SchemaHelpers.js");
/* harmony import */ var components_SchemaEditor_AbstractSchemaRow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/SchemaEditor/AbstractSchemaRow */ "./components/SchemaEditor/AbstractSchemaRow/index.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var components_SelectWithOptions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/SelectWithOptions */ "./components/SelectWithOptions/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash/cloneDeep */ "../../node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var services_cdapavscwrapper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! services/cdapavscwrapper */ "./services/cdapavscwrapper/index.ts");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





__webpack_require__(/*! ./RecordSchemaRow.scss */ "./components/SchemaEditor/RecordSchemaRow/RecordSchemaRow.scss");










var RecordSchemaRow =
/*#__PURE__*/
function (_Component) {
  _inherits(RecordSchemaRow, _Component);

  function RecordSchemaRow(props) {
    var _this;

    _classCallCheck(this, RecordSchemaRow);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(RecordSchemaRow).call(this, props));

    if (_typeof(props.row) === 'object') {
      var displayFields = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["getParsedSchema"])(props.row).map(function (field) {
        field.showAbstractSchemaRow = true;
        return field;
      });
      var parsedFields = displayFields.map(function (_ref) {
        var name = _ref.name,
            type = _ref.type,
            nullable = _ref.nullable;
        return {
          name: name,
          type: nullable ? [type, 'null'] : type
        };
      });
      _this.state = {
        type: 'record',
        name: 'a' + uuid_v4__WEBPACK_IMPORTED_MODULE_4___default()().split('-').join(''),
        displayFields: displayFields,
        error: ''
      };
      _this.parsedFields = parsedFields;
    } else {
      _this.state = {
        type: 'record',
        name: 'a' + uuid_v4__WEBPACK_IMPORTED_MODULE_4___default()().split('-').join(''),
        displayFields: [{
          name: '',
          type: 'string',
          displayType: 'string',
          nullable: false,
          id: uuid_v4__WEBPACK_IMPORTED_MODULE_4___default()(),
          showAbstractSchemaRow: true
        }],
        error: ''
      };
      _this.parsedFields = [{
        name: '',
        type: 'string'
      }];
    }

    setTimeout(_this.updateParent.bind(_assertThisInitialized(_this)));
    return _this;
  }

  _createClass(RecordSchemaRow, [{
    key: "onRowAdd",
    value: function onRowAdd(index, e) {
      var _this2 = this;

      var displayFieldsCopy = _toConsumableArray(this.state.displayFields).map(function (field) {
        delete field.refRequired;
        return field;
      });

      var parsedFieldsCopy = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_10___default()(this.parsedFields);

      if (e.target.value) {
        displayFieldsCopy[index].name = e.target.value;
        parsedFieldsCopy[index].name = e.target.value;
      }

      var displayFields = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["insertAt"])(displayFieldsCopy, index, {
        name: '',
        displayType: 'string',
        id: uuid_v4__WEBPACK_IMPORTED_MODULE_4___default()(),
        refRequired: true,
        nullable: false,
        showAbstractSchemaRow: true
      });
      var parsedFields = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["insertAt"])(parsedFieldsCopy, index, {
        name: '',
        type: 'string'
      });
      this.parsedFields = parsedFields;
      this.setState({
        displayFields: displayFields
      }, function () {
        _this2.inputToFocus.focus();
      });
    }
  }, {
    key: "onRowRemove",
    value: function onRowRemove(index) {
      var displayFields = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["removeAt"])(_toConsumableArray(this.state.displayFields), index);
      var parsedFields = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["removeAt"])(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_10___default()(this.parsedFields), index);

      if (!displayFields.length) {
        displayFields = [{
          name: '',
          type: 'string',
          displayType: 'string',
          nullable: false,
          id: uuid_v4__WEBPACK_IMPORTED_MODULE_4___default()(),
          showAbstractSchemaRow: true
        }];
        parsedFields = [{
          name: '',
          type: 'string'
        }];
      }

      this.parsedFields = parsedFields;
      this.setState({
        displayFields: displayFields,
        error: this.checkForErrors(parsedFields)
      }, this.updateParent.bind(this));
    }
  }, {
    key: "onNameChange",
    value: function onNameChange(index, e) {
      if (!e.target.value) {
        return;
      }

      var displayFields = this.state.displayFields;
      var parsedFields = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_10___default()(this.parsedFields);
      displayFields[index].name = e.target.value;
      parsedFields[index].name = e.target.value;
      this.parsedFields = parsedFields;
      this.setState({
        displayFields: displayFields,
        error: ''
      }, this.updateParent.bind(this));
    }
  }, {
    key: "onTypeChange",
    value: function onTypeChange(index, e) {
      var selectType = e.target.value;
      var displayFields = this.state.displayFields;
      var parsedFields = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_10___default()(this.parsedFields);
      var formattedType = services_cdapavscwrapper__WEBPACK_IMPORTED_MODULE_11__["default"].formatType(selectType);
      displayFields[index].displayType = selectType;
      displayFields[index].type = formattedType;

      if (displayFields[index].nullable) {
        parsedFields[index].type = [formattedType, 'null'];
      } else {
        parsedFields[index].type = formattedType;
      }

      this.parsedFields = parsedFields;
      this.setState({
        displayFields: displayFields,
        error: ''
      }, function () {
        if (!Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkComplexType"])(selectType)) {
          this.updateParent();
        }
      }.bind(this));
    }
  }, {
    key: "onNullableChange",
    value: function onNullableChange(index, e) {
      var displayFields = this.state.displayFields;
      var parsedFields = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_10___default()(this.parsedFields);
      displayFields[index].nullable = e.target.checked;

      if (e.target.checked) {
        parsedFields[index].type = [parsedFields[index].type, 'null'];
      } else {
        if (Array.isArray(parsedFields[index].type)) {
          parsedFields[index].type = parsedFields[index].type[0];
        }
      }

      this.parsedFields = parsedFields;
      this.setState({
        displayFields: displayFields,
        error: ''
      }, this.updateParent.bind(this));
    }
  }, {
    key: "checkForErrors",
    value: function checkForErrors(parsedTypes) {
      var parsedType = {
        name: this.state.name,
        type: 'record',
        fields: parsedTypes.filter(function (field) {
          return field.name && field.type;
        })
      };
      return Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkParsedTypeForError"])(parsedType);
    }
  }, {
    key: "onChildrenChange",
    value: function onChildrenChange(index, fieldType) {
      var parsedFields = this.parsedFields;
      var displayFields = this.state.displayFields;

      if (displayFields[index].nullable) {
        parsedFields[index].type = [fieldType, 'null'];
      } else {
        parsedFields[index].type = fieldType;
      }

      var error = this.checkForErrors(parsedFields);

      if (error) {
        this.setState({
          error: error
        });
        return;
      }

      this.parsedFields = parsedFields;
      this.updateParent();
    }
  }, {
    key: "updateParent",
    value: function updateParent() {
      var error = this.checkForErrors(this.parsedFields);

      if (error) {
        this.setState({
          error: error
        });
        return;
      }

      this.props.onChange({
        name: this.state.name,
        type: 'record',
        fields: this.parsedFields.filter(function (field) {
          return field.name && field.type;
        })
      });
    }
  }, {
    key: "toggleAbstractSchemaRow",
    value: function toggleAbstractSchemaRow(index) {
      var displayFields = this.state.displayFields;
      displayFields[index].showAbstractSchemaRow = !displayFields[index].showAbstractSchemaRow;
      this.setState({
        displayFields: displayFields
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var showArrow = function showArrow(row, index) {
        if (row.showAbstractSchemaRow) {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
            className: "fa fa-caret-down",
            onClick: _this3.toggleAbstractSchemaRow.bind(_this3, index)
          });
        }

        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "fa fa-caret-right",
          onClick: _this3.toggleAbstractSchemaRow.bind(_this3, index)
        });
      };

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "record-schema-row"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "text-danger"
      }, this.state.error), this.state.displayFields.map(function (row, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: classnames__WEBPACK_IMPORTED_MODULE_9___default()('schema-row', {
            nested: Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkComplexType"])(row.displayType)
          }),
          key: row.id
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "field-name"
        }, row.refRequired ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_5__["Input"], {
          placeholder: i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate('features.SchemaEditor.Labels.fieldName'),
          defaultValue: row.name,
          onFocus: function onFocus() {
            return row.name;
          },
          getRef: function getRef(ref) {
            return _this3.inputToFocus = ref;
          },
          onBlur: _this3.onNameChange.bind(_this3, index),
          onKeyPress: function onKeyPress(e) {
            return e.nativeEvent.keyCode === 13 ? _this3.onRowAdd(index, e) : null;
          }
        }) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_5__["Input"], {
          placeholder: i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate('features.SchemaEditor.Labels.fieldName'),
          defaultValue: row.name,
          onFocus: function onFocus() {
            return row.name;
          },
          onBlur: _this3.onNameChange.bind(_this3, index),
          onKeyPress: function onKeyPress(e) {
            return e.nativeEvent.keyCode === 13 ? _this3.onRowAdd(index, e) : null;
          }
        }), Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkComplexType"])(row.displayType) ? showArrow(row, index) : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "field-type"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SelectWithOptions__WEBPACK_IMPORTED_MODULE_6__["default"], {
          options: components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["SCHEMA_TYPES"].types,
          value: row.displayType,
          onChange: _this3.onTypeChange.bind(_this3, index)
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "field-isnull"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "btn btn-link"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("input", {
          type: "checkbox",
          checked: row.nullable,
          onChange: _this3.onNullableChange.bind(_this3, index)
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "btn btn-link"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "fa fa-plus fa-xs",
          onClick: _this3.onRowAdd.bind(_this3, index)
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "btn btn-link"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "fa fa-trash fa-xs text-danger",
          onClick: _this3.onRowRemove.bind(_this3, index)
        }))), Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkComplexType"])(row.displayType) && row.showAbstractSchemaRow ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SchemaEditor_AbstractSchemaRow__WEBPACK_IMPORTED_MODULE_3__["default"], {
          row: {
            type: Array.isArray(_this3.parsedFields[index].type) ? _this3.parsedFields[index].type[0] : _this3.parsedFields[index].type,
            displayType: row.displayType
          },
          onChange: _this3.onChildrenChange.bind(_this3, index)
        }) : null);
      }));
    }
  }]);

  return RecordSchemaRow;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


RecordSchemaRow.propTypes = {
  row: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.any,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func.isRequired
};

/***/ }),

/***/ "./components/SchemaEditor/SchemaEditor.scss":
/*!***************************************************!*\
  !*** ./components/SchemaEditor/SchemaEditor.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./SchemaEditor.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/SchemaEditor.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SchemaEditor/UnionSchemaRow/UnionSchemaRow.scss":
/*!********************************************************************!*\
  !*** ./components/SchemaEditor/UnionSchemaRow/UnionSchemaRow.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./UnionSchemaRow.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SchemaEditor/UnionSchemaRow/UnionSchemaRow.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SchemaEditor/UnionSchemaRow/index.js":
/*!*********************************************************!*\
  !*** ./components/SchemaEditor/UnionSchemaRow/index.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return UnionSchemaRow; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/SchemaEditor/SchemaHelpers */ "./components/SchemaEditor/SchemaHelpers.js");
/* harmony import */ var components_SelectWithOptions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/SelectWithOptions */ "./components/SelectWithOptions/index.js");
/* harmony import */ var components_SchemaEditor_AbstractSchemaRow__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/SchemaEditor/AbstractSchemaRow */ "./components/SchemaEditor/AbstractSchemaRow/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash/cloneDeep */ "../../node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9__);
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */











__webpack_require__(/*! ./UnionSchemaRow.scss */ "./components/SchemaEditor/UnionSchemaRow/UnionSchemaRow.scss");

var UnionSchemaRow =
/*#__PURE__*/
function (_Component) {
  _inherits(UnionSchemaRow, _Component);

  function UnionSchemaRow(props) {
    var _this;

    _classCallCheck(this, UnionSchemaRow);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(UnionSchemaRow).call(this, props));

    if (_typeof(props.row) === 'object') {
      var rowType = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["parseType"])(props.row);
      var parsedTypes = rowType.type.getTypes();
      var displayTypes = parsedTypes.map(function (type) {
        return Object.assign({}, Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["parseType"])(type), {
          id: 'a' + uuid_v4__WEBPACK_IMPORTED_MODULE_7___default()()
        });
      });
      _this.state = {
        displayTypes: displayTypes,
        error: ''
      };
      _this.parsedTypes = parsedTypes;
    } else {
      _this.state = {
        displayTypes: [{
          displayType: 'string',
          type: 'string',
          id: uuid_v4__WEBPACK_IMPORTED_MODULE_7___default()(),
          nullable: false
        }],
        error: ''
      };
      _this.parsedTypes = ['string'];
    }

    setTimeout(_this.updateParent.bind(_assertThisInitialized(_this)));
    _this.onTypeChange = _this.onTypeChange.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(UnionSchemaRow, [{
    key: "updateParent",
    value: function updateParent() {
      var error = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkParsedTypeForError"])(this.parsedTypes);

      if (error) {
        this.setState({
          error: error
        });
        return;
      }

      this.props.onChange(this.parsedTypes);
    }
  }, {
    key: "onNullableChange",
    value: function onNullableChange(index, e) {
      var displayTypes = this.state.displayTypes;
      var parsedTypes = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9___default()(this.parsedTypes);
      displayTypes[index].nullable = e.target.checked;

      if (e.target.checked) {
        parsedTypes[index] = [parsedTypes[index], 'null'];
      } else {
        parsedTypes[index] = parsedTypes[index][0];
      }

      this.parsedTypes = parsedTypes;
      this.setState({
        displayTypes: displayTypes,
        error: ''
      }, this.updateParent.bind(this));
    }
  }, {
    key: "onTypeChange",
    value: function onTypeChange(index, e) {
      var _this2 = this;

      var selectedType = e.target.value;
      var displayTypes = this.state.displayTypes;
      displayTypes[index].displayType = selectedType;
      displayTypes[index].type = selectedType;
      var parsedTypes = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9___default()(this.parsedTypes);

      if (displayTypes[index].nullable) {
        parsedTypes[index] = [selectedType, 'null'];
      } else {
        parsedTypes[index] = selectedType;
      }

      this.parsedTypes = parsedTypes;
      this.setState({
        displayTypes: displayTypes,
        error: ''
      }, function () {
        if (!Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkComplexType"])(selectedType)) {
          _this2.updateParent();
        }
      });
    }
  }, {
    key: "onTypeAdd",
    value: function onTypeAdd(index) {
      var displayTypes = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["insertAt"])(_toConsumableArray(this.state.displayTypes), index, {
        type: 'string',
        displayType: 'string',
        id: uuid_v4__WEBPACK_IMPORTED_MODULE_7___default()(),
        nullable: false
      });
      var parsedTypes = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["insertAt"])(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9___default()(this.parsedTypes), index, 'string');
      this.parsedTypes = parsedTypes;
      this.setState({
        displayTypes: displayTypes
      }, this.updateParent.bind(this));
    }
  }, {
    key: "onTypeRemove",
    value: function onTypeRemove(index) {
      var displayTypes = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["removeAt"])(_toConsumableArray(this.state.displayTypes), index);
      var parsedTypes = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["removeAt"])(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9___default()(this.parsedTypes), index);
      this.parsedTypes = parsedTypes;
      this.setState({
        displayTypes: displayTypes
      }, this.updateParent.bind(this));
    }
  }, {
    key: "onChildrenChange",
    value: function onChildrenChange(index, parsedType) {
      var parsedTypes = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9___default()(this.parsedTypes);
      var displayTypes = this.state.displayTypes;
      var error;

      if (displayTypes[index].nullable) {
        parsedTypes[index] = [parsedType, 'null'];
      } else {
        parsedTypes[index] = parsedType;
      }

      error = Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkParsedTypeForError"])(parsedTypes);

      if (error) {
        this.setState({
          error: error
        });
        return;
      }

      this.parsedTypes = parsedTypes;
      this.updateParent();
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "union-schema-row"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "text-danger"
      }, this.state.error), this.state.displayTypes.map(function (displayType, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('schema-row', {
            nested: Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkComplexType"])(displayType.displayType)
          }),
          key: displayType.id
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "field-name"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SelectWithOptions__WEBPACK_IMPORTED_MODULE_3__["default"], {
          options: components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["SCHEMA_TYPES"].types,
          value: displayType.displayType,
          onChange: _this3.onTypeChange.bind(_this3, index)
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "field-type"
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "field-isnull"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "btn btn-link"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_5__["Input"], {
          type: "checkbox",
          addon: true,
          checked: displayType.nullable,
          onChange: _this3.onNullableChange.bind(_this3, index)
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "btn btn-link"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "fa fa-plus",
          onClick: _this3.onTypeAdd.bind(_this3, index)
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "btn btn-link"
        }, _this3.state.displayTypes.length !== 1 ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "fa fa-trash fa-xs text-danger",
          onClick: _this3.onTypeRemove.bind(_this3, index)
        }) : null)), Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_2__["checkComplexType"])(displayType.displayType) ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SchemaEditor_AbstractSchemaRow__WEBPACK_IMPORTED_MODULE_4__["default"], {
          row: {
            type: Array.isArray(displayType.type) ? displayType.type[0] : displayType.type,
            displayType: displayType.displayType
          },
          onChange: _this3.onChildrenChange.bind(_this3, index)
        }) : null);
      }));
    }
  }]);

  return UnionSchemaRow;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


UnionSchemaRow.propTypes = {
  row: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.any,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func.isRequired
};

/***/ }),

/***/ "./components/SchemaEditor/index.js":
/*!******************************************!*\
  !*** ./components/SchemaEditor/index.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SchemaEditor; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_SchemaEditor_RecordSchemaRow__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/SchemaEditor/RecordSchemaRow */ "./components/SchemaEditor/RecordSchemaRow/index.js");
/* harmony import */ var components_SchemaEditor_SchemaStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/SchemaEditor/SchemaStore */ "./components/SchemaEditor/SchemaStore.js");
/* harmony import */ var services_cdapavscwrapper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/cdapavscwrapper */ "./services/cdapavscwrapper/index.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */



__webpack_require__(/*! ./SchemaEditor.scss */ "./components/SchemaEditor/SchemaEditor.scss");





var SchemaEditor =
/*#__PURE__*/
function (_Component) {
  _inherits(SchemaEditor, _Component);

  function SchemaEditor(props) {
    var _this;

    _classCallCheck(this, SchemaEditor);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(SchemaEditor).call(this, props));
    var state = components_SchemaEditor_SchemaStore__WEBPACK_IMPORTED_MODULE_3__["default"].getState();
    var rows;

    try {
      rows = services_cdapavscwrapper__WEBPACK_IMPORTED_MODULE_4__["default"].parse(state.schema, {
        wrapUnions: true
      });
    } catch (e) {
      console.log('Error parsing schema: ', e);
    }

    _this.state = {
      parsedRows: rows,
      rawSchema: state.schema
    };

    var updateRowsAndDisplayFields = function updateRowsAndDisplayFields() {
      var state = components_SchemaEditor_SchemaStore__WEBPACK_IMPORTED_MODULE_3__["default"].getState();
      var rows;

      try {
        rows = services_cdapavscwrapper__WEBPACK_IMPORTED_MODULE_4__["default"].parse(state.schema, {
          wrapUnions: true
        });
      } catch (e) {
        return;
      }

      _this.setState({
        parsedRows: rows,
        rawSchema: state.schema
      });
    };

    components_SchemaEditor_SchemaStore__WEBPACK_IMPORTED_MODULE_3__["default"].subscribe(updateRowsAndDisplayFields.bind(_assertThisInitialized(_this)));
    return _this;
  }

  _createClass(SchemaEditor, [{
    key: "shouldComponentUpdate",
    value: function shouldComponentUpdate(nextProps, nextState) {
      if (!nextState.rawSchema) {
        return true;
      }

      return nextState.rawSchema.fields.length !== this.state.rawSchema.fields.length;
    }
  }, {
    key: "onChange",
    value: function onChange(schema) {
      components_SchemaEditor_SchemaStore__WEBPACK_IMPORTED_MODULE_3__["default"].dispatch({
        type: 'FIELD_UPDATE',
        payload: {
          schema: schema
        }
      });
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_redux__WEBPACK_IMPORTED_MODULE_1__["Provider"], {
        store: components_SchemaEditor_SchemaStore__WEBPACK_IMPORTED_MODULE_3__["default"]
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "schema-editor"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "schema-header"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "field-name"
      }, "Name"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "field-type"
      }, "Type"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "field-isnull"
      }, "Null")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "schema-body"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_SchemaEditor_RecordSchemaRow__WEBPACK_IMPORTED_MODULE_2__["default"], {
        row: this.state.parsedRows,
        onChange: this.onChange.bind(this)
      }))));
    }
  }]);

  return SchemaEditor;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);



/***/ })

}]);
//# sourceMappingURL=SchemaEditor.5ee5c515ed38475ddf6d.js.map