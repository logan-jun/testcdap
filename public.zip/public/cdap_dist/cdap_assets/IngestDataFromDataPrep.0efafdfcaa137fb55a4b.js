(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["IngestDataFromDataPrep"],{

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/DataPrep/TopPanel/IngestDataFromDataPrep/IngestDataFromDataPrep.scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/DataPrep/TopPanel/IngestDataFromDataPrep/IngestDataFromDataPrep.scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.cdap-modal.dataprep-create-dataset-modal form input.form-control,\n.cdap-modal.dataprep-create-dataset-modal form select.form-control {\n  width: calc(100% - 20px);\n  display: inline-block;\n  margin-right: 5px; }\n\n.cdap-modal.dataprep-create-dataset-modal form .icon-info-circle {\n  fill: #5a84e4;\n  cursor: pointer; }\n\n.cdap-modal.dataprep-create-dataset-modal form .dataset-name-group {\n  position: relative; }\n  .cdap-modal.dataprep-create-dataset-modal form .dataset-name-group .required-label {\n    position: absolute;\n    top: -21px; }\n\n.cdap-modal.dataprep-create-dataset-modal form .col-form-label .text-danger {\n  margin-left: 3px; }\n\n.cdap-modal.dataprep-create-dataset-modal form .input-type-group button:focus, .cdap-modal.dataprep-create-dataset-modal form .input-type-group button:active {\n  outline: none; }\n\n.cdap-modal.dataprep-create-dataset-modal .modal-header .close-section.disabled {\n  color: #cccccc;\n  cursor: not-allowed; }\n\n.cdap-modal.dataprep-create-dataset-modal .modal-body {\n  min-height: 200px; }\n  .cdap-modal.dataprep-create-dataset-modal .modal-body.copying-steps-container {\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-pack: center;\n            justify-content: center;\n    -webkit-box-align: center;\n            align-items: center;\n    font-size: 18px; }\n    .cdap-modal.dataprep-create-dataset-modal .modal-body.copying-steps-container .steps-container .step-container > span:first-child {\n      margin-right: 5px; }\n    .cdap-modal.dataprep-create-dataset-modal .modal-body.copying-steps-container .steps-container .btn.btn-primary {\n      margin-top: 15px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./api/app.js":
/*!********************!*\
  !*** ./api/app.js ***!
  \********************/
/*! exports provided: MyAppApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyAppApi", function() { return MyAppApi; });
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__["default"].getInstance();
var basepath = '/namespaces/:namespace/apps';
var appPath = "".concat(basepath, "/:appId");
var MyAppApi = {
  list: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  deployApp: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'PUT', 'REQUEST', appPath),
  get: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', appPath),
  getVersions: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(appPath, "/versions")),
  getDeployedApp: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  batchStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'POLL', '/namespaces/:namespace/status'),
  batchAppDetail: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', '/namespaces/:namespace/appdetail'),
  "delete": Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', appPath)
};

/***/ }),

/***/ "./api/program.js":
/*!************************!*\
  !*** ./api/program.js ***!
  \************************/
/*! exports provided: MyProgramApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyProgramApi", function() { return MyProgramApi; });
/* harmony import */ var services_datasource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/datasource */ "./services/datasource/index.js");
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = new services_datasource__WEBPACK_IMPORTED_MODULE_0__["default"]();
var basepath = '/namespaces/:namespace/apps/:appId/:programType/:programId';
var MyProgramApi = {
  get: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  status: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/status")),
  runs: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/runs")),
  pollRuns: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'POLL', "".concat(basepath, "/runs")),
  pollStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'POLL', "".concat(basepath, "/status")),
  action: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/:action")),
  stopRun: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/runs/:runId/stop"))
};

/***/ }),

/***/ "./components/DataPrep/TopPanel/IngestDataFromDataPrep/IngestDataFromDataPrep.scss":
/*!*****************************************************************************************!*\
  !*** ./components/DataPrep/TopPanel/IngestDataFromDataPrep/IngestDataFromDataPrep.scss ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./IngestDataFromDataPrep.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/DataPrep/TopPanel/IngestDataFromDataPrep/IngestDataFromDataPrep.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/DataPrep/TopPanel/IngestDataFromDataPrep/index.js":
/*!**********************************************************************!*\
  !*** ./components/DataPrep/TopPanel/IngestDataFromDataPrep/index.js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return IngestDataFromDataPrep; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/UncontrolledComponents */ "./components/UncontrolledComponents/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_DataPrep_store___WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/DataPrep/store/ */ "./components/DataPrep/store/index.js");
/* harmony import */ var components_DataPrep_TopPanel_PipelineConfigHelper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/DataPrep/TopPanel/PipelineConfigHelper */ "./components/DataPrep/TopPanel/PipelineConfigHelper.js");
/* harmony import */ var api_artifact__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! api/artifact */ "./api/artifact.js");
/* harmony import */ var api_dataset__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! api/dataset */ "./api/dataset.js");
/* harmony import */ var api_app__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! api/app */ "./api/app.js");
/* harmony import */ var api_program__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! api/program */ "./api/program.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var lodash_find__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! lodash/find */ "../../node_modules/lodash/find.js");
/* harmony import */ var lodash_find__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(lodash_find__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! lodash/isNil */ "../../node_modules/lodash/isNil.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(lodash_isNil__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash/isEmpty */ "../../node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! lodash/cloneDeep */ "../../node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var components_CardActionFeedback__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! components/CardActionFeedback */ "./components/CardActionFeedback/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */























__webpack_require__(/*! ./IngestDataFromDataPrep.scss */ "./components/DataPrep/TopPanel/IngestDataFromDataPrep/IngestDataFromDataPrep.scss");

var PREFIX = "features.DataPrep.TopPanel.copyToCDAPDatasetBtn";
var fieldsetDataType = [{
  id: 'TPFSAvro',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Formats.avro"))
}, {
  id: 'TPFSOrc',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Formats.orc"))
}, {
  id: 'TPFSParquet',
  label: i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Formats.parquet"))
}];
var copyingSteps = [{
  message: i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".copyingSteps.Step1")),
  error: i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".copyingSteps.Step1Error")),
  status: null
}, {
  message: i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".copyingSteps.Step2")),
  error: i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".copyingSteps.Step2Error")),
  status: null
}];

var IngestDataFromDataPrep =
/*#__PURE__*/
function (_Component) {
  _inherits(IngestDataFromDataPrep, _Component);

  function IngestDataFromDataPrep() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, IngestDataFromDataPrep);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(IngestDataFromDataPrep)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", _this.getDefaultState());

    _defineProperty(_assertThisInitialized(_this), "toggleModal", function () {
      var state = Object.assign(_this.getDefaultState(), {
        showModal: !_this.state.showModal,
        sinkPluginsForDataset: _this.state.sinkPluginsForDataset,
        batchPipelineConfig: _this.state.batchPipelineConfig
      });

      _this.setState(state);

      if (!_this.state.showModal) {
        Object(components_DataPrep_TopPanel_PipelineConfigHelper__WEBPACK_IMPORTED_MODULE_9__["default"])().subscribe(function (res) {
          _this.setState({
            batchPipelineConfig: res.batchConfig
          });
        }, function (err) {
          _this.setState({
            error: err
          });
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleDatasetNameChange", function (e) {
      _this.setState({
        datasetName: e.target.value
      });
    });

    _defineProperty(_assertThisInitialized(_this), "handleRowkeyChange", function (e) {
      _this.setState({
        rowKey: e.target.value
      });
    });

    _defineProperty(_assertThisInitialized(_this), "handleFormatChange", function (e) {
      _this.setState({
        format: e.target.value
      });
    });

    _defineProperty(_assertThisInitialized(_this), "handleOnSubmit", function (e) {
      Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["preventPropagation"])(e);
      return false;
    });

    _defineProperty(_assertThisInitialized(_this), "submitForm", function () {
      var steps = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default()(copyingSteps);

      var _DataPrepStore$getSta = components_DataPrep_store___WEBPACK_IMPORTED_MODULE_8__["default"].getState(),
          dataprep = _DataPrepStore$getSta.dataprep;

      var workspaceProps = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(dataprep, 'workspaceInfo', 'properties');
      steps[0].status = 'running';

      _this.setState({
        copyInProgress: true,
        copyingSteps: steps
      });

      var _NamespaceStore$getSt = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_14__["default"].getState(),
          namespace = _NamespaceStore$getSt.selectedNamespace;

      var pipelineName; // FIXME: We need to fix backend to enable adding macro to pluginType and name in database.
      // Right now we don't support it and hence UI creates new pipeline based on jdbc plugin name.

      var dbStage = _this.state.batchPipelineConfig.config.stages.find(function (dataType) {
        return dataType.name === 'Database';
      });

      if (_this.state.inputType === 'fileset') {
        pipelineName = "one_time_copy_to_fs_".concat(_this.state.format);

        if (workspaceProps.connection === 'database') {
          pipelineName = "one_time_copy_to_fs_from_".concat(dbStage.plugin.properties.jdbcPluginName);
        } else if (workspaceProps.connection === 'kafka') {
          pipelineName = 'one_time_copy_to_fs_from_kafka';
        } else if (workspaceProps.connection === 's3') {
          pipelineName = 'one_time_copy_to_fs_from_s3';
        } else if (workspaceProps.connection === 'gcs') {
          pipelineName = 'one_time_copy_to_fs_from_gcs';
        } else if (workspaceProps.connection === 'bigquery') {
          pipelineName = 'one_time_copy_to_fs_from_bigquery';
        } else if (workspaceProps.connection === 'spanner') {
          pipelineName = 'one_time_copy_to_fs_from_spanner';
        } else if (workspaceProps.connection === 'adls') {
          pipelineName = 'one_time_copy_to_fs_from_adls';
        }
      } else {
        pipelineName = "one_time_copy_to_table";

        if (workspaceProps.connection === 'database') {
          pipelineName = "one_time_copy_to_table_from_".concat(dbStage.plugin.properties.jdbcPluginName);
        } else if (workspaceProps.connection === 'kafka') {
          pipelineName = 'one_time_copy_to_table_from_kafka';
        } else if (workspaceProps.connection === 's3') {
          pipelineName = 'one_time_copy_to_table_from_s3';
        } else if (workspaceProps.connection === 'gcs') {
          pipelineName = 'one_time_copy_to_table_from_gcs';
        } else if (workspaceProps.connection === 'bigquery') {
          pipelineName = 'one_time_copy_to_table_from_bigquery';
        } else if (workspaceProps.connection === 'spanner') {
          pipelineName = 'one_time_copy_to_table_from_spanner';
        } else if (workspaceProps.connection === 'adls') {
          pipelineName = 'one_time_copy_to_table_from_adls';
        }
      }

      pipelineName = pipelineName.replace('TPFS', '');
      pipelineName = pipelineName.toLowerCase();
      var pipelineconfig, macroMap; // Get list of pipelines to check if the pipeline is already published

      api_app__WEBPACK_IMPORTED_MODULE_12__["MyAppApi"].list({
        namespace: namespace
      }).mergeMap(function (res) {
        var appAlreadyDeployed = res.find(function (app) {
          return app.id === pipelineName;
        });

        if (!appAlreadyDeployed) {
          var appConfigWithMacros = _this.preparePipelineConfig();

          pipelineconfig = appConfigWithMacros.appConfig;
          macroMap = appConfigWithMacros.macroMap;
          pipelineconfig.name = pipelineName;
          var params = {
            namespace: namespace,
            appId: pipelineName
          }; // If it doesn't exist create a new pipeline with macros.

          return api_app__WEBPACK_IMPORTED_MODULE_12__["MyAppApi"].deployApp(params, pipelineconfig);
        } // If it already exists just move to next step.


        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_19__["Observable"].create(function (observer) {
          observer.next();
        });
      }).mergeMap(function () {
        var copyingSteps = _toConsumableArray(_this.state.copyingSteps);

        copyingSteps[0].status = 'success';
        copyingSteps[1].status = 'running';

        _this.setState({
          copyingSteps: copyingSteps
        });

        if (!macroMap) {
          macroMap = _this.getAppConfigMacros();
        } // Once the pipeline is published start the workflow. Pass run time arguments for macros.


        return api_program__WEBPACK_IMPORTED_MODULE_13__["MyProgramApi"].action({
          namespace: namespace,
          appId: pipelineName,
          programType: 'workflows',
          programId: 'DataPipelineWorkflow',
          action: 'start'
        }, macroMap);
      }).mergeMap(function () {
        _this.setState({
          copyTaskStarted: true
        });

        var count = 1;

        var getDataset = function getDataset(callback, errorCallback, count) {
          var params = {
            namespace: namespace,
            datasetId: _this.state.datasetName
          };
          api_dataset__WEBPACK_IMPORTED_MODULE_11__["MyDatasetApi"].get(params).subscribe(callback, function () {
            if (count < 120) {
              count += count;
              setTimeout(function () {
                getDataset(callback, errorCallback, count);
              }, count * 1000);
            } else {
              errorCallback();
            }
          });
        };

        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_19__["Observable"].create(function (observer) {
          var successCallback = function successCallback() {
            observer.next();
          };

          var errorCallback = function errorCallback() {
            observer.error('Copy task timed out after 2 mins. Please check logs for more information.');
          };

          getDataset(successCallback, errorCallback, count);
        });
      }).subscribe(function () {
        // Once workflow started successfully create a link to pipeline datasets tab for user reference.
        var copyingSteps = _toConsumableArray(_this.state.copyingSteps);

        var _NamespaceStore$getSt2 = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_14__["default"].getState(),
            namespaceId = _NamespaceStore$getSt2.selectedNamespace;

        copyingSteps[1].status = 'success';
        var datasetUrl = window.getAbsUIUrl({
          namespaceId: namespaceId,
          entityType: 'datasets',
          entityId: _this.state.datasetName
        });
        datasetUrl = "".concat(datasetUrl, "?modalToOpen=explore");

        _this.setState({
          copyingSteps: copyingSteps,
          datasetUrl: datasetUrl
        });
      }, function (err) {
        console.log('err', err);

        var copyingSteps = _this.state.copyingSteps.map(function (step) {
          if (step.status === 'running') {
            return Object.assign({}, step, {
              status: 'failure'
            });
          }

          return step;
        });

        var state = {
          copyingSteps: copyingSteps
        };

        if (!_this.state.error) {
          state.error = _typeof(err) === 'object' ? err.response : err;
        }

        _this.setState(state);
      }); // FIXME: Need to handle the failure case here as well.
    });

    return _this;
  }

  _createClass(IngestDataFromDataPrep, [{
    key: "getDefaultState",
    value: function getDefaultState() {
      var headers = components_DataPrep_store___WEBPACK_IMPORTED_MODULE_8__["default"].getState().dataprep.headers;
      return {
        showModal: false,
        inputType: 'fileset',
        rowKey: headers.length ? headers[0] : null,
        format: fieldsetDataType[0].id,
        sinkPluginsForDataset: {},
        batchPipelineConfig: {},
        datasetName: '',
        copyingSteps: [].concat(copyingSteps),
        copyInProgress: false,
        // This is to enable closing the modal on workflow start.
        // Ideally users won't wait till the dataset is created (till pipeline runs successfully and creates the dataset)
        copyTaskStarted: false,
        datasetUrl: null,
        error: null
      };
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      var _this2 = this;

      var _NamespaceStore$getSt3 = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_14__["default"].getState(),
          namespace = _NamespaceStore$getSt3.selectedNamespace;

      var corePlugins;
      api_artifact__WEBPACK_IMPORTED_MODULE_10__["MyArtifactApi"].list({
        namespace: namespace
      }).subscribe(function (res) {
        corePlugins = lodash_find__WEBPACK_IMPORTED_MODULE_15___default()(res, {
          name: 'core-plugins'
        });

        if (corePlugins) {
          corePlugins.version = '[1.7.0, 3.0.0)';
        }

        var getPluginConfig = function getPluginConfig(pluginName) {
          return {
            name: pluginName,
            plugin: {
              name: pluginName,
              label: pluginName,
              type: 'batchsink',
              artifact: corePlugins,
              properties: {}
            }
          };
        };

        var sinks = {
          TPFSAvro: getPluginConfig('TPFSAvro'),
          TPFSParquet: getPluginConfig('TPFSParquet'),
          TPFSOrc: getPluginConfig('TPFSOrc'),
          Table: getPluginConfig('Table')
        };

        _this2.setState({
          sinkPluginsForDataset: sinks
        });
      });
    }
  }, {
    key: "getAppConfigMacros",
    value: function getAppConfigMacros() {
      var _DataPrepStore$getSta2 = components_DataPrep_store___WEBPACK_IMPORTED_MODULE_8__["default"].getState().dataprep,
          workspaceInfo = _DataPrepStore$getSta2.workspaceInfo,
          directives = _DataPrepStore$getSta2.directives,
          headers = _DataPrepStore$getSta2.headers;
      var pipelineConfig = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default()(this.state.batchPipelineConfig);
      var wranglerStage = pipelineConfig.config.stages.find(function (stage) {
        return stage.name === 'Wrangler';
      });
      var dbStage = pipelineConfig.config.stages.find(function (stage) {
        return stage.name === 'Database';
      });
      var kafkaStage = pipelineConfig.config.stages.find(function (stage) {
        return stage.name === 'Kafka';
      });
      var databaseConfig = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(workspaceInfo, 'properties', 'databaseConfig');
      var s3Stage = pipelineConfig.config.stages.find(function (stage) {
        return stage.name === 'S3';
      });
      var gcsStage = pipelineConfig.config.stages.find(function (stage) {
        return stage.name === 'GCS';
      });
      var bigqueryStage = pipelineConfig.config.stages.find(function (stage) {
        return stage.name === 'BigQueryTable';
      });
      var spannerStage = pipelineConfig.config.stages.find(function (stage) {
        return stage.name === 'Spanner';
      });
      var adlsStage = pipelineConfig.config.stages.find(function (stage) {
        return stage.name === 'ADLS';
      });
      var macroMap = {};

      if (databaseConfig) {
        try {
          databaseConfig = JSON.parse(databaseConfig);
        } catch (e) {
          databaseConfig = {};
        }

        macroMap = Object.assign(macroMap, databaseConfig);
      }

      macroMap = Object.assign({}, macroMap, {
        datasetName: this.state.datasetName,
        filename: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(workspaceInfo, 'properties', 'path') || '',
        directives: directives.join('\n'),
        schema: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(wranglerStage, 'plugin', 'properties', 'schema') || '',
        schemaRowField: lodash_isNil__WEBPACK_IMPORTED_MODULE_16___default()(this.state.rowKey) ? headers[0] : this.state.rowKey,
        query: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(dbStage, 'plugin', 'properties', 'importQuery') || '',
        connectionString: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(dbStage, 'plugin', 'properties', 'connectionString') || '',
        password: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(dbStage, 'plugin', 'properties', 'password') || '',
        userName: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(dbStage, 'plugin', 'properties', 'user') || '',
        topic: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(kafkaStage, 'plugin', 'properties', 'topic') || '',
        kafkaBrokers: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(kafkaStage, 'plugin', 'properties', 'kafkaBrokers') || '',
        accessID: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(s3Stage, 'plugin', 'properties', 'accessID') || '',
        path: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(s3Stage, 'plugin', 'properties', 'path') || Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(gcsStage, 'plugin', 'properties', 'path') || '',
        // This is Goofed
        accessKey: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(s3Stage, 'plugin', 'properties', 'accessKey') || '',
        bucket: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(gcsStage, 'plugin', 'properties', 'bucket') || '',
        serviceFilePath: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(gcsStage, 'plugin', 'properties', 'serviceFilePath') || '',
        project: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(gcsStage, 'plugin', 'properties', 'project') || '',
        bqBucket: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(bigqueryStage, 'plugin', 'properties', 'bucket') || '',
        bqServiceFilePath: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(bigqueryStage, 'plugin', 'properties', 'serviceFilePath') || '',
        bqProject: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(bigqueryStage, 'plugin', 'properties', 'project') || '',
        bqDataset: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(bigqueryStage, 'plugin', 'properties', 'dataset') || '',
        bqTable: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(bigqueryStage, 'plugin', 'properties', 'table') || '',
        bqSchema: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(bigqueryStage, 'plugin', 'properties', 'schema') || '',
        spannerServiceFilePath: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(spannerStage, 'plugin', 'properties', 'serviceFilePath') || '',
        spannerProject: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(spannerStage, 'plugin', 'properties', 'project') || '',
        spannerInstance: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(spannerStage, 'plugin', 'properties', 'instance') || '',
        spannerDatabase: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(spannerStage, 'plugin', 'properties', 'database') || '',
        spannerTable: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(spannerStage, 'plugin', 'properties', 'table') || '',
        spannerSchema: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(spannerStage, 'plugin', 'properties', 'schema') || '',
        adlsProject: Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(adlsStage, 'plugin', 'properties', 'project') || ''
      });
      var newMacorMap = {}; // This is to prevent from passing all the empty properties as payload while starting the pipeline.

      Object.keys(macroMap).filter(function (key) {
        return !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_17___default()(macroMap[key]);
      }).forEach(function (key) {
        return newMacorMap[key] = macroMap[key];
      });
      return newMacorMap;
    }
  }, {
    key: "addMacrosToPipelineConfig",
    value: function addMacrosToPipelineConfig(pipelineConfig) {
      var _DataPrepStore$getSta3 = components_DataPrep_store___WEBPACK_IMPORTED_MODULE_8__["default"].getState(),
          dataprep = _DataPrepStore$getSta3.dataprep;

      var workspaceProps = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(dataprep, 'workspaceInfo', 'properties');
      var macroMap = this.getAppConfigMacros();
      var dataFormatProperties = {
        schema: '${schema}',
        name: '${datasetName}'
      };
      var pluginsMap = {
        Wrangler: {
          directives: '${directives}',
          schema: '${schema}',
          field: workspaceProps.connection === 'file' ? 'body' : '*',
          precondition: 'false',
          threshold: '1'
        },
        File: {
          path: '${filename}',
          referenceName: 'FileNode'
        },
        Table: {
          'schema.row.field': '${schemaRowField}',
          name: '${datasetName}',
          schema: '${schema}'
        },
        Database: {
          connectionString: '${connectionString}',
          user: '${userName}',
          password: '${password}',
          importQuery: '${query}'
        },
        Kafka: {
          referenceName: 'KafkaNode',
          kafkaBrokers: '${kafkaBrokers}',
          topic: '${topic}'
        },
        TPFSOrc: dataFormatProperties,
        TPFSParquet: dataFormatProperties,
        TPFSAvro: dataFormatProperties,
        S3: {
          accessID: '${accessID}',
          path: '${path}',
          accessKey: '${accessKey}',
          authenticationMethod: 'Access Credentials',
          recursive: 'false'
        },
        GCS: {
          bucket: '${bucket}',
          filenameOnly: 'false',
          path: '${path}',
          serviceFilePath: '${serviceFilePath}',
          project: '${project}',
          recursive: 'false',
          ignoreNonExistingFolders: 'false'
        },
        BigQueryTable: {
          project: '${bqProject}',
          serviceFilePath: '${bqServiceFilePath}',
          bucket: '${bqBucket}',
          dataset: '${bqDataset}',
          table: '${bqTable}',
          schema: '${bqSchema}'
        },
        Spanner: {
          project: '${spannerProject}',
          serviceFilePath: '${spannerServiceFilePath}',
          instance: '${spannerInstance}',
          database: '${spannerDatabase}',
          table: '${spannerTable}',
          schema: '${spannerSchema}'
        },
        ADLS: {
          project: '${adlsProject}'
        }
      };
      pipelineConfig.config.stages = pipelineConfig.config.stages.map(function (stage) {
        if (!lodash_isNil__WEBPACK_IMPORTED_MODULE_16___default()(pluginsMap[stage.name])) {
          stage.plugin.properties = Object.assign({}, stage.plugin.properties, pluginsMap[stage.name]);
        }

        return stage;
      });
      return {
        pipelineConfig: pipelineConfig,
        macroMap: macroMap
      };
    }
  }, {
    key: "preparePipelineConfig",
    value: function preparePipelineConfig() {
      var _this3 = this;

      var sink;
      var workspaceInfo = components_DataPrep_store___WEBPACK_IMPORTED_MODULE_8__["default"].getState().dataprep.workspaceInfo;
      var pipelineName = workspaceInfo.properties.name;
      var pipelineconfig = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default()(this.state.batchPipelineConfig);

      if (this.state.inputType === 'fileset') {
        sink = fieldsetDataType.find(function (dataType) {
          return dataType.id === _this3.state.format;
        });

        if (sink) {
          sink = this.state.sinkPluginsForDataset[sink.id];
        }
      }

      if (this.state.inputType === 'table') {
        sink = this.state.sinkPluginsForDataset['Table'];
      }

      pipelineconfig.config.stages.push(sink);

      var _this$addMacrosToPipe = this.addMacrosToPipelineConfig(pipelineconfig),
          appConfig = _this$addMacrosToPipe.pipelineConfig,
          macroMap = _this$addMacrosToPipe.macroMap;

      var connections = this.state.batchPipelineConfig.config.connections;
      var sinkConnection = [{
        from: connections[0].to,
        to: sink.name
      }];
      appConfig.config.connections = connections.concat(sinkConnection);
      appConfig.config.schedule = '0 * * * *';
      appConfig.config.engine = 'mapreduce';
      appConfig.description = "Pipeline to create dataset for workspace ".concat(pipelineName, " from dataprep");
      return {
        appConfig: appConfig,
        macroMap: macroMap
      };
    }
  }, {
    key: "setType",
    value: function setType(type) {
      this.setState({
        inputType: type
      });
    }
  }, {
    key: "renderDatasetSpecificContent",
    value: function renderDatasetSpecificContent() {
      if (this.state.inputType === 'table') {
        var headers = components_DataPrep_store___WEBPACK_IMPORTED_MODULE_8__["default"].getState().dataprep.headers;
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
          row: true
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Label"], {
          xs: "4",
          className: "text-right"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Form.rowKeyLabel")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "text-danger"
        }, "*")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
          xs: "6"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
          type: "select",
          onChange: this.handleRowkeyChange,
          value: this.state.rowKey
        }, headers.map(function (header, index) {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("option", {
            value: header,
            key: index
          }, header);
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
          id: "row-key-info-icon",
          name: "icon-info-circle"
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_4__["UncontrolledTooltip"], {
          target: "row-key-info-icon",
          delay: {
            show: 250,
            hide: 0
          }
        }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Form.rowKeyTooltip")))));
      }

      if (this.state.inputType === 'fileset') {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
          row: true
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Label"], {
          xs: "4",
          className: "text-right"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Form.formatLabel")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "text-danger"
        }, "*")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
          xs: "6"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
          type: "select",
          onChange: this.handleFormatChange,
          value: this.state.format
        }, fieldsetDataType.map(function (datatype, index) {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("option", {
            value: datatype.id,
            key: index
          }, datatype.label);
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
          id: "row-key-info-icon",
          name: "icon-info-circle"
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_4__["UncontrolledTooltip"], {
          target: "row-key-info-icon",
          delay: {
            show: 250,
            hide: 0
          }
        }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Form.formatTooltip")))));
      }
    }
  }, {
    key: "renderSteps",
    value: function renderSteps() {
      if (!this.state.copyInProgress) {
        return null;
      }

      var statusContainer = function statusContainer(status) {
        var icon, className;

        if (status === 'running') {
          icon = 'icon-spinner';
          className = 'fa-spin';
        }

        if (status === 'success') {
          icon = 'icon-check-circle';
        }

        if (status === 'failure') {
          icon = 'icon-times-circle';
        }

        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
          name: icon,
          className: className
        });
      };

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "text-left steps-container"
      }, this.state.copyingSteps.map(function (step, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          key: index,
          className: classnames__WEBPACK_IMPORTED_MODULE_5___default()('step-container', {
            'text-success': step.status === 'success',
            'text-danger': step.status === 'failure',
            'text-info': step.status === 'running',
            'text-muted': step.status === null
          })
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, statusContainer(step.status)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, step.status === 'failure' ? step.error : step.message));
      }), this.state.copyingSteps[1].status === 'success' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
        className: "btn btn-primary",
        href: "".concat(this.state.datasetUrl)
      }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".monitorBtnLabel"))) : null);
    }
  }, {
    key: "renderForm",
    value: function renderForm() {
      var _DataPrepStore$getSta4 = components_DataPrep_store___WEBPACK_IMPORTED_MODULE_8__["default"].getState(),
          dataprep = _DataPrepStore$getSta4.dataprep;

      var isTableOptionDisabled = Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(dataprep, 'workspaceInfo', 'properties', 'databaseConfig');
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("fieldset", {
        disabled: this.state.error ? true : false
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".description"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Form"], {
        onSubmit: this.handleOnSubmit
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
        row: true
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Label"], {
        xs: 4,
        className: "text-right"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Form.typeLabel"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
        xs: 8
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["ButtonGroup"], {
        className: "input-type-group"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        color: "secondary",
        onClick: this.setType.bind(this, 'fileset'),
        active: this.state.inputType === 'fileset'
      }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Form.fileSetBtnlabel"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        color: "secondary",
        onClick: this.setType.bind(this, 'table'),
        active: this.state.inputType === 'table',
        disabled: lodash_isNil__WEBPACK_IMPORTED_MODULE_16___default()(isTableOptionDisabled) ? false : true
      }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Form.tableBtnlabel")))))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
        row: true
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
        xs: "4"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
        xs: "8"
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
        row: true
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Label"], {
        xs: "4",
        className: "text-right"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Form.datasetNameLabel")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "text-danger"
      }, "*")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
        xs: "6",
        className: "dataset-name-group"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "required-label"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Form.requiredLabel")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "text-danger"
      }, "*")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
        value: this.state.datasetName,
        onChange: this.handleDatasetNameChange
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
        id: "dataset-name-info-icon",
        name: "icon-info-circle"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_UncontrolledComponents__WEBPACK_IMPORTED_MODULE_4__["UncontrolledTooltip"], {
        target: "dataset-name-info-icon",
        delay: {
          show: 250,
          hide: 0
        }
      }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".Form.datasetTooltip"))))), this.renderDatasetSpecificContent()));
    }
  }, {
    key: "renderFooter",
    value: function renderFooter() {
      if (this.state.error) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_CardActionFeedback__WEBPACK_IMPORTED_MODULE_20__["default"], {
          type: "DANGER",
          message: i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".ingestFailMessage")),
          extendedMessage: this.state.error
        });
      }

      if (!this.state.copyInProgress) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["ModalFooter"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "btn btn-primary",
          onClick: this.submitForm,
          disabled: lodash_isEmpty__WEBPACK_IMPORTED_MODULE_17___default()(this.state.datasetName)
        }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".createBtnLabel"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "btn btn-secondary",
          onClick: this.toggleModal
        }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate('features.DataPrep.Directives.cancel')), this.renderSteps());
      }
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "create-dataset-btn",
        title: this.props.title
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()('btn btn-link', this.props.className),
        onClick: this.toggleModal,
        disabled: this.props.disabledState
      }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".btnLabel"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Modal"], {
        toggle: this.toggleModal,
        isOpen: this.state.showModal,
        size: "md",
        backdrop: "static",
        zIndex: "1061",
        className: "cdap-modal dataprep-create-dataset-modal"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["ModalHeader"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate("".concat(PREFIX, ".modalTitle"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()('close-section float-right', {
          disabled: this.state.copyInProgress && !this.state.copyTaskStarted && !this.state.error
        }),
        onClick: this.state.copyInProgress && !this.state.copyTaskStarted && !this.state.error ? function () {} : this.toggleModal
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-times"
      }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["ModalBody"], {
        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()({
          'copying-steps-container': this.state.copyInProgress
        })
      }, this.state.copyInProgress ? this.renderSteps() : this.renderForm()), this.renderFooter()));
    }
  }]);

  return IngestDataFromDataPrep;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(IngestDataFromDataPrep, "propTypes", {
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  disabledState: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  title: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
});



/***/ }),

/***/ "./components/DataPrep/TopPanel/PipelineConfigHelper.js":
/*!**************************************************************!*\
  !*** ./components/DataPrep/TopPanel/PipelineConfigHelper.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return getPipelineConfig; });
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_dataprep__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! api/dataprep */ "./api/dataprep.js");
/* harmony import */ var components_DataPrep_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/DataPrep/store */ "./components/DataPrep/store/index.js");
/* harmony import */ var components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/DataPrep/helper */ "./components/DataPrep/helper.js");
/* harmony import */ var api_artifact__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! api/artifact */ "./api/artifact.js");
/* harmony import */ var components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/SchemaEditor/SchemaHelpers */ "./components/SchemaEditor/SchemaHelpers.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_VersionRange_VersionUtilities__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/VersionRange/VersionUtilities */ "./services/VersionRange/VersionUtilities.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var rxjs_Subject__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/Subject */ "../../node_modules/rxjs/Subject.js");
/* harmony import */ var rxjs_Subject__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(rxjs_Subject__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var lodash_find__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash/find */ "../../node_modules/lodash/find.js");
/* harmony import */ var lodash_find__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(lodash_find__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */












var PREFIX = 'features.DataPrep.PipelineError';
function getPipelineConfig() {
  var workspaceInfo = components_DataPrep_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().dataprep.workspaceInfo;
  return api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getInfo().mergeMap(function (res) {
    if (res.statusCode === 404) {
      console.log("can't find method; use latest wrangler-transform");
      return constructProperties(workspaceInfo);
    }

    var pluginVersion = res.values[0]['plugin.version'];
    return constructProperties(workspaceInfo, pluginVersion);
  });
}

function findWranglerArtifacts(artifacts, pluginVersion) {
  var wranglerArtifacts = artifacts.filter(function (artifact) {
    if (pluginVersion) {
      return artifact.name === 'wrangler-transform' && artifact.version === pluginVersion;
    }

    return artifact.name === 'wrangler-transform';
  });

  if (wranglerArtifacts.length === 0) {
    // cannot find plugin. Error out
    throw i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".missingWranglerPlugin"));
  }

  var filteredArtifacts = wranglerArtifacts;

  if (!pluginVersion) {
    var highestVersion = Object(services_VersionRange_VersionUtilities__WEBPACK_IMPORTED_MODULE_7__["findHighestVersion"])(wranglerArtifacts.map(function (artifact) {
      return artifact.version;
    }), true);
    filteredArtifacts = wranglerArtifacts.filter(function (artifact) {
      return artifact.version === highestVersion;
    });
  }

  var returnArtifact = filteredArtifacts[0];

  if (filteredArtifacts.length > 1) {
    returnArtifact.scope = services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SCOPES"].USER;
  }

  return returnArtifact;
}

function constructFileSource(artifactsList, properties) {
  if (!properties) {
    return null;
  }

  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(properties, 'values', '0');
  var pluginName = Object.keys(plugin)[0];
  plugin = plugin[pluginName];
  var batchArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'core-plugins'
  });
  var realtimeArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'spark-plugins'
  });

  if (!batchArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".fileBatch"));
  }

  if (!realtimeArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".fileRealtime"));
  }

  batchArtifact.version = '[1.7.0, 3.0.0)';
  realtimeArtifact.version = '[1.7.0, 3.0.0)';
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: batchArtifact,
    properties: plugin.properties
  };
  var realtimePluginInfo = Object.assign({}, batchPluginInfo, {
    type: 'streamingsource',
    artifact: realtimeArtifact
  });
  var batchStage = {
    name: 'File',
    plugin: batchPluginInfo
  };
  var realtimeStage = {
    name: 'File',
    plugin: realtimePluginInfo
  };
  return {
    batchSource: batchStage,
    realtimeSource: realtimeStage,
    connections: [{
      from: 'File',
      to: 'Wrangler'
    }]
  };
} // Need to be modified once backend is complete


function constructDatabaseSource(artifactsList, dbInfo) {
  if (!dbInfo) {
    return null;
  }

  var batchArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'database-plugins'
  });

  if (!batchArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".database"));
  }

  batchArtifact.version = '[1.7.0, 3.0.0)';
  var pluginName = 'Database';

  try {
    var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(dbInfo, 'values', 0, 'Database');
    var pluginInfo = {
      name: 'Database',
      label: plugin.name,
      type: 'batchsource',
      artifact: batchArtifact,
      properties: plugin.properties
    };
    var batchStage = {
      name: pluginName,
      plugin: pluginInfo
    };
    return {
      batchSource: batchStage,
      connections: [{
        from: pluginName,
        to: 'Wrangler'
      }]
    };
  } catch (e) {
    console.log('properties parse error', e);
  }
}

function constructKafkaSource(artifactsList, kafkaInfo) {
  if (!kafkaInfo) {
    return null;
  }

  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(kafkaInfo, 'values', '0');
  var pluginName = Object.keys(plugin)[0]; // This is a hack.. should not do this
  // We are still shipping kafka-plugins with hydrator-plugins 1.7 but
  // it doesn't contain the streamingsource or batchsource plugins

  var pluginArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'kafka-plugins'
  });

  if (!pluginArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".kafka"));
  }

  plugin = plugin[pluginName];
  plugin.properties.schema = JSON.stringify({
    name: 'kafkaAvroSchema',
    type: 'record',
    fields: [{
      name: 'body',
      type: 'string'
    }]
  });
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: pluginArtifact,
    properties: plugin.properties
  };
  var realtimePluginInfo = Object.assign({}, batchPluginInfo, {
    type: 'streamingsource',
    artifact: pluginArtifact
  });
  var batchStage = {
    name: plugin.name,
    plugin: batchPluginInfo
  };
  var realtimeStage = {
    name: plugin.name,
    plugin: realtimePluginInfo
  };
  return {
    batchSource: batchStage,
    realtimeSource: realtimeStage,
    connections: [{
      from: plugin.name,
      to: 'Wrangler'
    }]
  };
}

function constructS3Source(artifactsList, s3Info) {
  if (!s3Info) {
    return null;
  }

  var batchArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'amazon-s3-plugins'
  });

  if (!batchArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".s3"));
  }

  batchArtifact.version = '[1.7.0, 3.0.0)';
  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(s3Info, 'values', 0, 'S3');
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: batchArtifact,
    properties: _objectSpread({}, plugin.properties, {
      referenceName: plugin.name
    })
  };
  var batchStage = {
    name: 'S3',
    plugin: batchPluginInfo
  };
  return {
    batchSource: batchStage,
    connections: [{
      from: 'S3',
      to: 'Wrangler'
    }]
  };
}

function constructGCSSource(artifactsList, gcsInfo) {
  if (!gcsInfo) {
    return null;
  }

  var batchArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'google-cloud'
  });

  if (!batchArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".gcs"));
  }

  batchArtifact.version = '[0.9.0, 3.0.0)';
  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(gcsInfo, 'values', 0);
  var pluginName = Object.keys(plugin)[0]; // this is because the plugin can be GCSFile or GCSFileBlob

  plugin = plugin[pluginName];
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: batchArtifact,
    properties: plugin.properties
  };
  var batchStage = {
    name: 'GCS',
    plugin: batchPluginInfo
  };
  return {
    batchSource: batchStage,
    connections: [{
      from: 'GCS',
      to: 'Wrangler'
    }]
  };
}

function constructBigQuerySource(artifactsList, bigqueryInfo) {
  if (!bigqueryInfo) {
    return null;
  }

  var batchArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'google-cloud'
  });

  if (!batchArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".bigquery"));
  }

  batchArtifact.version = '[0.9.2, 3.0.0)';
  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(bigqueryInfo, 'values', 0);
  var pluginName = Object.keys(plugin)[0];
  plugin = plugin[pluginName];
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: batchArtifact,
    properties: plugin.properties
  };
  var batchStage = {
    name: 'BigQueryTable',
    plugin: batchPluginInfo
  };
  return {
    batchSource: batchStage,
    connections: [{
      from: 'BigQueryTable',
      to: 'Wrangler'
    }]
  };
}

function constructSpannerSource(artifactsList, spannerInfo) {
  if (!spannerInfo) {
    return null;
  }

  var googleCloudArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'google-cloud'
  });

  if (!googleCloudArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".spanner"));
  }

  googleCloudArtifact.version = '[0.11.0-SNAPSHOT, 3.0.0)';
  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(spannerInfo, 'values', 0);
  var pluginName = Object.keys(plugin)[0];
  plugin = plugin[pluginName];
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: googleCloudArtifact,
    properties: plugin.properties
  };
  var batchStage = {
    name: 'SpannerTable',
    plugin: batchPluginInfo
  };
  return {
    batchSource: batchStage,
    connections: [{
      from: 'SpannerTable',
      to: 'Wrangler'
    }]
  };
}

function constructAdlsSource(artifactsList, adlsInfo) {
  if (!adlsInfo) {
    return null;
  }

  var batchArtifact = lodash_find__WEBPACK_IMPORTED_MODULE_10___default()(artifactsList, {
    name: 'adls-plugins'
  });

  if (!batchArtifact) {
    return i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".adls"));
  }

  var plugin = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(adlsInfo, 'values', 0);
  var batchPluginInfo = {
    name: plugin.name,
    label: plugin.name,
    type: 'batchsource',
    artifact: batchArtifact,
    properties: plugin.properties
  };
  var batchStage = {
    name: 'ADLS Batch Source',
    plugin: batchPluginInfo
  };
  return {
    batchSource: batchStage,
    connections: [{
      from: 'ADLS Batch Source',
      to: 'Wrangler'
    }]
  };
}

function constructProperties(workspaceInfo, pluginVersion) {
  var observable = new rxjs_Subject__WEBPACK_IMPORTED_MODULE_9__["Subject"]();
  var namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState().selectedNamespace;
  var state = components_DataPrep_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().dataprep;
  var workspaceId = state.workspaceId;
  var requestObj = {
    context: namespace,
    workspaceId: workspaceId
  };
  var directives = state.directives;
  var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_3__["directiveRequestBodyCreator"])(directives);
  var rxArray = [api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getSchema(requestObj, requestBody)];
  var connectionId = Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(state, 'workspaceInfo', 'properties', 'connectionid');

  if (state.workspaceInfo.properties.connection === 'file') {
    var specParams = {
      context: namespace,
      path: state.workspaceUri,
      wid: workspaceId
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getSpecification(specParams));
  } else if (state.workspaceInfo.properties.connection === 'database') {
    var _specParams = {
      context: namespace,
      connectionId: connectionId,
      tableId: state.workspaceInfo.properties.id
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getDatabaseSpecification(_specParams));

    var _requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_3__["directiveRequestBodyCreator"])([]);

    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getSchema(requestObj, _requestBody));
  } else if (state.workspaceInfo.properties.connection === 'kafka') {
    var _specParams2 = {
      context: namespace,
      connectionId: connectionId,
      topic: state.workspaceInfo.properties.topic
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getKafkaSpecification(_specParams2));
  } else if (state.workspaceInfo.properties.connection === 's3') {
    var activeBucket = state.workspaceInfo.properties['bucket-name'];
    var key = state.workspaceInfo.properties.key;
    var _specParams3 = {
      context: namespace,
      connectionId: connectionId,
      activeBucket: activeBucket,
      key: key,
      wid: workspaceId
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getS3Specification(_specParams3));
  } else if (state.workspaceInfo.properties.connection === 'gcs') {
    var _specParams4 = {
      context: namespace,
      connectionId: state.workspaceInfo.properties.connectionid,
      wid: workspaceId
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getGCSSpecification(_specParams4));
  } else if (state.workspaceInfo.properties.connection === 'bigquery') {
    var _specParams5 = {
      context: namespace,
      connectionId: state.workspaceInfo.properties.connectionid,
      wid: workspaceId
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getBigQuerySpecification(_specParams5));
  } else if (state.workspaceInfo.properties.connection === 'spanner') {
    var _specParams6 = {
      context: namespace,
      workspaceId: workspaceId
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getSpannerSpecification(_specParams6));
  } else if (state.workspaceInfo.properties.connection === 'adls') {
    var _specParams7 = {
      context: namespace,
      path: state.workspaceUri,
      wid: workspaceId,
      connectionId: state.workspaceInfo.properties.connectionid
    };
    rxArray.push(api_dataprep__WEBPACK_IMPORTED_MODULE_1__["default"].getAdlsSpecification(_specParams7));
  }

  try {
    api_artifact__WEBPACK_IMPORTED_MODULE_4__["MyArtifactApi"].list({
      namespace: namespace
    }).combineLatest(rxArray).subscribe(function (res) {
      var batchArtifactsList = res[0].filter(function (artifact) {
        return artifact.name === 'cdap-data-pipeline';
      });
      var realtimeArtifactsList = res[0].filter(function (artifact) {
        return artifact.name === 'cdap-data-streams';
      });
      var highestBatchArtifactVersion = Object(services_VersionRange_VersionUtilities__WEBPACK_IMPORTED_MODULE_7__["findHighestVersion"])(batchArtifactsList.map(function (artifact) {
        return artifact.version;
      }), true);
      var highestRealtimeArtifactVersion = Object(services_VersionRange_VersionUtilities__WEBPACK_IMPORTED_MODULE_7__["findHighestVersion"])(realtimeArtifactsList.map(function (artifact) {
        return artifact.version;
      }), true);
      var batchArtifact = {
        name: 'cdap-data-pipeline',
        version: highestBatchArtifactVersion,
        scope: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SCOPES"].SYSTEM
      };
      var realtimeArtifact = {
        name: 'cdap-data-streams',
        version: highestRealtimeArtifactVersion,
        scope: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["SCOPES"].SYSTEM
      };
      var wranglerArtifact;

      try {
        wranglerArtifact = findWranglerArtifacts(res[0], pluginVersion);
      } catch (e) {
        observable.error(e);
      }

      var tempSchema = {
        name: 'avroSchema',
        type: 'record',
        fields: res[1]
      };
      var properties = {
        workspaceId: workspaceId,
        directives: directives.join('\n'),
        schema: JSON.stringify(tempSchema),
        field: '*',
        precondition: 'false',
        threshold: '1'
      };

      if (state.workspaceInfo.properties.connection === 'file') {
        properties.field = 'body';
      }

      try {
        Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_5__["getParsedSchemaForDataPrep"])(tempSchema);
      } catch (e) {
        observable.error(Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(e, 'message'));
      }

      var wranglerStage = {
        name: 'Wrangler',
        plugin: {
          name: 'Wrangler',
          label: 'Wrangler',
          type: 'transform',
          artifact: wranglerArtifact,
          properties: properties
        }
      };
      var realtimeStages = [wranglerStage];
      var batchStages = [wranglerStage];
      var sourceConfigs, realtimeSource, batchSource;
      var connections = [];
      var connectionType = state.workspaceInfo.properties.connection;

      if (connectionType === 'file') {
        sourceConfigs = constructFileSource(res[0], res[2]);
      } else if (connectionType === 'database') {
        sourceConfigs = constructDatabaseSource(res[0], res[2]);
        delete sourceConfigs.batchSource.plugin.properties.schema;
      } else if (connectionType === 'kafka') {
        sourceConfigs = constructKafkaSource(res[0], res[2]);
      } else if (connectionType === 's3') {
        sourceConfigs = constructS3Source(res[0], res[2]);
      } else if (connectionType === 'gcs') {
        sourceConfigs = constructGCSSource(res[0], res[2]);
      } else if (connectionType === 'bigquery') {
        sourceConfigs = constructBigQuerySource(res[0], res[2]);
      } else if (state.workspaceInfo.properties.connection === 'spanner') {
        sourceConfigs = constructSpannerSource(res[0], res[2]);
      } else if (connectionType === 'adls') {
        sourceConfigs = constructAdlsSource(res[0], res[2]);
      }

      if (typeof sourceConfigs === 'string') {
        observable.error(sourceConfigs);
        return;
      }

      if (sourceConfigs) {
        var _sourceConfigs = sourceConfigs;
        realtimeSource = _sourceConfigs.realtimeSource;
        batchSource = _sourceConfigs.batchSource;
        connections = _sourceConfigs.connections;
      }

      var realtimeConfig = null,
          batchConfig = null;

      if (realtimeSource || connectionType === 'upload') {
        if (realtimeSource) {
          realtimeStages.push(realtimeSource);
        }

        realtimeConfig = {
          artifact: realtimeArtifact,
          config: {
            stages: realtimeStages,
            batchInterval: '10s',
            connections: connections,
            resources: {
              memoryMB: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.memoryMB,
              virtualCores: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.virtualCores
            },
            driverResources: {
              memoryMB: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.memoryMB,
              virtualCores: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.virtualCores
            }
          }
        };
      }

      if (batchSource || connectionType === 'upload') {
        if (batchSource) {
          batchStages.push(batchSource);
        }

        batchConfig = {
          artifact: batchArtifact,
          config: {
            stages: batchStages,
            connections: connections,
            resources: {
              memoryMB: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.memoryMB,
              virtualCores: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.virtualCores
            },
            driverResources: {
              memoryMB: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.memoryMB,
              virtualCores: services_global_constants__WEBPACK_IMPORTED_MODULE_11__["HYDRATOR_DEFAULT_VALUES"].resources.virtualCores
            }
          }
        };
      }

      observable.next({
        realtimeConfig: realtimeConfig,
        batchConfig: batchConfig
      });
    }, function (err) {
      observable.error(Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(err, 'response', 'message') || i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate("".concat(PREFIX, ".defaultMessage")));
    });
  } catch (e) {
    observable.error(Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(e, 'message') || e);
  }

  return observable;
}

/***/ })

}]);
//# sourceMappingURL=IngestDataFromDataPrep.0efafdfcaa137fb55a4b.js.map