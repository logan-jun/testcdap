(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["PipelineList"],{

/***/ "../../node_modules/@material-ui/icons/ChevronLeft.js":
/*!****************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/@material-ui/icons/ChevronLeft.js ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@material-ui/icons/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "../../node_modules/react/index.js"));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@material-ui/icons/utils/createSvgIcon.js"));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  d: "M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"
}), _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0z"
})), 'ChevronLeft');

exports.default = _default;

/***/ }),

/***/ "../../node_modules/@material-ui/icons/ChevronRight.js":
/*!*****************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/@material-ui/icons/ChevronRight.js ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@material-ui/icons/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "../../node_modules/react/index.js"));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@material-ui/icons/utils/createSvgIcon.js"));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  d: "M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"
}), _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0z"
})), 'ChevronRight');

exports.default = _default;

/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/ActionsPopover/ActionsPopover.scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/ActionsPopover/ActionsPopover.scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.actions-popover {\n  display: inline-block; }\n  .actions-popover .default-target.icon-svg.icon-cog-empty {\n    fill: none;\n    stroke: #bbbbbb;\n    font-size: 23px;\n    cursor: pointer; }\n    .actions-popover .default-target.icon-svg.icon-cog-empty:hover, .actions-popover .default-target.icon-svg.icon-cog-empty.active {\n      stroke: #58b7f6; }\n  .actions-popover .popper {\n    width: 100px;\n    min-width: 100px;\n    padding: 0;\n    z-index: 1; }\n    .actions-popover .popper hr {\n      margin: 5px 0; }\n    .actions-popover .popper ul {\n      padding: 10px 0; }\n    .actions-popover .popper li {\n      padding: 5px 15px; }\n    .actions-popover .popper .delete {\n      color: #d40001; }\n    .actions-popover .popper .disabled {\n      color: #bbbbbb;\n      cursor: not-allowed; }\n    .actions-popover .popper .popper__arrow {\n      border-color: #bbbbbb; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Pagination/Pagination.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Pagination/Pagination.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.pagination-container {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n          justify-content: center;\n  overflow-x: hidden;\n  position: relative; }\n  .pagination-container .pagination-content {\n    display: inline-block;\n    width: 100%; }\n  .pagination-container .change-page-panel {\n    display: inline-block;\n    position: absolute;\n    top: 0;\n    cursor: pointer;\n    /* Page height minus footer height */\n    height: 100%;\n    z-index: 300;\n    opacity: 0;\n    padding-left: 5px;\n    padding-right: 5px; }\n    .pagination-container .change-page-panel.first-page, .pagination-container .change-page-panel.last-page {\n      display: none; }\n    .pagination-container .change-page-panel:hover, .pagination-container .change-page-panel.pressed {\n      opacity: 0.8; }\n  .pagination-container .change-page-panel-left {\n    left: 0; }\n  .pagination-container .change-page-panel-right {\n    right: 0; }\n  .pagination-container .page-change-arrow-container {\n    position: relative;\n    top: 50%; }\n  .pagination-container .disabled-page-change {\n    visibility: hidden; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Pagination/PaginationDropdown.scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Pagination/PaginationDropdown.scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.pagination-dropdown {\n  cursor: pointer; }\n  .pagination-dropdown.dropdown.show {\n    /*\n      * We have important here because the 'show' css class added by reactstrap\n      * has important while showing the dropdown. Because of the display being\n      * set as block by reactstrap dropdown overflows out and screws up the display\n      * FIXME: CDAP-16605\n      */\n    display: inline-block !important; }\n  .pagination-dropdown.dropdown .dropdown-menu .dropdown-item {\n    cursor: pointer; }\n    .pagination-dropdown.dropdown .dropdown-menu .dropdown-item .dropdownItems .page-number {\n      line-height: 1; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PaginationStepper/PaginationStepper.scss":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PaginationStepper/PaginationStepper.scss ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2019 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.pagination-stepper-container .step-button:focus {\n  outline: none; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineExportModal/PipelineExportModal.scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PipelineExportModal/PipelineExportModal.scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.cdap-modal.modal-dialog {\n  margin-top: 125px; }\n  .cdap-modal.modal-dialog .modal-content {\n    border-radius: 0;\n    border: 0; }\n  .cdap-modal.modal-dialog .modal-header {\n    padding: 0 10px;\n    background-color: #464a57;\n    border-bottom: 0;\n    height: 40px;\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-align: center;\n            align-items: center;\n    border-radius: 0; }\n    .cdap-modal.modal-dialog .modal-header .modal-title {\n      font-weight: normal;\n      font-size: 14px;\n      color: white;\n      line-height: 40px;\n      width: 100%; }\n      .cdap-modal.modal-dialog .modal-header .modal-title .fa,\n      .cdap-modal.modal-dialog .modal-header .modal-title .icon-svg {\n        cursor: pointer; }\n    .cdap-modal.modal-dialog .modal-header button.close {\n      background: transparent;\n      border: 0;\n      color: white;\n      font-weight: bold;\n      font-size: 18px;\n      opacity: 1;\n      text-shadow: none;\n      padding: 0;\n      float: none;\n      margin: 0; }\n      .cdap-modal.modal-dialog .modal-header button.close:hover, .cdap-modal.modal-dialog .modal-header button.close:active, .cdap-modal.modal-dialog .modal-header button.close:focus {\n        outline: none; }\n  .cdap-modal.modal-dialog .modal-body {\n    padding: 10px; }\n    .cdap-modal.modal-dialog .modal-body.loading {\n      padding: 25px; }\n      .cdap-modal.modal-dialog .modal-body.loading h3 {\n        margin: 0;\n        font-size: 45px; }\n  .cdap-modal.modal-dialog .modal-footer {\n    -webkit-box-pack: start;\n            justify-content: flex-start;\n    padding: 10px; }\n    .cdap-modal.modal-dialog .modal-footer .btn {\n      margin: 0; }\n      .cdap-modal.modal-dialog .modal-footer .btn:first-of-type {\n        margin-right: 10px; }\n\n.pipeline-export-modal .textarea-container textarea {\n  padding-right: 55px;\n  font-family: monospace;\n  resize: none;\n  height: 60vh;\n  min-height: 100px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DeployedPipelineView/DeployedPipelineView.scss":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DeployedPipelineView/DeployedPipelineView.scss ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2019 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.pipeline-deployed-view {\n  padding-left: 45px;\n  padding-right: 45px; }\n  .pipeline-deployed-view.error-container {\n    color: #d40001;\n    font-size: 14px;\n    padding-top: 25px; }\n  .pipeline-deployed-view .deployed-header {\n    height: 70px;\n    line-height: 70px; }\n    .pipeline-deployed-view .deployed-header .search-box {\n      display: inline-block;\n      width: 250px;\n      vertical-align: middle;\n      margin-top: -5px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DeployedPipelineView/PipelineCount/PipelineCount.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DeployedPipelineView/PipelineCount/PipelineCount.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.pipeline-count {\n  display: inline-block;\n  margin-right: 30px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DeployedPipelineView/PipelineTable/PipelineTable.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DeployedPipelineView/PipelineTable/PipelineTable.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2019 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.pipeline-list-table.grid-wrapper {\n  background-color: white;\n  padding: 0 4px;\n  height: calc(100% - 70px); }\n  .pipeline-list-table.grid-wrapper .grid.grid-container {\n    max-height: 100%; }\n    .pipeline-list-table.grid-wrapper .grid.grid-container .grid-header > .grid-row {\n      border-width: 3px; }\n      .pipeline-list-table.grid-wrapper .grid.grid-container .grid-header > .grid-row .sortable {\n        cursor: pointer; }\n      .pipeline-list-table.grid-wrapper .grid.grid-container .grid-header > .grid-row .fa.fa-lg {\n        vertical-align: top;\n        margin-left: 5px; }\n    .pipeline-list-table.grid-wrapper .grid.grid-container .grid-row {\n      grid-template-columns: 1fr 100px 150px 200px 150px 120px 1fr 60px; }\n      .pipeline-list-table.grid-wrapper .grid.grid-container .grid-row > div {\n        padding-top: 5px;\n        padding-bottom: 5px; }\n      .pipeline-list-table.grid-wrapper .grid.grid-container .grid-row > *:first-child {\n        padding-left: 25px; }\n      .pipeline-list-table.grid-wrapper .grid.grid-container .grid-row > *:last-child {\n        padding-right: 25px; }\n    .pipeline-list-table.grid-wrapper .grid.grid-container .grid-body .grid-row {\n      color: #333333; }\n      .pipeline-list-table.grid-wrapper .grid.grid-container .grid-body .grid-row:hover {\n        background-color: #f5f5f5;\n        text-decoration: none; }\n  .pipeline-list-table.grid-wrapper .status .text {\n    vertical-align: middle; }\n  .pipeline-list-table.grid-wrapper .status .fa {\n    margin-right: 2px; }\n  .pipeline-list-table.grid-wrapper .status .status-light-grey {\n    color: #999999; }\n  .pipeline-list-table.grid-wrapper .status .status-light-green {\n    color: #01b133; }\n  .pipeline-list-table.grid-wrapper .status .status-blue {\n    color: #0076dc; }\n  .pipeline-list-table.grid-wrapper .status .status-light-red {\n    color: #d40001; }\n  .pipeline-list-table.grid-wrapper .action {\n    text-align: right; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DeployedPipelineView/PipelineTags/PipelineTags.scss":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DeployedPipelineView/PipelineTags/PipelineTags.scss ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.pipeline-list-table .tags .tags-holder .tags-list {\n  max-width: 100%;\n  overflow: initial;\n  white-space: pre-wrap; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DraftPipelineView/DraftCount/DraftCount.scss":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DraftPipelineView/DraftCount/DraftCount.scss ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.draft-count {\n  display: inline-block; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DraftPipelineView/DraftPipelineView.scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DraftPipelineView/DraftPipelineView.scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.pipeline-draft-view {\n  padding: 0 45px 15px 45px;\n  background-color: #dbdbdb; }\n  .pipeline-draft-view .draft-header {\n    height: 70px;\n    line-height: 70px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DraftPipelineView/DraftTable/DraftTable.scss":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DraftPipelineView/DraftTable/DraftTable.scss ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.draft-table.grid-wrapper {\n  background-color: #f5f5f5;\n  padding: 0 4px;\n  height: calc(100% - 70px); }\n  .draft-table.grid-wrapper .grid.grid-container {\n    max-height: 100%; }\n    .draft-table.grid-wrapper .grid.grid-container .grid-header {\n      background-color: #f5f5f5; }\n      .draft-table.grid-wrapper .grid.grid-container .grid-header .sortable {\n        cursor: pointer; }\n      .draft-table.grid-wrapper .grid.grid-container .grid-header > .grid-row {\n        border-width: 3px; }\n        .draft-table.grid-wrapper .grid.grid-container .grid-header > .grid-row .fa.fa-lg {\n          vertical-align: top;\n          margin-left: 5px; }\n    .draft-table.grid-wrapper .grid.grid-container .grid-row {\n      grid-template-columns: 1fr 20% 20% 60px; }\n      .draft-table.grid-wrapper .grid.grid-container .grid-row > div {\n        padding-top: 5px;\n        padding-bottom: 5px; }\n      .draft-table.grid-wrapper .grid.grid-container .grid-row > *:first-child {\n        padding-left: 25px; }\n      .draft-table.grid-wrapper .grid.grid-container .grid-row > *:last-child {\n        padding-right: 25px; }\n    .draft-table.grid-wrapper .grid.grid-container .grid-body .grid-row {\n      color: #333333; }\n      .draft-table.grid-wrapper .grid.grid-container .grid-body .grid-row:hover {\n        background-color: white;\n        text-decoration: none; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/EmptyList/EmptyList.scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PipelineList/EmptyList/EmptyList.scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.pipeline-list-empty-container {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n  min-height: 150px;\n  height: 100%;\n  padding-top: 150px; }\n  .pipeline-list-empty-container hr {\n    border-color: #333333; }\n  .pipeline-list-empty-container .action-cta {\n    margin-right: 5px;\n    color: var(--brand-primary-color);\n    cursor: pointer; }\n  .pipeline-list-empty-container .call-to-actions > div {\n    line-height: 1.8; }\n  .pipeline-list-empty-container #import-pipeline {\n    display: none; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/PaginationView/Pagination.scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PipelineList/PaginationView/Pagination.scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2019 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.pipeline-deployed-view .pagination-container,\n.pipeline-draft-view .pagination-container {\n  margin-right: 50px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/PipelineList.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PipelineList/PipelineList.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.pipeline-list-view {\n  height: calc(100vh - (53px + 48px));\n  background-color: #f5f5f5; }\n  .pipeline-list-view .cask-resourcecenter-button {\n    top: 75px; }\n  .pipeline-list-view .pipeline-list-content {\n    height: calc(100% - 55px);\n    overflow: auto;\n    padding-bottom: 10px; }\n  .pipeline-list-view .view-header {\n    background-color: white;\n    height: 55px;\n    padding-left: 45px;\n    line-height: 55px;\n    margin-bottom: 0;\n    margin-top: 0; }\n    .pipeline-list-view .view-header .option {\n      cursor: pointer;\n      color: #333333; }\n    .pipeline-list-view .view-header .active {\n      font-weight: 600;\n      text-decoration: underline; }\n    .pipeline-list-view .view-header .separator {\n      margin-left: 15px;\n      margin-right: 15px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/ResourceCenterButton/ResourceCenterButton.scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/ResourceCenterButton/ResourceCenterButton.scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.cask-resourcecenter-button {\n  position: fixed;\n  top: 71px;\n  right: 20px;\n  cursor: pointer;\n  z-index: 998;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none; }\n  .cask-resourcecenter-button .button-container {\n    height: 58px;\n    width: 58px; }\n    .cask-resourcecenter-button .button-container h1 {\n      font-size: 3em; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016-2019 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.modal-dialog.search-results-modal {\n  margin-top: 95px;\n  width: 700px; }\n  .modal-dialog.search-results-modal .modal-content {\n    border-radius: 0; }\n  .modal-dialog.search-results-modal .modal-header {\n    background-color: #464a57;\n    color: white;\n    padding: 10px 15px;\n    border-bottom: 0;\n    border-radius: 0; }\n    .modal-dialog.search-results-modal .modal-header .close-section .dropdown {\n      display: inline-block;\n      margin-right: 26px; }\n      .modal-dialog.search-results-modal .modal-header .close-section .dropdown .current-page {\n        margin-left: 5px; }\n      .modal-dialog.search-results-modal .modal-header .close-section .dropdown .fa-caret-down {\n        margin-top: 4px;\n        margin-left: 10px; }\n      .modal-dialog.search-results-modal .modal-header .close-section .dropdown .dropdown-menu {\n        min-width: 65px;\n        outline: 0; }\n      .modal-dialog.search-results-modal .modal-header .close-section .dropdown .dropdown-item {\n        border: none;\n        display: block;\n        color: black;\n        background-color: white;\n        width: 100%;\n        text-align: left;\n        outline: 0; }\n        .modal-dialog.search-results-modal .modal-header .close-section .dropdown .dropdown-item:hover {\n          background-color: #2e323b;\n          color: white; }\n    .modal-dialog.search-results-modal .modal-header .tag-title {\n      width: 100%;\n      text-overflow: ellipsis;\n      overflow: hidden;\n      white-space: nowrap; }\n    .modal-dialog.search-results-modal .modal-header .modal-title {\n      font-size: 14px;\n      font-weight: 500;\n      width: 100%;\n      display: grid;\n      grid-template-columns: repeat(2, minmax(auto, auto)); }\n      .modal-dialog.search-results-modal .modal-header .modal-title .search-results-total {\n        color: #cccccc;\n        font-size: 13px;\n        margin-right: 26px; }\n      .modal-dialog.search-results-modal .modal-header .modal-title span.fa.fa-times {\n        cursor: pointer; }\n  .modal-dialog.search-results-modal .modal-body {\n    padding: 0;\n    min-height: 550px;\n    max-height: 550px;\n    overflow-y: auto; }\n    .modal-dialog.search-results-modal .modal-body a {\n      color: inherit; }\n      .modal-dialog.search-results-modal .modal-body a:nth-of-type(odd) .search-results-item {\n        background-color: #eeeeee; }\n      .modal-dialog.search-results-modal .modal-body a.search-results-item-link:hover {\n        text-decoration: none; }\n      .modal-dialog.search-results-modal .modal-body a .search-results-item {\n        padding: 5px 15px;\n        margin-right: 0;\n        margin-left: 0;\n        min-height: 55px; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .entity-title,\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .tag {\n          white-space: nowrap;\n          overflow-x: hidden;\n          text-overflow: ellipsis; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .entity-title {\n          font-size: 16px;\n          font-weight: 500; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .entity-icon {\n          margin-right: 10px;\n          vertical-align: middle;\n          color: #464a57; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .entity-description {\n          color: #666666;\n          margin-top: 3px; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .entity-tags-container .badge {\n          margin-right: 3px; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item .tag {\n          max-width: 200px;\n          display: inline-block;\n          padding: 2px 5px;\n          margin-right: 3px;\n          margin-top: 3px;\n          font-size: 10px;\n          background-color: #464a57;\n          color: white;\n          border-radius: 3px;\n          cursor: pointer;\n          line-height: 13px;\n          font-weight: normal; }\n        .modal-dialog.search-results-modal .modal-body a .search-results-item:hover {\n          background-color: #dbdbdb;\n          text-decoration: none; }\n    .modal-dialog.search-results-modal .modal-body .pagination .page-item.active .page-link {\n      background-color: #464a57;\n      border-color: #464a57;\n      color: white; }\n    .modal-dialog.search-results-modal .modal-body .pagination .page-item:not(:last-child):not(:first-child) .page-link {\n      border: none; }\n    .modal-dialog.search-results-modal .modal-body .pagination .page-item:first-child > .page-link {\n      margin-right: 10px; }\n    .modal-dialog.search-results-modal .modal-body .pagination .page-item:last-child > .page-link {\n      margin-left: 10px; }\n    .modal-dialog.search-results-modal .modal-body .pagination .page-item.disabled > .page-link {\n      cursor: not-allowed; }\n    .modal-dialog.search-results-modal .modal-body .pagination .page-link {\n      cursor: pointer;\n      color: #464a57;\n      border-radius: 4px; }\n    .modal-dialog.search-results-modal .modal-body .search-results-container .no-search-results {\n      margin-top: 5px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Tags/Tag/Tag.scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Tags/Tag/Tag.scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.tags-holder .btn.tag-btn {\n  margin: 3px; }\n  .tags-holder .btn.tag-btn .tag-content {\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-align: center;\n            align-items: center;\n    white-space: nowrap; }\n  .tags-holder .btn.tag-btn .icon-close {\n    font-size: 12px;\n    margin-left: 5px; }\n  .tags-holder .btn.tag-btn.user-tag {\n    background-color: #eeeeee;\n    border: 1px solid #dce0ea;\n    color: #666666; }\n    .tags-holder .btn.tag-btn.user-tag:hover {\n      background-color: #dbdbdb;\n      color: #333333; }\n  .tags-holder .btn.tag-btn.system-tag {\n    background-color: white;\n    color: #5d6789;\n    border: 1px solid #dce0ea; }\n    .tags-holder .btn.tag-btn.system-tag:hover {\n      border-color: #5d6789;\n      color: #454a57; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Tags/Tags.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Tags/Tags.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.tags-holder {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center; }\n  .tags-holder > span {\n    display: inline-block; }\n  .tags-holder .tags-list {\n    /* 120px width of input box + 10px padding + 50px width of All Tags label + 10px padding + 15px width of loading icon */\n    max-width: calc(100% - 120px - 10px - 50px - 10px - 15px);\n    overflow: hidden;\n    white-space: nowrap; }\n    .tags-holder .tags-list .tag-btn:first-child {\n      margin-left: 0; }\n  .tags-holder .btn {\n    padding: 3px 5px;\n    font-size: 12px;\n    display: -webkit-inline-box;\n    display: inline-flex;\n    -webkit-box-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n            justify-content: center;\n    line-height: 1;\n    height: 18px; }\n    .tags-holder .btn.plus-button-container {\n      margin-left: 3px;\n      height: 18px;\n      background-color: #bbbbbb;\n      border-radius: 4px;\n      border-color: white; }\n      .tags-holder .btn.plus-button-container .icon-plus {\n        font-size: 7px; }\n  .tags-holder .tag-input {\n    height: 20px;\n    line-height: 20px;\n    width: 120px;\n    display: inline-block;\n    padding: 0 5px;\n    margin-left: 5px;\n    margin-right: 3px;\n    vertical-align: middle;\n    font-size: 12px; }\n  .tags-holder .tags-popover {\n    margin: 0 5px; }\n    .tags-holder .tags-popover .all-tags-label {\n      color: #0099ff;\n      cursor: pointer; }\n    .tags-holder .tags-popover .popper {\n      z-index: 1000;\n      padding: 10px;\n      text-align: left;\n      width: inherit;\n      max-height: 240px;\n      overflow-y: auto; }\n      .tags-holder .tags-popover .popper .tags-popover-header {\n        display: -webkit-box;\n        display: flex;\n        -webkit-box-align: center;\n                align-items: center;\n        margin-bottom: 10px; }\n        .tags-holder .tags-popover .popper .tags-popover-header .icon-close {\n          font-size: 13px;\n          margin-left: auto;\n          cursor: pointer; }\n      .tags-holder .tags-popover .popper .tag-btn {\n        display: table;\n        margin-left: 0; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/natural-orderby/esm/natural-orderby.js":
/*!*********************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/natural-orderby/esm/natural-orderby.js ***!
  \*********************************************************************************************************/
/*! exports provided: orderBy, compare */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orderBy", function() { return orderBy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "compare", function() { return compare; });
var compareNumbers = function compareNumbers(numberA, numberB) {
  if (numberA < numberB) {
    return -1;
  }

  if (numberA > numberB) {
    return 1;
  }

  return 0;
};

var RE_NUMBERS = /(^0x[\da-fA-F]+$|^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?(?!\.\d+)(?=\D|\s|$))|\d+)/g;
var RE_LEADING_OR_TRAILING_WHITESPACES = /^\s+|\s+$/g; // trim pre-post whitespace

var RE_WHITESPACES = /\s+/g; // normalize all whitespace to single ' ' character

var RE_INT_OR_FLOAT = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/; // identify integers and floats

var RE_DATE = /(^([\w ]+,?[\w ]+)?[\w ]+,?[\w ]+\d+:\d+(:\d+)?[\w ]?|^\d{1,4}[/-]\d{1,4}[/-]\d{1,4}|^\w+, \w+ \d+, \d{4})/; // identify date strings

var RE_LEADING_ZERO = /^0+[1-9]{1}[0-9]*$/;
var RE_UNICODE_CHARACTERS = /[^\x00-\x80]/;

var compareUnicode = function compareUnicode(stringA, stringB) {
  var result = stringA.localeCompare(stringB);
  return result ? result / Math.abs(result) : 0;
};

var stringCompare = function stringCompare(stringA, stringB) {
  if (stringA < stringB) {
    return -1;
  }

  if (stringA > stringB) {
    return 1;
  }

  return 0;
};

var compareChunks = function compareChunks(chunksA, chunksB) {
  var lengthA = chunksA.length;
  var lengthB = chunksB.length;
  var size = Math.min(lengthA, lengthB);

  for (var i = 0; i < size; i++) {
    var chunkA = chunksA[i];
    var chunkB = chunksB[i];

    if (chunkA.normalizedString !== chunkB.normalizedString) {
      if (chunkA.normalizedString === '' !== (chunkB.normalizedString === '')) {
        // empty strings have lowest value
        return chunkA.normalizedString === '' ? -1 : 1;
      }

      if (chunkA.parsedNumber !== undefined && chunkB.parsedNumber !== undefined) {
        // compare numbers
        var result = compareNumbers(chunkA.parsedNumber, chunkB.parsedNumber);

        if (result === 0) {
          // compare string value, if parsed numbers are equal
          // Example:
          // chunkA = { parsedNumber: 1, normalizedString: "001" }
          // chunkB = { parsedNumber: 1, normalizedString: "01" }
          // chunkA.parsedNumber === chunkB.parsedNumber
          // chunkA.normalizedString < chunkB.normalizedString
          return stringCompare(chunkA.normalizedString, chunkB.normalizedString);
        }

        return result;
      } else if (chunkA.parsedNumber !== undefined || chunkB.parsedNumber !== undefined) {
        // number < string
        return chunkA.parsedNumber !== undefined ? -1 : 1;
      } else if (RE_UNICODE_CHARACTERS.test(chunkA.normalizedString + chunkB.normalizedString) && chunkA.normalizedString.localeCompare) {
        // use locale comparison only if one of the chunks contains unicode characters
        return compareUnicode(chunkA.normalizedString, chunkB.normalizedString);
      } else {
        // use common string comparison for performance reason
        return stringCompare(chunkA.normalizedString, chunkB.normalizedString);
      }
    }
  } // if the chunks are equal so far, the one which has more chunks is greater than the other one


  if (lengthA > size || lengthB > size) {
    return lengthA <= size ? -1 : 1;
  }

  return 0;
};

var compareOtherTypes = function compareOtherTypes(valueA, valueB) {
  if (!valueA.chunks ? valueB.chunks : !valueB.chunks) {
    return !valueA.chunks ? 1 : -1;
  }

  if (valueA.isNaN ? !valueB.isNaN : valueB.isNaN) {
    return valueA.isNaN ? -1 : 1;
  }

  if (valueA.isSymbol ? !valueB.isSymbol : valueB.isSymbol) {
    return valueA.isSymbol ? -1 : 1;
  }

  if (valueA.isObject ? !valueB.isObject : valueB.isObject) {
    return valueA.isObject ? -1 : 1;
  }

  if (valueA.isArray ? !valueB.isArray : valueB.isArray) {
    return valueA.isArray ? -1 : 1;
  }

  if (valueA.isFunction ? !valueB.isFunction : valueB.isFunction) {
    return valueA.isFunction ? -1 : 1;
  }

  if (valueA.isNull ? !valueB.isNull : valueB.isNull) {
    return valueA.isNull ? -1 : 1;
  }

  return 0;
};

var compareValues = function compareValues(valueA, valueB) {
  if (valueA.value === valueB.value) {
    return 0;
  }

  if (valueA.parsedNumber !== undefined && valueB.parsedNumber !== undefined) {
    return compareNumbers(valueA.parsedNumber, valueB.parsedNumber);
  }

  if (valueA.chunks && valueB.chunks) {
    return compareChunks(valueA.chunks, valueB.chunks);
  }

  return compareOtherTypes(valueA, valueB);
};

var compareMultiple = function compareMultiple(recordA, recordB, orders) {
  var indexA = recordA.index,
      valuesA = recordA.values;
  var indexB = recordB.index,
      valuesB = recordB.values;
  var length = valuesA.length;
  var ordersLength = orders.length;

  for (var i = 0; i < length; i++) {
    var order = i < ordersLength ? orders[i] : null;

    if (order && typeof order === 'function') {
      var result = order(valuesA[i].value, valuesB[i].value);

      if (result) {
        return result;
      }
    } else {
      var _result = compareValues(valuesA[i], valuesB[i]);

      if (_result) {
        return _result * (order === 'desc' ? -1 : 1);
      }
    }
  }

  return indexA - indexB;
};

var createIdentifierFn = function createIdentifierFn(identifier) {
  if (typeof identifier === 'function') {
    // identifier is already a lookup function
    return identifier;
  }

  return function (value) {
    if (Array.isArray(value)) {
      var index = Number(identifier);

      if (Number.isInteger(index)) {
        return value[index];
      }
    } else if (value && typeof value === 'object' && typeof identifier !== 'function') {
      return value[identifier];
    }

    return value;
  };
};

var stringify = function stringify(value) {
  if (typeof value === 'boolean' || value instanceof Boolean) {
    return Number(value).toString();
  }

  if (typeof value === 'number' || value instanceof Number) {
    return value.toString();
  }

  if (value instanceof Date) {
    return value.getTime().toString();
  }

  if (typeof value === 'string' || value instanceof String) {
    return value.toLowerCase().replace(RE_LEADING_OR_TRAILING_WHITESPACES, '');
  }

  return '';
};

var parseNumber = function parseNumber(value) {
  if (value.length !== 0) {
    var parsedNumber = Number(value);

    if (!Number.isNaN(parsedNumber)) {
      return parsedNumber;
    }
  }

  return undefined;
};

var parseDate = function parseDate(value) {
  if (RE_DATE.test(value)) {
    var parsedDate = Date.parse(value);

    if (!Number.isNaN(parsedDate)) {
      return parsedDate;
    }
  }

  return undefined;
};

var numberify = function numberify(value) {
  var parsedNumber = parseNumber(value);

  if (parsedNumber !== undefined) {
    return parsedNumber;
  }

  return parseDate(value);
};

var createChunks = function createChunks(value) {
  return value.replace(RE_NUMBERS, '\0$1\0').replace(/\0$/, '').replace(/^\0/, '').split('\0');
};

var normalizeAlphaChunk = function normalizeAlphaChunk(chunk) {
  return chunk.replace(RE_WHITESPACES, ' ').replace(RE_LEADING_OR_TRAILING_WHITESPACES, '');
};

var normalizeNumericChunk = function normalizeNumericChunk(chunk, index, chunks) {
  if (RE_INT_OR_FLOAT.test(chunk)) {
    // don´t parse a number, if there´s a preceding decimal point
    // to keep significance
    // e.g. 1.0020, 1.020
    if (!RE_LEADING_ZERO.test(chunk) || index === 0 || chunks[index - 1] !== '.') {
      return parseNumber(chunk) || 0;
    }
  }

  return undefined;
};

var createChunkMap = function createChunkMap(chunk, index, chunks) {
  return {
    parsedNumber: normalizeNumericChunk(chunk, index, chunks),
    normalizedString: normalizeAlphaChunk(chunk)
  };
};

var createChunkMaps = function createChunkMaps(value) {
  var chunksMaps = createChunks(value).map(createChunkMap);
  return chunksMaps;
};

var isFunction = function isFunction(value) {
  return typeof value === 'function';
};

var isNaN = function isNaN(value) {
  return Number.isNaN(value) || value instanceof Number && Number.isNaN(value.valueOf());
};

var isNull = function isNull(value) {
  return value === null;
};

var isObject = function isObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) && !(value instanceof Number) && !(value instanceof String) && !(value instanceof Boolean) && !(value instanceof Date);
};

var isSymbol = function isSymbol(value) {
  return typeof value === 'symbol';
};

var isUndefined = function isUndefined(value) {
  return value === undefined;
};

var getMappedValueRecord = function getMappedValueRecord(value) {
  if (typeof value === 'string' || value instanceof String || (typeof value === 'number' || value instanceof Number) && !isNaN(value) || typeof value === 'boolean' || value instanceof Boolean || value instanceof Date) {
    var stringValue = stringify(value);
    var parsedNumber = numberify(stringValue);
    var chunks = createChunkMaps(parsedNumber ? "" + parsedNumber : stringValue);
    return {
      parsedNumber: parsedNumber,
      chunks: chunks,
      value: value
    };
  }

  return {
    isArray: Array.isArray(value),
    isFunction: isFunction(value),
    isNaN: isNaN(value),
    isNull: isNull(value),
    isObject: isObject(value),
    isSymbol: isSymbol(value),
    isUndefined: isUndefined(value),
    value: value
  };
};

var getValueByIdentifier = function getValueByIdentifier(value, getValue) {
  return getValue(value);
};

var getElementByIndex = function getElementByIndex(collection, index) {
  return collection[index];
};

var baseOrderBy = function baseOrderBy(collection, identifiers, orders) {
  var identifierFns = identifiers.length ? identifiers.map(createIdentifierFn) : [function (value) {
    return value;
  }]; // temporary array holds elements with position and sort-values

  var mappedCollection = collection.map(function (element, index) {
    var values = identifierFns.map(function (identifier) {
      return getValueByIdentifier(element, identifier);
    }).map(getMappedValueRecord);
    return {
      index: index,
      values: values
    };
  }); // iterate over values and compare values until a != b or last value reached

  mappedCollection.sort(function (recordA, recordB) {
    return compareMultiple(recordA, recordB, orders);
  });
  return mappedCollection.map(function (element) {
    return getElementByIndex(collection, element.index);
  });
};

var getIdentifiers = function getIdentifiers(identifiers) {
  if (!identifiers) {
    return [];
  }

  var identifierList = !Array.isArray(identifiers) ? [identifiers] : [].concat(identifiers);

  if (identifierList.some(function (identifier) {
    return typeof identifier !== 'string' && typeof identifier !== 'number' && typeof identifier !== 'function';
  })) {
    return [];
  }

  return identifierList;
};

var getOrders = function getOrders(orders) {
  if (!orders) {
    return [];
  }

  var orderList = !Array.isArray(orders) ? [orders] : [].concat(orders);

  if (orderList.some(function (order) {
    return order !== 'asc' && order !== 'desc' && typeof order !== 'function';
  })) {
    return [];
  }

  return orderList;
};

/**
 * Creates an array of elements, natural sorted by specified identifiers and
 * the corresponding sort orders. This method implements a stable sort
 * algorithm, which means the original sort order of equal elements is
 * preserved.
 *
 * If `collection` is an array of primitives, `identifiers` may be unspecified.
 * Otherwise, you should specify `identifiers` to sort by or `collection` will
 * be returned unsorted. An identifier can expressed by:
 *
 * - an index position, if `collection` is a nested array,
 * - a property name, if `collection` is an array of objects,
 * - a function which returns a particular value from an element of a nested array or an array of objects. This function will be invoked by passing one element of `collection`.
 *
 * If `orders` is unspecified, all values are sorted in ascending order.
 * Otherwise, specify an order of `'desc'` for descending or `'asc'` for
 * ascending sort order of corresponding values. You may also specify a compare
 * function for an order, which will be invoked by two arguments:
 * `(valueA, valueB)`. It must return a number representing the sort order.
 *
 * @example
 *
 * import { orderBy } from 'natural-orderby';
 *
 * const users = [
 *   {
 *     username: 'Bamm-Bamm',
 *     ip: '192.168.5.2',
 *     datetime: 'Fri Jun 15 2018 16:48:00 GMT+0200 (CEST)'
 *   },
 *   {
 *     username: 'Wilma',
 *     ip: '192.168.10.1',
 *     datetime: '14 Jun 2018 00:00:00 PDT'
 *   },
 *   {
 *     username: 'dino',
 *     ip: '192.168.0.2',
 *     datetime: 'June 15, 2018 14:48:00'
 *   },
 *   {
 *     username: 'Barney',
 *     ip: '192.168.1.1',
 *     datetime: 'Thu, 14 Jun 2018 07:00:00 GMT'
 *   },
 *   {
 *     username: 'Pebbles',
 *     ip: '192.168.1.21',
 *     datetime: '15 June 2018 14:48 UTC'
 *   },
 *   {
 *     username: 'Hoppy',
 *     ip: '192.168.5.10',
 *     datetime: '2018-06-15T14:48:00.000Z'
 *   },
 * ];
 *
 * orderBy(
 *   users,
 *   [v => v.datetime, v => v.ip],
 *   ['desc', 'asc']
 * );
 *
 * // => [
 * //      {
 * //        username: 'dino',
 * //        ip: '192.168.0.2',
 * //        datetime: 'June 15, 2018 14:48:00',
 * //      },
 * //      {
 * //        username: 'Pebbles',
 * //        ip: '192.168.1.21',
 * //        datetime: '15 June 2018 14:48 UTC',
 * //      },
 * //      {
 * //        username: 'Bamm-Bamm',
 * //        ip: '192.168.5.2',
 * //        datetime: 'Fri Jun 15 2018 16:48:00 GMT+0200 (CEST)',
 * //      },
 * //      {
 * //        username: 'Hoppy',
 * //        ip: '192.168.5.10',
 * //        datetime: '2018-06-15T14:48:00.000Z',
 * //      },
 * //      {
 * //        username: 'Barney',
 * //        ip: '192.168.1.1',
 * //        datetime: 'Thu, 14 Jun 2018 07:00:00 GMT',
 * //      },
 * //      {
 * //        username: 'Wilma',
 * //        ip: '192.168.10.1',
 * //        datetime: '14 Jun 2018 00:00:00 PDT',
 * //      },
 * //    ]
 */
function orderBy(collection, identifiers, orders) {
  if (!collection || !Array.isArray(collection)) {
    return [];
  }

  var validatedIdentifiers = getIdentifiers(identifiers);
  var validatedOrders = getOrders(orders);
  return baseOrderBy(collection, validatedIdentifiers, validatedOrders);
}

var baseCompare = function baseCompare(options) {
  return function (valueA, valueB) {
    var a = getMappedValueRecord(valueA);
    var b = getMappedValueRecord(valueB);
    var result = compareValues(a, b);
    return result * (options.order === 'desc' ? -1 : 1);
  };
};

var isValidOrder = function isValidOrder(value) {
  return typeof value === 'string' && (value === 'asc' || value === 'desc');
};

var getOptions = function getOptions(customOptions) {
  var order = 'asc';

  if (typeof customOptions === 'string' && isValidOrder(customOptions)) {
    order = customOptions;
  } else if (customOptions && typeof customOptions === 'object' && customOptions.order && isValidOrder(customOptions.order)) {
    order = customOptions.order;
  }

  return {
    order: order
  };
};

/**
 * Creates a compare function that defines the natural sort order considering
 * the given `options` which may be passed to [`Array.prototype.sort()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/sort).
 *
 * If `options` or its property `order` is unspecified, values are sorted in
 * ascending sort order. Otherwise, specify an order of `'desc'` for descending
 * or `'asc'` for ascending sort order of values.
 *
 * @example
 *
 * import { compare } from 'natural-orderby';
 *
 * const users = [
 *   {
 *     username: 'Bamm-Bamm',
 *     lastLogin: {
 *       ip: '192.168.5.2',
 *       datetime: 'Fri Jun 15 2018 16:48:00 GMT+0200 (CEST)'
 *     },
 *   },
 *   {
 *     username: 'Wilma',
 *     lastLogin: {
 *       ip: '192.168.10.1',
 *       datetime: '14 Jun 2018 00:00:00 PDT'
 *     },
 *   },
 *   {
 *     username: 'dino',
 *     lastLogin: {
 *       ip: '192.168.0.2',
 *       datetime: 'June 15, 2018 14:48:00'
 *     },
 *   },
 *   {
 *     username: 'Barney',
 *     lastLogin: {
 *       ip: '192.168.1.1',
 *       datetime: 'Thu, 14 Jun 2018 07:00:00 GMT'
 *     },
 *   },
 *   {
 *     username: 'Pebbles',
 *     lastLogin: {
 *       ip: '192.168.1.21',
 *       datetime: '15 June 2018 14:48 UTC'
 *     },
 *   },
 *   {
 *     username: 'Hoppy',
 *     lastLogin: {
 *       ip: '192.168.5.10',
 *       datetime: '2018-06-15T14:48:00.000Z'
 *     },
 *   },
 * ];
 *
 * users.sort((a, b) => compare()(a.ip, b.ip));
 *
 * // => [
 * //      {
 * //        username: 'dino',
 * //        ip: '192.168.0.2',
 * //        datetime: 'June 15, 2018 14:48:00'
 * //      },
 * //      {
 * //        username: 'Barney',
 * //        ip: '192.168.1.1',
 * //        datetime: 'Thu, 14 Jun 2018 07:00:00 GMT'
 * //      },
 * //      {
 * //        username: 'Pebbles',
 * //        ip: '192.168.1.21',
 * //        datetime: '15 June 2018 14:48 UTC'
 * //      },
 * //      {
 * //        username: 'Bamm-Bamm',
 * //        ip: '192.168.5.2',
 * //        datetime: 'Fri Jun 15 2018 16:48:00 GMT+0200 (CEST)'
 * //      },
 * //      {
 * //        username: 'Hoppy',
 * //        ip: '192.168.5.10',
 * //        datetime: '2018-06-15T14:48:00.000Z'
 * //      },
 * //      {
 * //        username: 'Wilma',
 * //        ip: '192.168.10.1',
 * //        datetime: '14 Jun 2018 00:00:00 PDT'
 * //      }
 * //    ]
 */
function compare(options) {
  var validatedOptions = getOptions(options);
  return baseCompare(validatedOptions);
}

/*
* Javascript natural sort algorithm with unicode support
* based on chunking idea by Dave Koelle
*
* https://github.com/yobacca/natural-sort-order
* released under MIT License
*/




/***/ }),

/***/ "./api/metadata.js":
/*!*************************!*\
  !*** ./api/metadata.js ***!
  \*************************/
/*! exports provided: MyMetadataApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyMetadataApi", function() { return MyMetadataApi; });
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__["default"].getInstance();
var basepath = '/namespaces/:namespace/:entityType/:entityId/metadata';
var lineagePath = '/namespaces/:namespace/datasets/:entityId/lineage/fields';
var fieldLineagePath = '/namespaces/:namespace/datasets/:entityId/lineage/allfieldlineage';
var MyMetadataApi = {
  getMetadata: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  getProperties: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/properties?responseFormat=v6")),
  addProperties: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/properties")),
  deleteProperty: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(basepath, "/properties/:key")),
  getTags: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/tags?responseFormat=v6")),
  addTags: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/tags")),
  deleteTags: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(basepath, "/tags/:key")),
  // Field Level Lineage
  getFields: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', lineagePath),
  getFieldLineage: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(lineagePath, "/:fieldName")),
  getFieldOperations: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(lineagePath, "/:fieldName/operations")),
  getAllFieldLineage: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', fieldLineagePath)
};

/***/ }),

/***/ "./api/schedule.js":
/*!*************************!*\
  !*** ./api/schedule.js ***!
  \*************************/
/*! exports provided: MyScheduleApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyScheduleApi", function() { return MyScheduleApi; });
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__["default"].getInstance();
var basepath = '/namespaces/:namespace/apps/:appId/schedules';
var workflowPath = '/namespaces/:namespace/apps/:appId/workflows/:workflowId';
var MyScheduleApi = {
  create: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'PUT', 'REQUEST', "".concat(basepath, "/:scheduleName")),
  "delete": Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(basepath, "/:scheduleName")),
  update: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/:scheduleName/update")),
  get: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/:scheduleName")),
  getTriggers: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(workflowPath, "/schedules")),
  enableTrigger: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/:scheduleName/enable")),
  disableTrigger: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/:scheduleName/disable")),
  getTriggeredList: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', '/namespaces/:namespace/schedules/trigger-type/program-status')
};

/***/ }),

/***/ "./components/ActionsPopover/ActionsPopover.scss":
/*!*******************************************************!*\
  !*** ./components/ActionsPopover/ActionsPopover.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./ActionsPopover.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/ActionsPopover/ActionsPopover.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/ActionsPopover/index.tsx":
/*!*********************************************!*\
  !*** ./components/ActionsPopover/index.tsx ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ActionsPopover_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ActionsPopover.scss */ "./components/ActionsPopover/ActionsPopover.scss");
/* harmony import */ var _ActionsPopover_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ActionsPopover_scss__WEBPACK_IMPORTED_MODULE_4__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
    }

    return t;
  };

  return __assign.apply(this, arguments);
};






var POPPER_MODIFIERS = {
  preventOverflow: {
    enabled: false
  },
  hide: {
    enabled: false
  }
};

var ActionsPopover = function ActionsPopover(_a) {
  var actions = _a.actions,
      targetElem = _a.targetElem;

  var target = function target(props) {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_IconSVG__WEBPACK_IMPORTED_MODULE_1__["default"], __assign({
      name: "icon-cog-empty"
    }, props, {
      className: "default-target " + props.className
    }));
  };

  if (targetElem) {
    target = targetElem;
  }

  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Popover__WEBPACK_IMPORTED_MODULE_2__["default"], {
    target: target,
    className: "actions-popover",
    placement: "bottom",
    bubbleEvent: false,
    enableInteractionInPopover: true,
    modifiers: POPPER_MODIFIERS
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("ul", null, actions.map(function (action, i) {
    if (action.label === 'separator') {
      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("hr", {
        key: "" + action.label + i
      });
    }

    var onClick = function onClick() {
      if (action.disabled || !action.actionFn) {
        return;
      }

      action.actionFn();
    };

    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("li", {
      key: i,
      className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(action.className, {
        disabled: action.disabled
      }),
      onClick: onClick,
      title: action.title
    }, action.label);
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (ActionsPopover);

/***/ }),

/***/ "./components/Duration/index.js":
/*!**************************************!*\
  !*** ./components/Duration/index.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Duration; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "../../node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var Duration =
/*#__PURE__*/
function (_Component) {
  _inherits(Duration, _Component);

  function Duration() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, Duration);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(Duration)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      displayDuration: null
    });

    _defineProperty(_assertThisInitialized(_this), "calculateTimeCallback", function (duration) {
      var delay = services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_SECOND_MS"];

      if (!_this.props.showFullDuration) {
        var absDuration = Math.abs(duration);

        if (absDuration > services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_HOUR_SECONDS"]) {
          delay = 15 * services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_MIN_SECONDS"];
        } else if (absDuration > 5 * services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_MIN_SECONDS"]) {
          delay = services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_MIN_SECONDS"];
        } else if (absDuration > 2 * services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_MIN_SECONDS"]) {
          delay = 15 * services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_SECOND_MS"];
        }
      }

      _this.timeout = setTimeout(function () {
        _this.calculateTime();
      }, delay);
    });

    return _this;
  }

  _createClass(Duration, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      this.calculateTime();
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (nextProps.targetTime !== this.props.targetTime) {
        this.stopCounter();
      }

      this.calculateTime(nextProps.targetTime);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.stopCounter();
    }
  }, {
    key: "stopCounter",
    value: function stopCounter() {
      if (this.timeout) {
        clearTimeout(this.timeout);
      }
    }
  }, {
    key: "calculateTime",
    value: function calculateTime() {
      var newTime = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.props.targetTime;

      if (!newTime) {
        return;
      }

      var targetTime = newTime;

      if (!this.props.isMillisecond) {
        targetTime *= services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_SECOND_MS"];
      }

      if (this.props.showFullDuration) {
        var duration = new Date().valueOf() - targetTime;
        this.setState({
          displayDuration: Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableDuration"])(duration /= services_helpers__WEBPACK_IMPORTED_MODULE_3__["ONE_SECOND_MS"])
        }, this.calculateTimeCallback.bind(this, duration));
      } else {
        var _duration = targetTime - new Date().valueOf();

        var isPast = _duration < 0;
        this.setState({
          displayDuration: moment__WEBPACK_IMPORTED_MODULE_2___default.a.duration(_duration).humanize(isPast)
        }, this.calculateTimeCallback.bind(this, _duration));
      }
    }
  }, {
    key: "render",
    value: function render() {
      if (!this.props.targetTime) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "duration-display"
        }, "--");
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "duration-display"
      }, this.state.displayDuration);
    }
  }]);

  return Duration;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(Duration, "propTypes", {
  targetTime: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  isMillisecond: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  showFullDuration: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});

_defineProperty(Duration, "defaultProps", {
  isMillisecond: true,
  showFullDuration: false
});



/***/ }),

/***/ "./components/Pagination/Pagination.scss":
/*!***********************************************!*\
  !*** ./components/Pagination/Pagination.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Pagination.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Pagination/Pagination.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Pagination/PaginationDropdown.js":
/*!*****************************************************!*\
  !*** ./components/Pagination/PaginationDropdown.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PaginationDropdown; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_4__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./Pagination.scss */ "./components/Pagination/Pagination.scss");

__webpack_require__(/*! ./PaginationDropdown.scss */ "./components/Pagination/PaginationDropdown.scss");

var PaginationDropdown =
/*#__PURE__*/
function (_Component) {
  _inherits(PaginationDropdown, _Component);

  function PaginationDropdown(props) {
    var _this;

    _classCallCheck(this, PaginationDropdown);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(PaginationDropdown).call(this, props));
    _this.state = {
      isPaginationExpanded: false
    };
    _this.handleExpansionToggle = _this.handleExpansionToggle.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(PaginationDropdown, [{
    key: "handleExpansionToggle",
    value: function handleExpansionToggle() {
      this.setState({
        isPaginationExpanded: !this.state.isPaginationExpanded
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var dropdownItems = [];

      for (var i = 0; i < this.props.numberOfPages; i++) {
        dropdownItems.push(react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "dropdownItems clearfix"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "page-number float-left"
        }, i + 1), this.props.currentPage === i + 1 ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "fa fa-check float-right"
        }) : null));
      }

      if (this.props.numberOfPages === 1) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
        className: "pagination-dropdown",
        isOpen: this.state.isPaginationExpanded,
        toggle: this.handleExpansionToggle
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["DropdownToggle"], {
        tag: "div"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate('features.Pagination.dropdown-label')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "current-page"
      }, this.props.currentPage), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-caret-down float-right"
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["DropdownMenu"], {
        onClick: function onClick(e) {
          return e.stopPropagation();
        }
      }, dropdownItems.map(function (item, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["DropdownItem"], {
          key: uuid_v4__WEBPACK_IMPORTED_MODULE_4___default()(),
          onClick: _this2.props.onPageChange.bind(_this2, index + 1)
        }, item);
      })));
    }
  }]);

  return PaginationDropdown;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


PaginationDropdown.propTypes = {
  numberOfPages: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  currentPage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  onPageChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/***/ }),

/***/ "./components/Pagination/PaginationDropdown.scss":
/*!*******************************************************!*\
  !*** ./components/Pagination/PaginationDropdown.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./PaginationDropdown.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Pagination/PaginationDropdown.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Pagination/index.js":
/*!****************************************!*\
  !*** ./components/Pagination/index.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Pagination; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! mousetrap */ "../../node_modules/mousetrap/mousetrap.js");
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(mousetrap__WEBPACK_IMPORTED_MODULE_3__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./Pagination.scss */ "./components/Pagination/Pagination.scss");

var Pagination =
/*#__PURE__*/
function (_Component) {
  _inherits(Pagination, _Component);

  function Pagination(props) {
    var _this;

    _classCallCheck(this, Pagination);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(Pagination).call(this, props));
    _this.state = {
      numResults: 0,
      leftPressed: false,
      rightPressed: false,
      currentPage: props.currentPage,
      totalPages: props.totalPages
    };
    _this.goToNext = _this.goToNext.bind(_assertThisInitialized(_this));
    _this.goToPrev = _this.goToPrev.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(Pagination, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_3___default.a.bind('right', this.goToNext);
      mousetrap__WEBPACK_IMPORTED_MODULE_3___default.a.bind('left', this.goToPrev);
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.setState({
        currentPage: nextProps.currentPage,
        totalPages: nextProps.totalPages
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_3___default.a.unbind('left');
      mousetrap__WEBPACK_IMPORTED_MODULE_3___default.a.unbind('right');
    }
  }, {
    key: "goToPrev",
    value: function goToPrev() {
      var _this2 = this;

      if (this.state.currentPage - 1 === 0) {
        return;
      } // Highlight the side that is pressed


      this.setState({
        leftPressed: true
      });
      setTimeout(function () {
        _this2.setState({
          leftPressed: false
        });
      }, 250);

      if (this.props.setDirection) {
        this.props.setDirection('prev');
      }

      this.props.setCurrentPage(this.state.currentPage - 1);
    }
  }, {
    key: "goToNext",
    value: function goToNext() {
      var _this3 = this;

      if (this.state.currentPage + 1 > this.state.totalPages) {
        return;
      } // Highlight the side that is pressed


      this.setState({
        rightPressed: true
      });
      setTimeout(function () {
        _this3.setState({
          rightPressed: false
        });
      }, 250);

      if (this.props.setDirection) {
        this.props.setDirection('next');
      }

      this.props.setCurrentPage(this.state.currentPage + 1);
    }
  }, {
    key: "render",
    value: function render() {
      var pageChangeRightClass = classnames__WEBPACK_IMPORTED_MODULE_2___default()('change-page-panel', 'change-page-panel-right', {
        pressed: this.state.rightPressed,
        'last-page': this.state.currentPage + 1 > this.state.totalPages
      });
      var pageChangeLeftClass = classnames__WEBPACK_IMPORTED_MODULE_2___default()('change-page-panel', 'change-page-panel-left', {
        pressed: this.state.leftPressed,
        'first-page': this.state.currentPage - 1 === 0
      });
      mousetrap__WEBPACK_IMPORTED_MODULE_3___default.a.bind('right', this.goToNext);
      mousetrap__WEBPACK_IMPORTED_MODULE_3___default.a.bind('left', this.goToPrev);
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()('pagination-container', this.props.className)
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        onClick: this.goToPrev,
        className: pageChangeLeftClass
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "pagination-content"
      }, this.props.children), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        onClick: this.goToNext,
        className: pageChangeRightClass
      }));
    }
  }]);

  return Pagination;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


Pagination.propTypes = {
  currentPage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  totalPages: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  children: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.node,
  setCurrentPage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  setDirection: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/PaginationStepper/PaginationStepper.scss":
/*!*************************************************************!*\
  !*** ./components/PaginationStepper/PaginationStepper.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./PaginationStepper.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PaginationStepper/PaginationStepper.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PaginationStepper/index.tsx":
/*!************************************************!*\
  !*** ./components/PaginationStepper/index.tsx ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/IconButton */ "../../node_modules/@material-ui/core/esm/IconButton/index.js");
/* harmony import */ var _material_ui_icons_ChevronLeft__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/icons/ChevronLeft */ "../../node_modules/@material-ui/icons/ChevronLeft.js");
/* harmony import */ var _material_ui_icons_ChevronLeft__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_ChevronLeft__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons_ChevronRight__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/icons/ChevronRight */ "../../node_modules/@material-ui/icons/ChevronRight.js");
/* harmony import */ var _material_ui_icons_ChevronRight__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_ChevronRight__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _PaginationStepper_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./PaginationStepper.scss */ "./components/PaginationStepper/PaginationStepper.scss");
/* harmony import */ var _PaginationStepper_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_PaginationStepper_scss__WEBPACK_IMPORTED_MODULE_4__);
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PaginationStepper = function PaginationStepper(_a) {
  var onPrev = _a.onPrev,
      onNext = _a.onNext,
      prevDisabled = _a.prevDisabled,
      nextDisabled = _a.nextDisabled;
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "pagination-stepper-container"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_1__["default"], {
    onClick: onPrev,
    disabled: prevDisabled,
    className: "step-button"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_icons_ChevronLeft__WEBPACK_IMPORTED_MODULE_2___default.a, null)), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_1__["default"], {
    onClick: onNext,
    disabled: nextDisabled,
    className: "step-button"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_icons_ChevronRight__WEBPACK_IMPORTED_MODULE_3___default.a, null)));
};

/* harmony default export */ __webpack_exports__["default"] = (PaginationStepper);

/***/ }),

/***/ "./components/PipelineExportModal/PipelineExportModal.scss":
/*!*****************************************************************!*\
  !*** ./components/PipelineExportModal/PipelineExportModal.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./PipelineExportModal.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineExportModal/PipelineExportModal.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PipelineExportModal/index.tsx":
/*!**************************************************!*\
  !*** ./components/PipelineExportModal/index.tsx ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _PipelineExportModal_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./PipelineExportModal.scss */ "./components/PipelineExportModal/PipelineExportModal.scss");
/* harmony import */ var _PipelineExportModal_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_PipelineExportModal_scss__WEBPACK_IMPORTED_MODULE_4__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var PREFIX = 'features.PipelineDetails.TopPanel';

var PipelineExportModal = function PipelineExportModal(_a) {
  var isOpen = _a.isOpen,
      onClose = _a.onClose,
      pipelineConfig = _a.pipelineConfig;

  var exportPipeline = function exportPipeline() {
    var blob = new Blob([JSON.stringify(pipelineConfig, null, 4)], {
      type: 'application/json'
    });
    var url = URL.createObjectURL(blob);
    var exportFileName = (pipelineConfig.name ? pipelineConfig.name : 'noname') + '-' + pipelineConfig.artifact.name;
    var a = document.createElement('a');
    a.href = url;
    a.download = exportFileName + ".json";

    var clickHandler = function clickHandler(event) {
      event.stopPropagation();
      setTimeout(function () {
        onClose();
      }, 300);
    };

    a.addEventListener('click', clickHandler, false);
    a.click();
  };

  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](reactstrap__WEBPACK_IMPORTED_MODULE_1__["Modal"], {
    isOpen: isOpen,
    toggle: onClose,
    size: "lg",
    backdrop: "static",
    className: "cdap-modal pipeline-export-modal"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](reactstrap__WEBPACK_IMPORTED_MODULE_1__["ModalHeader"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate(PREFIX + ".exportModalTitle")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "close-section float-right",
    onClick: onClose
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
    name: "icon-close"
  }))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](reactstrap__WEBPACK_IMPORTED_MODULE_1__["ModalBody"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("fieldset", {
    disabled: true,
    className: "view-plugin-json"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "widget-json-editor"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "textarea-container"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("textarea", {
    className: "form-control",
    value: JSON.stringify(pipelineConfig, null, 2),
    readOnly: true
  }))))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](reactstrap__WEBPACK_IMPORTED_MODULE_1__["ModalFooter"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "btn btn-primary",
    onClick: exportPipeline
  }, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate(PREFIX + ".export")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "btn btn-secondary close-button",
    onClick: onClose
  }, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate('commons.close'))));
};

/* harmony default export */ __webpack_exports__["default"] = (PipelineExportModal);

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/DeployedActions/index.tsx":
/*!********************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/DeployedActions/index.tsx ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_PipelineList_DeployedPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/store/ActionCreator */ "./components/PipelineList/DeployedPipelineView/store/ActionCreator.ts");
/* harmony import */ var components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/store */ "./components/PipelineList/DeployedPipelineView/store/index.ts");
/* harmony import */ var components_ActionsPopover__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/ActionsPopover */ "./components/ActionsPopover/index.tsx");
/* harmony import */ var services_PipelineUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/PipelineUtils */ "./services/PipelineUtils/index.ts");
/* harmony import */ var components_PipelineExportModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/PipelineExportModal */ "./components/PipelineExportModal/index.tsx");
/* harmony import */ var components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/ConfirmationModal */ "./components/ConfirmationModal/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_schedule__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! api/schedule */ "./api/schedule.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_11__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();













var PREFIX = 'features.PipelineList.DeleteConfirmation';

var DeployedActionsView =
/** @class */
function (_super) {
  __extends(DeployedActionsView, _super);

  function DeployedActionsView() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.state = {
      showExport: false,
      showDeleteConfirmation: false,
      triggeredPipelines: []
    };
    _this.pipelineConfig = {};

    _this.showExportModal = function () {
      Object(services_PipelineUtils__WEBPACK_IMPORTED_MODULE_4__["getPipelineConfig"])(_this.props.pipeline.name).subscribe(function (pipelineConfig) {
        _this.pipelineConfig = pipelineConfig;

        _this.setState({
          showExport: true
        });
      });
    };

    _this.closeExportModal = function () {
      _this.pipelineConfig = {};

      _this.setState({
        showExport: false
      });
    };

    _this.renderConfirmationBody = function () {
      var triggered = _this.state.triggeredPipelines;

      if (triggered.length > 0) {
        var triggersText = _this.state.triggeredPipelines.map(function (pipeline) {
          return pipeline.application;
        }).join(', ');

        return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate(PREFIX + ".pipeline"), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("em", null, _this.props.pipeline.name)), i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate(PREFIX + ".trigger"), i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate(PREFIX + ".triggerPluralCheck", {
          context: triggered.length
        }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("em", null, triggersText), i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate(PREFIX + ".triggerDelete"), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("em", null, _this.props.pipeline.name)), i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate(PREFIX + ".proceedPrompt"));
      }

      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate(PREFIX + ".confirmPrompt"), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("em", null, _this.props.pipeline.name)), "?");
    };

    _this.renderDeleteConfirmation = function () {
      if (!_this.state.showDeleteConfirmation) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_6__["default"], {
        headerTitle: i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate(PREFIX + ".title"),
        toggleModal: _this.toggleDeleteConfirmation,
        confirmationElem: _this.renderConfirmationBody(),
        confirmButtonText: i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate(PREFIX + ".confirm"),
        confirmFn: components_PipelineList_DeployedPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_1__["deletePipeline"].bind(null, _this.props.pipeline, _this.props.refetch),
        cancelFn: _this.toggleDeleteConfirmation,
        isOpen: _this.state.showDeleteConfirmation,
        errorMessage: !_this.props.deleteError ? '' : i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate(PREFIX + ".deleteError"),
        extendedMessage: _this.props.deleteError
      });
    };
    /**
     * If the pipeline is a batch pipeline, we have to fetch the list of schedules first. Otherwise
     * just show the confirmation modal.
     */


    _this.showDeleteConfirmation = function () {
      var pipeline = _this.props.pipeline;

      if (pipeline.artifact.name !== services_global_constants__WEBPACK_IMPORTED_MODULE_10__["GLOBALS"].etlDataPipeline) {
        _this.setState({
          showDeleteConfirmation: true,
          triggeredPipelines: []
        });

        return;
      }

      var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_8__["getCurrentNamespace"])();
      var params = {
        namespace: namespace,
        'trigger-namespace-id': namespace,
        'trigger-program-type': 'workflows',
        'trigger-app-name': _this.props.pipeline.name,
        'trigger-program-name': 'DataPipelineWorkflow',
        'schedule-status': 'SCHEDULED'
      };
      api_schedule__WEBPACK_IMPORTED_MODULE_9__["MyScheduleApi"].getTriggeredList(params).subscribe(function (res) {
        _this.setState({
          showDeleteConfirmation: true,
          triggeredPipelines: res
        });
      });
    };

    _this.toggleDeleteConfirmation = function () {
      _this.setState({
        showDeleteConfirmation: !_this.state.showDeleteConfirmation,
        triggeredPipelines: []
      });

      if (!_this.state.showDeleteConfirmation) {
        _this.props.clearDeleteError();
      }
    };

    _this.actions = [{
      label: i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('commons.duplicate'),
      actionFn: services_PipelineUtils__WEBPACK_IMPORTED_MODULE_4__["duplicatePipeline"].bind(null, _this.props.pipeline.name)
    }, {
      label: i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('commons.export'),
      actionFn: _this.showExportModal
    }, {
      label: 'separator'
    }, {
      label: i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('commons.delete'),
      actionFn: _this.showDeleteConfirmation,
      className: 'delete'
    }];
    return _this;
  }

  DeployedActionsView.prototype.render = function () {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "action"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
      onClick: function onClick(e) {
        return e.preventDefault();
      }
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_ActionsPopover__WEBPACK_IMPORTED_MODULE_3__["default"], {
      actions: this.actions
    })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineExportModal__WEBPACK_IMPORTED_MODULE_5__["default"], {
      isOpen: this.state.showExport,
      onClose: this.closeExportModal,
      pipelineConfig: this.pipelineConfig
    }), this.renderDeleteConfirmation());
  };

  return DeployedActionsView;
}(react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"]);

var mapStateToProps = function mapStateToProps(state, ownProp) {
  return {
    deleteError: state.deployed.deleteError,
    pipeline: ownProp.pipeline
  };
};

var mapDispatch = function mapDispatch(dispatch) {
  return {
    clearDeleteError: function clearDeleteError() {
      dispatch({
        type: components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["Actions"].clearDeleteError
      });
    }
  };
};

var DeployedActions = Object(react_redux__WEBPACK_IMPORTED_MODULE_7__["connect"])(mapStateToProps, mapDispatch)(DeployedActionsView);
/* harmony default export */ __webpack_exports__["default"] = (DeployedActions);

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/DeployedPipelineView.scss":
/*!********************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/DeployedPipelineView.scss ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./DeployedPipelineView.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DeployedPipelineView/DeployedPipelineView.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/LastStart/index.tsx":
/*!**************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/LastStart/index.tsx ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var LastStart = function LastStart(_a) {
  var pipeline = _a.pipeline;
  var runs = pipeline.runs;

  if (runs === null) {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "last-start"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
      className: "fa fa-spin fa-lg"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
      name: "icon-spinner"
    })));
  }

  var lastStarting = Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["objectQuery"])(runs, 0, 'starting');
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "last-start"
  }, Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["humanReadableDate"])(lastStarting));
};

/* harmony default export */ __webpack_exports__["default"] = (LastStart);

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/NextRun/index.tsx":
/*!************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/NextRun/index.tsx ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NextRun; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_Duration__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/Duration */ "./components/Duration/index.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




function NextRun(_a) {
  var pipeline = _a.pipeline;
  var nextRuntime = pipeline.nextRuntime,
      artifact = pipeline.artifact;

  if (nextRuntime === null) {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "next-run"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
      className: "fa fa-spin fa-lg"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
      name: "icon-spinner"
    })));
  }

  if (artifact.name === services_global_constants__WEBPACK_IMPORTED_MODULE_2__["GLOBALS"].etlDataStreams || Array.isArray(nextRuntime) && !nextRuntime.length) {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "next-run"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null, "--"));
  }

  var nextRun = nextRuntime[0].time;
  nextRun = parseInt(nextRun, 10);
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "next-run"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Duration__WEBPACK_IMPORTED_MODULE_1__["default"], {
    targetTime: nextRun
  }));
}

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/Pagination/index.tsx":
/*!***************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/Pagination/index.tsx ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_PipelineList_PaginationView__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PipelineList/PaginationView */ "./components/PipelineList/PaginationView/index.tsx");
/* harmony import */ var components_PipelineList_DeployedPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/store/ActionCreator */ "./components/PipelineList/DeployedPipelineView/store/ActionCreator.ts");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var mapStateToProps = function mapStateToProps(state) {
  var _a = state.deployed,
      _b = _a.filteredPipelines,
      filteredPipelines = _b === void 0 ? [] : _b,
      _c = _a.pipelines,
      pipelines = _c === void 0 ? [] : _c;
  var _d = state.deployed,
      pageLimit = _d.pageLimit,
      currentPage = _d.currentPage;
  /**
   * We need to show pagination if,
   * 1. The current filtered pipelines length is 1 less than pageLimit, or
   * 2. The current filtered pipelines is less than total pipelines, or
   * 3. If the user is in any page other than 1 (which means we need to show always)
   *
   * The filteredPipelines will atmost have pageLimit pipelines. We don't need to show
   * pagination if there are exactly 25 pipelines or less (reason for pipelines & filteredPipelines length check).
   */

  filteredPipelines = filteredPipelines || [];
  pipelines = pipelines || [];
  var shouldDisplay = filteredPipelines.length > pageLimit - 1 && pipelines.length > filteredPipelines.length || state.deployed.currentPage !== 1;
  return {
    currentPage: currentPage,
    pageLimit: pageLimit,
    shouldDisplay: shouldDisplay,
    numPipelines: pipelines.length
  };
};

var mapDispatch = function mapDispatch() {
  return {
    setPage: components_PipelineList_DeployedPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_2__["setPage"]
  };
};

var Pagination = Object(react_redux__WEBPACK_IMPORTED_MODULE_0__["connect"])(mapStateToProps, mapDispatch)(components_PipelineList_PaginationView__WEBPACK_IMPORTED_MODULE_1__["default"]);
/* harmony default export */ __webpack_exports__["default"] = (Pagination);

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/PipelineCount/PipelineCount.scss":
/*!***************************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/PipelineCount/PipelineCount.scss ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./PipelineCount.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DeployedPipelineView/PipelineCount/PipelineCount.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/PipelineCount/index.tsx":
/*!******************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/PipelineCount/index.tsx ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var _PipelineCount_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./PipelineCount.scss */ "./components/PipelineList/DeployedPipelineView/PipelineCount/PipelineCount.scss");
/* harmony import */ var _PipelineCount_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_PipelineCount_scss__WEBPACK_IMPORTED_MODULE_3__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var PREFIX = 'features.PipelineList';

var PipelineCountView = function PipelineCountView(_a) {
  var _b = _a.pipelines,
      pipelines = _b === void 0 ? [] : _b,
      pipelinesLoading = _a.pipelinesLoading;

  if (pipelinesLoading) {
    return null;
  }

  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "pipeline-count"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h5", null, i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate(PREFIX + ".DeployedPipelineView.pipelineCount", {
    context: pipelines ? pipelines.length : 0
  })));
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    pipelines: state.deployed.pipelines
  };
};

var PipelineCount = PipelineCountView;
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps)(PipelineCount));

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/PipelineTable/PipelineTable.scss":
/*!***************************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/PipelineTable/PipelineTable.scss ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./PipelineTable.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DeployedPipelineView/PipelineTable/PipelineTable.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/PipelineTable/PipelineTableRow.tsx":
/*!*****************************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/PipelineTable/PipelineTableRow.tsx ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_PipelineList_DeployedPipelineView_NextRun__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/NextRun */ "./components/PipelineList/DeployedPipelineView/NextRun/index.tsx");
/* harmony import */ var components_PipelineList_DeployedPipelineView_PipelineTags__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/PipelineTags */ "./components/PipelineList/DeployedPipelineView/PipelineTags/index.tsx");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_PipelineList_DeployedPipelineView_Status__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/Status */ "./components/PipelineList/DeployedPipelineView/Status/index.tsx");
/* harmony import */ var components_PipelineList_DeployedPipelineView_LastStart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/LastStart */ "./components/PipelineList/DeployedPipelineView/LastStart/index.tsx");
/* harmony import */ var components_PipelineList_DeployedPipelineView_RunsCount__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/RunsCount */ "./components/PipelineList/DeployedPipelineView/RunsCount/index.tsx");
/* harmony import */ var components_PipelineList_DeployedPipelineView_DeployedActions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/DeployedActions */ "./components/PipelineList/DeployedPipelineView/DeployedActions/index.tsx");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();










var PREFIX = 'features.PipelineList';

var PipelineTableRow =
/** @class */
function (_super) {
  __extends(PipelineTableRow, _super);

  function PipelineTableRow() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  PipelineTableRow.prototype.render = function () {
    var pipeline = this.props.pipeline;
    var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])();
    var pipelineLink = window.getHydratorUrl({
      stateName: 'hydrator.detail',
      stateParams: {
        namespace: namespace,
        pipelineId: pipeline.name
      }
    });
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("a", {
      href: pipelineLink,
      className: " grid-row"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "name",
      title: pipeline.name
    }, pipeline.name), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "type"
    }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate(PREFIX + "." + pipeline.artifact.name)), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DeployedPipelineView_Status__WEBPACK_IMPORTED_MODULE_5__["default"], {
      pipeline: pipeline
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DeployedPipelineView_LastStart__WEBPACK_IMPORTED_MODULE_6__["default"], {
      pipeline: pipeline
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DeployedPipelineView_NextRun__WEBPACK_IMPORTED_MODULE_1__["default"], {
      pipeline: pipeline
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DeployedPipelineView_RunsCount__WEBPACK_IMPORTED_MODULE_7__["default"], {
      pipeline: pipeline
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DeployedPipelineView_PipelineTags__WEBPACK_IMPORTED_MODULE_2__["default"], {
      pipeline: pipeline
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DeployedPipelineView_DeployedActions__WEBPACK_IMPORTED_MODULE_8__["default"], {
      pipeline: pipeline,
      refetch: this.props.refetch
    }));
  };

  return PipelineTableRow;
}(react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"]);

/* harmony default export */ __webpack_exports__["default"] = (PipelineTableRow);

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/PipelineTable/SortableHeader.tsx":
/*!***************************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/PipelineTable/SortableHeader.tsx ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_PipelineList_DeployedPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/store/ActionCreator */ "./components/PipelineList/DeployedPipelineView/store/ActionCreator.ts");
/* harmony import */ var components_PipelineList_SortableHeaderView__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PipelineList/SortableHeaderView */ "./components/PipelineList/SortableHeaderView/index.tsx");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var mapStateToProps = function mapStateToProps(state, ownProp) {
  return {
    sortColumn: state.deployed.sortColumn,
    sortOrder: state.deployed.sortOrder,
    columnName: ownProp.columnName
  };
};

var mapDispatch = function mapDispatch() {
  return {
    setSort: components_PipelineList_DeployedPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_1__["setSort"]
  };
};

var SortableHeader = Object(react_redux__WEBPACK_IMPORTED_MODULE_0__["connect"])(mapStateToProps, mapDispatch)(components_PipelineList_SortableHeaderView__WEBPACK_IMPORTED_MODULE_2__["default"]);
/* harmony default export */ __webpack_exports__["default"] = (SortableHeader);

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/PipelineTable/index.tsx":
/*!******************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/PipelineTable/index.tsx ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_PipelineList_DeployedPipelineView_PipelineTable_PipelineTableRow__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/PipelineTable/PipelineTableRow */ "./components/PipelineList/DeployedPipelineView/PipelineTable/PipelineTableRow.tsx");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_PipelineList_EmptyList__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/PipelineList/EmptyList */ "./components/PipelineList/EmptyList/index.tsx");
/* harmony import */ var components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/store */ "./components/PipelineList/DeployedPipelineView/store/index.ts");
/* harmony import */ var components_EmptyMessageContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/EmptyMessageContainer */ "./components/EmptyMessageContainer/index.js");
/* harmony import */ var components_PipelineList_DeployedPipelineView_PipelineTable_SortableHeader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/PipelineTable/SortableHeader */ "./components/PipelineList/DeployedPipelineView/PipelineTable/SortableHeader.tsx");
/* harmony import */ var _PipelineTable_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./PipelineTable.scss */ "./components/PipelineList/DeployedPipelineView/PipelineTable/PipelineTable.scss");
/* harmony import */ var _PipelineTable_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_PipelineTable_scss__WEBPACK_IMPORTED_MODULE_8__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









var PREFIX = 'features.PipelineList';

var PipelineTableView = function PipelineTableView(_a) {
  var pipelines = _a.pipelines,
      filteredList = _a.filteredPipelines,
      search = _a.search,
      onClear = _a.onClear,
      refetch = _a.refetch;

  function renderBody() {
    if (!pipelines || Array.isArray(pipelines) && pipelines.length === 0) {
      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_EmptyList__WEBPACK_IMPORTED_MODULE_4__["default"], {
        type: components_PipelineList_EmptyList__WEBPACK_IMPORTED_MODULE_4__["VIEW_TYPES"].deployed
      });
    }

    if (!filteredList || Array.isArray(filteredList) && filteredList.length === 0) {
      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_EmptyMessageContainer__WEBPACK_IMPORTED_MODULE_6__["default"], {
        title: i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate(PREFIX + ".EmptyList.EmptySearch.heading", {
          search: search
        }).toString()
      }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("ul", null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("li", null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
        className: "link-text",
        onClick: onClear
      }, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate(PREFIX + ".EmptyList.EmptySearch.clear")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate(PREFIX + ".EmptyList.EmptySearch.search")))));
    }

    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "grid-body"
    }, filteredList.map(function (pipeline) {
      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DeployedPipelineView_PipelineTable_PipelineTableRow__WEBPACK_IMPORTED_MODULE_1__["default"], {
        key: pipeline.name,
        pipeline: pipeline,
        refetch: refetch
      });
    }));
  }

  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "grid-wrapper pipeline-list-table"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "grid grid-container"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "grid-header"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "grid-row"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DeployedPipelineView_PipelineTable_SortableHeader__WEBPACK_IMPORTED_MODULE_7__["default"], {
    columnName: "name"
  }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate(PREFIX + ".type")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate(PREFIX + ".status")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate(PREFIX + ".lastStartTime")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate(PREFIX + ".nextRun")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate(PREFIX + ".runs")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate(PREFIX + ".tags")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", null))), renderBody()));
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    search: state.deployed.search,
    pageLimit: state.deployed.pageLimit,
    currentPage: state.deployed.currentPage,
    sortOrder: state.deployed.sortOrder,
    sortColumn: state.deployed.sortColumn,
    pipelines: state.deployed.pipelines,
    filteredPipelines: state.deployed.filteredPipelines
  };
};

var mapDispatch = function mapDispatch(dispatch) {
  return {
    onClear: function onClear() {
      dispatch({
        type: components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_5__["Actions"].setSearch,
        payload: {
          search: ''
        }
      });
    }
  };
};

var PipelineTable = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps, mapDispatch)(PipelineTableView);
/* harmony default export */ __webpack_exports__["default"] = (PipelineTable);

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/PipelineTags/PipelineTags.scss":
/*!*************************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/PipelineTags/PipelineTags.scss ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./PipelineTags.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DeployedPipelineView/PipelineTags/PipelineTags.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/PipelineTags/index.tsx":
/*!*****************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/PipelineTags/index.tsx ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_Tags__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/Tags */ "./components/Tags/index.js");
/* harmony import */ var _PipelineTags_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PipelineTags.scss */ "./components/PipelineList/DeployedPipelineView/PipelineTags/PipelineTags.scss");
/* harmony import */ var _PipelineTags_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_PipelineTags_scss__WEBPACK_IMPORTED_MODULE_2__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var PipelineTags = function PipelineTags(_a) {
  var pipeline = _a.pipeline;
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "tags"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Tags__WEBPACK_IMPORTED_MODULE_1__["default"], {
    entity: {
      id: pipeline.name,
      type: 'application'
    },
    showCountLabel: false,
    viewOnly: true,
    displayAll: true,
    isNativeLink: true,
    preventDefault: true
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (PipelineTags);

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/RunsCount/index.tsx":
/*!**************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/RunsCount/index.tsx ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */



var RunsCount = function RunsCount(_a) {
  var pipeline = _a.pipeline;
  var runsCount = pipeline.totalRuns;

  if (runsCount === null) {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "runs"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
      className: "fa fa-spin fa-lg"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_IconSVG__WEBPACK_IMPORTED_MODULE_1__["default"], {
      name: "icon-spinner"
    })));
  }

  if (runsCount === 0) {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "runs"
    }, "--");
  }

  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "runs"
  }, runsCount);
};

/* harmony default export */ __webpack_exports__["default"] = (RunsCount);

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/SearchBox/index.tsx":
/*!**************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/SearchBox/index.tsx ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_PipelineList_DeployedPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/store/ActionCreator */ "./components/PipelineList/DeployedPipelineView/store/ActionCreator.ts");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var PREFIX = 'features.PipelineList';

var SearchBoxView = function SearchBoxView(_a) {
  var value = _a.value,
      onChange = _a.onChange;
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "search-box"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "input-group"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "input-group-prepend"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "input-group-text"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
    name: "icon-search"
  }))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("input", {
    type: "text",
    className: "form-control",
    placeholder: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate(PREFIX + ".DeployedPipelineView.searchPlaceholder").toString(),
    value: value,
    onChange: onChange
  })));
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    value: state.deployed.search
  };
};

var mapDispatch = function mapDispatch() {
  return {
    onChange: function onChange(e) {
      Object(components_PipelineList_DeployedPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_3__["setSearch"])(e.target.value);
    }
  };
};

var SearchBox = Object(react_redux__WEBPACK_IMPORTED_MODULE_1__["connect"])(mapStateToProps, mapDispatch)(SearchBoxView);
/* harmony default export */ __webpack_exports__["default"] = (SearchBox);

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/Status/index.tsx":
/*!***********************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/Status/index.tsx ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var services_StatusMapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/StatusMapper */ "./services/StatusMapper.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash/isEmpty */ "../../node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */







var Status = function Status(_a) {
  var pipeline = _a.pipeline;
  var pipelineRuns = pipeline.runs;
  var pipelineStatus = Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(pipelineRuns, 0, 'status');

  if (pipelineRuns === null) {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "status"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
      className: "fa fa-spin fa-lg"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_IconSVG__WEBPACK_IMPORTED_MODULE_1__["default"], {
      name: "icon-spinner"
    })));
  }

  pipelineStatus = lodash_isEmpty__WEBPACK_IMPORTED_MODULE_5___default()(pipelineStatus) ? services_global_constants__WEBPACK_IMPORTED_MODULE_3__["PROGRAM_STATUSES"].DEPLOYED : pipelineStatus;
  var displayStatus = services_StatusMapper__WEBPACK_IMPORTED_MODULE_2__["default"].statusMap[pipelineStatus];
  var statusClassName = services_StatusMapper__WEBPACK_IMPORTED_MODULE_2__["default"].getStatusIndicatorClass(displayStatus);
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "status"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
    className: "fa fa-fw " + statusClassName
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_IconSVG__WEBPACK_IMPORTED_MODULE_1__["default"], {
    name: "icon-circle"
  })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
    className: "text"
  }, displayStatus));
};

/* harmony default export */ __webpack_exports__["default"] = (Status);

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/index.tsx":
/*!****************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/index.tsx ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_PipelineList_DeployedPipelineView_PipelineTable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/PipelineTable */ "./components/PipelineList/DeployedPipelineView/PipelineTable/index.tsx");
/* harmony import */ var components_PipelineList_DeployedPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/store/ActionCreator */ "./components/PipelineList/DeployedPipelineView/store/ActionCreator.ts");
/* harmony import */ var components_PipelineList_DeployedPipelineView_PipelineCount__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/PipelineCount */ "./components/PipelineList/DeployedPipelineView/PipelineCount/index.tsx");
/* harmony import */ var components_PipelineList_DeployedPipelineView_SearchBox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/SearchBox */ "./components/PipelineList/DeployedPipelineView/SearchBox/index.tsx");
/* harmony import */ var components_PipelineList_DeployedPipelineView_Pagination__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/Pagination */ "./components/PipelineList/DeployedPipelineView/Pagination/index.tsx");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/store */ "./components/PipelineList/DeployedPipelineView/store/index.ts");
/* harmony import */ var components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/LoadingSVGCentered */ "./components/LoadingSVGCentered/index.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var apollo_boost__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! apollo-boost */ "../../node_modules/apollo-boost/lib/bundle.esm.js");
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @apollo/react-hooks */ "../../node_modules/@apollo/react-hooks/lib/react-hooks.esm.js");
/* harmony import */ var _DeployedPipelineView_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./DeployedPipelineView.scss */ "./components/PipelineList/DeployedPipelineView/DeployedPipelineView.scss");
/* harmony import */ var _DeployedPipelineView_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_DeployedPipelineView_scss__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __makeTemplateObject = undefined && undefined.__makeTemplateObject || function (cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", {
      value: raw
    });
  } else {
    cooked.raw = raw;
  }

  return cooked;
};
















var DeployedPipeline = function DeployedPipeline() {
  var QUERY = Object(apollo_boost__WEBPACK_IMPORTED_MODULE_10__["gql"])(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n    {\n      pipelines(namespace: \"", "\") {\n        name,\n        artifact {\n          name\n        },\n        runs {\n          status,\n          starting\n        },\n        totalRuns,\n        nextRuntime {\n          id,\n          time\n        }\n      }\n    }\n  "], ["\n    {\n      pipelines(namespace: \"", "\") {\n        name,\n        artifact {\n          name\n        },\n        runs {\n          status,\n          starting\n        },\n        totalRuns,\n        nextRuntime {\n          id,\n          time\n        }\n      }\n    }\n  "])), Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_9__["getCurrentNamespace"])()); // on unmount

  react__WEBPACK_IMPORTED_MODULE_0__["useEffect"](function () {
    return function () {
      Object(components_PipelineList_DeployedPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_2__["reset"])();
    };
  }, []);

  var _a = Object(_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_11__["useQuery"])(QUERY, {
    errorPolicy: 'all',
    notifyOnNetworkStatusChange: true
  }),
      loading = _a.loading,
      error = _a.error,
      data = _a.data,
      refetch = _a.refetch,
      networkStatus = _a.networkStatus;

  if (loading || networkStatus === 4) {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_8__["default"], null);
  }

  if (error) {
    // tslint:disable-next-line: no-console
    console.log('error', JSON.stringify(error, null, 2));
    var graphQLErrors = Object(services_helpers__WEBPACK_IMPORTED_MODULE_13__["objectQuery"])(error, 'graphQLErrors') || [];
    var networkErrors = Object(services_helpers__WEBPACK_IMPORTED_MODULE_13__["objectQuery"])(error, 'networkError') || [];
    var errors = graphQLErrors.concat(networkErrors).map(function (err) {
      return err.message;
    }).join('\n');

    if (!errors || errors.length === 0) {
      var prefix = /^GraphQL error\:/;
      errors = error.message.replace(prefix, '').trim();
    }

    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "pipeline-deployed-view error-container"
    }, errors);
  }

  Object(components_PipelineList_DeployedPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_2__["setFilteredPipelines"])(data.pipelines);
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react_redux__WEBPACK_IMPORTED_MODULE_6__["Provider"], {
    store: components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_7__["default"]
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "pipeline-deployed-view pipeline-list-content"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "deployed-header"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DeployedPipelineView_PipelineCount__WEBPACK_IMPORTED_MODULE_3__["default"], {
    pipelinesLoading: loading
  }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DeployedPipelineView_SearchBox__WEBPACK_IMPORTED_MODULE_4__["default"], null), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DeployedPipelineView_Pagination__WEBPACK_IMPORTED_MODULE_5__["default"], null)), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DeployedPipelineView_PipelineTable__WEBPACK_IMPORTED_MODULE_1__["default"], {
    refetch: refetch
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (DeployedPipeline);
var templateObject_1;

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/store/ActionCreator.ts":
/*!*****************************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/store/ActionCreator.ts ***!
  \*****************************************************************************/
/*! exports provided: deletePipeline, reset, setFilteredPipelines, setPage, setSearch, setSort */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deletePipeline", function() { return deletePipeline; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reset", function() { return reset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setFilteredPipelines", function() { return setFilteredPipelines; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setPage", function() { return setPage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setSearch", function() { return setSearch; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setSort", function() { return setSort; });
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_pipeline__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! api/pipeline */ "./api/pipeline.js");
/* harmony import */ var components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/store */ "./components/PipelineList/DeployedPipelineView/store/index.ts");
/* harmony import */ var natural_orderby__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! natural-orderby */ "../../node_modules/natural-orderby/esm/natural-orderby.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash/debounce */ "../../node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_6__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
    }

    return t;
  };

  return __assign.apply(this, arguments);
};

var __spreadArrays = undefined && undefined.__spreadArrays || function () {
  for (var s = 0, i = 0, il = arguments.length; i < il; i++) {
    s += arguments[i].length;
  }

  for (var r = Array(s), k = 0, i = 0; i < il; i++) {
    for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) {
      r[k] = a[j];
    }
  }

  return r;
};








var debounceFilteredPipelineRunsFetch = lodash_debounce__WEBPACK_IMPORTED_MODULE_6___default()(getRunsForFilteredPipelines, 500);

function getOrderColumnFunction(sortColumn, sortOrder) {
  switch (sortColumn) {
    case 'name':
      return function (pipeline) {
        return pipeline.name.toLowerCase();
      };

    case 'type':
      return function (pipeline) {
        return pipeline.artifact.name;
      };

    case 'status':
      return function (pipeline) {
        return Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(pipeline, 'runs', 0, 'status') || services_global_constants__WEBPACK_IMPORTED_MODULE_5__["PROGRAM_STATUSES"].DEPLOYED;
      };

    case 'lastStartTime':
      return function (pipeline) {
        var lastStarting = Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(pipeline, 'runs', 0, 'starting');

        if (!lastStarting) {
          return sortOrder === components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["SORT_ORDER"].asc ? Infinity : -1;
        }

        return lastStarting;
      };

    case 'runs':
      return function (pipeline) {
        return pipeline.totalRuns || 0;
      };
  }
}

function deletePipeline(pipeline, refetch) {
  var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_0__["getCurrentNamespace"])();
  var params = {
    namespace: namespace,
    appId: pipeline.name
  };
  api_pipeline__WEBPACK_IMPORTED_MODULE_1__["MyPipelineApi"]["delete"](params).subscribe(function () {
    refetch();
    reset();
  }, function (err) {
    components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
      type: components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setDeleteError,
      payload: {
        deleteError: err
      }
    });
  });
}
function reset() {
  components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
    type: components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["Actions"].reset
  });
}

function getRunsForFilteredPipelines() {
  var _a = components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().deployed,
      filteredPipelines = _a.filteredPipelines,
      pipelines = _a.pipelines;

  if (!filteredPipelines || !pipelines) {
    return;
  }

  var pipelinesWithoutRuns = filteredPipelines.filter(function (pipeline) {
    return pipeline.runs === null || pipeline.totalRuns === null;
  });

  if (!pipelinesWithoutRuns.length) {
    return;
  }

  var getProgram = function getProgram(pipelineType) {
    var programId = services_global_constants__WEBPACK_IMPORTED_MODULE_5__["GLOBALS"].programId[pipelineType];
    var programType = services_global_constants__WEBPACK_IMPORTED_MODULE_5__["GLOBALS"].programTypeName[pipelineType];
    return {
      programId: programId,
      programType: programType
    };
  };

  var postBody = pipelinesWithoutRuns.map(function (pipeline) {
    return __assign({
      appId: pipeline.name
    }, getProgram(pipeline.artifact.name));
  });
  var nextRuntimePostBody = pipelinesWithoutRuns.filter(function (pipeline) {
    return pipeline.artifact.name === services_global_constants__WEBPACK_IMPORTED_MODULE_5__["GLOBALS"].etlDataPipeline;
  }).map(function (pipeline) {
    return __assign({
      appId: pipeline.name
    }, getProgram(pipeline.artifact.name));
  });
  var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_0__["getCurrentNamespace"])();
  api_pipeline__WEBPACK_IMPORTED_MODULE_1__["MyPipelineApi"].getBatchRuns({
    namespace: namespace
  }, postBody).combineLatest(api_pipeline__WEBPACK_IMPORTED_MODULE_1__["MyPipelineApi"].getRunsCount({
    namespace: namespace
  }, postBody), api_pipeline__WEBPACK_IMPORTED_MODULE_1__["MyPipelineApi"].batchGetNextRunTime({
    namespace: namespace
  }, nextRuntimePostBody)).subscribe(function (_a) {
    var runs = _a[0],
        runsCount = _a[1],
        nextRuntime = _a[2];
    var runsMap = Object.assign.apply(Object, __spreadArrays([{}], runs.map(function (app) {
      var _a;

      return _a = {}, _a[app.appId] = app.runs, _a;
    })));
    var nextRuntimeMap = Object.assign.apply(Object, __spreadArrays([{}], nextRuntime.map(function (app) {
      var _a;

      return _a = {}, _a[app.appId] = app.schedules, _a;
    })));
    var runsCountMap = Object.assign.apply(Object, __spreadArrays([{}], runsCount.map(function (app) {
      var _a;

      return _a = {}, _a[app.appId] = app.runCount, _a;
    })));

    var getNextrunTime = function getNextrunTime(nrMap, pipeline) {
      if (pipeline.artifact.name === services_global_constants__WEBPACK_IMPORTED_MODULE_5__["GLOBALS"].etlDataStreams) {
        return [];
      }

      return nrMap[pipeline.name] || pipeline.nextRuntime;
    };

    var filteredPipelinesWithRuns = filteredPipelines.map(function (pipeline) {
      return __assign(__assign({}, pipeline), {
        runs: runsMap[pipeline.name] || pipeline.runs,
        totalRuns: runsCountMap[pipeline.name] || pipeline.totalRuns,
        nextRuntime: getNextrunTime(nextRuntimeMap, pipeline)
      });
    });
    var pipelinesWithRuns = pipelines.map(function (pipeline) {
      return __assign(__assign({}, pipeline), {
        runs: runsMap[pipeline.name] || pipeline.runs,
        totalRuns: runsCountMap[pipeline.name] || pipeline.totalRuns,
        nextRuntime: getNextrunTime(nextRuntimeMap, pipeline)
      });
    });
    components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
      type: components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["Actions"].updateFilteredPipelines,
      payload: {
        filteredPipelines: filteredPipelinesWithRuns,
        pipelines: pipelinesWithRuns
      }
    });
  });
}

function getFilteredPipelines(_a) {
  var pipelines = _a.pipelines,
      search = _a.search,
      sortOrder = _a.sortOrder,
      sortColumn = _a.sortColumn,
      currentPage = _a.currentPage,
      pageLimit = _a.pageLimit;

  if (!pipelines) {
    return;
  }

  var filteredPipelines = pipelines;

  if (search.length > 0) {
    filteredPipelines = pipelines.filter(function (pipeline) {
      var name = pipeline.name.toLowerCase();
      var searchFilter = search.toLowerCase();
      return name.indexOf(searchFilter) !== -1;
    });
  }

  filteredPipelines = Object(natural_orderby__WEBPACK_IMPORTED_MODULE_3__["orderBy"])(filteredPipelines, [getOrderColumnFunction(sortColumn, sortOrder)], [sortOrder]);
  var startIndex = (currentPage - 1) * pageLimit;
  var endIndex = startIndex + pageLimit;
  filteredPipelines = filteredPipelines.slice(startIndex, endIndex);
  return filteredPipelines;
}

function setFilteredPipelines(pipelines) {
  if (pipelines === void 0) {
    pipelines = components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().deployed.pipelines;
  }

  var filteredPipelines = getFilteredPipelines(__assign(__assign({}, components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().deployed), {
    pipelines: pipelines
  }));
  components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
    type: components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setPipelines,
    payload: {
      pipelines: pipelines,
      filteredPipelines: filteredPipelines
    }
  });
  getRunsForFilteredPipelines();
}
function setPage(currentPage) {
  var currentPageFromStore = components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().deployed.currentPage;

  if (!currentPage) {
    currentPage = currentPageFromStore;
  }

  var filteredPipelines = getFilteredPipelines(__assign(__assign({}, components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().deployed), {
    currentPage: currentPage
  }));
  components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
    type: components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setPage,
    payload: {
      currentPage: currentPage,
      filteredPipelines: filteredPipelines
    }
  });
  getRunsForFilteredPipelines();
}
function setSearch(searchText) {
  var newState = __assign(__assign({}, components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().deployed), {
    search: searchText
  });

  if (!searchText) {
    newState.currentPage = 1;
  }

  var filteredPipelines = getFilteredPipelines(newState);
  components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
    type: components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setSearch,
    payload: {
      search: searchText,
      filteredPipelines: filteredPipelines
    }
  });
  debounceFilteredPipelineRunsFetch();
}
function setSort(columnName) {
  var state = components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().deployed;
  var currentColumn = state.sortColumn;
  var currentSortOrder = state.sortOrder;
  var sortOrder = components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["SORT_ORDER"].asc;

  if (currentColumn === columnName && currentSortOrder === components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["SORT_ORDER"].asc) {
    sortOrder = components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["SORT_ORDER"].desc;
  }

  var filteredPipelines = getFilteredPipelines(__assign(__assign({}, components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().deployed), {
    sortColumn: columnName,
    sortOrder: sortOrder,
    currentPage: 1
  }));
  components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
    type: components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setSort,
    payload: {
      sortColumn: columnName,
      sortOrder: sortOrder,
      filteredPipelines: filteredPipelines
    }
  });
  getRunsForFilteredPipelines();
}

/***/ }),

/***/ "./components/PipelineList/DeployedPipelineView/store/index.ts":
/*!*********************************************************************!*\
  !*** ./components/PipelineList/DeployedPipelineView/store/index.ts ***!
  \*********************************************************************/
/*! exports provided: default, Actions, SORT_ORDER */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Actions", function() { return Actions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SORT_ORDER", function() { return SORT_ORDER; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
    }

    return t;
  };

  return __assign.apply(this, arguments);
};



var SORT_ORDER;

(function (SORT_ORDER) {
  SORT_ORDER["asc"] = "asc";
  SORT_ORDER["desc"] = "desc";
})(SORT_ORDER || (SORT_ORDER = {}));

var Actions = {
  setSearch: 'DEPLOYED_SET_SEARCH',
  setDeleteError: 'DEPLOYED_PIPELINE_SET_DELETE_ERROR',
  clearDeleteError: 'DEPLOYED_PIPELINE_CLEAR_DELETE_ERROR',
  setSort: 'DEPLOYED_PIPELINE_SET_SORT',
  setPage: 'DEPLOYED_PIPELINE_SET_PAGE',
  reset: 'DEPLOYED_PIPELINE_RESET',
  setPipelines: 'DEPLOYED_PIPELINE_SET_PIPELINES',
  updateFilteredPipelines: 'DEPLOYED_PIPELINE_UPDATE_FILTERED_PIPELINES'
};
var defaultInitialState = {
  deleteError: null,
  sortColumn: 'name',
  sortOrder: SORT_ORDER.asc,
  search: '',
  currentPage: 1,
  pageLimit: 25,
  pipelines: null,
  filteredPipelines: null
};

var deployed = function deployed(state, action) {
  if (state === void 0) {
    state = defaultInitialState;
  }

  switch (action.type) {
    case Actions.setDeleteError:
      return __assign(__assign({}, state), {
        deleteError: action.payload.deleteError
      });

    case Actions.clearDeleteError:
      return __assign(__assign({}, state), {
        deleteError: null
      });

    case Actions.setSearch:
      return __assign(__assign({}, state), {
        search: action.payload.search,
        filteredPipelines: action.payload.filteredPipelines,
        currentPage: 1
      });

    case Actions.setSort:
      return __assign(__assign({}, state), {
        sortColumn: action.payload.sortColumn,
        sortOrder: action.payload.sortOrder,
        filteredPipelines: action.payload.filteredPipelines,
        currentPage: 1
      });

    case Actions.setPage:
      return __assign(__assign({}, state), {
        currentPage: action.payload.currentPage,
        filteredPipelines: action.payload.filteredPipelines
      });

    case Actions.setPipelines:
      return __assign(__assign({}, state), {
        pipelines: action.payload.pipelines,
        filteredPipelines: action.payload.filteredPipelines
      });

    case Actions.updateFilteredPipelines:
      return __assign(__assign({}, state), {
        pipelines: action.payload.pipelines,
        filteredPipelines: action.payload.filteredPipelines
      });

    case Actions.reset:
      return defaultInitialState;

    default:
      return state;
  }
};

var Store = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  deployed: deployed
}), {
  deployed: defaultInitialState
}, Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["composeEnhancers"])('DeployedPipelineStore')());
/* harmony default export */ __webpack_exports__["default"] = (Store);


/***/ }),

/***/ "./components/PipelineList/DraftPipelineView/DraftActions/index.tsx":
/*!**************************************************************************!*\
  !*** ./components/PipelineList/DraftPipelineView/DraftActions/index.tsx ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_PipelineList_DraftPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView/store/ActionCreator */ "./components/PipelineList/DraftPipelineView/store/ActionCreator.ts");
/* harmony import */ var components_ActionsPopover__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/ActionsPopover */ "./components/ActionsPopover/index.tsx");
/* harmony import */ var components_PipelineExportModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/PipelineExportModal */ "./components/PipelineExportModal/index.tsx");
/* harmony import */ var components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/ConfirmationModal */ "./components/ConfirmationModal/index.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();







var PREFIX = 'features.PipelineList.DeleteConfirmation';

var DraftActions =
/** @class */
function (_super) {
  __extends(DraftActions, _super);

  function DraftActions() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.state = {
      showExport: false,
      showDeleteConfirmation: false
    };
    _this.pipelineConfig = {};

    _this.openExportModal = function () {
      var draft = _this.props.draft;
      _this.pipelineConfig = {
        name: draft.name,
        description: draft.description,
        artifact: draft.artifact,
        config: draft.config
      };

      _this.setState({
        showExport: true
      });
    };

    _this.closeExportModal = function () {
      _this.pipelineConfig = {};

      _this.setState({
        showExport: false
      });
    };

    _this.toggleDeleteConfirmation = function () {
      _this.setState({
        showDeleteConfirmation: !_this.state.showDeleteConfirmation
      });
    };

    _this.renderConfirmationBody = function () {
      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", null, i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate(PREFIX + ".confirmDraftPrompt"), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("em", null, _this.props.draft.name)), "?");
    };

    _this.renderDeleteConfirmation = function () {
      if (!_this.state.showDeleteConfirmation) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_5__["default"], {
        headerTitle: i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate(PREFIX + ".titleDraft"),
        toggleModal: _this.toggleDeleteConfirmation,
        confirmationElem: _this.renderConfirmationBody(),
        confirmButtonText: i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate(PREFIX + ".confirm"),
        confirmFn: components_PipelineList_DraftPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_2__["deleteDraft"].bind(null, _this.props.draft),
        cancelFn: _this.toggleDeleteConfirmation,
        isOpen: _this.state.showDeleteConfirmation
      });
    };

    _this.actions = [{
      label: i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate('commons.export'),
      actionFn: _this.openExportModal
    }, {
      label: 'separator'
    }, {
      label: i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate('commons.delete'),
      actionFn: _this.toggleDeleteConfirmation,
      className: 'delete'
    }];
    return _this;
  }

  DraftActions.prototype.render = function () {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "action",
      onClick: function onClick(e) {
        return e.preventDefault();
      }
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_ActionsPopover__WEBPACK_IMPORTED_MODULE_3__["default"], {
      actions: this.actions
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineExportModal__WEBPACK_IMPORTED_MODULE_4__["default"], {
      isOpen: this.state.showExport,
      onClose: this.closeExportModal,
      pipelineConfig: this.pipelineConfig
    }), this.renderDeleteConfirmation());
  };

  return DraftActions;
}(react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"]);

/* harmony default export */ __webpack_exports__["default"] = (DraftActions);

/***/ }),

/***/ "./components/PipelineList/DraftPipelineView/DraftCount/DraftCount.scss":
/*!******************************************************************************!*\
  !*** ./components/PipelineList/DraftPipelineView/DraftCount/DraftCount.scss ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./DraftCount.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DraftPipelineView/DraftCount/DraftCount.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PipelineList/DraftPipelineView/DraftCount/index.tsx":
/*!************************************************************************!*\
  !*** ./components/PipelineList/DraftPipelineView/DraftCount/index.tsx ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _DraftCount_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./DraftCount.scss */ "./components/PipelineList/DraftPipelineView/DraftCount/DraftCount.scss");
/* harmony import */ var _DraftCount_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_DraftCount_scss__WEBPACK_IMPORTED_MODULE_3__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var PREFIX = 'features.PipelineList.DraftPipelineView';

var DraftCountView = function DraftCountView(_a) {
  var drafts = _a.drafts;
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "draft-count"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h5", null, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate(PREFIX + ".draftCount", {
    context: drafts.length
  })));
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    drafts: state.drafts.list
  };
};

var DraftCount = Object(react_redux__WEBPACK_IMPORTED_MODULE_1__["connect"])(mapStateToProps)(DraftCountView);
/* harmony default export */ __webpack_exports__["default"] = (DraftCount);

/***/ }),

/***/ "./components/PipelineList/DraftPipelineView/DraftPipelineView.scss":
/*!**************************************************************************!*\
  !*** ./components/PipelineList/DraftPipelineView/DraftPipelineView.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./DraftPipelineView.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DraftPipelineView/DraftPipelineView.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PipelineList/DraftPipelineView/DraftTable/DraftTable.scss":
/*!******************************************************************************!*\
  !*** ./components/PipelineList/DraftPipelineView/DraftTable/DraftTable.scss ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./DraftTable.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/DraftPipelineView/DraftTable/DraftTable.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PipelineList/DraftPipelineView/DraftTable/DraftTableRow.tsx":
/*!********************************************************************************!*\
  !*** ./components/PipelineList/DraftPipelineView/DraftTable/DraftTableRow.tsx ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_PipelineList_DraftPipelineView_DraftActions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView/DraftActions */ "./components/PipelineList/DraftPipelineView/DraftActions/index.tsx");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();






var PREFIX = 'features.PipelineList';

var DraftTableRow =
/** @class */
function (_super) {
  __extends(DraftTableRow, _super);

  function DraftTableRow() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  DraftTableRow.prototype.render = function () {
    var draft = this.props.draft;
    var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__["getCurrentNamespace"])();
    var lastSaved = Object(services_helpers__WEBPACK_IMPORTED_MODULE_3__["humanReadableDate"])(draft.__ui__.lastSaved, true);
    var link = window.getHydratorUrl({
      stateName: 'hydrator.create',
      stateParams: {
        namespace: namespace,
        draftId: draft.__ui__.draftId
      }
    });
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("a", {
      href: link,
      className: "grid-row"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "name",
      title: draft.name
    }, draft.name), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "type"
    }, i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate(PREFIX + "." + draft.artifact.name)), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "last-saved"
    }, lastSaved), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DraftPipelineView_DraftActions__WEBPACK_IMPORTED_MODULE_4__["default"], {
      draft: this.props.draft
    }));
  };

  return DraftTableRow;
}(react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"]);

/* harmony default export */ __webpack_exports__["default"] = (DraftTableRow);

/***/ }),

/***/ "./components/PipelineList/DraftPipelineView/DraftTable/SortableHeader.tsx":
/*!*********************************************************************************!*\
  !*** ./components/PipelineList/DraftPipelineView/DraftTable/SortableHeader.tsx ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_PipelineList_DraftPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView/store/ActionCreator */ "./components/PipelineList/DraftPipelineView/store/ActionCreator.ts");
/* harmony import */ var components_PipelineList_SortableHeaderView__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PipelineList/SortableHeaderView */ "./components/PipelineList/SortableHeaderView/index.tsx");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var mapStateToProps = function mapStateToProps(state, ownProp) {
  return {
    sortColumn: state.drafts.sortColumn,
    sortOrder: state.drafts.sortOrder,
    columnName: ownProp.columnName
  };
};

var mapDispatch = function mapDispatch() {
  return {
    setSort: components_PipelineList_DraftPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_1__["setSort"]
  };
};

var SortableHeader = Object(react_redux__WEBPACK_IMPORTED_MODULE_0__["connect"])(mapStateToProps, mapDispatch)(components_PipelineList_SortableHeaderView__WEBPACK_IMPORTED_MODULE_2__["default"]);
/* harmony default export */ __webpack_exports__["default"] = (SortableHeader);

/***/ }),

/***/ "./components/PipelineList/DraftPipelineView/DraftTable/index.tsx":
/*!************************************************************************!*\
  !*** ./components/PipelineList/DraftPipelineView/DraftTable/index.tsx ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_PipelineList_DraftPipelineView_DraftTable_DraftTableRow__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView/DraftTable/DraftTableRow */ "./components/PipelineList/DraftPipelineView/DraftTable/DraftTableRow.tsx");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_PipelineList_EmptyList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/PipelineList/EmptyList */ "./components/PipelineList/EmptyList/index.tsx");
/* harmony import */ var components_PipelineList_DraftPipelineView_DraftTable_SortableHeader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView/DraftTable/SortableHeader */ "./components/PipelineList/DraftPipelineView/DraftTable/SortableHeader.tsx");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./DraftTable.scss */ "./components/PipelineList/DraftPipelineView/DraftTable/DraftTable.scss");

var DraftTableView = function DraftTableView(_a) {
  var drafts = _a.drafts,
      currentPage = _a.currentPage,
      pageLimit = _a.pageLimit;

  function renderBody() {
    if (drafts.length === 0) {
      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_EmptyList__WEBPACK_IMPORTED_MODULE_3__["default"], {
        type: components_PipelineList_EmptyList__WEBPACK_IMPORTED_MODULE_3__["VIEW_TYPES"].draft
      });
    }

    var startIndex = (currentPage - 1) * pageLimit;
    var endIndex = startIndex + pageLimit;
    var filteredDrafts = drafts.slice(startIndex, endIndex);
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "grid-body"
    }, filteredDrafts.map(function (draft) {
      return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DraftPipelineView_DraftTable_DraftTableRow__WEBPACK_IMPORTED_MODULE_1__["default"], {
        draft: draft,
        key: draft.__ui__.draftId
      });
    }));
  }

  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "draft-table grid-wrapper"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "grid grid-container"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "grid-header"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "grid-row"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DraftPipelineView_DraftTable_SortableHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
    columnName: "name"
  }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DraftPipelineView_DraftTable_SortableHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
    columnName: "type"
  }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DraftPipelineView_DraftTable_SortableHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
    columnName: "lastSaved"
  }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", null))), renderBody()));
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    drafts: state.drafts.list,
    currentPage: state.drafts.currentPage,
    pageLimit: state.drafts.pageLimit
  };
};

var DraftTable = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps)(DraftTableView);
/* harmony default export */ __webpack_exports__["default"] = (DraftTable);

/***/ }),

/***/ "./components/PipelineList/DraftPipelineView/Pagination/index.tsx":
/*!************************************************************************!*\
  !*** ./components/PipelineList/DraftPipelineView/Pagination/index.tsx ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView/store */ "./components/PipelineList/DraftPipelineView/store/index.ts");
/* harmony import */ var components_PipelineList_PaginationView__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PipelineList/PaginationView */ "./components/PipelineList/PaginationView/index.tsx");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var mapStateToProps = function mapStateToProps(state) {
  return {
    currentPage: state.drafts.currentPage,
    numPipelines: state.drafts.list.length,
    pageLimit: state.drafts.pageLimit
  };
};

var mapDispatch = function mapDispatch(dispatch) {
  return {
    setPage: function setPage(page) {
      dispatch({
        type: components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_1__["Actions"].setPage,
        payload: {
          currentPage: page
        }
      });
    }
  };
};

var Pagination = Object(react_redux__WEBPACK_IMPORTED_MODULE_0__["connect"])(mapStateToProps, mapDispatch)(components_PipelineList_PaginationView__WEBPACK_IMPORTED_MODULE_2__["default"]);
/* harmony default export */ __webpack_exports__["default"] = (Pagination);

/***/ }),

/***/ "./components/PipelineList/DraftPipelineView/index.tsx":
/*!*************************************************************!*\
  !*** ./components/PipelineList/DraftPipelineView/index.tsx ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_PipelineList_DraftPipelineView_DraftTable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView/DraftTable */ "./components/PipelineList/DraftPipelineView/DraftTable/index.tsx");
/* harmony import */ var components_PipelineList_DraftPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView/store/ActionCreator */ "./components/PipelineList/DraftPipelineView/store/ActionCreator.ts");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView/store */ "./components/PipelineList/DraftPipelineView/store/index.ts");
/* harmony import */ var components_PipelineList_DraftPipelineView_DraftCount__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView/DraftCount */ "./components/PipelineList/DraftPipelineView/DraftCount/index.tsx");
/* harmony import */ var components_PipelineList_DraftPipelineView_Pagination__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView/Pagination */ "./components/PipelineList/DraftPipelineView/Pagination/index.tsx");
/* harmony import */ var _DraftPipelineView_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./DraftPipelineView.scss */ "./components/PipelineList/DraftPipelineView/DraftPipelineView.scss");
/* harmony import */ var _DraftPipelineView_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_DraftPipelineView_scss__WEBPACK_IMPORTED_MODULE_7__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();










var DraftPipelineView =
/** @class */
function (_super) {
  __extends(DraftPipelineView, _super);

  function DraftPipelineView() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  DraftPipelineView.prototype.componentDidMount = function () {
    Object(components_PipelineList_DraftPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_2__["getDrafts"])();
  };

  DraftPipelineView.prototype.componentWillUnmount = function () {
    Object(components_PipelineList_DraftPipelineView_store_ActionCreator__WEBPACK_IMPORTED_MODULE_2__["reset"])();
  };

  DraftPipelineView.prototype.render = function () {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react_redux__WEBPACK_IMPORTED_MODULE_3__["Provider"], {
      store: components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_4__["default"]
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "pipeline-draft-view pipeline-list-content"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "draft-header"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DraftPipelineView_DraftCount__WEBPACK_IMPORTED_MODULE_5__["default"], null), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DraftPipelineView_Pagination__WEBPACK_IMPORTED_MODULE_6__["default"], null)), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PipelineList_DraftPipelineView_DraftTable__WEBPACK_IMPORTED_MODULE_1__["default"], null)));
  };

  return DraftPipelineView;
}(react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"]);

/* harmony default export */ __webpack_exports__["default"] = (DraftPipelineView);

/***/ }),

/***/ "./components/PipelineList/DraftPipelineView/store/ActionCreator.ts":
/*!**************************************************************************!*\
  !*** ./components/PipelineList/DraftPipelineView/store/ActionCreator.ts ***!
  \**************************************************************************/
/*! exports provided: getDrafts, reset, deleteDraft, setSort */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDrafts", function() { return getDrafts; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reset", function() { return reset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deleteDraft", function() { return deleteDraft; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setSort", function() { return setSort; });
/* harmony import */ var api_userstore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! api/userstore */ "./api/userstore.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView/store */ "./components/PipelineList/DraftPipelineView/store/index.ts");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/orderBy */ "../../node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_4__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var DRAFTS_KEY = 'hydratorDrafts';
var PROPERTY = 'property';
function getDrafts() {
  api_userstore__WEBPACK_IMPORTED_MODULE_0__["default"].get().subscribe(function (res) {
    var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__["getCurrentNamespace"])();
    var draftsObj = Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(res, PROPERTY, DRAFTS_KEY, namespace) || {};
    var drafts = [];
    Object.keys(draftsObj).forEach(function (id) {
      drafts.push(draftsObj[id]);
    });
    drafts = lodash_orderBy__WEBPACK_IMPORTED_MODULE_4___default()(drafts, [function (draft) {
      return draft.name.toLowerCase();
    }], ['asc']);
    components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_3__["default"].dispatch({
      type: components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_3__["Actions"].setDrafts,
      payload: {
        list: drafts
      }
    });
  });
}
function reset() {
  components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_3__["default"].dispatch({
    type: components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_3__["Actions"].reset
  });
}
function deleteDraft(draft) {
  var draftId = draft.__ui__.draftId;
  api_userstore__WEBPACK_IMPORTED_MODULE_0__["default"].get().subscribe(function (res) {
    var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__["getCurrentNamespace"])();
    var draftObj = Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(res, PROPERTY, DRAFTS_KEY, namespace, draftId);

    if (draftObj) {
      delete res.property[DRAFTS_KEY][namespace][draftId];
      api_userstore__WEBPACK_IMPORTED_MODULE_0__["default"].set(null, res.property).subscribe(getDrafts);
    }
  });
}
function setSort(columnName) {
  var state = components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_3__["default"].getState().drafts;
  var currentColumn = state.sortColumn;
  var currentSortOrder = state.sortOrder;
  var sortOrder = components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_3__["SORT_ORDER"].asc;

  if (currentColumn === columnName && currentSortOrder === components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_3__["SORT_ORDER"].asc) {
    sortOrder = components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_3__["SORT_ORDER"].desc;
  }

  var orderColumnFunction;

  switch (columnName) {
    case 'name':
      orderColumnFunction = function orderColumnFunction(draft) {
        return draft.name;
      };

      break;

    case 'type':
      orderColumnFunction = function orderColumnFunction(draft) {
        return draft.artifact.name;
      };

      break;

    case 'lastSaved':
      orderColumnFunction = function orderColumnFunction(draft) {
        return draft.__ui__.lastSaved;
      };

      break;
  }

  var drafts = lodash_orderBy__WEBPACK_IMPORTED_MODULE_4___default()(state.list, [orderColumnFunction], [sortOrder]);
  components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_3__["default"].dispatch({
    type: components_PipelineList_DraftPipelineView_store__WEBPACK_IMPORTED_MODULE_3__["Actions"].setSort,
    payload: {
      sortColumn: columnName,
      sortOrder: sortOrder,
      list: drafts
    }
  });
}

/***/ }),

/***/ "./components/PipelineList/DraftPipelineView/store/index.ts":
/*!******************************************************************!*\
  !*** ./components/PipelineList/DraftPipelineView/store/index.ts ***!
  \******************************************************************/
/*! exports provided: default, Actions, SORT_ORDER */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Actions", function() { return Actions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SORT_ORDER", function() { return SORT_ORDER; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
    }

    return t;
  };

  return __assign.apply(this, arguments);
};



var SORT_ORDER;

(function (SORT_ORDER) {
  SORT_ORDER["asc"] = "asc";
  SORT_ORDER["desc"] = "desc";
})(SORT_ORDER || (SORT_ORDER = {}));

var Actions = {
  setDrafts: 'SET_PIPELINE_DRAFTS',
  setSort: 'SET_PIPELINE_DRAFTS_SORT',
  setPage: 'SET_PIPELINE_DRAFTS_PAGE',
  reset: 'DRAFTS_RESET'
};
var defaultInitialState = {
  list: [],
  sortColumn: 'name',
  sortOrder: SORT_ORDER.asc,
  currentPage: 1,
  pageLimit: 25
};

var drafts = function drafts(state, action) {
  if (state === void 0) {
    state = defaultInitialState;
  }

  switch (action.type) {
    case Actions.setDrafts:
      return __assign(__assign({}, state), {
        list: action.payload.list,
        currentPage: 1
      });

    case Actions.setSort:
      return __assign(__assign({}, state), {
        sortColumn: action.payload.sortColumn,
        sortOrder: action.payload.sortOrder,
        list: action.payload.list,
        currentPage: 1
      });

    case Actions.setPage:
      return __assign(__assign({}, state), {
        currentPage: action.payload.currentPage
      });

    case Actions.reset:
      return defaultInitialState;

    default:
      return state;
  }
};

var Store = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  drafts: drafts
}), {
  drafts: defaultInitialState
}, Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["composeEnhancers"])('PipelineDraftsEnhancers')());
/* harmony default export */ __webpack_exports__["default"] = (Store);


/***/ }),

/***/ "./components/PipelineList/EmptyList/EmptyList.scss":
/*!**********************************************************!*\
  !*** ./components/PipelineList/EmptyList/EmptyList.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./EmptyList.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/EmptyList/EmptyList.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PipelineList/EmptyList/index.tsx":
/*!*****************************************************!*\
  !*** ./components/PipelineList/EmptyList/index.tsx ***!
  \*****************************************************/
/*! exports provided: VIEW_TYPES, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VIEW_TYPES", function() { return VIEW_TYPES; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var services_PipelineErrorFactory__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/PipelineErrorFactory */ "./services/PipelineErrorFactory.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var components_Alert__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/Alert */ "./components/Alert/index.js");
/* harmony import */ var _EmptyList_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./EmptyList.scss */ "./components/PipelineList/EmptyList/EmptyList.scss");
/* harmony import */ var _EmptyList_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_EmptyList_scss__WEBPACK_IMPORTED_MODULE_9__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
    }

    return t;
  };

  return __assign.apply(this, arguments);
};











var PREFIX = 'features.PipelineList.EmptyList';
var PIPELINE_STUDIO_STATE = 'hydrator.create';
var VIEW_TYPES;

(function (VIEW_TYPES) {
  VIEW_TYPES["deployed"] = "DEPLOYED";
  VIEW_TYPES["draft"] = "DRAFT";
})(VIEW_TYPES || (VIEW_TYPES = {}));

var EmptyList =
/** @class */
function (_super) {
  __extends(EmptyList, _super);

  function EmptyList() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.state = {
      error: null
    };

    _this.getPipelineParams = function () {
      return {
        namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__["getCurrentNamespace"])(),
        artifactType: services_global_constants__WEBPACK_IMPORTED_MODULE_2__["GLOBALS"].etlDataPipeline
      };
    };

    _this.onError = function (error) {
      _this.setState({
        error: error
      });
    };

    _this.importHandler = function (event) {
      if (!Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(event, 'target', 'files', 0)) {
        return;
      }

      var resourceCenterId = uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()();
      var pipelineImportLink = window.getHydratorUrl({
        stateName: PIPELINE_STUDIO_STATE,
        stateParams: __assign(__assign({}, _this.getPipelineParams()), {
          resourceCenterId: resourceCenterId
        })
      });
      var uploadedFile = event.target.files[0];

      if (uploadedFile.type !== 'application/json') {
        _this.onError(i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate(PREFIX + ".nonJSONError"));

        return;
      }

      var reader = new FileReader();
      reader.readAsText(uploadedFile, 'UTF-8');

      reader.onload = function (evt) {
        if (typeof evt.target.result !== 'string') {
          return;
        }

        var fileDataString = evt.target.result;
        var error = Object(services_PipelineErrorFactory__WEBPACK_IMPORTED_MODULE_3__["validateImportJSON"])(fileDataString);

        if (error) {
          _this.onError(error);

          return;
        }

        _this.onError(null);

        window.localStorage.setItem(resourceCenterId, fileDataString);
        window.location.href = pipelineImportLink;
      };
    };

    return _this;
  }

  EmptyList.prototype.render = function () {
    var pipelineCreateLink = window.getHydratorUrl({
      stateName: PIPELINE_STUDIO_STATE,
      stateParams: this.getPipelineParams()
    });
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "pipeline-list-empty-container"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Alert__WEBPACK_IMPORTED_MODULE_8__["default"], {
      message: this.state.error,
      showAlert: this.state.error && this.state.error.length > 0,
      type: "error"
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "message-container"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h3", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate(PREFIX + ".Message." + this.props.type)), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("hr", null), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "call-to-actions"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "subheading"
    }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate(PREFIX + ".actionTitle")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "action-row"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("a", {
      href: pipelineCreateLink,
      className: "action-cta"
    }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate(PREFIX + ".create")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
      className: "message"
    }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate(PREFIX + ".aPipeline"))), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
      className: "action-row"
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](reactstrap__WEBPACK_IMPORTED_MODULE_4__["Label"], {
      "for": "import-pipeline",
      className: "action-cta"
    }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate(PREFIX + ".import"), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](reactstrap__WEBPACK_IMPORTED_MODULE_4__["Input"], {
      type: "file",
      accept: ".json",
      id: "import-pipeline",
      onChange: this.importHandler
    })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
      className: "message"
    }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate(PREFIX + ".aPipeline"))))));
  };

  return EmptyList;
}(react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"]);

/* harmony default export */ __webpack_exports__["default"] = (EmptyList);

/***/ }),

/***/ "./components/PipelineList/PaginationView/Pagination.scss":
/*!****************************************************************!*\
  !*** ./components/PipelineList/PaginationView/Pagination.scss ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./Pagination.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/PaginationView/Pagination.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PipelineList/PaginationView/index.tsx":
/*!**********************************************************!*\
  !*** ./components/PipelineList/PaginationView/index.tsx ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_PaginationStepper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PaginationStepper */ "./components/PaginationStepper/index.tsx");
/* harmony import */ var _Pagination_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Pagination.scss */ "./components/PipelineList/PaginationView/Pagination.scss");
/* harmony import */ var _Pagination_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Pagination_scss__WEBPACK_IMPORTED_MODULE_2__);
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var PaginationView = function PaginationView(_a) {
  var setPage = _a.setPage,
      currentPage = _a.currentPage,
      numPipelines = _a.numPipelines,
      pageLimit = _a.pageLimit,
      _b = _a.shouldDisplay,
      shouldDisplay = _b === void 0 ? true : _b;
  var numPages = Math.ceil(numPipelines / pageLimit);

  if (!shouldDisplay || numPages <= 1) {
    return null;
  }

  var prevDisabled = currentPage === 1;
  var nextDisabled = currentPage === numPages;

  function handleNext() {
    if (nextDisabled) {
      return;
    }

    setPage(currentPage + 1);
  }

  function handlePrev() {
    if (prevDisabled) {
      return;
    }

    setPage(currentPage - 1);
  }

  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: "pagination-container float-right"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_PaginationStepper__WEBPACK_IMPORTED_MODULE_1__["default"], {
    onNext: handleNext,
    onPrev: handlePrev,
    nextDisabled: nextDisabled,
    prevDisabled: prevDisabled
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (PaginationView);

/***/ }),

/***/ "./components/PipelineList/PipelineList.scss":
/*!***************************************************!*\
  !*** ./components/PipelineList/PipelineList.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./PipelineList.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PipelineList/PipelineList.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PipelineList/SortableHeaderView/index.tsx":
/*!**************************************************************!*\
  !*** ./components/PipelineList/SortableHeaderView/index.tsx ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView/store */ "./components/PipelineList/DeployedPipelineView/store/index.ts");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PREFIX = 'features.PipelineList';

var SortableHeaderView = function SortableHeaderView(_a) {
  var sortColumn = _a.sortColumn,
      sortOrder = _a.sortOrder,
      columnName = _a.columnName,
      disabled = _a.disabled,
      setSort = _a.setSort;

  function handleClick() {
    if (disabled) {
      return;
    }

    setSort(columnName);
  }

  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("strong", {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()({
      sortable: !disabled
    }),
    onClick: handleClick
  }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate(PREFIX + "." + columnName), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_If__WEBPACK_IMPORTED_MODULE_2__["default"], {
    condition: sortColumn === columnName
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
    className: "fa fa-lg"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
    name: sortOrder === components_PipelineList_DeployedPipelineView_store__WEBPACK_IMPORTED_MODULE_1__["SORT_ORDER"].asc ? 'icon-caret-down' : 'icon-caret-up'
  }))));
};

/* harmony default export */ __webpack_exports__["default"] = (SortableHeaderView);

/***/ }),

/***/ "./components/PipelineList/index.tsx":
/*!*******************************************!*\
  !*** ./components/PipelineList/index.tsx ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_PipelineList_DeployedPipelineView__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/PipelineList/DeployedPipelineView */ "./components/PipelineList/DeployedPipelineView/index.tsx");
/* harmony import */ var components_ResourceCenterButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/ResourceCenterButton */ "./components/ResourceCenterButton/index.js");
/* harmony import */ var components_PipelineList_DraftPipelineView__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/PipelineList/DraftPipelineView */ "./components/PipelineList/DraftPipelineView/index.tsx");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-helmet */ "../../node_modules/react-helmet/lib/Helmet.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _PipelineList_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./PipelineList.scss */ "./components/PipelineList/PipelineList.scss");
/* harmony import */ var _PipelineList_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_PipelineList_scss__WEBPACK_IMPORTED_MODULE_9__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */










var PREFIX = 'features.PipelineList';

var PipelineList = function PipelineList() {
  var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__["getCurrentNamespace"])();
  var basepath = "/ns/" + namespace + "/pipelines";
  var productName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_7__["Theme"].productName;
  var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_7__["Theme"].featureNames.pipelines;
  var pageTitle = productName + " | " + featureName;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "pipeline-list-view"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_helmet__WEBPACK_IMPORTED_MODULE_6___default.a, {
    title: pageTitle
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h4", {
    className: "view-header"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["NavLink"], {
    exact: true,
    to: basepath,
    className: "option",
    activeClassName: "active"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate(PREFIX + ".deployed")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "separator"
  }, "|"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["NavLink"], {
    exact: true,
    to: basepath + "/drafts",
    className: "option",
    activeClassName: "active"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_8___default.a.translate(PREFIX + ".draft"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_ResourceCenterButton__WEBPACK_IMPORTED_MODULE_2__["default"], null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Switch"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
    exact: true,
    path: "/ns/:namespace/pipelines",
    component: components_PipelineList_DeployedPipelineView__WEBPACK_IMPORTED_MODULE_1__["default"]
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
    exact: true,
    path: "/ns/:namespace/pipelines/drafts",
    component: components_PipelineList_DraftPipelineView__WEBPACK_IMPORTED_MODULE_3__["default"]
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (PipelineList);

/***/ }),

/***/ "./components/ResourceCenterButton/ResourceCenterButton.scss":
/*!*******************************************************************!*\
  !*** ./components/ResourceCenterButton/ResourceCenterButton.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./ResourceCenterButton.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/ResourceCenterButton/ResourceCenterButton.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/ResourceCenterButton/index.js":
/*!**************************************************!*\
  !*** ./components/ResourceCenterButton/index.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ResourceCenterButton; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_PlusButtonStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/PlusButtonStore */ "./services/PlusButtonStore.js");
/* harmony import */ var components_PlusButtonModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/PlusButtonModal */ "./components/PlusButtonModal/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var event_emitter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! event-emitter */ "../../node_modules/event-emitter/index.js");
/* harmony import */ var event_emitter__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(event_emitter__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var services_global_events__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/global-events */ "./services/global-events.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








__webpack_require__(/*! ./ResourceCenterButton.scss */ "./components/ResourceCenterButton/ResourceCenterButton.scss");
/**
 * This module is used solely for angular side. This includes styling and stripping of context
 * information used by the PlusButton. We may nee to consider using one component for both angular
 * and react as it seems redundant.
 */


var ResourceCenterButton =
/*#__PURE__*/
function (_Component) {
  _inherits(ResourceCenterButton, _Component);

  function ResourceCenterButton(props) {
    var _this;

    _classCallCheck(this, ResourceCenterButton);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ResourceCenterButton).call(this, props));

    _defineProperty(_assertThisInitialized(_this), "eventemitter", event_emitter__WEBPACK_IMPORTED_MODULE_5___default()(event_emitter__WEBPACK_IMPORTED_MODULE_5___default.a));

    _defineProperty(_assertThisInitialized(_this), "openResourceCenter", function () {
      _this.setState({
        showResourceCenter: true
      });
    });

    _defineProperty(_assertThisInitialized(_this), "closeResourceCenter", function () {
      _this.setState({
        showResourceCenter: false
      });
    });

    _this.state = {
      showResourceCenter: false
    };

    _this.eventemitter.on(services_global_events__WEBPACK_IMPORTED_MODULE_6__["default"].OPENRESOURCECENTER, _this.openResourceCenter);

    _this.eventemitter.on(services_global_events__WEBPACK_IMPORTED_MODULE_6__["default"].CLOSERESOURCECENTER, _this.closeResourceCenter);

    return _this;
  }

  _createClass(ResourceCenterButton, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      this.plusButtonSubscription = services_PlusButtonStore__WEBPACK_IMPORTED_MODULE_2__["default"].subscribe(function () {
        var modalState = services_PlusButtonStore__WEBPACK_IMPORTED_MODULE_2__["default"].getState().modalState;

        _this2.setState({
          showResourceCenter: modalState
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.plusButtonSubscription) {
        this.plusButtonSubscription();
      }

      this.eventemitter.off(services_global_events__WEBPACK_IMPORTED_MODULE_6__["default"].OPENRESOURCECENTER, this.openResourceCenter);
      this.eventemitter.off(services_global_events__WEBPACK_IMPORTED_MODULE_6__["default"].CLOSERESOURCECENTER, this.closeResourceCenter);
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()('cask-resourcecenter-button', this.props.className),
        onClick: this.openResourceCenter.bind(this)
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("img", {
        id: "resource-center-btn",
        className: "button-container",
        src: "/cdap_assets/img/plus_ico.svg"
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PlusButtonModal__WEBPACK_IMPORTED_MODULE_3__["default"], {
        isOpen: this.state.showResourceCenter,
        onCloseHandler: this.closeResourceCenter.bind(this),
        mode: "resourcecenter"
      }));
    }
  }]);

  return ResourceCenterButton;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


ResourceCenterButton.propTypes = {
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss":
/*!***********************************************************************!*\
  !*** ./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./SpotlightModal.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SpotlightSearch/SpotlightModal/SpotlightModalHeader.js":
/*!***************************************************************************!*\
  !*** ./components/SpotlightSearch/SpotlightModal/SpotlightModalHeader.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SpotlightModalHeader; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_Pagination_PaginationDropdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Pagination/PaginationDropdown */ "./components/Pagination/PaginationDropdown.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./SpotlightModal.scss */ "./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss");

var SpotlightModalHeader =
/*#__PURE__*/
function (_Component) {
  _inherits(SpotlightModalHeader, _Component);

  function SpotlightModalHeader(props) {
    var _this;

    _classCallCheck(this, SpotlightModalHeader);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(SpotlightModalHeader).call(this, props));
    _this.state = {
      isDropdownExpanded: false
    };
    _this.toggleExpansion = _this.toggleExpansion.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(SpotlightModalHeader, [{
    key: "toggleExpansion",
    value: function toggleExpansion() {
      this.setState({
        isDropdownExpanded: !this.state.isDropdownExpanded
      });
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_4__["ModalHeader"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "tag-title"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate('features.SpotlightSearch.SpotlightModal.headerTagResults', {
        tag: this.props.tag
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "close-section text-right"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "search-results-total"
      }, this.props.total === 1 ? i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate('features.SpotlightSearch.SpotlightModal.numResult', {
        total: this.props.total
      }) : i18n_react__WEBPACK_IMPORTED_MODULE_2___default.a.translate('features.SpotlightSearch.SpotlightModal.numResults', {
        total: this.props.total
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Pagination_PaginationDropdown__WEBPACK_IMPORTED_MODULE_3__["default"], {
        numberOfPages: this.props.numPages,
        currentPage: this.props.currentPage,
        onPageChange: this.props.handleSearch.bind(this)
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-times",
        onClick: this.props.toggle
      })));
    }
  }]);

  return SpotlightModalHeader;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


SpotlightModalHeader.propTypes = {
  toggle: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  handleSearch: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  currentPage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  tag: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  numPages: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  total: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number
};

/***/ }),

/***/ "./components/SpotlightSearch/SpotlightModal/index.js":
/*!************************************************************!*\
  !*** ./components/SpotlightSearch/SpotlightModal/index.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SpotlightModal; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_search__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/search */ "./api/search.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_metadata_parser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/metadata-parser */ "./services/metadata-parser/index.js");
/* harmony import */ var services_entity_type_api_converter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/entity-type-api-converter */ "./services/entity-type-api-converter/index.js");
/* harmony import */ var components_NavLinkWrapper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/NavLinkWrapper */ "./components/NavLinkWrapper/index.js");
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! mousetrap */ "../../node_modules/mousetrap/mousetrap.js");
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(mousetrap__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var components_Pagination__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/Pagination */ "./components/Pagination/index.js");
/* harmony import */ var components_SpotlightSearch_SpotlightModal_SpotlightModalHeader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/SpotlightSearch/SpotlightModal/SpotlightModalHeader */ "./components/SpotlightSearch/SpotlightModal/SpotlightModalHeader.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

















__webpack_require__(/*! ./SpotlightModal.scss */ "./components/SpotlightSearch/SpotlightModal/SpotlightModal.scss");

var PREFIX = 'features.SpotlightSearch.SpotlightModal';
var PAGE_SIZE = 10;

var SpotlightModal =
/*#__PURE__*/
function (_Component) {
  _inherits(SpotlightModal, _Component);

  function SpotlightModal() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SpotlightModal);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SpotlightModal)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      searchResults: {
        results: []
      },
      currentPage: 1,
      numPages: 1,
      focusIndex: 0,
      isPaginationExpanded: false
    });

    _defineProperty(_assertThisInitialized(_this), "handlePaginationToggle", function () {
      _this.setState({
        isPaginationExpanded: !_this.state.isPaginationExpanded
      });
    });

    return _this;
  }

  _createClass(SpotlightModal, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_7___default.a.bind('up', this.handleUpDownArrow.bind(this, 'UP'));
      mousetrap__WEBPACK_IMPORTED_MODULE_7___default.a.bind('down', this.handleUpDownArrow.bind(this, 'DOWN'));
      mousetrap__WEBPACK_IMPORTED_MODULE_7___default.a.bind('enter', this.handleEnter.bind(this));
      this.handleSearch(1);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_7___default.a.unbind('up');
      mousetrap__WEBPACK_IMPORTED_MODULE_7___default.a.unbind('down');
      mousetrap__WEBPACK_IMPORTED_MODULE_7___default.a.unbind('enter');
    }
  }, {
    key: "handleUpDownArrow",
    value: function handleUpDownArrow(direction) {
      if (direction === 'UP') {
        var focusIndex = this.state.focusIndex === 0 ? 0 : this.state.focusIndex - 1;
        this.setState({
          focusIndex: focusIndex
        });
      } else if (direction === 'DOWN') {
        var totalResults = this.state.searchResults.results.length;

        var _focusIndex = this.state.focusIndex === totalResults - 1 ? this.state.focusIndex : this.state.focusIndex + 1;

        this.setState({
          focusIndex: _focusIndex
        });
      }
    }
  }, {
    key: "handleEnter",
    value: function handleEnter() {
      var entity = Object(services_metadata_parser__WEBPACK_IMPORTED_MODULE_4__["parseMetadata"])(this.state.searchResults.results[this.state.focusIndex]); // Redirect to entity once we have entity detail page
      // Right now console logging entity for identification purposes

      console.log('ENTER on:', entity.id);
    }
  }, {
    key: "handleSearch",
    value: function handleSearch(page) {
      var _this2 = this;

      if (page === 0 || page > this.state.numPages) {
        return;
      }

      var offset = (page - 1) * PAGE_SIZE;
      var query = 'tags:' + this.props.tag;
      var target = this.props.target ? this.props.target : []; // removed sort, cannot search and sort at the same time

      api_search__WEBPACK_IMPORTED_MODULE_2__["MySearchApi"].search({
        namespace: services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["default"].getState().selectedNamespace,
        query: query,
        target: target,
        limit: PAGE_SIZE,
        offset: offset,
        responseFormat: 'v6'
      }).subscribe(function (res) {
        _this2.setState({
          searchResults: res,
          currentPage: page,
          numPages: Math.ceil(res.totalResults / PAGE_SIZE),
          focusIndex: 0
        });
      });
    }
  }, {
    key: "renderBodyContent",
    value: function renderBodyContent() {
      var _this3 = this;

      if (!this.state.searchResults.results.length) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "text-center no-search-results"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate("".concat(PREFIX, ".noResults"), {
          tag: this.props.tag
        }));
      }

      var currentNamespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["default"].getState().selectedNamespace;
      var searchResultsToBeRendered = this.state.searchResults.results.map(services_metadata_parser__WEBPACK_IMPORTED_MODULE_4__["parseMetadata"]).map(function (entity, index) {
        var entityTypeLabel = Object(services_entity_type_api_converter__WEBPACK_IMPORTED_MODULE_5__["convertEntityTypeToApi"])(entity.type);
        var entityUrl = "/ns/".concat(currentNamespace, "/").concat(entityTypeLabel, "/").concat(entity.id);

        if (entityTypeLabel === 'apps') {
          entityUrl = "/pipelines/ns/".concat(currentNamespace, "/view/").concat(entity.id);
        }

        if (_this3.props.isNativeLink && entityTypeLabel !== 'apps') {
          entityUrl = "/cdap".concat(entityUrl);
        } // (CDAP-16788) We have removed app detailed view. So if it is not a pipeline don't
        // navigate anywhere.


        if ([services_global_constants__WEBPACK_IMPORTED_MODULE_13__["GLOBALS"].etlDataPipeline, services_global_constants__WEBPACK_IMPORTED_MODULE_13__["GLOBALS"].etlDataStreams].indexOf(Object(services_metadata_parser__WEBPACK_IMPORTED_MODULE_4__["getType"])(entity)) === -1) {
          entityUrl = '';
        }

        var description = entity.metadata.metadata.properties.find(function (property) {
          return property.name === 'description';
        });
        description = description ? description.value : null;
        var entityTags = entity.metadata.metadata.tags || [];
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_NavLinkWrapper__WEBPACK_IMPORTED_MODULE_6__["default"], {
          key: entity.id,
          to: entityUrl,
          isNativeLink: _this3.props.isNativeLink,
          className: "search-results-item-link"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          key: uuid_v4__WEBPACK_IMPORTED_MODULE_9___default()(),
          className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('row search-results-item', {
            active: index === _this3.state.focusIndex
          })
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_14__["Col"], {
          xs: "6"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "entity-title"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "entity-icon"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: entity.icon
        })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "entity-name"
        }, entity.id)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "entity-description"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, description))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_14__["Col"], {
          xs: "6"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "entity-tags-container text-right"
        }, entityTags.map(function (tag) {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_14__["Badge"], {
            key: uuid_v4__WEBPACK_IMPORTED_MODULE_9___default()()
          }, tag.name);
        })))));
      });
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, searchResultsToBeRendered);
    }
  }, {
    key: "render",
    value: function render() {
      var results = Object(services_helpers__WEBPACK_IMPORTED_MODULE_15__["objectQuery"])(this.state.searchResults, 'results') || [];
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_14__["Modal"], {
        isOpen: this.props.isOpen,
        toggle: this.props.toggle,
        className: "search-results-modal",
        size: "lg",
        backdrop: "static"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SpotlightSearch_SpotlightModal_SpotlightModalHeader__WEBPACK_IMPORTED_MODULE_11__["default"], {
        toggle: this.props.toggle,
        handleSearch: this.handleSearch.bind(this),
        currentPage: this.state.currentPage,
        query: this.props.query,
        tag: this.props.tag,
        numPages: this.state.numPages,
        total: results.length
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_14__["ModalBody"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "search-results-container"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Pagination__WEBPACK_IMPORTED_MODULE_10__["default"], {
        setCurrentPage: this.handleSearch.bind(this),
        currentPage: this.state.currentPage
      }, this.renderBodyContent()))));
    }
  }]);

  return SpotlightModal;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(SpotlightModal, "propTypes", {
  query: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  tag: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  target: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.array,
  isOpen: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  toggle: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  isNativeLink: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});

_defineProperty(SpotlightModal, "defaultProps", {
  isNativeLink: false
});



/***/ }),

/***/ "./components/Tags/Tag/Tag.scss":
/*!**************************************!*\
  !*** ./components/Tags/Tag/Tag.scss ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./Tag.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Tags/Tag/Tag.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Tags/Tag/index.js":
/*!**************************************!*\
  !*** ./components/Tags/Tag/index.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Tag; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_SpotlightSearch_SpotlightModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/SpotlightSearch/SpotlightModal */ "./components/SpotlightSearch/SpotlightModal/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */







__webpack_require__(/*! ./Tag.scss */ "./components/Tags/Tag/Tag.scss");

var Tag =
/*#__PURE__*/
function (_Component) {
  _inherits(Tag, _Component);

  function Tag() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, Tag);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(Tag)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      searchModalOpen: false
    });

    _defineProperty(_assertThisInitialized(_this), "toggleSearchModal", function (e) {
      if (_this.props.preventDefault) {
        e.preventDefault();
      }

      _this.setState({
        searchModalOpen: !_this.state.searchModalOpen
      });
    });

    return _this;
  }

  _createClass(Tag, [{
    key: "render",
    value: function render() {
      var tagClasses = classnames__WEBPACK_IMPORTED_MODULE_3___default()('btn btn-secondary tag-btn', {
        'system-tag': this.props.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_5__["SCOPES"].SYSTEM,
        'user-tag': this.props.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_5__["SCOPES"].USER
      });
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: tagClasses
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        onClick: this.toggleSearchModal,
        className: "tag-content"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.props.value), this.props.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_5__["SCOPES"].USER && !this.props.viewOnly ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-close",
        onClick: this.props.onDelete
      }) : null), this.state.searchModalOpen ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SpotlightSearch_SpotlightModal__WEBPACK_IMPORTED_MODULE_2__["default"], {
        tag: this.props.value,
        target: ['application', 'dataset'],
        isOpen: this.state.searchModalOpen,
        toggle: this.toggleSearchModal,
        isNativeLink: this.props.isNativeLink
      }) : null);
    }
  }]);

  return Tag;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(Tag, "propTypes", {
  value: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  scope: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onDelete: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  isNativeLink: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  viewOnly: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  preventDefault: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});

_defineProperty(Tag, "defaultProps", {
  isNativeLink: false,
  viewOnly: false
});



/***/ }),

/***/ "./components/Tags/Tags.scss":
/*!***********************************!*\
  !*** ./components/Tags/Tags.scss ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Tags.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Tags/Tags.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Tags/index.js":
/*!**********************************!*\
  !*** ./components/Tags/index.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Tags; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_metadata__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/metadata */ "./api/metadata.js");
/* harmony import */ var lodash_isObject__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/isObject */ "../../node_modules/lodash/isObject.js");
/* harmony import */ var lodash_isObject__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_isObject__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! mousetrap */ "../../node_modules/mousetrap/mousetrap.js");
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(mousetrap__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_entity_type_api_converter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/entity-type-api-converter */ "./services/entity-type-api-converter/index.js");
/* harmony import */ var components_Tags_Tag__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Tags/Tag */ "./components/Tags/Tag/index.js");
/* harmony import */ var components_Alert__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/Alert */ "./components/Alert/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */












__webpack_require__(/*! ./Tags.scss */ "./components/Tags/Tags.scss");



var PREFIX = 'features.Tags';

var Tags =
/*#__PURE__*/
function (_Component) {
  _inherits(Tags, _Component);

  function Tags() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, Tags);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(Tags)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      systemTags: [],
      userTags: [],
      showInputField: false,
      loading: false,
      currentInputTag: '',
      showAllTagsLabel: false,
      showAllTagsPopover: false
    });

    _defineProperty(_assertThisInitialized(_this), "params", {
      namespace: services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__["default"].getState().selectedNamespace,
      entityType: Object(services_entity_type_api_converter__WEBPACK_IMPORTED_MODULE_6__["convertEntityTypeToApi"])(_this.props.entity.type),
      entityId: _this.props.entity.id
    });

    _defineProperty(_assertThisInitialized(_this), "subscriptions", []);

    _defineProperty(_assertThisInitialized(_this), "getTags", function () {
      _this.setState({
        loading: false
      });

      var tagsSubscription = api_metadata__WEBPACK_IMPORTED_MODULE_2__["MyMetadataApi"].getTags(_this.params).subscribe(function (res) {
        _this.setState({
          systemTags: res.tags.filter(function (tag) {
            return tag.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_12__["SCOPES"].SYSTEM;
          }).map(function (tag) {
            return tag.name;
          }).sort(),
          userTags: res.tags.filter(function (tag) {
            return tag.scope === services_global_constants__WEBPACK_IMPORTED_MODULE_12__["SCOPES"].USER;
          }).map(function (tag) {
            return tag.name;
          }).sort(),
          loading: false
        }, _this.isTagsOverflowing);

        if (_this.state.showInputField) {
          _this.toggleInputField();
        }
      }, function (err) {
        _this.setState({
          error: lodash_isObject__WEBPACK_IMPORTED_MODULE_3___default()(err) ? err.response : err,
          loading: false
        });
      });

      _this.subscriptions.push(tagsSubscription);
    });

    _defineProperty(_assertThisInitialized(_this), "toggleInputField", function () {
      if (!_this.state.loading) {
        if (_this.state.showInputField) {
          _this.setState({
            currentInputTag: '',
            error: false
          });
        }

        _this.setState({
          showInputField: !_this.state.showInputField
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "closeInputFieldIfEmpty", function () {
      if (_this.state.currentInputTag === '' && _this.state.showInputField) {
        _this.setState({
          showInputField: false,
          error: false
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "onInputTagChange", function (e) {
      _this.setState({
        currentInputTag: e.target.value
      });
    });

    _defineProperty(_assertThisInitialized(_this), "addTag", function () {
      if (_this.state.currentInputTag !== '') {
        _this.setState({
          loading: true
        });

        var addTagsSubscription = api_metadata__WEBPACK_IMPORTED_MODULE_2__["MyMetadataApi"].addTags(_this.params, [_this.state.currentInputTag]).subscribe(function () {
          _this.getTags();
        }, function (err) {
          _this.setState({
            error: lodash_isObject__WEBPACK_IMPORTED_MODULE_3___default()(err) ? err.response : err,
            loading: false
          });
        });

        _this.subscriptions.push(addTagsSubscription);
      }
    });

    _defineProperty(_assertThisInitialized(_this), "isTagsOverflowing", function () {
      if (_this.props.displayAll) {
        return;
      }

      var tagsListElem = document.getElementsByClassName('tags-list')[0];

      if (!tagsListElem) {
        return;
      }

      var tagsAreOverflowing = tagsListElem.clientWidth < tagsListElem.scrollWidth;

      if (tagsAreOverflowing && _this.state.showAllTagsLabel || !tagsAreOverflowing && !_this.state.showAllTagsLabel) {
        return;
      }

      _this.setState({
        showAllTagsLabel: tagsAreOverflowing
      });
    });

    _defineProperty(_assertThisInitialized(_this), "toggleAllTagsPopover", function () {
      _this.setState({
        showAllTagsPopover: !_this.state.showAllTagsPopover
      });
    });

    return _this;
  }

  _createClass(Tags, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_4___default.a.bind('return', this.addTag);
      mousetrap__WEBPACK_IMPORTED_MODULE_4___default.a.bind('escape', this.closeInputFieldIfEmpty);
      this.getTags();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_4___default.a.unbind('return');
      mousetrap__WEBPACK_IMPORTED_MODULE_4___default.a.unbind('escape');
      this.subscriptions.map(function (subscriber) {
        return subscriber.unsubscribe();
      });
    }
  }, {
    key: "deleteTag",
    value: function deleteTag(tag, event) {
      var _this2 = this;

      event.preventDefault();
      event.stopPropagation();
      event.nativeEvent.stopImmediatePropagation();
      var params = Object.assign({}, this.params, {
        key: tag
      });
      var deleteTagsSubscription = api_metadata__WEBPACK_IMPORTED_MODULE_2__["MyMetadataApi"].deleteTags(params).subscribe(function () {
        _this2.getTags();
      }, function (err) {
        _this2.setState({
          error: lodash_isObject__WEBPACK_IMPORTED_MODULE_3___default()(err) ? err.response : err
        });
      });
      this.subscriptions.push(deleteTagsSubscription);
    }
  }, {
    key: "renderSystemTags",
    value: function renderSystemTags() {
      var _this3 = this;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.state.systemTags.map(function (tag) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Tags_Tag__WEBPACK_IMPORTED_MODULE_7__["default"], {
          value: tag,
          scope: services_global_constants__WEBPACK_IMPORTED_MODULE_12__["SCOPES"].SYSTEM,
          isNativeLink: _this3.props.isNativeLink,
          preventDefault: _this3.props.preventDefault,
          key: tag
        });
      }));
    }
  }, {
    key: "renderUserTags",
    value: function renderUserTags() {
      var _this4 = this;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.state.userTags.map(function (tag) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Tags_Tag__WEBPACK_IMPORTED_MODULE_7__["default"], {
          value: tag,
          onDelete: _this4.deleteTag.bind(_this4, tag),
          scope: services_global_constants__WEBPACK_IMPORTED_MODULE_12__["SCOPES"].USER,
          isNativeLink: _this4.props.isNativeLink,
          viewOnly: _this4.props.viewOnly,
          preventDefault: _this4.props.preventDefault,
          key: tag
        });
      }));
    }
  }, {
    key: "renderTagsPopover",
    value: function renderTagsPopover() {
      var labelElem = function labelElem() {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "all-tags-label"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".allTags")));
      };

      var tagsCount = this.state.systemTags.length + this.state.userTags.length;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_10__["default"], {
        target: labelElem,
        className: "tags-popover",
        placement: "bottom",
        bubbleEvent: false,
        enableInteractionInPopover: true,
        showPopover: this.state.showAllTagsPopover
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "tags-popover-header"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".labelWithCount"), {
        count: tagsCount
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_9__["default"], {
        name: "icon-close",
        onClick: this.toggleAllTagsPopover
      })), this.renderSystemTags(), this.renderUserTags());
    }
  }, {
    key: "renderInputField",
    value: function renderInputField() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("input", {
        type: "text",
        className: "tag-input form-control mousetrap",
        value: this.state.currentInputTag,
        onChange: this.onInputTagChange,
        onBlur: this.toggleInputField,
        autoFocus: true,
        disabled: this.state.loading ? 'disabled' : null,
        "data-testid": "tag-input"
      }));
    }
  }, {
    key: "renderPlusButton",
    value: function renderPlusButton() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "btn btn-primary plus-button-container",
        onClick: this.toggleInputField,
        "data-testid": "tag-plus-button"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_9__["default"], {
        name: "icon-plus",
        className: "text-white"
      }));
    }
  }, {
    key: "renderAddTag",
    value: function renderAddTag() {
      if (this.props.viewOnly) {
        return null;
      }

      return this.state.showInputField ? this.renderInputField() : this.renderPlusButton();
    }
  }, {
    key: "render",
    value: function render() {
      var _this5 = this;

      var tagsCount = this.state.systemTags.length + this.state.userTags.length;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "tags-holder"
      }, this.props.showCountLabel ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, "".concat(i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".labelWithCount"), {
        count: tagsCount
      }), ":")) : null, !tagsCount && !this.state.loading ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".notags"))) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "tags-list"
      }, this.renderSystemTags(), this.renderUserTags()), this.state.showAllTagsLabel ? this.renderTagsPopover() : null, this.renderAddTag(), this.state.loading ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_9__["default"], {
        name: "icon-spinner",
        className: "fa-lg fa-spin",
        "data-testid": "loading-icon"
      }) : null, this.state.error ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Alert__WEBPACK_IMPORTED_MODULE_8__["default"], {
        message: this.state.error,
        type: "error",
        showAlert: true,
        onClose: function onClose() {
          return _this5.setState({
            error: false
          });
        }
      }) : null);
    }
  }]);

  return Tags;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(Tags, "defaultProps", {
  showCountLabel: true,
  isNativeLink: false,
  viewOnly: false,
  displayAll: false,
  preventDefault: false
});

_defineProperty(Tags, "propTypes", {
  entity: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  showCountLabel: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  isNativeLink: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  viewOnly: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  displayAll: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  preventDefault: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});



/***/ }),

/***/ "./services/PipelineUtils/index.ts":
/*!*****************************************!*\
  !*** ./services/PipelineUtils/index.ts ***!
  \*****************************************/
/*! exports provided: duplicatePipeline, getPipelineConfig */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "duplicatePipeline", function() { return duplicatePipeline; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPipelineConfig", function() { return getPipelineConfig; });
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_pipeline__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! api/pipeline */ "./api/pipeline.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
    }

    return t;
  };

  return __assign.apply(this, arguments);
};




function duplicatePipeline(pipelineName, config) {
  var newName = getClonePipelineName(pipelineName);

  if (config) {
    setConfigAndNavigate(__assign(__assign({}, config), {
      name: newName
    }));
    return;
  }

  getPipelineConfig(pipelineName).subscribe(function (pipelineConfig) {
    setConfigAndNavigate(__assign(__assign({}, pipelineConfig), {
      name: newName
    }));
  });
}
function getPipelineConfig(pipelineName) {
  return rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"].create(function (observer) {
    var params = {
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_0__["getCurrentNamespace"])(),
      appId: pipelineName
    };
    api_pipeline__WEBPACK_IMPORTED_MODULE_1__["MyPipelineApi"].get(params).subscribe(function (res) {
      var pipelineConfig = {
        name: res.name,
        description: res.description,
        artifact: res.artifact,
        config: JSON.parse(res.configuration)
      };
      observer.next(pipelineConfig);
      observer.complete();
    });
  });
}

function setConfigAndNavigate(config) {
  window.localStorage.setItem(config.name, JSON.stringify(config));
  var hydratorLink = window.getHydratorUrl({
    stateName: 'hydrator.create',
    stateParams: {
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_0__["getCurrentNamespace"])(),
      cloneId: config.name,
      artifactType: config.artifact.name
    }
  });
  window.location.href = hydratorLink;
}

function getClonePipelineName(name) {
  var match = name.match(/(_v[\d]*)$/g);
  var version;
  var existingSuffix;

  if (Array.isArray(match)) {
    version = match.pop();
    existingSuffix = version;
    version = version.replace('_v', '');
    version = '_v' + ((!isNaN(parseInt(version, 10)) ? parseInt(version, 10) : 1) + 1);
  } else {
    version = '_v1';
  }

  return name.split(existingSuffix)[0] + version;
}

/***/ }),

/***/ "./services/StatusMapper.js":
/*!**********************************!*\
  !*** ./services/StatusMapper.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
var _statusMap;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
*/

var statusMap = (_statusMap = {}, _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].DEPLOYED, 'Deployed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUBMITTING, 'Submitting'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].RUNNING, 'Running'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUCCEEDED, 'Succeeded'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].FAILED, 'Failed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].REJECTED, 'Rejected'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].DRAFT, 'Draft'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STOPPED, 'Stopped'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].COMPLETED, 'Succeeded'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].KILLED, 'Stopped'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].KILLED_BY_TIMER, 'Succeeded'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].DEPLOY_FAILED, 'Failed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].RUN_FAILED, 'Failed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUSPENDED, 'Deployed'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SCHEDULED, 'Scheduled'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STARTING, 'Starting'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SCHEDULING, 'Scheduling'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STOPPING, 'Stopping'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUSPENDING, 'Suspending'), _defineProperty(_statusMap, services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].PENDING, 'Provisioning'), _statusMap);

function lookupDisplayStatus(systemStatus) {
  if (systemStatus in statusMap) {
    return statusMap[systemStatus];
  } else {
    return systemStatus;
  }
}

function getStatusIndicatorClass(displayStatus) {
  if (displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].RUNNING] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STARTING] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].PENDING]) {
    return 'status-blue';
  } else if (displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SUCCEEDED] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].SCHEDULING] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].STOPPING]) {
    return 'status-light-green';
  } else if (displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].FAILED] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].REJECTED]) {
    return 'status-light-red';
  } else {
    return 'status-light-grey';
  }
}

function getStatusIndicatorIcon(displayStatus) {
  if (displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].PENDING] || displayStatus === statusMap[services_global_constants__WEBPACK_IMPORTED_MODULE_0__["PROGRAM_STATUSES"].DRAFT]) {
    return 'icon-circle-o';
  }

  return 'icon-circle';
}

/* harmony default export */ __webpack_exports__["default"] = ({
  statusMap: statusMap,
  lookupDisplayStatus: lookupDisplayStatus,
  getStatusIndicatorClass: getStatusIndicatorClass,
  getStatusIndicatorIcon: getStatusIndicatorIcon
});

/***/ }),

/***/ "./services/entity-icon-map/index.js":
/*!*******************************************!*\
  !*** ./services/entity-icon-map/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var EntityIconMap = {
  'cdap-data-pipeline': 'icon-ETLBatch',
  'cdap-data-streams': 'icon-sparkstreaming',
  mapreduce: 'icon-mapreduce',
  service: 'icon-service',
  spark: 'icon-spark',
  worker: 'icon-worker',
  workflow: 'icon-workflow',
  application: 'icon-fist',
  artifact: 'icon-archive',
  dataset: 'icon-datasets',
  view: 'icon-streamview'
};
/* harmony default export */ __webpack_exports__["default"] = (EntityIconMap);

/***/ }),

/***/ "./services/entity-type-api-converter/index.js":
/*!*****************************************************!*\
  !*** ./services/entity-type-api-converter/index.js ***!
  \*****************************************************/
/*! exports provided: convertEntityTypeToApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convertEntityTypeToApi", function() { return convertEntityTypeToApi; });
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var apiEntityTypeConvert = {
  application: 'apps',
  dataset: 'datasets'
};
function convertEntityTypeToApi(entityType) {
  return apiEntityTypeConvert[entityType.toLowerCase()];
}

/***/ }),

/***/ "./services/metadata-parser/index.js":
/*!*******************************************!*\
  !*** ./services/metadata-parser/index.js ***!
  \*******************************************/
/*! exports provided: parseMetadata, getType, getCustomAppPipelineDatasetCounts */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseMetadata", function() { return parseMetadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getType", function() { return getType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCustomAppPipelineDatasetCounts", function() { return getCustomAppPipelineDatasetCounts; });
/* harmony import */ var services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/entity-icon-map */ "./services/entity-icon-map/index.js");
/* harmony import */ var lodash_intersection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash/intersection */ "../../node_modules/lodash/intersection.js");
/* harmony import */ var lodash_intersection__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_intersection__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/metadata-parser/EntityType */ "./services/metadata-parser/EntityType.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/*
 * Copyright © 2016-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var SYSTEM_SCOPE = 'SYSTEM';
function parseMetadata(entityObj) {
  var type = entityObj.entity.type;

  switch (type) {
    case services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].artifact:
      return createArtifactObj(entityObj);

    case services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].application:
      return createApplicationObj(entityObj);

    case services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].dataset:
      return createDatasetObj(entityObj);

    case services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].program:
      return createProgramObj(entityObj);
  }
}
function getType(entity) {
  if (entity.type === 'program') {
    return entity.programType.toLowerCase();
  }

  if (entity.type === 'dataset') {
    return 'dataset';
  } else if (entity.type !== 'application') {
    return entity.type;
  }

  if (entity.metadata.metadata.tags.find(function (tag) {
    return tag.name === services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline && tag.scope === SYSTEM_SCOPE;
  })) {
    return services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline;
  } else if (entity.metadata.metadata.tags.find(function (tag) {
    return tag.name === services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams && tag.scope === SYSTEM_SCOPE;
  })) {
    return services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams;
  } else {
    return entity.type;
  }
}
/**
 * TODO:
 * This function should be refactored. It should just return the entities count, and not care about the entity types.
 *
 * https://issues.cask.co/browse/CDAP-14639
 */

function getCustomAppPipelineDatasetCounts(entities) {
  var apps = entities.results.filter(function (entity) {
    return entityIsApp(entity);
  });
  var pipelineCount = apps.filter(function (entity) {
    return entityIsPipeline(entity);
  }).length;
  var customAppCount = apps.length - pipelineCount;
  var datasetCount = entities.results.length - apps.length;
  return {
    pipelineCount: pipelineCount,
    customAppCount: customAppCount,
    datasetCount: datasetCount
  };
}

function entityIsApp(entityObj) {
  return Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(entityObj, 'entity', 'type') === services_metadata_parser_EntityType__WEBPACK_IMPORTED_MODULE_2__["default"].application;
}

function entityIsPipeline(entityObj) {
  return lodash_intersection__WEBPACK_IMPORTED_MODULE_1___default()(services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlPipelineTypes, Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["objectQuery"])(entityObj, 'metadata', 'tags').map(function (tag) {
    return tag.name;
  })).length > 0;
}

function createArtifactObj(entityObj) {
  return {
    id: entityObj.entity.details.artifact,
    type: entityObj.entity.type.toLowerCase(),
    version: entityObj.entity.details.version,
    metadata: entityObj,
    icon: services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"]['artifact']
  };
}

function createApplicationObj(entityObj) {
  var version = entityObj.entity.details.version;

  if (version === '-SNAPSHOT') {
    version = '1.0.0-SNAPSHOT';
  }

  var icon = services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"]['application'];

  if (entityObj.metadata.tags.find(function (tag) {
    return tag.name === services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline && tag.scope === SYSTEM_SCOPE;
  })) {
    icon = services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"][services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataPipeline];
  } else if (entityObj.metadata.tags.find(function (tag) {
    return tag.name === services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams && tag.scope === SYSTEM_SCOPE;
  })) {
    icon = services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"][services_global_constants__WEBPACK_IMPORTED_MODULE_3__["GLOBALS"].etlDataStreams];
  }

  return {
    id: entityObj.entity.details.application,
    type: entityObj.entity.type.toLowerCase(),
    metadata: entityObj,
    version: version,
    icon: icon,
    isHydrator: entityIsPipeline(entityObj)
  };
}

function createDatasetObj(entityObj) {
  return {
    id: entityObj.entity.details.dataset,
    type: entityObj.entity.type.toLowerCase(),
    metadata: entityObj,
    icon: services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"]['dataset']
  };
}

function createProgramObj(entityObj) {
  return {
    id: entityObj.entity.details.program,
    applicationId: entityObj.entity.details.application,
    type: entityObj.entity.type.toLowerCase(),
    programType: entityObj.entity.details.type,
    metadata: entityObj,
    icon: services_entity_icon_map__WEBPACK_IMPORTED_MODULE_0__["default"][entityObj.entity.details.type.toLowerCase()]
  };
}

/***/ })

}]);
//# sourceMappingURL=PipelineList.8f44debc4fd1b8b90807.js.map