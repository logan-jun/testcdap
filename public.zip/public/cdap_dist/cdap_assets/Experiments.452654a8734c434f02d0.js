(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Experiments"],{

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/ExperimentsServiceControl/ExperimentsServiceControl.scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/ExperimentsServiceControl/ExperimentsServiceControl.scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.experiments-service-control {\n  display: -webkit-box;\n  display: flex;\n  height: calc(100vh - (53px + 48px));\n  font-size: 15px;\n  overflow: auto; }\n  .experiments-service-control .text-container,\n  .experiments-service-control .image-containers {\n    width: 50%;\n    height: 100%; }\n  .experiments-service-control .image-containers {\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n            flex-direction: column;\n    -webkit-box-align: center;\n            align-items: center;\n    padding-top: 50px;\n    padding-left: 25px; }\n    .experiments-service-control .image-containers img {\n      height: auto;\n      margin: 20px;\n      width: 75%; }\n      .experiments-service-control .image-containers img:first-child {\n        margin-top: 0; }\n  .experiments-service-control .text-container {\n    padding-top: 50px;\n    padding-left: 30px;\n    padding-right: 30px; }\n    .experiments-service-control .text-container p {\n      line-height: 2;\n      padding-right: 20px; }\n    .experiments-service-control .text-container .experiments-benefit li {\n      padding: 10px 0; }\n    .experiments-service-control .text-container .action-container {\n      padding-top: 25px;\n      padding-bottom: 25px; }\n      .experiments-service-control .text-container .action-container .loading-bar {\n        height: 16px; }\n        .experiments-service-control .text-container .action-container .loading-bar rect {\n          fill: #cae7ef; }\n      .experiments-service-control .text-container .action-container.service-disabled {\n        display: grid;\n        -webkit-box-align: center;\n                align-items: center;\n        grid-template-columns: 20px 1fr;\n        grid-gap: 5px; }\n    .experiments-service-control .text-container .mail-to-link {\n      color: var(--brand-primary-color); }\n    .experiments-service-control .text-container .btn .btn-label {\n      vertical-align: top; }\n  .experiments-service-control .experiments-service-control-error .icon-svg {\n    margin-right: 5px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/ListView/ListView.scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/ListView/ListView.scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2015 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.experiments-list-container {\n  height: 100%; }\n\n.experiments-listview {\n  padding: 0 20px;\n  height: 100%;\n  overflow: hidden; }\n  .experiments-listview .empty-search-container a[href] {\n    color: var(--brand-primary-color); }\n  .experiments-listview .experiments-toppanel {\n    position: relative; }\n    .experiments-listview .experiments-toppanel .plus-button {\n      margin-top: 48px; }\n  .experiments-listview .experiment-list-chart {\n    margin-top: 20px;\n    height: 290px; }\n  .experiments-listview > .clearfix {\n    margin-top: 20px; }\n    .experiments-listview > .clearfix .pagination-with-title {\n      margin-right: 0; }\n    .experiments-listview > .clearfix .table-container {\n      height: 100%; }\n    .experiments-listview > .clearfix .table-scroll {\n      height: calc(100% - 70px);\n      overflow-y: auto; }\n  .experiments-listview .grid-wrapper {\n    max-height: calc(100% - 411px);\n    overflow: auto; }\n  .experiments-listview .grid.grid-container {\n    max-height: 100%; }\n    .experiments-listview .grid.grid-container .grid-header .grid-row {\n      grid-template-rows: auto; }\n    .experiments-listview .grid.grid-container .grid-header .sortable-header {\n      cursor: pointer;\n      display: -webkit-box;\n      display: flex;\n      -webkit-box-align: center;\n              align-items: center; }\n      .experiments-listview .grid.grid-container .grid-header .sortable-header:hover {\n        text-decoration: underline; }\n      .experiments-listview .grid.grid-container .grid-header .sortable-header .icon-svg {\n        font-size: 1.3rem; }\n    .experiments-listview .grid.grid-container .grid-row {\n      grid-template-columns: repeat(4, 1fr);\n      grid-template-rows: 50px; }\n      .experiments-listview .grid.grid-container .grid-row > div {\n        padding: 0; }\n      .experiments-listview .grid.grid-container .grid-row .experiment-list-name,\n      .experiments-listview .grid.grid-container .grid-row .experiment-list-description {\n        max-width: 100%;\n        overflow: hidden;\n        text-overflow: ellipsis;\n        white-space: nowrap;\n        display: inline-block;\n        line-height: 1.4; }\n      .experiments-listview .grid.grid-container .grid-row .experiment-list-description {\n        color: #666e83; }\n    .experiments-listview .grid.grid-container a.grid-row {\n      color: inherit; }\n  .experiments-listview .table:first-child {\n    margin-bottom: 0; }\n  .experiments-listview .table tbody > tr > a {\n    display: table;\n    width: 100%;\n    text-decoration: none;\n    color: inherit;\n    outline: none; }\n    .experiments-listview .table tbody > tr > a:hover {\n      background-color: #f5f5f5; }\n  .experiments-listview .table th,\n  .experiments-listview .table td {\n    width: 20%;\n    vertical-align: middle; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/TopPanel/TopPanel.scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/TopPanel/TopPanel.scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.experiments-toppanel {\n  background: #eeeeee;\n  height: 50px;\n  margin-left: -20px;\n  margin-right: -20px;\n  padding: 0 20px;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  border-bottom: 1px solid #cccccc; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PaginationWithTitle/PaginationWithTitle.scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/PaginationWithTitle/PaginationWithTitle.scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.pagination-with-title {\n  float: right;\n  margin-right: 50px;\n  margin-bottom: initial; }\n  .pagination-with-title .total-entities {\n    display: inline-block;\n    vertical-align: top; }\n    .pagination-with-title .total-entities span {\n      font-weight: bold;\n      font-size: 12px; }\n  .pagination-with-title .page-list {\n    padding-left: 16px;\n    list-style-type: none;\n    display: inline-block;\n    margin-bottom: 0;\n    vertical-align: top; }\n    .pagination-with-title .page-list li {\n      font-weight: bold;\n      display: inline-block;\n      border-radius: 100%; }\n      .pagination-with-title .page-list li a,\n      .pagination-with-title .page-list li span {\n        display: -webkit-box;\n        display: flex;\n        height: 22px;\n        width: 22px;\n        -webkit-box-pack: center;\n                justify-content: center;\n        -webkit-box-align: center;\n                align-items: center;\n        color: inherit;\n        -webkit-user-select: none;\n           -moz-user-select: none;\n            -ms-user-select: none;\n                user-select: none; }\n        .pagination-with-title .page-list li a:hover, .pagination-with-title .page-list li a:focus,\n        .pagination-with-title .page-list li span:hover,\n        .pagination-with-title .page-list li span:focus {\n          text-decoration: none;\n          outline: 0; }\n      .pagination-with-title .page-list li:not(:first-child) {\n        margin-left: 15px; }\n      .pagination-with-title .page-list li.current-page {\n        background-color: #5d6789; }\n        .pagination-with-title .page-list li.current-page a {\n          color: #ffffff; }\n      .pagination-with-title .page-list li.ellipsis {\n        margin-left: 5px;\n        margin-right: -10px; }\n        .pagination-with-title .page-list li.ellipsis span {\n          -webkit-user-select: none;\n             -moz-user-select: none;\n              -ms-user-select: none;\n                  user-select: none; }\n      .pagination-with-title .page-list li:hover:not(.current-page):not(.ellipsis) {\n        cursor: pointer;\n        background-color: #dbdbdb; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/VegaLiteChart/VegaLiteChart.scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/VegaLiteChart/VegaLiteChart.scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.vega-lite-chart {\n  height: 100%;\n  width: 100%; }\n  .vega-lite-chart > div:first-of-type {\n    height: 100%;\n    overflow: auto; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/d3/index.js":
/*!**********************************************************************************!*\
  !*** delegated ../../../node_modules/d3/index.js from dll-reference cdap_vendor ***!
  \**********************************************************************************/
/*! exports provided: version, bisect, bisectRight, bisectLeft, ascending, bisector, cross, descending, deviation, extent, histogram, thresholdFreedmanDiaconis, thresholdScott, thresholdSturges, max, mean, median, merge, min, pairs, permute, quantile, range, scan, shuffle, sum, ticks, tickIncrement, tickStep, transpose, variance, zip, axisTop, axisRight, axisBottom, axisLeft, brush, brushX, brushY, brushSelection, chord, ribbon, nest, set, map, keys, values, entries, color, rgb, hsl, lab, hcl, cubehelix, contours, contourDensity, dispatch, drag, dragDisable, dragEnable, dsvFormat, csvParse, csvParseRows, csvFormat, csvFormatRows, tsvParse, tsvParseRows, tsvFormat, tsvFormatRows, easeLinear, easeQuad, easeQuadIn, easeQuadOut, easeQuadInOut, easeCubic, easeCubicIn, easeCubicOut, easeCubicInOut, easePoly, easePolyIn, easePolyOut, easePolyInOut, easeSin, easeSinIn, easeSinOut, easeSinInOut, easeExp, easeExpIn, easeExpOut, easeExpInOut, easeCircle, easeCircleIn, easeCircleOut, easeCircleInOut, easeBounce, easeBounceIn, easeBounceOut, easeBounceInOut, easeBack, easeBackIn, easeBackOut, easeBackInOut, easeElastic, easeElasticIn, easeElasticOut, easeElasticInOut, blob, buffer, dsv, csv, tsv, image, json, text, xml, html, svg, forceCenter, forceCollide, forceLink, forceManyBody, forceRadial, forceSimulation, forceX, forceY, formatDefaultLocale, format, formatPrefix, formatLocale, formatSpecifier, precisionFixed, precisionPrefix, precisionRound, geoArea, geoBounds, geoCentroid, geoCircle, geoClipAntimeridian, geoClipCircle, geoClipExtent, geoClipRectangle, geoContains, geoDistance, geoGraticule, geoGraticule10, geoInterpolate, geoLength, geoPath, geoAlbers, geoAlbersUsa, geoAzimuthalEqualArea, geoAzimuthalEqualAreaRaw, geoAzimuthalEquidistant, geoAzimuthalEquidistantRaw, geoConicConformal, geoConicConformalRaw, geoConicEqualArea, geoConicEqualAreaRaw, geoConicEquidistant, geoConicEquidistantRaw, geoEquirectangular, geoEquirectangularRaw, geoGnomonic, geoGnomonicRaw, geoIdentity, geoProjection, geoProjectionMutator, geoMercator, geoMercatorRaw, geoNaturalEarth1, geoNaturalEarth1Raw, geoOrthographic, geoOrthographicRaw, geoStereographic, geoStereographicRaw, geoTransverseMercator, geoTransverseMercatorRaw, geoRotation, geoStream, geoTransform, cluster, hierarchy, pack, packSiblings, packEnclose, partition, stratify, tree, treemap, treemapBinary, treemapDice, treemapSlice, treemapSliceDice, treemapSquarify, treemapResquarify, interpolate, interpolateArray, interpolateBasis, interpolateBasisClosed, interpolateDate, interpolateNumber, interpolateObject, interpolateRound, interpolateString, interpolateTransformCss, interpolateTransformSvg, interpolateZoom, interpolateRgb, interpolateRgbBasis, interpolateRgbBasisClosed, interpolateHsl, interpolateHslLong, interpolateLab, interpolateHcl, interpolateHclLong, interpolateCubehelix, interpolateCubehelixLong, quantize, path, polygonArea, polygonCentroid, polygonHull, polygonContains, polygonLength, quadtree, randomUniform, randomNormal, randomLogNormal, randomBates, randomIrwinHall, randomExponential, scaleBand, scalePoint, scaleIdentity, scaleLinear, scaleLog, scaleSymlog, scaleOrdinal, scaleImplicit, scalePow, scaleSqrt, scaleQuantile, scaleQuantize, scaleThreshold, scaleTime, scaleUtc, scaleSequential, scaleSequentialLog, scaleSequentialPow, scaleSequentialSqrt, scaleSequentialSymlog, scaleSequentialQuantile, scaleDiverging, scaleDivergingLog, scaleDivergingPow, scaleDivergingSqrt, scaleDivergingSymlog, tickFormat, schemeCategory10, schemeAccent, schemeDark2, schemePaired, schemePastel1, schemePastel2, schemeSet1, schemeSet2, schemeSet3, schemeTableau10, interpolateBrBG, schemeBrBG, interpolatePRGn, schemePRGn, interpolatePiYG, schemePiYG, interpolatePuOr, schemePuOr, interpolateRdBu, schemeRdBu, interpolateRdGy, schemeRdGy, interpolateRdYlBu, schemeRdYlBu, interpolateRdYlGn, schemeRdYlGn, interpolateSpectral, schemeSpectral, interpolateBuGn, schemeBuGn, interpolateBuPu, schemeBuPu, interpolateGnBu, schemeGnBu, interpolateOrRd, schemeOrRd, interpolatePuBuGn, schemePuBuGn, interpolatePuBu, schemePuBu, interpolatePuRd, schemePuRd, interpolateRdPu, schemeRdPu, interpolateYlGnBu, schemeYlGnBu, interpolateYlGn, schemeYlGn, interpolateYlOrBr, schemeYlOrBr, interpolateYlOrRd, schemeYlOrRd, interpolateBlues, schemeBlues, interpolateGreens, schemeGreens, interpolateGreys, schemeGreys, interpolatePurples, schemePurples, interpolateReds, schemeReds, interpolateOranges, schemeOranges, interpolateCividis, interpolateCubehelixDefault, interpolateRainbow, interpolateWarm, interpolateCool, interpolateSinebow, interpolateTurbo, interpolateViridis, interpolateMagma, interpolateInferno, interpolatePlasma, creator, local, matcher, mouse, namespace, namespaces, clientPoint, select, selectAll, selection, selector, selectorAll, style, touch, touches, window, event, customEvent, arc, area, line, pie, areaRadial, radialArea, lineRadial, radialLine, pointRadial, linkHorizontal, linkVertical, linkRadial, symbol, symbols, symbolCircle, symbolCross, symbolDiamond, symbolSquare, symbolStar, symbolTriangle, symbolWye, curveBasisClosed, curveBasisOpen, curveBasis, curveBundle, curveCardinalClosed, curveCardinalOpen, curveCardinal, curveCatmullRomClosed, curveCatmullRomOpen, curveCatmullRom, curveLinearClosed, curveLinear, curveMonotoneX, curveMonotoneY, curveNatural, curveStep, curveStepAfter, curveStepBefore, stack, stackOffsetExpand, stackOffsetDiverging, stackOffsetNone, stackOffsetSilhouette, stackOffsetWiggle, stackOrderAscending, stackOrderDescending, stackOrderInsideOut, stackOrderNone, stackOrderReverse, timeInterval, timeMillisecond, timeMilliseconds, utcMillisecond, utcMilliseconds, timeSecond, timeSeconds, utcSecond, utcSeconds, timeMinute, timeMinutes, timeHour, timeHours, timeDay, timeDays, timeWeek, timeWeeks, timeSunday, timeSundays, timeMonday, timeMondays, timeTuesday, timeTuesdays, timeWednesday, timeWednesdays, timeThursday, timeThursdays, timeFriday, timeFridays, timeSaturday, timeSaturdays, timeMonth, timeMonths, timeYear, timeYears, utcMinute, utcMinutes, utcHour, utcHours, utcDay, utcDays, utcWeek, utcWeeks, utcSunday, utcSundays, utcMonday, utcMondays, utcTuesday, utcTuesdays, utcWednesday, utcWednesdays, utcThursday, utcThursdays, utcFriday, utcFridays, utcSaturday, utcSaturdays, utcMonth, utcMonths, utcYear, utcYears, timeFormatDefaultLocale, timeFormat, timeParse, utcFormat, utcParse, timeFormatLocale, isoFormat, isoParse, now, timer, timerFlush, timeout, interval, transition, active, interrupt, voronoi, zoom, zoomTransform, zoomIdentity */
/***/ (function(module, exports, __webpack_require__) {

module.exports = (__webpack_require__(/*! dll-reference cdap_vendor */ "dll-reference cdap_vendor"))("./node_modules/d3/index.js");

/***/ }),

/***/ "../../node_modules/react-paginate/dist/BreakView.js":
/*!***************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/dist/BreakView.js ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(/*! react */ "../../node_modules/react/index.js");

var _react2 = _interopRequireDefault(_react);

var _propTypes = __webpack_require__(/*! prop-types */ "../../node_modules/react-paginate/node_modules/prop-types/index.js");

var _propTypes2 = _interopRequireDefault(_propTypes);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var BreakView = function BreakView(props) {
  var breakLabel = props.breakLabel,
      breakClassName = props.breakClassName,
      breakLinkClassName = props.breakLinkClassName,
      onClick = props.onClick;

  var className = breakClassName || 'break';

  return _react2.default.createElement(
    'li',
    { className: className },
    _react2.default.createElement(
      'a',
      {
        className: breakLinkClassName,
        onClick: onClick,
        role: 'button',
        tabIndex: '0',
        onKeyPress: onClick
      },
      breakLabel
    )
  );
};

BreakView.propTypes = {
  breakLabel: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.node]),
  breakClassName: _propTypes2.default.string,
  breakLinkClassName: _propTypes2.default.string,
  onClick: _propTypes2.default.func.isRequired
};

exports.default = BreakView;
//# sourceMappingURL=BreakView.js.map

/***/ }),

/***/ "../../node_modules/react-paginate/dist/PageView.js":
/*!**************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/dist/PageView.js ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(/*! react */ "../../node_modules/react/index.js");

var _react2 = _interopRequireDefault(_react);

var _propTypes = __webpack_require__(/*! prop-types */ "../../node_modules/react-paginate/node_modules/prop-types/index.js");

var _propTypes2 = _interopRequireDefault(_propTypes);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var PageView = function PageView(props) {
  var pageClassName = props.pageClassName;
  var pageLinkClassName = props.pageLinkClassName;

  var onClick = props.onClick;
  var href = props.href;
  var ariaLabel = props.ariaLabel || 'Page ' + props.page + (props.extraAriaContext ? ' ' + props.extraAriaContext : '');
  var ariaCurrent = null;

  if (props.selected) {
    ariaCurrent = 'page';

    ariaLabel = props.ariaLabel || 'Page ' + props.page + ' is your current page';

    if (typeof pageClassName !== 'undefined') {
      pageClassName = pageClassName + ' ' + props.activeClassName;
    } else {
      pageClassName = props.activeClassName;
    }

    if (typeof pageLinkClassName !== 'undefined') {
      if (typeof props.activeLinkClassName !== 'undefined') {
        pageLinkClassName = pageLinkClassName + ' ' + props.activeLinkClassName;
      }
    } else {
      pageLinkClassName = props.activeLinkClassName;
    }
  }

  return _react2.default.createElement(
    'li',
    { className: pageClassName },
    _react2.default.createElement(
      'a',
      {
        onClick: onClick,
        role: 'button',
        className: pageLinkClassName,
        href: href,
        tabIndex: '0',
        'aria-label': ariaLabel,
        'aria-current': ariaCurrent,
        onKeyPress: onClick
      },
      props.page
    )
  );
};

PageView.propTypes = {
  onClick: _propTypes2.default.func.isRequired,
  selected: _propTypes2.default.bool.isRequired,
  pageClassName: _propTypes2.default.string,
  pageLinkClassName: _propTypes2.default.string,
  activeClassName: _propTypes2.default.string,
  activeLinkClassName: _propTypes2.default.string,
  extraAriaContext: _propTypes2.default.string,
  href: _propTypes2.default.string,
  ariaLabel: _propTypes2.default.string,
  page: _propTypes2.default.number.isRequired
};

exports.default = PageView;
//# sourceMappingURL=PageView.js.map

/***/ }),

/***/ "../../node_modules/react-paginate/dist/PaginationBoxView.js":
/*!***********************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/dist/PaginationBoxView.js ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(/*! react */ "../../node_modules/react/index.js");

var _react2 = _interopRequireDefault(_react);

var _propTypes = __webpack_require__(/*! prop-types */ "../../node_modules/react-paginate/node_modules/prop-types/index.js");

var _propTypes2 = _interopRequireDefault(_propTypes);

var _PageView = __webpack_require__(/*! ./PageView */ "../../node_modules/react-paginate/dist/PageView.js");

var _PageView2 = _interopRequireDefault(_PageView);

var _BreakView = __webpack_require__(/*! ./BreakView */ "../../node_modules/react-paginate/dist/BreakView.js");

var _BreakView2 = _interopRequireDefault(_BreakView);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var PaginationBoxView = function (_Component) {
  _inherits(PaginationBoxView, _Component);

  function PaginationBoxView(props) {
    _classCallCheck(this, PaginationBoxView);

    var _this = _possibleConstructorReturn(this, (PaginationBoxView.__proto__ || Object.getPrototypeOf(PaginationBoxView)).call(this, props));

    _this.handlePreviousPage = function (evt) {
      var selected = _this.state.selected;

      evt.preventDefault ? evt.preventDefault() : evt.returnValue = false;
      if (selected > 0) {
        _this.handlePageSelected(selected - 1, evt);
      }
    };

    _this.handleNextPage = function (evt) {
      var selected = _this.state.selected;
      var pageCount = _this.props.pageCount;


      evt.preventDefault ? evt.preventDefault() : evt.returnValue = false;
      if (selected < pageCount - 1) {
        _this.handlePageSelected(selected + 1, evt);
      }
    };

    _this.handlePageSelected = function (selected, evt) {
      evt.preventDefault ? evt.preventDefault() : evt.returnValue = false;

      if (_this.state.selected === selected) return;

      _this.setState({ selected: selected });

      // Call the callback with the new selected item:
      _this.callCallback(selected);
    };

    _this.handleBreakClick = function (index, evt) {
      evt.preventDefault ? evt.preventDefault() : evt.returnValue = false;

      var selected = _this.state.selected;


      _this.handlePageSelected(selected < index ? _this.getForwardJump() : _this.getBackwardJump(), evt);
    };

    _this.callCallback = function (selectedItem) {
      if (typeof _this.props.onPageChange !== 'undefined' && typeof _this.props.onPageChange === 'function') {
        _this.props.onPageChange({ selected: selectedItem });
      }
    };

    _this.pagination = function () {
      var items = [];
      var _this$props = _this.props,
          pageRangeDisplayed = _this$props.pageRangeDisplayed,
          pageCount = _this$props.pageCount,
          marginPagesDisplayed = _this$props.marginPagesDisplayed,
          breakLabel = _this$props.breakLabel,
          breakClassName = _this$props.breakClassName,
          breakLinkClassName = _this$props.breakLinkClassName;
      var selected = _this.state.selected;


      if (pageCount <= pageRangeDisplayed) {
        for (var index = 0; index < pageCount; index++) {
          items.push(_this.getPageElement(index));
        }
      } else {
        var leftSide = pageRangeDisplayed / 2;
        var rightSide = pageRangeDisplayed - leftSide;

        // If the selected page index is on the default right side of the pagination,
        // we consider that the new right side is made up of it (= only one break element).
        // If the selected page index is on the default left side of the pagination,
        // we consider that the new left side is made up of it (= only one break element).
        if (selected > pageCount - pageRangeDisplayed / 2) {
          rightSide = pageCount - selected;
          leftSide = pageRangeDisplayed - rightSide;
        } else if (selected < pageRangeDisplayed / 2) {
          leftSide = selected;
          rightSide = pageRangeDisplayed - leftSide;
        }

        var _index = void 0;
        var page = void 0;
        var breakView = void 0;
        var createPageView = function createPageView(index) {
          return _this.getPageElement(index);
        };

        for (_index = 0; _index < pageCount; _index++) {
          page = _index + 1;

          // If the page index is lower than the margin defined,
          // the page has to be displayed on the left side of
          // the pagination.
          if (page <= marginPagesDisplayed) {
            items.push(createPageView(_index));
            continue;
          }

          // If the page index is greater than the page count
          // minus the margin defined, the page has to be
          // displayed on the right side of the pagination.
          if (page > pageCount - marginPagesDisplayed) {
            items.push(createPageView(_index));
            continue;
          }

          // If the page index is near the selected page index
          // and inside the defined range (pageRangeDisplayed)
          // we have to display it (it will create the center
          // part of the pagination).
          if (_index >= selected - leftSide && _index <= selected + rightSide) {
            items.push(createPageView(_index));
            continue;
          }

          // If the page index doesn't meet any of the conditions above,
          // we check if the last item of the current "items" array
          // is a break element. If not, we add a break element, else,
          // we do nothing (because we don't want to display the page).
          if (breakLabel && items[items.length - 1] !== breakView) {
            breakView = _react2.default.createElement(_BreakView2.default, {
              key: _index,
              breakLabel: breakLabel,
              breakClassName: breakClassName,
              breakLinkClassName: breakLinkClassName,
              onClick: _this.handleBreakClick.bind(null, _index)
            });
            items.push(breakView);
          }
        }
      }

      return items;
    };

    var initialSelected = void 0;
    if (props.initialPage) {
      initialSelected = props.initialPage;
    } else if (props.forcePage) {
      initialSelected = props.forcePage;
    } else {
      initialSelected = 0;
    }

    _this.state = {
      selected: initialSelected
    };
    return _this;
  }

  _createClass(PaginationBoxView, [{
    key: 'componentDidMount',
    value: function componentDidMount() {
      var _props = this.props,
          initialPage = _props.initialPage,
          disableInitialCallback = _props.disableInitialCallback,
          extraAriaContext = _props.extraAriaContext;
      // Call the callback with the initialPage item:

      if (typeof initialPage !== 'undefined' && !disableInitialCallback) {
        this.callCallback(initialPage);
      }

      if (extraAriaContext) {
        console.warn('DEPRECATED (react-paginate): The extraAriaContext prop is deprecated. You should now use the ariaLabelBuilder instead.');
      }
    }
  }, {
    key: 'componentDidUpdate',
    value: function componentDidUpdate(prevProps) {
      if (typeof this.props.forcePage !== 'undefined' && this.props.forcePage !== prevProps.forcePage) {
        this.setState({ selected: this.props.forcePage });
      }
    }
  }, {
    key: 'getForwardJump',
    value: function getForwardJump() {
      var selected = this.state.selected;
      var _props2 = this.props,
          pageCount = _props2.pageCount,
          pageRangeDisplayed = _props2.pageRangeDisplayed;


      var forwardJump = selected + pageRangeDisplayed;
      return forwardJump >= pageCount ? pageCount - 1 : forwardJump;
    }
  }, {
    key: 'getBackwardJump',
    value: function getBackwardJump() {
      var selected = this.state.selected;
      var pageRangeDisplayed = this.props.pageRangeDisplayed;


      var backwardJump = selected - pageRangeDisplayed;
      return backwardJump < 0 ? 0 : backwardJump;
    }
  }, {
    key: 'hrefBuilder',
    value: function hrefBuilder(pageIndex) {
      var _props3 = this.props,
          hrefBuilder = _props3.hrefBuilder,
          pageCount = _props3.pageCount;

      if (hrefBuilder && pageIndex !== this.state.selected && pageIndex >= 0 && pageIndex < pageCount) {
        return hrefBuilder(pageIndex + 1);
      }
    }
  }, {
    key: 'ariaLabelBuilder',
    value: function ariaLabelBuilder(pageIndex) {
      var selected = pageIndex === this.state.selected;
      if (this.props.ariaLabelBuilder && pageIndex >= 0 && pageIndex < this.props.pageCount) {
        var label = this.props.ariaLabelBuilder(pageIndex + 1, selected);
        // DEPRECATED: The extraAriaContext prop was used to add additional context
        // to the aria-label. Users should now use the ariaLabelBuilder instead.
        if (this.props.extraAriaContext && !selected) {
          label = label + ' ' + this.props.extraAriaContext;
        }
        return label;
      }
    }
  }, {
    key: 'getPageElement',
    value: function getPageElement(index) {
      var selected = this.state.selected;
      var _props4 = this.props,
          pageClassName = _props4.pageClassName,
          pageLinkClassName = _props4.pageLinkClassName,
          activeClassName = _props4.activeClassName,
          activeLinkClassName = _props4.activeLinkClassName,
          extraAriaContext = _props4.extraAriaContext;


      return _react2.default.createElement(_PageView2.default, {
        key: index,
        onClick: this.handlePageSelected.bind(null, index),
        selected: selected === index,
        pageClassName: pageClassName,
        pageLinkClassName: pageLinkClassName,
        activeClassName: activeClassName,
        activeLinkClassName: activeLinkClassName,
        extraAriaContext: extraAriaContext,
        href: this.hrefBuilder(index),
        ariaLabel: this.ariaLabelBuilder(index),
        page: index + 1
      });
    }
  }, {
    key: 'render',
    value: function render() {
      var _props5 = this.props,
          disabledClassName = _props5.disabledClassName,
          previousClassName = _props5.previousClassName,
          nextClassName = _props5.nextClassName,
          pageCount = _props5.pageCount,
          containerClassName = _props5.containerClassName,
          previousLinkClassName = _props5.previousLinkClassName,
          previousLabel = _props5.previousLabel,
          nextLinkClassName = _props5.nextLinkClassName,
          nextLabel = _props5.nextLabel;
      var selected = this.state.selected;


      var previousClasses = previousClassName + (selected === 0 ? ' ' + disabledClassName : '');
      var nextClasses = nextClassName + (selected === pageCount - 1 ? ' ' + disabledClassName : '');

      var previousAriaDisabled = selected === 0 ? 'true' : 'false';
      var nextAriaDisabled = selected === pageCount - 1 ? 'true' : 'false';

      return _react2.default.createElement(
        'ul',
        { className: containerClassName },
        _react2.default.createElement(
          'li',
          { className: previousClasses },
          _react2.default.createElement(
            'a',
            {
              onClick: this.handlePreviousPage,
              className: previousLinkClassName,
              href: this.hrefBuilder(selected - 1),
              tabIndex: '0',
              role: 'button',
              onKeyPress: this.handlePreviousPage,
              'aria-disabled': previousAriaDisabled
            },
            previousLabel
          )
        ),
        this.pagination(),
        _react2.default.createElement(
          'li',
          { className: nextClasses },
          _react2.default.createElement(
            'a',
            {
              onClick: this.handleNextPage,
              className: nextLinkClassName,
              href: this.hrefBuilder(selected + 1),
              tabIndex: '0',
              role: 'button',
              onKeyPress: this.handleNextPage,
              'aria-disabled': nextAriaDisabled
            },
            nextLabel
          )
        )
      );
    }
  }]);

  return PaginationBoxView;
}(_react.Component);

PaginationBoxView.propTypes = {
  pageCount: _propTypes2.default.number.isRequired,
  pageRangeDisplayed: _propTypes2.default.number.isRequired,
  marginPagesDisplayed: _propTypes2.default.number.isRequired,
  previousLabel: _propTypes2.default.node,
  nextLabel: _propTypes2.default.node,
  breakLabel: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.node]),
  hrefBuilder: _propTypes2.default.func,
  onPageChange: _propTypes2.default.func,
  initialPage: _propTypes2.default.number,
  forcePage: _propTypes2.default.number,
  disableInitialCallback: _propTypes2.default.bool,
  containerClassName: _propTypes2.default.string,
  pageClassName: _propTypes2.default.string,
  pageLinkClassName: _propTypes2.default.string,
  activeClassName: _propTypes2.default.string,
  activeLinkClassName: _propTypes2.default.string,
  previousClassName: _propTypes2.default.string,
  nextClassName: _propTypes2.default.string,
  previousLinkClassName: _propTypes2.default.string,
  nextLinkClassName: _propTypes2.default.string,
  disabledClassName: _propTypes2.default.string,
  breakClassName: _propTypes2.default.string,
  breakLinkClassName: _propTypes2.default.string,
  extraAriaContext: _propTypes2.default.string,
  ariaLabelBuilder: _propTypes2.default.func
};
PaginationBoxView.defaultProps = {
  pageCount: 10,
  pageRangeDisplayed: 2,
  marginPagesDisplayed: 3,
  activeClassName: 'selected',
  previousClassName: 'previous',
  nextClassName: 'next',
  previousLabel: 'Previous',
  nextLabel: 'Next',
  breakLabel: '...',
  disabledClassName: 'disabled',
  disableInitialCallback: false
};
exports.default = PaginationBoxView;
//# sourceMappingURL=PaginationBoxView.js.map

/***/ }),

/***/ "../../node_modules/react-paginate/dist/index.js":
/*!***********************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/dist/index.js ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _PaginationBoxView = __webpack_require__(/*! ./PaginationBoxView */ "../../node_modules/react-paginate/dist/PaginationBoxView.js");

var _PaginationBoxView2 = _interopRequireDefault(_PaginationBoxView);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _PaginationBoxView2.default;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "../../node_modules/react-paginate/node_modules/prop-types/checkPropTypes.js":
/*!***************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/node_modules/prop-types/checkPropTypes.js ***!
  \***************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var printWarning = function() {};

if (true) {
  var ReactPropTypesSecret = __webpack_require__(/*! ./lib/ReactPropTypesSecret */ "../../node_modules/react-paginate/node_modules/prop-types/lib/ReactPropTypesSecret.js");
  var loggedTypeFailures = {};

  printWarning = function(text) {
    var message = 'Warning: ' + text;
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  };
}

/**
 * Assert that the values match with the type specs.
 * Error messages are memorized and will only be shown once.
 *
 * @param {object} typeSpecs Map of name to a ReactPropType
 * @param {object} values Runtime values that need to be type-checked
 * @param {string} location e.g. "prop", "context", "child context"
 * @param {string} componentName Name of the component for error messages.
 * @param {?Function} getStack Returns the component stack.
 * @private
 */
function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
  if (true) {
    for (var typeSpecName in typeSpecs) {
      if (typeSpecs.hasOwnProperty(typeSpecName)) {
        var error;
        // Prop type validation may throw. In case they do, we don't want to
        // fail the render phase where it didn't fail before. So we log it.
        // After these have been cleaned up, we'll let them throw.
        try {
          // This is intentionally an invariant that gets caught. It's the same
          // behavior as without this statement except with a better message.
          if (typeof typeSpecs[typeSpecName] !== 'function') {
            var err = Error(
              (componentName || 'React class') + ': ' + location + ' type `' + typeSpecName + '` is invalid; ' +
              'it must be a function, usually from the `prop-types` package, but received `' + typeof typeSpecs[typeSpecName] + '`.'
            );
            err.name = 'Invariant Violation';
            throw err;
          }
          error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
        } catch (ex) {
          error = ex;
        }
        if (error && !(error instanceof Error)) {
          printWarning(
            (componentName || 'React class') + ': type specification of ' +
            location + ' `' + typeSpecName + '` is invalid; the type checker ' +
            'function must return `null` or an `Error` but returned a ' + typeof error + '. ' +
            'You may have forgotten to pass an argument to the type checker ' +
            'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' +
            'shape all require an argument).'
          )

        }
        if (error instanceof Error && !(error.message in loggedTypeFailures)) {
          // Only monitor this failure once because there tends to be a lot of the
          // same error.
          loggedTypeFailures[error.message] = true;

          var stack = getStack ? getStack() : '';

          printWarning(
            'Failed ' + location + ' type: ' + error.message + (stack != null ? stack : '')
          );
        }
      }
    }
  }
}

module.exports = checkPropTypes;


/***/ }),

/***/ "../../node_modules/react-paginate/node_modules/prop-types/factoryWithTypeCheckers.js":
/*!************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/node_modules/prop-types/factoryWithTypeCheckers.js ***!
  \************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var assign = __webpack_require__(/*! object-assign */ "../../node_modules/object-assign/index.js");

var ReactPropTypesSecret = __webpack_require__(/*! ./lib/ReactPropTypesSecret */ "../../node_modules/react-paginate/node_modules/prop-types/lib/ReactPropTypesSecret.js");
var checkPropTypes = __webpack_require__(/*! ./checkPropTypes */ "../../node_modules/react-paginate/node_modules/prop-types/checkPropTypes.js");

var printWarning = function() {};

if (true) {
  printWarning = function(text) {
    var message = 'Warning: ' + text;
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  };
}

function emptyFunctionThatReturnsNull() {
  return null;
}

module.exports = function(isValidElement, throwOnDirectAccess) {
  /* global Symbol */
  var ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
  var FAUX_ITERATOR_SYMBOL = '@@iterator'; // Before Symbol spec.

  /**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */
  function getIteratorFn(maybeIterable) {
    var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
    if (typeof iteratorFn === 'function') {
      return iteratorFn;
    }
  }

  /**
   * Collection of methods that allow declaration and validation of props that are
   * supplied to React components. Example usage:
   *
   *   var Props = require('ReactPropTypes');
   *   var MyArticle = React.createClass({
   *     propTypes: {
   *       // An optional string prop named "description".
   *       description: Props.string,
   *
   *       // A required enum prop named "category".
   *       category: Props.oneOf(['News','Photos']).isRequired,
   *
   *       // A prop named "dialog" that requires an instance of Dialog.
   *       dialog: Props.instanceOf(Dialog).isRequired
   *     },
   *     render: function() { ... }
   *   });
   *
   * A more formal specification of how these methods are used:
   *
   *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
   *   decl := ReactPropTypes.{type}(.isRequired)?
   *
   * Each and every declaration produces a function with the same signature. This
   * allows the creation of custom validation functions. For example:
   *
   *  var MyLink = React.createClass({
   *    propTypes: {
   *      // An optional string or URI prop named "href".
   *      href: function(props, propName, componentName) {
   *        var propValue = props[propName];
   *        if (propValue != null && typeof propValue !== 'string' &&
   *            !(propValue instanceof URI)) {
   *          return new Error(
   *            'Expected a string or an URI for ' + propName + ' in ' +
   *            componentName
   *          );
   *        }
   *      }
   *    },
   *    render: function() {...}
   *  });
   *
   * @internal
   */

  var ANONYMOUS = '<<anonymous>>';

  // Important!
  // Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
  var ReactPropTypes = {
    array: createPrimitiveTypeChecker('array'),
    bool: createPrimitiveTypeChecker('boolean'),
    func: createPrimitiveTypeChecker('function'),
    number: createPrimitiveTypeChecker('number'),
    object: createPrimitiveTypeChecker('object'),
    string: createPrimitiveTypeChecker('string'),
    symbol: createPrimitiveTypeChecker('symbol'),

    any: createAnyTypeChecker(),
    arrayOf: createArrayOfTypeChecker,
    element: createElementTypeChecker(),
    instanceOf: createInstanceTypeChecker,
    node: createNodeChecker(),
    objectOf: createObjectOfTypeChecker,
    oneOf: createEnumTypeChecker,
    oneOfType: createUnionTypeChecker,
    shape: createShapeTypeChecker,
    exact: createStrictShapeTypeChecker,
  };

  /**
   * inlined Object.is polyfill to avoid requiring consumers ship their own
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
   */
  /*eslint-disable no-self-compare*/
  function is(x, y) {
    // SameValue algorithm
    if (x === y) {
      // Steps 1-5, 7-10
      // Steps 6.b-6.e: +0 != -0
      return x !== 0 || 1 / x === 1 / y;
    } else {
      // Step 6.a: NaN == NaN
      return x !== x && y !== y;
    }
  }
  /*eslint-enable no-self-compare*/

  /**
   * We use an Error-like object for backward compatibility as people may call
   * PropTypes directly and inspect their output. However, we don't use real
   * Errors anymore. We don't inspect their stack anyway, and creating them
   * is prohibitively expensive if they are created too often, such as what
   * happens in oneOfType() for any type before the one that matched.
   */
  function PropTypeError(message) {
    this.message = message;
    this.stack = '';
  }
  // Make `instanceof Error` still work for returned errors.
  PropTypeError.prototype = Error.prototype;

  function createChainableTypeChecker(validate) {
    if (true) {
      var manualPropTypeCallCache = {};
      var manualPropTypeWarningCount = 0;
    }
    function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
      componentName = componentName || ANONYMOUS;
      propFullName = propFullName || propName;

      if (secret !== ReactPropTypesSecret) {
        if (throwOnDirectAccess) {
          // New behavior only for users of `prop-types` package
          var err = new Error(
            'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
            'Use `PropTypes.checkPropTypes()` to call them. ' +
            'Read more at http://fb.me/use-check-prop-types'
          );
          err.name = 'Invariant Violation';
          throw err;
        } else if ( true && typeof console !== 'undefined') {
          // Old behavior for people using React.PropTypes
          var cacheKey = componentName + ':' + propName;
          if (
            !manualPropTypeCallCache[cacheKey] &&
            // Avoid spamming the console because they are often not actionable except for lib authors
            manualPropTypeWarningCount < 3
          ) {
            printWarning(
              'You are manually calling a React.PropTypes validation ' +
              'function for the `' + propFullName + '` prop on `' + componentName  + '`. This is deprecated ' +
              'and will throw in the standalone `prop-types` package. ' +
              'You may be seeing this warning due to a third-party PropTypes ' +
              'library. See https://fb.me/react-warning-dont-call-proptypes ' + 'for details.'
            );
            manualPropTypeCallCache[cacheKey] = true;
            manualPropTypeWarningCount++;
          }
        }
      }
      if (props[propName] == null) {
        if (isRequired) {
          if (props[propName] === null) {
            return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required ' + ('in `' + componentName + '`, but its value is `null`.'));
          }
          return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required in ' + ('`' + componentName + '`, but its value is `undefined`.'));
        }
        return null;
      } else {
        return validate(props, propName, componentName, location, propFullName);
      }
    }

    var chainedCheckType = checkType.bind(null, false);
    chainedCheckType.isRequired = checkType.bind(null, true);

    return chainedCheckType;
  }

  function createPrimitiveTypeChecker(expectedType) {
    function validate(props, propName, componentName, location, propFullName, secret) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== expectedType) {
        // `propValue` being instance of, say, date/regexp, pass the 'object'
        // check, but we can offer a more precise error message here rather than
        // 'of type `object`'.
        var preciseType = getPreciseType(propValue);

        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + preciseType + '` supplied to `' + componentName + '`, expected ') + ('`' + expectedType + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createAnyTypeChecker() {
    return createChainableTypeChecker(emptyFunctionThatReturnsNull);
  }

  function createArrayOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside arrayOf.');
      }
      var propValue = props[propName];
      if (!Array.isArray(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an array.'));
      }
      for (var i = 0; i < propValue.length; i++) {
        var error = typeChecker(propValue, i, componentName, location, propFullName + '[' + i + ']', ReactPropTypesSecret);
        if (error instanceof Error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createElementTypeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      if (!isValidElement(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createInstanceTypeChecker(expectedClass) {
    function validate(props, propName, componentName, location, propFullName) {
      if (!(props[propName] instanceof expectedClass)) {
        var expectedClassName = expectedClass.name || ANONYMOUS;
        var actualClassName = getClassName(props[propName]);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + actualClassName + '` supplied to `' + componentName + '`, expected ') + ('instance of `' + expectedClassName + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createEnumTypeChecker(expectedValues) {
    if (!Array.isArray(expectedValues)) {
       true ? printWarning('Invalid argument supplied to oneOf, expected an instance of array.') : undefined;
      return emptyFunctionThatReturnsNull;
    }

    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      for (var i = 0; i < expectedValues.length; i++) {
        if (is(propValue, expectedValues[i])) {
          return null;
        }
      }

      var valuesString = JSON.stringify(expectedValues);
      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of value `' + propValue + '` ' + ('supplied to `' + componentName + '`, expected one of ' + valuesString + '.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createObjectOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside objectOf.');
      }
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an object.'));
      }
      for (var key in propValue) {
        if (propValue.hasOwnProperty(key)) {
          var error = typeChecker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
          if (error instanceof Error) {
            return error;
          }
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createUnionTypeChecker(arrayOfTypeCheckers) {
    if (!Array.isArray(arrayOfTypeCheckers)) {
       true ? printWarning('Invalid argument supplied to oneOfType, expected an instance of array.') : undefined;
      return emptyFunctionThatReturnsNull;
    }

    for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
      var checker = arrayOfTypeCheckers[i];
      if (typeof checker !== 'function') {
        printWarning(
          'Invalid argument supplied to oneOfType. Expected an array of check functions, but ' +
          'received ' + getPostfixForTypeWarning(checker) + ' at index ' + i + '.'
        );
        return emptyFunctionThatReturnsNull;
      }
    }

    function validate(props, propName, componentName, location, propFullName) {
      for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
        var checker = arrayOfTypeCheckers[i];
        if (checker(props, propName, componentName, location, propFullName, ReactPropTypesSecret) == null) {
          return null;
        }
      }

      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createNodeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      if (!isNode(props[propName])) {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`, expected a ReactNode.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      for (var key in shapeTypes) {
        var checker = shapeTypes[key];
        if (!checker) {
          continue;
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createStrictShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      // We need to check all keys in case some are required but missing from
      // props.
      var allKeys = assign({}, props[propName], shapeTypes);
      for (var key in allKeys) {
        var checker = shapeTypes[key];
        if (!checker) {
          return new PropTypeError(
            'Invalid ' + location + ' `' + propFullName + '` key `' + key + '` supplied to `' + componentName + '`.' +
            '\nBad object: ' + JSON.stringify(props[propName], null, '  ') +
            '\nValid keys: ' +  JSON.stringify(Object.keys(shapeTypes), null, '  ')
          );
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }

    return createChainableTypeChecker(validate);
  }

  function isNode(propValue) {
    switch (typeof propValue) {
      case 'number':
      case 'string':
      case 'undefined':
        return true;
      case 'boolean':
        return !propValue;
      case 'object':
        if (Array.isArray(propValue)) {
          return propValue.every(isNode);
        }
        if (propValue === null || isValidElement(propValue)) {
          return true;
        }

        var iteratorFn = getIteratorFn(propValue);
        if (iteratorFn) {
          var iterator = iteratorFn.call(propValue);
          var step;
          if (iteratorFn !== propValue.entries) {
            while (!(step = iterator.next()).done) {
              if (!isNode(step.value)) {
                return false;
              }
            }
          } else {
            // Iterator will provide entry [k,v] tuples rather than values.
            while (!(step = iterator.next()).done) {
              var entry = step.value;
              if (entry) {
                if (!isNode(entry[1])) {
                  return false;
                }
              }
            }
          }
        } else {
          return false;
        }

        return true;
      default:
        return false;
    }
  }

  function isSymbol(propType, propValue) {
    // Native Symbol.
    if (propType === 'symbol') {
      return true;
    }

    // 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
    if (propValue['@@toStringTag'] === 'Symbol') {
      return true;
    }

    // Fallback for non-spec compliant Symbols which are polyfilled.
    if (typeof Symbol === 'function' && propValue instanceof Symbol) {
      return true;
    }

    return false;
  }

  // Equivalent of `typeof` but with special handling for array and regexp.
  function getPropType(propValue) {
    var propType = typeof propValue;
    if (Array.isArray(propValue)) {
      return 'array';
    }
    if (propValue instanceof RegExp) {
      // Old webkits (at least until Android 4.0) return 'function' rather than
      // 'object' for typeof a RegExp. We'll normalize this here so that /bla/
      // passes PropTypes.object.
      return 'object';
    }
    if (isSymbol(propType, propValue)) {
      return 'symbol';
    }
    return propType;
  }

  // This handles more types than `getPropType`. Only used for error messages.
  // See `createPrimitiveTypeChecker`.
  function getPreciseType(propValue) {
    if (typeof propValue === 'undefined' || propValue === null) {
      return '' + propValue;
    }
    var propType = getPropType(propValue);
    if (propType === 'object') {
      if (propValue instanceof Date) {
        return 'date';
      } else if (propValue instanceof RegExp) {
        return 'regexp';
      }
    }
    return propType;
  }

  // Returns a string that is postfixed to a warning about an invalid type.
  // For example, "undefined" or "of type array"
  function getPostfixForTypeWarning(value) {
    var type = getPreciseType(value);
    switch (type) {
      case 'array':
      case 'object':
        return 'an ' + type;
      case 'boolean':
      case 'date':
      case 'regexp':
        return 'a ' + type;
      default:
        return type;
    }
  }

  // Returns class name of the object, if any.
  function getClassName(propValue) {
    if (!propValue.constructor || !propValue.constructor.name) {
      return ANONYMOUS;
    }
    return propValue.constructor.name;
  }

  ReactPropTypes.checkPropTypes = checkPropTypes;
  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};


/***/ }),

/***/ "../../node_modules/react-paginate/node_modules/prop-types/index.js":
/*!******************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/node_modules/prop-types/index.js ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

if (true) {
  var REACT_ELEMENT_TYPE = (typeof Symbol === 'function' &&
    Symbol.for &&
    Symbol.for('react.element')) ||
    0xeac7;

  var isValidElement = function(object) {
    return typeof object === 'object' &&
      object !== null &&
      object.$$typeof === REACT_ELEMENT_TYPE;
  };

  // By explicitly using `prop-types` you are opting into new development behavior.
  // http://fb.me/prop-types-in-prod
  var throwOnDirectAccess = true;
  module.exports = __webpack_require__(/*! ./factoryWithTypeCheckers */ "../../node_modules/react-paginate/node_modules/prop-types/factoryWithTypeCheckers.js")(isValidElement, throwOnDirectAccess);
} else {}


/***/ }),

/***/ "../../node_modules/react-paginate/node_modules/prop-types/lib/ReactPropTypesSecret.js":
/*!*************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/react-paginate/node_modules/prop-types/lib/ReactPropTypesSecret.js ***!
  \*************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

module.exports = ReactPropTypesSecret;


/***/ }),

/***/ "../../node_modules/vega-lite/build/src/index.js":
/*!***************************************************************************************************!*\
  !*** delegated ../../../node_modules/vega-lite/build/src/index.js from dll-reference cdap_vendor ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = (__webpack_require__(/*! dll-reference cdap_vendor */ "dll-reference cdap_vendor"))("./node_modules/vega-lite/build/src/index.js");

/***/ }),

/***/ "../../node_modules/vega-tooltip/build/src/index.js":
/*!******************************************************************************************************!*\
  !*** delegated ../../../node_modules/vega-tooltip/build/src/index.js from dll-reference cdap_vendor ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = (__webpack_require__(/*! dll-reference cdap_vendor */ "dll-reference cdap_vendor"))("./node_modules/vega-tooltip/build/src/index.js");

/***/ }),

/***/ "../../node_modules/vega/index.js":
/*!************************************************************************************!*\
  !*** delegated ../../../node_modules/vega/index.js from dll-reference cdap_vendor ***!
  \************************************************************************************/
/*! exports provided: version, Dataflow, EventStream, Parameters, Pulse, MultiPulse, Operator, Transform, changeset, ingest, isTuple, definition, transform, transforms, tupleid, scale, scheme, interpolate, interpolateRange, timeInterval, utcInterval, projection, View, parse, expressionFunction, formatLocale, timeFormatLocale, runtime, runtimeContext, bandwidthNRD, bin, bootstrapCI, dotbin, quantiles, quartiles, random, setRandom, randomLCG, randomInteger, randomKDE, randomLogNormal, sampleLogNormal, densityLogNormal, cumulativeLogNormal, quantileLogNormal, randomMixture, randomNormal, sampleNormal, densityNormal, cumulativeNormal, quantileNormal, randomUniform, sampleUniform, densityUniform, cumulativeUniform, quantileUniform, regressionLinear, regressionLog, regressionExp, regressionPow, regressionQuad, regressionPoly, regressionLoess, sampleCurve, accessor, accessorName, accessorFields, id, identity, zero, one, truthy, falsy, logger, None, Error, Warn, Info, Debug, mergeConfig, writeConfig, panLinear, panLog, panPow, panSymlog, zoomLinear, zoomLog, zoomPow, zoomSymlog, quarter, utcquarter, array, clampRange, compare, constant, debounce, error, extend, extent, extentIndex, fastmap, field, flush, hasOwnProperty, inherits, inrange, isArray, isBoolean, isDate, isFunction, isNumber, isObject, isRegExp, isString, key, lerp, lruCache, merge, pad, peek, repeat, span, splitAccessPath, stringValue, toBoolean, toDate, toNumber, toString, toSet, truncate, visitArray, loader, read, inferType, inferTypes, typeParsers, formats, Bounds, Gradient, GroupItem, ResourceLoader, Item, Scenegraph, Handler, Renderer, CanvasHandler, CanvasRenderer, SVGHandler, SVGRenderer, SVGStringRenderer, RenderType, renderModule, Marks, boundClip, boundContext, boundStroke, boundItem, boundMark, pathCurves, pathSymbols, pathRectangle, pathTrail, pathParse, pathRender, point, domCreate, domFind, domChild, domClear, openTag, closeTag, font, textMetrics, resetSVGClipId, sceneEqual, pathEqual, sceneToJSON, sceneFromJSON, sceneZOrder, sceneVisit, scenePickVisit */
/***/ (function(module, exports, __webpack_require__) {

module.exports = (__webpack_require__(/*! dll-reference cdap_vendor */ "dll-reference cdap_vendor"))("./node_modules/vega/index.js");

/***/ }),

/***/ "./api/experiments.js":
/*!****************************!*\
  !*** ./api/experiments.js ***!
  \****************************/
/*! exports provided: myExperimentsApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "myExperimentsApi", function() { return myExperimentsApi; });
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_0__["default"].getInstance();
var appPath = '/namespaces/:namespace/apps/ModelManagementApp';
var servicePath = "".concat(appPath, "/spark/ModelManagerService");
var basePath = "".concat(servicePath, "/methods");
var myExperimentsApi = {
  list: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basePath, "/experiments")),
  getExperiment: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basePath, "/experiments/:experimentId")),
  getModelsInExperiment: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basePath, "/experiments/:experimentId/models")),
  getModel: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basePath, "/experiments/:experimentId/models/:modelId")),
  pollModel: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'POLL', "".concat(basePath, "/experiments/:experimentId/models/:modelId")),
  getSplitDetails: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basePath, "/experiments/:experimentId/splits/:splitId")),
  getSplitStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'POLL', "".concat(basePath, "/experiments/:experimentId/splits/:splitId/status")),
  getAlgorithms: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basePath, "/algorithms")),
  getModelStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basePath, "/experiments/:experimentId/models/:modelId/status")),
  pollModelStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'POLL', "".concat(basePath, "/experiments/:experimentId/models/:modelId/status")),
  trainModel: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basePath, "/experiments/:experimentId/models/:modelId/train")),
  getSplitsInExperiment: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basePath, "/experiments/:experimentId/splits")),
  deleteModelInExperiment: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(basePath, "/experiments/:experimentId/models/:modelId")),
  deleteExperiment: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(basePath, "/experiments/:experimentId")),
  updateDirectivesInModel: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'PUT', 'REQUEST', "".concat(basePath, "/experiments/:experimentId/models/:modelId/directives")),
  deleteSplitInModel: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(basePath, "/experiments/:experimentId/models/:modelId/split")),
  createExperiment: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'PUT', 'REQUEST', "".concat(basePath, "/experiments/:experimentId")),
  createSplit: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basePath, "/experiments/:experimentId/models/:modelId/split")),
  createModelInExperiment: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basePath, "/experiments/:experimentId/models")),
  // Service management
  getApp: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(appPath)),
  startService: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(servicePath, "/start")),
  stopService: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(servicePath, "/stop")),
  createApp: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'PUT', 'REQUEST', "".concat(appPath)),
  getServiceStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(servicePath, "/status")),
  pollServiceStatus: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'POLL', "".concat(servicePath, "/status")),
  ping: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_1__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basePath, "/health"))
};

/***/ }),

/***/ "./components/Experiments/ExperimentsServiceControl/ExperimentsServiceControl.scss":
/*!*****************************************************************************************!*\
  !*** ./components/Experiments/ExperimentsServiceControl/ExperimentsServiceControl.scss ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./ExperimentsServiceControl.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/ExperimentsServiceControl/ExperimentsServiceControl.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/ExperimentsServiceControl/index.js":
/*!*******************************************************************!*\
  !*** ./components/Experiments/ExperimentsServiceControl/index.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ExperimentsServiceControl; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_ServiceEnablerUtilities__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/ServiceEnablerUtilities */ "./services/ServiceEnablerUtilities.js");
/* harmony import */ var components_LoadingSVG__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/LoadingSVG */ "./components/LoadingSVG/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var lodash_isObject__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash/isObject */ "../../node_modules/lodash/isObject.js");
/* harmony import */ var lodash_isObject__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash_isObject__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var api_experiments__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! api/experiments */ "./api/experiments.js");
/* harmony import */ var services_CDAPComponentsVersions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! services/CDAPComponentsVersions */ "./services/CDAPComponentsVersions.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-helmet */ "../../node_modules/react-helmet/lib/Helmet.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */












__webpack_require__(/*! ./ExperimentsServiceControl.scss */ "./components/Experiments/ExperimentsServiceControl/ExperimentsServiceControl.scss");

var EXPERIMENTS_I18N_PREFIX = 'features.Experiments';
var PREFIX = "".concat(EXPERIMENTS_I18N_PREFIX, ".ServiceControl");
var MMDSArtifact = 'mmds-app';

var ExperimentsServiceControl =
/*#__PURE__*/
function (_Component) {
  _inherits(ExperimentsServiceControl, _Component);

  function ExperimentsServiceControl() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ExperimentsServiceControl);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ExperimentsServiceControl)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      loading: false,
      disabled: false,
      checkingForSpark2: true,
      error: null,
      extendedError: null
    });

    _defineProperty(_assertThisInitialized(_this), "enableMMDS", function () {
      _this.setState({
        loading: true
      });

      var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__["Theme"].featureNames.analytics;
      Object(services_ServiceEnablerUtilities__WEBPACK_IMPORTED_MODULE_2__["default"])({
        shouldStopService: false,
        artifactName: MMDSArtifact,
        api: api_experiments__WEBPACK_IMPORTED_MODULE_7__["myExperimentsApi"],
        i18nPrefix: PREFIX,
        featureName: featureName
      }).subscribe(_this.props.onServiceStart, function (err) {
        var extendedMessage = lodash_isObject__WEBPACK_IMPORTED_MODULE_6___default()(err.extendedMessage) ? err.extendedMessage.response || err.extendedMessage.message : err.extendedMessage;

        _this.setState({
          error: err.error,
          extendedError: extendedMessage,
          loading: false
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "renderEnableBtn", function () {
      var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__["Theme"].featureNames.analytics;

      if (_this.state.checkingForSpark2) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "action-container service-disabled"
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_5__["default"], {
          name: "icon-spinner",
          className: "fa-spin"
        }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "text-primary"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".environmentCheckMessage"), {
          featureName: featureName
        })));
      }

      if (_this.state.disabled) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "action-container service-disabled"
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_5__["default"], {
          name: "icon-exclamation-triangle",
          className: "text-danger"
        }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "text-danger"
        }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".serviceDisabledMessage"), {
          featureName: featureName
        })));
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "action-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("button", {
        className: "btn btn-primary",
        onClick: _this.enableMMDS,
        disabled: _this.state.loading
      }, _this.state.loading ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_LoadingSVG__WEBPACK_IMPORTED_MODULE_3__["default"], null) : null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "btn-label"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".enableBtnLabel"), {
        featureName: featureName
      }))));
    });

    _defineProperty(_assertThisInitialized(_this), "renderError", function () {
      if (!_this.state.error) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "experiments-service-control-error"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", {
        className: "text-danger"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_5__["default"], {
        name: "icon-exclamation-triangle"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, _this.state.error)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
        className: "text-danger"
      }, _this.state.extendedError));
    });

    return _this;
  }

  _createClass(ExperimentsServiceControl, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      Object(services_CDAPComponentsVersions__WEBPACK_IMPORTED_MODULE_8__["isSpark2Available"])().subscribe(function (isAvailable) {
        return _this2.setState({
          checkingForSpark2: false,
          disabled: !isAvailable
        });
      });
    }
  }, {
    key: "render",
    value: function render() {
      var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__["Theme"].featureNames.analytics;
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "experiments-service-control"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_helmet__WEBPACK_IMPORTED_MODULE_9___default.a, {
        title: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(EXPERIMENTS_I18N_PREFIX, ".pageTitle"), {
          productName: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__["Theme"].productName,
          featureName: featureName
        })
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "image-containers"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
        className: "img-thumbnail",
        src: "/cdap_assets/img/MMDS_preview1.png"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
        className: "img-thumbnail",
        src: "/cdap_assets/img/MMDS_preview2.png"
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "text-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h2", null, " ", i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".title"), {
        featureName: featureName
      }), " "), this.renderEnableBtn(), this.renderError(), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".description"), {
        featureName: featureName
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "experiments-benefit"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".Benefits.title"), {
        featureName: featureName
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("ul", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".Benefits.b1")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".Benefits.b2")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".Benefits.b3")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".Benefits.b4")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".Benefits.b5")))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("".concat(PREFIX, ".Benefits.b6"))))))));
    }
  }]);

  return ExperimentsServiceControl;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(ExperimentsServiceControl, "propTypes", {
  onServiceStart: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
});



/***/ }),

/***/ "./components/Experiments/ListView/EmptyListView.js":
/*!**********************************************************!*\
  !*** ./components/Experiments/ListView/EmptyListView.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EmptyListView; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_EmptyMessageContainer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/EmptyMessageContainer */ "./components/EmptyMessageContainer/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




function EmptyListView(_ref) {
  var namespace = _ref.namespace;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_EmptyMessageContainer__WEBPACK_IMPORTED_MODULE_2__["default"], {
    title: "You have not created any experiments"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("ul", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"], {
    to: "/ns/".concat(namespace, "/experiments/create")
  }, "Create"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, " a new experiment"))));
}
EmptyListView.propTypes = {
  namespace: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/Experiments/ListView/ExperimentsListBarChart/index.js":
/*!**************************************************************************!*\
  !*** ./components/Experiments/ListView/ExperimentsListBarChart/index.js ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ExperimentsListBarChart; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_GroupedBarChart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/GroupedBarChart */ "./components/GroupedBarChart/index.js");
/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */



var DEFAULT_DEPLOYED_COLOR = '#B9C0D8';
var DEFAULT_TOTAL_COLOR = '#5B6787';
var customEncoding = {
  color: {
    field: 'type',
    type: 'nominal',
    scale: {
      range: [DEFAULT_DEPLOYED_COLOR, DEFAULT_TOTAL_COLOR]
    }
  },
  column: {
    field: 'name',
    type: 'ordinal',
    header: {
      title: null
    }
  },
  x: {
    field: 'type',
    type: 'nominal',
    axis: {
      labels: false,
      title: null
    }
  },
  y: {
    field: 'count',
    type: 'quantitative',
    axis: {
      title: 'Models',
      grid: false
    }
  }
};
function ExperimentsListBarChart(_ref) {
  var data = _ref.data;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "experiment-list-chart"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h5", null, "Models created"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_GroupedBarChart__WEBPACK_IMPORTED_MODULE_2__["default"], {
    data: data,
    customEncoding: customEncoding,
    width: function width(dimension, data) {
      return (dimension.width - 290) / data.length;
    },
    heightOffset: 70
  }));
}
ExperimentsListBarChart.propTypes = {
  data: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    name: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  })).isRequired
};

/***/ }),

/***/ "./components/Experiments/ListView/InvalidPageView.js":
/*!************************************************************!*\
  !*** ./components/Experiments/ListView/InvalidPageView.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EmptyListView; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_EmptyMessageContainer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/EmptyMessageContainer */ "./components/EmptyMessageContainer/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




function EmptyListView(_ref) {
  var namespace = _ref.namespace;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_EmptyMessageContainer__WEBPACK_IMPORTED_MODULE_2__["default"], {
    title: "You have landed on an invalid page"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("ul", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"], {
    to: "/ns/".concat(namespace, "/experiments?limit=10&offset=0")
  }, "To browse"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, " all the experiments"))));
}
EmptyListView.propTypes = {
  namespace: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/Experiments/ListView/ListView.scss":
/*!*******************************************************!*\
  !*** ./components/Experiments/ListView/ListView.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./ListView.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/ListView/ListView.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/ListView/ListViewWrapper.js":
/*!************************************************************!*\
  !*** ./components/Experiments/ListView/ListViewWrapper.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/LoadingSVGCentered */ "./components/LoadingSVGCentered/index.js");
/* harmony import */ var components_Experiments_TopPanel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/TopPanel */ "./components/Experiments/TopPanel/index.js");
/* harmony import */ var components_PieChart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/PieChart */ "./components/PieChart/index.js");
/* harmony import */ var components_PaginationWithTitle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/PaginationWithTitle */ "./components/PaginationWithTitle/index.js");
/* harmony import */ var d3__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! d3 */ "../../node_modules/d3/index.js");
/* harmony import */ var components_Experiments_ListView_ExperimentsListBarChart__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/Experiments/ListView/ExperimentsListBarChart */ "./components/Experiments/ListView/ExperimentsListBarChart/index.js");
/* harmony import */ var components_PlusButton__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/PlusButton */ "./components/PlusButton/index.js");
/* harmony import */ var components_Experiments_ListView_InvalidPageView__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/Experiments/ListView/InvalidPageView */ "./components/Experiments/ListView/InvalidPageView.js");
/* harmony import */ var components_Experiments_ListView_EmptyListView__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/Experiments/ListView/EmptyListView */ "./components/Experiments/ListView/EmptyListView.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var components_Experiments_store_ExperimentsListActionCreator__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! components/Experiments/store/ExperimentsListActionCreator */ "./components/Experiments/store/ExperimentsListActionCreator.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_Alert__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! components/Alert */ "./components/Alert/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */



















var PREFIX = 'features.Experiments.ListView';

__webpack_require__(/*! ./ListView.scss */ "./components/Experiments/ListView/ListView.scss");

var tableHeaders = [{
  label: i18n_react__WEBPACK_IMPORTED_MODULE_17___default.a.translate("".concat(PREFIX, ".experiment")),
  property: 'name'
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_17___default.a.translate("".concat(PREFIX, ".numModels")),
  property: 'numOfModels'
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_17___default.a.translate("".concat(PREFIX, ".algoTypes")),
  property: 'algorithmTypes'
}, {
  label: i18n_react__WEBPACK_IMPORTED_MODULE_17___default.a.translate("".concat(PREFIX, ".data")),
  property: 'testData'
}];
var colorScale = d3__WEBPACK_IMPORTED_MODULE_7__["scaleOrdinal"](d3__WEBPACK_IMPORTED_MODULE_7__["schemeCategory20"]);
var PLUSBUTTONCONTEXTMENUITEMS = [{
  label: i18n_react__WEBPACK_IMPORTED_MODULE_17___default.a.translate("".concat(PREFIX, ".createNew")),
  to: "/ns/".concat(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_12__["getCurrentNamespace"])(), "/experiments/create")
}];

var getAlgoDistribution = function getAlgoDistribution(models) {
  if (!models.length) {
    return [];
  }

  var modelsMap = {};
  models.forEach(function (model) {
    var algo = model.algorithm;

    if (!algo) {
      return;
    }

    if (!modelsMap[algo]) {
      modelsMap = _objectSpread({}, modelsMap, _defineProperty({}, algo, {
        value: algo,
        count: 1,
        color: colorScale(algo)
      }));
    } else {
      modelsMap = _objectSpread({}, modelsMap, _defineProperty({}, algo, _objectSpread({}, modelsMap[algo], {
        count: modelsMap[algo].count + 1
      })));
    }
  });
  return Object.keys(modelsMap).map(function (m) {
    return modelsMap[m];
  });
};

var renderGrid = function renderGrid(experiments, sortMethod, sortColumn) {
  var list = experiments.map(function (entity) {
    var models = entity.models || [];
    var modelsCount = entity.modelsCount;
    return {
      name: entity.name,
      description: entity.description,
      numOfModels: modelsCount,
      numOfDeployedModels: models.filter(function (model) {
        return model.deploytime;
      }).length,
      testData: entity.srcpath.split('/').pop(),
      algorithmTypes: getAlgoDistribution(models)
    };
  });

  var renderSortIcon = function renderSortIcon(sortMethod) {
    return sortMethod === 'asc' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_15__["default"], {
      name: "icon-caret-down"
    }) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_15__["default"], {
      name: "icon-caret-up"
    });
  };

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid grid-container"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-header"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-row"
  }, tableHeaders.map(function (header, i) {
    if (sortColumn === header.property) {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", {
        className: "sortable-header",
        key: i,
        onClick: components_Experiments_store_ExperimentsListActionCreator__WEBPACK_IMPORTED_MODULE_14__["handleExperimentsSort"].bind(null, header.property)
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, header.label), renderSortIcon(sortMethod));
    }

    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", {
      key: i
    }, header.label);
  }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-body"
  }, list.map(function (experiment) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_13__["Link"], {
      to: "/ns/".concat(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_12__["getCurrentNamespace"])(), "/experiments/").concat(experiment.name),
      className: "grid-row grid-link",
      key: experiment.name
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h5", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
      className: "experiment-list-name"
    }, experiment.name)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
      className: "experiment-list-description"
    }, experiment.description)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, experiment.numOfModels), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, !experiment.algorithmTypes.length ? '--' : // This is to align with empty content beneath if happens.
    react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PieChart__WEBPACK_IMPORTED_MODULE_5__["default"], {
      data: experiment.algorithmTypes,
      translateX: 15,
      translateY: 25
    })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, experiment.testData));
  })));
};

var getDataForGroupedChart = function getDataForGroupedChart(experiments) {
  if (!experiments.length) {
    return null;
  }

  var data = [];
  experiments.map(function (experiment) {
    data.push({
      name: experiment.name,
      type: 'Models',
      count: Array.isArray(experiment.models) ? experiment.models.length : 0
    });
  });
  return data;
};

function ExperimentsListView(_ref) {
  var props = _extends({}, _ref);

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, ExperimentsListViewContent(props), props.error ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Alert__WEBPACK_IMPORTED_MODULE_16__["default"], {
    message: props.error,
    type: "error",
    showAlert: true,
    onClose: components_Experiments_store_ExperimentsListActionCreator__WEBPACK_IMPORTED_MODULE_14__["setExperimentsListError"]
  }) : null);
}

ExperimentsListView.propTypes = {
  error: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.any
};

function ExperimentsListViewContent(_ref2) {
  var loading = _ref2.loading,
      list = _ref2.list,
      totalPages = _ref2.totalPages,
      currentPage = _ref2.currentPage,
      totalCount = _ref2.totalCount,
      sortMethod = _ref2.sortMethod,
      sortColumn = _ref2.sortColumn;

  if (loading) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_3__["default"], null);
  }

  var _NamespaceStore$getSt = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_12__["default"].getState(),
      namespace = _NamespaceStore$getSt.selectedNamespace;

  var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_18__["Theme"].featureNames.analytics;

  if (!list.length) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
      className: "experiments-listview"
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_TopPanel__WEBPACK_IMPORTED_MODULE_4__["default"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h4", null, featureName, " - All Experiments"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PlusButton__WEBPACK_IMPORTED_MODULE_9__["default"], {
      mode: components_PlusButton__WEBPACK_IMPORTED_MODULE_9__["default"].MODE.resourcecenter,
      contextItems: PLUSBUTTONCONTEXTMENUITEMS
    })), totalPages ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_ListView_InvalidPageView__WEBPACK_IMPORTED_MODULE_10__["default"], {
      namespace: namespace
    }) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_ListView_EmptyListView__WEBPACK_IMPORTED_MODULE_11__["default"], {
      namespace: namespace
    }));
  }

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "experiments-listview"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_TopPanel__WEBPACK_IMPORTED_MODULE_4__["default"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h4", null, featureName, " - All Experiments"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PlusButton__WEBPACK_IMPORTED_MODULE_9__["default"], {
    mode: components_PlusButton__WEBPACK_IMPORTED_MODULE_9__["default"].MODE.resourcecenter,
    contextItems: PLUSBUTTONCONTEXTMENUITEMS
  })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_ListView_ExperimentsListBarChart__WEBPACK_IMPORTED_MODULE_8__["default"], {
    data: getDataForGroupedChart(list)
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "clearfix"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_PaginationWithTitle__WEBPACK_IMPORTED_MODULE_6__["default"], {
    handlePageChange: components_Experiments_store_ExperimentsListActionCreator__WEBPACK_IMPORTED_MODULE_14__["handlePageChange"],
    currentPage: currentPage,
    totalPages: totalPages,
    title: i18n_react__WEBPACK_IMPORTED_MODULE_17___default.a.translate("".concat(PREFIX, ".experiments"), {
      context: totalCount
    })
  })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "grid-wrapper"
  }, renderGrid(list, sortMethod, sortColumn)));
}

ExperimentsListViewContent.propTypes = {
  loading: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  list: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object),
  totalPages: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  currentPage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  totalCount: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  sortMethod: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  sortColumn: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    loading: state.experiments.loading,
    list: state.experiments.list,
    totalPages: state.experiments.totalPages,
    currentPage: state.experiments.offset === 0 ? 1 : Math.ceil((state.experiments.offset + 1) / state.experiments.limit),
    totalCount: state.experiments.totalCount,
    sortMethod: state.experiments.sortMethod,
    sortColumn: state.experiments.sortColumn,
    error: state.experiments.error
  };
};

var ExperimentsListViewWrapper = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps)(ExperimentsListView);
/* harmony default export */ __webpack_exports__["default"] = (ExperimentsListViewWrapper);

/***/ }),

/***/ "./components/Experiments/ListView/index.js":
/*!**************************************************!*\
  !*** ./components/Experiments/ListView/index.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ExperimentsList; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-helmet */ "../../node_modules/react-helmet/lib/Helmet.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Experiments_ListView_ListViewWrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Experiments/ListView/ListViewWrapper */ "./components/Experiments/ListView/ListViewWrapper.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Experiments_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/store */ "./components/Experiments/store/index.js");
/* harmony import */ var components_Experiments_store_ExperimentsListActionCreator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Experiments/store/ExperimentsListActionCreator */ "./components/Experiments/store/ExperimentsListActionCreator.js");
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! query-string */ "../../node_modules/query-string/index.js");
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(query_string__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash/isNil */ "../../node_modules/lodash/isNil.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_isNil__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! mousetrap */ "../../node_modules/mousetrap/mousetrap.js");
/* harmony import */ var mousetrap__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(mousetrap__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */











var PREFIX = 'features.Experiments.ListView';

var ExperimentsList =
/*#__PURE__*/
function (_Component) {
  _inherits(ExperimentsList, _Component);

  function ExperimentsList() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ExperimentsList);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ExperimentsList)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "goToNextPage", function () {
      var _experimentsStore$get = components_Experiments_store__WEBPACK_IMPORTED_MODULE_4__["default"].getState().experiments,
          offset = _experimentsStore$get.offset,
          limit = _experimentsStore$get.limit,
          totalPages = _experimentsStore$get.totalPages;
      var nextPage = offset === 0 ? 1 : Math.ceil((offset + 1) / limit);

      if (nextPage < totalPages) {
        Object(components_Experiments_store_ExperimentsListActionCreator__WEBPACK_IMPORTED_MODULE_5__["handlePageChange"])({
          selected: nextPage
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "goToPreviousPage", function () {
      var _experimentsStore$get2 = components_Experiments_store__WEBPACK_IMPORTED_MODULE_4__["default"].getState().experiments,
          offset = _experimentsStore$get2.offset,
          limit = _experimentsStore$get2.limit;
      var prevPage = offset === 0 ? 1 : Math.ceil((offset + 1) / limit);

      if (prevPage > 1) {
        Object(components_Experiments_store_ExperimentsListActionCreator__WEBPACK_IMPORTED_MODULE_5__["handlePageChange"])({
          selected: prevPage - 2
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "parseUrlAndUpdateStore", function (nextProps) {
      var props = nextProps || _this.props;

      var _this$getQueryObject = _this.getQueryObject(query_string__WEBPACK_IMPORTED_MODULE_6___default.a.parse(props.location.search)),
          offset = _this$getQueryObject.offset,
          limit = _this$getQueryObject.limit,
          sortMethod = _this$getQueryObject.sortMethod,
          sortColumn = _this$getQueryObject.sortColumn;

      Object(components_Experiments_store_ExperimentsListActionCreator__WEBPACK_IMPORTED_MODULE_5__["updateQueryParameters"])({
        offset: offset,
        limit: limit,
        sortMethod: sortMethod,
        sortColumn: sortColumn
      });
    });

    _defineProperty(_assertThisInitialized(_this), "getQueryObject", function (query) {
      if (lodash_isNil__WEBPACK_IMPORTED_MODULE_7___default()(query)) {
        return {};
      }

      var _query$offset = query.offset,
          offset = _query$offset === void 0 ? components_Experiments_store__WEBPACK_IMPORTED_MODULE_4__["DEFAULT_EXPERIMENTS"].offset : _query$offset,
          _query$limit = query.limit,
          limit = _query$limit === void 0 ? components_Experiments_store__WEBPACK_IMPORTED_MODULE_4__["DEFAULT_EXPERIMENTS"].limit : _query$limit,
          sort = query.sort;
      var sortMethod, sortColumn;
      offset = parseInt(offset, 10);
      limit = parseInt(limit, 10);

      if (isNaN(offset)) {
        offset = components_Experiments_store__WEBPACK_IMPORTED_MODULE_4__["DEFAULT_EXPERIMENTS"].offset;
      }

      if (isNaN(limit)) {
        limit = components_Experiments_store__WEBPACK_IMPORTED_MODULE_4__["DEFAULT_EXPERIMENTS"].limit;
      }

      if (!sort) {
        sortMethod = components_Experiments_store__WEBPACK_IMPORTED_MODULE_4__["MMDS_SORT_METHODS"].ASC;
        sortColumn = components_Experiments_store__WEBPACK_IMPORTED_MODULE_4__["MMDS_SORT_COLUMN"];
      } else {
        var sortSplit = sort.split(' ');
        sortColumn = sortSplit[0] || components_Experiments_store__WEBPACK_IMPORTED_MODULE_4__["MMDS_SORT_COLUMN"];
        sortMethod = sortSplit[1] || components_Experiments_store__WEBPACK_IMPORTED_MODULE_4__["MMDS_SORT_METHODS"].ASC;
      }

      return {
        offset: offset,
        limit: limit,
        sortMethod: sortMethod,
        sortColumn: sortColumn
      };
    });

    return _this;
  }

  _createClass(ExperimentsList, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      Object(components_Experiments_store_ExperimentsListActionCreator__WEBPACK_IMPORTED_MODULE_5__["setAlgorithmsListForListView"])();
      mousetrap__WEBPACK_IMPORTED_MODULE_8___default.a.bind('right', this.goToNextPage);
      mousetrap__WEBPACK_IMPORTED_MODULE_8___default.a.bind('left', this.goToPreviousPage);
      this.parseUrlAndUpdateStore();
      Object(components_Experiments_store_ExperimentsListActionCreator__WEBPACK_IMPORTED_MODULE_5__["getExperimentsList"])();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      mousetrap__WEBPACK_IMPORTED_MODULE_8___default.a.unbind('left');
      mousetrap__WEBPACK_IMPORTED_MODULE_8___default.a.unbind('right');
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.parseUrlAndUpdateStore(nextProps);
      Object(components_Experiments_store_ExperimentsListActionCreator__WEBPACK_IMPORTED_MODULE_5__["getExperimentsList"])();
    }
  }, {
    key: "render",
    value: function render() {
      var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__["Theme"].featureNames.analytics;
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_redux__WEBPACK_IMPORTED_MODULE_3__["Provider"], {
        store: components_Experiments_store__WEBPACK_IMPORTED_MODULE_4__["default"]
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "experiments-list-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_helmet__WEBPACK_IMPORTED_MODULE_1___default.a, {
        title: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".pageTitle"), {
          productName: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_10__["Theme"].productName,
          featureName: featureName
        })
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Experiments_ListView_ListViewWrapper__WEBPACK_IMPORTED_MODULE_2__["default"], null)));
    }
  }]);

  return ExperimentsList;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);



/***/ }),

/***/ "./components/Experiments/TopPanel/TopPanel.scss":
/*!*******************************************************!*\
  !*** ./components/Experiments/TopPanel/TopPanel.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./TopPanel.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/TopPanel/TopPanel.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/TopPanel/index.js":
/*!**************************************************!*\
  !*** ./components/Experiments/TopPanel/index.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TopPanel; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




__webpack_require__(/*! ./TopPanel.scss */ "./components/Experiments/TopPanel/TopPanel.scss");

function TopPanel(_ref) {
  var message = _ref.message,
      children = _ref.children,
      className = _ref.className;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()('experiments-toppanel', className)
  }, children ? children : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h4", null, message));
}
TopPanel.propTypes = {
  message: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  children: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.node,
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

/***/ }),

/***/ "./components/Experiments/index.js":
/*!*****************************************!*\
  !*** ./components/Experiments/index.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Experiments; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var api_experiments__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! api/experiments */ "./api/experiments.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-loadable */ "../../node_modules/react-loadable/lib/index.js");
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_loadable__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/LoadingSVGCentered */ "./components/LoadingSVGCentered/index.js");
/* harmony import */ var components_Experiments_ExperimentsServiceControl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Experiments/ExperimentsServiceControl */ "./components/Experiments/ExperimentsServiceControl/index.js");
/* harmony import */ var components_Experiments_ListView__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Experiments/ListView */ "./components/Experiments/ListView/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








var ExperimentsCreateView = react_loadable__WEBPACK_IMPORTED_MODULE_3___default()({
  loader: function loader() {
    return __webpack_require__.e(/*! import() | ExperimentsCreateView */ "ExperimentsCreateView").then(__webpack_require__.bind(null, /*! components/Experiments/CreateView */ "./components/Experiments/CreateView/index.js"));
  },
  loading: components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_5__["default"]
});
var ExperimentDetailedView = react_loadable__WEBPACK_IMPORTED_MODULE_3___default()({
  loader: function loader() {
    return __webpack_require__.e(/*! import() | ExperimentsDetailedView */ "ExperimentsDetailedView").then(__webpack_require__.bind(null, /*! components/Experiments/DetailedView */ "./components/Experiments/DetailedView/index.js"));
  },
  loading: components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_5__["default"]
});

var Experiments =
/*#__PURE__*/
function (_Component) {
  _inherits(Experiments, _Component);

  function Experiments() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, Experiments);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(Experiments)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      loading: true,
      isRunning: false
    });

    _defineProperty(_assertThisInitialized(_this), "checkIfMMDSRunning", function () {
      var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__["getCurrentNamespace"])();
      api_experiments__WEBPACK_IMPORTED_MODULE_1__["myExperimentsApi"].list({
        namespace: namespace
      }).subscribe(function () {
        _this.setState({
          loading: false,
          isRunning: true
        });
      }, function () {
        _this.setState({
          loading: false,
          isRunning: false
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "onServiceStart", function () {
      _this.setState({
        loading: false,
        isRunning: true
      });
    });

    return _this;
  }

  _createClass(Experiments, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      this.checkIfMMDSRunning();
    }
  }, {
    key: "renderLoading",
    value: function renderLoading() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_5__["default"], null);
    }
  }, {
    key: "render",
    value: function render() {
      if (this.state.loading) {
        return this.renderLoading();
      }

      if (!this.state.isRunning) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Experiments_ExperimentsServiceControl__WEBPACK_IMPORTED_MODULE_6__["default"], {
          onServiceStart: this.onServiceStart
        });
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Switch"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
        exact: true,
        path: "/ns/:namespace/experiments",
        component: components_Experiments_ListView__WEBPACK_IMPORTED_MODULE_7__["default"]
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
        exact: true,
        path: "/ns/:namespace/experiments/create",
        component: ExperimentsCreateView
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
        exact: true,
        path: "/ns/:namespace/experiments/:experimentId",
        component: ExperimentDetailedView
      })));
    }
  }]);

  return Experiments;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);



/***/ }),

/***/ "./components/Experiments/store/AlgorithmsListStore.js":
/*!*************************************************************!*\
  !*** ./components/Experiments/store/AlgorithmsListStore.js ***!
  \*************************************************************/
/*! exports provided: ACTIONS, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTIONS", function() { return ACTIONS; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var DEFAULT_ALGORITHMS = [];
var ACTIONS = {
  SET_ALGORITHMS_LIST: 'SET_ALGORITHMS_LIST'
};

var algorithmsList = function algorithmsList() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_ALGORITHMS;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ACTIONS.SET_ALGORITHMS_LIST:
      return action.payload.algorithmsList || state;

    default:
      return state;
  }
};

var algorithmsStore = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(algorithmsList, DEFAULT_ALGORITHMS, Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["composeEnhancers"])('ALGORITHMS_STORE')());
/* harmony default export */ __webpack_exports__["default"] = (algorithmsStore);

/***/ }),

/***/ "./components/Experiments/store/ExperimentsListActionCreator.js":
/*!**********************************************************************!*\
  !*** ./components/Experiments/store/ExperimentsListActionCreator.js ***!
  \**********************************************************************/
/*! exports provided: setExperimentsListError, getExperimentsList, getModelsListInExperiment, handlePageChange, handleExperimentsSort, setAlgorithmsListForListView, updateQueryParameters */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setExperimentsListError", function() { return setExperimentsListError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getExperimentsList", function() { return getExperimentsList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getModelsListInExperiment", function() { return getModelsListInExperiment; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "handlePageChange", function() { return handlePageChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "handleExperimentsSort", function() { return handleExperimentsSort; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setAlgorithmsListForListView", function() { return setAlgorithmsListForListView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateQueryParameters", function() { return updateQueryParameters; });
/* harmony import */ var components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! components/Experiments/store */ "./components/Experiments/store/index.js");
/* harmony import */ var components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/Experiments/store/SharedActionCreator */ "./components/Experiments/store/SharedActionCreator.js");
/* harmony import */ var api_experiments__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! api/experiments */ "./api/experiments.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





function setExperimentsLoading() {
  components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENTS_LOADING
  });
}

function setExperimentsListError() {
  var error = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
  components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_ERROR,
    payload: {
      error: error
    }
  });
}

function getExperimentsList() {
  setExperimentsLoading();
  var _experimentsStore$get = components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["default"].getState().experiments,
      offset = _experimentsStore$get.offset,
      limit = _experimentsStore$get.limit,
      sortMethod = _experimentsStore$get.sortMethod,
      sortColumn = _experimentsStore$get.sortColumn;
  api_experiments__WEBPACK_IMPORTED_MODULE_2__["myExperimentsApi"].list({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])(),
    offset: offset,
    limit: limit,
    sort: "".concat(sortColumn, " ").concat(sortMethod)
  }).subscribe(function (res) {
    var experiments = res.experiments,
        totalCount = res.totalRowCount;
    experiments.forEach(function (experiment) {
      return getModelsListInExperiment(experiment.name);
    });
    components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENTS_LIST,
      payload: {
        experiments: experiments,
        totalCount: totalCount
      }
    });
  }, function (err) {
    setExperimentsListError("Failed to get experiments: ".concat(err.response || err));
  });
}

function getModelsListInExperiment(experimentId) {
  api_experiments__WEBPACK_IMPORTED_MODULE_2__["myExperimentsApi"].getModelsInExperiment({
    experimentId: experimentId,
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])()
  }).subscribe(function (res) {
    var models = res.models,
        modelsCount = res.totalRowCount;
    components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODELS_IN_EXPERIMENT,
      payload: {
        experimentId: experimentId,
        models: models,
        modelsCount: modelsCount
      }
    });
  }, function (err) {
    setExperimentsListError("Failed to get model count for the experiment '".concat(experimentId, "' - ").concat(err.response || err));
  });
}

function handlePageChange(_ref) {
  var selected = _ref.selected;
  var limit = components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["default"].getState().experiments.limit;
  components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_PAGINATION,
    payload: {
      offset: selected * limit
    }
  });
  updateQueryString();
  getExperimentsList();
}

function handleExperimentsSort(field) {
  var _experimentsStore$get2 = components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["default"].getState().experiments,
      sortColumn = _experimentsStore$get2.sortColumn,
      sortMethod = _experimentsStore$get2.sortMethod;
  var newSortField = field !== sortColumn ? field : sortColumn;
  var newSortMethod = components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["MMDS_SORT_METHODS"].ASC === sortMethod ? components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["MMDS_SORT_METHODS"].DESC : components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["MMDS_SORT_METHODS"].ASC;
  components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENTS_SORT,
    payload: {
      sortMethod: newSortMethod,
      sortColumn: newSortField
    }
  });
  updateQueryString();
  getExperimentsList();
}

var setAlgorithmsListForListView = function setAlgorithmsListForListView() {
  Object(components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_1__["setAlgorithmsList"])().subscribe(function () {}, function (err) {
    setExperimentsListError("Failed to get list of algorithms: ".concat(err.response || err));
  });
};

function updateQueryParameters(_ref2) {
  var limit = _ref2.limit,
      offset = _ref2.offset,
      sortMethod = _ref2.sortMethod,
      sortColumn = _ref2.sortColumn;
  components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_QUERY_PARAMS,
    payload: {
      limit: limit,
      offset: offset,
      sortMethod: sortMethod,
      sortColumn: sortColumn
    }
  });
}

function updateQueryString() {
  var _experimentsStore$get3 = components_Experiments_store__WEBPACK_IMPORTED_MODULE_0__["default"].getState().experiments,
      offset = _experimentsStore$get3.offset,
      limit = _experimentsStore$get3.limit,
      sortMethod = _experimentsStore$get3.sortMethod,
      sortColumn = _experimentsStore$get3.sortColumn;
  var newQuery = "offset=".concat(offset, "&limit=").concat(limit, "&sort=").concat(sortColumn, " ").concat(sortMethod);
  var obj = {
    title: document.title,
    url: "".concat(location.pathname, "?").concat(newQuery)
  };
  history.pushState(obj, obj.title, obj.url);
}



/***/ }),

/***/ "./components/Experiments/store/SharedActionCreator.js":
/*!*************************************************************!*\
  !*** ./components/Experiments/store/SharedActionCreator.js ***!
  \*************************************************************/
/*! exports provided: getAlgorithmLabel, getHyperParamLabel, setAlgorithmsList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAlgorithmLabel", function() { return getAlgorithmLabel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getHyperParamLabel", function() { return getHyperParamLabel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setAlgorithmsList", function() { return setAlgorithmsList; });
/* harmony import */ var api_experiments__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! api/experiments */ "./api/experiments.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var components_Experiments_store_AlgorithmsListStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Experiments/store/AlgorithmsListStore */ "./components/Experiments/store/AlgorithmsListStore.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var getAlgorithmLabel = function getAlgorithmLabel(algorithm) {
  var algorithmsList = components_Experiments_store_AlgorithmsListStore__WEBPACK_IMPORTED_MODULE_2__["default"].getState();
  var match = algorithmsList.find(function (algo) {
    return algo.name === algorithm;
  });

  if (match) {
    return match.label;
  }

  return algorithm;
};

var getHyperParamLabel = function getHyperParamLabel(algorithm, hyperparam) {
  var algorithmsList = components_Experiments_store_AlgorithmsListStore__WEBPACK_IMPORTED_MODULE_2__["default"].getState();
  var match = algorithmsList.find(function (algo) {
    return algo.name === algorithm;
  });

  if (match) {
    var matchingHyperParameter = match.hyperparameters.find(function (hp) {
      return hp.name === hyperparam;
    });

    if (matchingHyperParameter) {
      return matchingHyperParameter.label;
    }
  }

  return hyperparam;
};

var setAlgorithmsList = function setAlgorithmsList() {
  var algoList = components_Experiments_store_AlgorithmsListStore__WEBPACK_IMPORTED_MODULE_2__["default"].getState();

  if (algoList.length) {
    return rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__["Observable"].of();
  }

  var getAlgorithmsApi = api_experiments__WEBPACK_IMPORTED_MODULE_0__["myExperimentsApi"].getAlgorithms({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__["getCurrentNamespace"])()
  });
  getAlgorithmsApi.subscribe(function (algorithmsList) {
    algorithmsList = algorithmsList.map(function (algo) {
      return _objectSpread({}, algo, {
        name: algo.algorithm
      });
    });
    components_Experiments_store_AlgorithmsListStore__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
      type: components_Experiments_store_AlgorithmsListStore__WEBPACK_IMPORTED_MODULE_2__["ACTIONS"].SET_ALGORITHMS_LIST,
      payload: {
        algorithmsList: algorithmsList
      }
    });
  });
  return getAlgorithmsApi;
};



/***/ }),

/***/ "./components/Experiments/store/index.js":
/*!***********************************************!*\
  !*** ./components/Experiments/store/index.js ***!
  \***********************************************/
/*! exports provided: MMDS_SORT_METHODS, MMDS_SORT_COLUMN, DEFAULT_EXPERIMENTS, default, ACTIONS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MMDS_SORT_METHODS", function() { return MMDS_SORT_METHODS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MMDS_SORT_COLUMN", function() { return MMDS_SORT_COLUMN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_EXPERIMENTS", function() { return DEFAULT_EXPERIMENTS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTIONS", function() { return ACTIONS; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var ACTIONS = {
  SET_EXPERIMENTS_LIST: 'SET_EXPERIMENTS_LIST',
  SET_EXPERIMENTS_LOADING: 'SET_EXPERIMENTS_LOADING',
  SET_MODELS_IN_EXPERIMENT: 'SET_MODELS_IN_EXPERIMENT',
  SET_EXPERIMENTS_SORT: 'SET_EXPERIMENTS_SORT',
  SET_QUERY_PARAMS: 'SET_QUERY_PARAMS',
  SET_PAGINATION: 'SET_PAGINATION',
  SET_ERROR: 'SET_ERROR'
};
var MMDS_SORT_METHODS = {
  ASC: 'asc',
  DESC: 'desc'
};
var MMDS_SORT_COLUMN = 'name';
var DEFAULT_EXPERIMENTS = {
  list: [],
  offset: 0,
  sortMethod: MMDS_SORT_METHODS.ASC,
  sortColumn: MMDS_SORT_COLUMN,
  totalPages: 0,
  totalCount: 0,
  limit: 10,
  loading: false,
  modelsCount: 0,
  error: null
};

var experiments = function experiments() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_EXPERIMENTS;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ACTIONS.SET_EXPERIMENTS_LIST:
      return _objectSpread({}, state, {
        list: action.payload.experiments,
        totalPages: Math.ceil(action.payload.totalCount / state.limit),
        totalCount: action.payload.totalCount,
        loading: false
      });

    case ACTIONS.SET_PAGINATION:
      return _objectSpread({}, state, {
        offset: action.payload.offset
      });

    case ACTIONS.SET_EXPERIMENTS_LOADING:
      return _objectSpread({}, state, {
        loading: true
      });

    case ACTIONS.SET_MODELS_IN_EXPERIMENT:
      return _objectSpread({}, state, {
        list: state.list.map(function (experiment) {
          if (experiment.name === action.payload.experimentId) {
            return _objectSpread({}, experiment, {
              models: action.payload.models,
              modelsCount: action.payload.modelsCount
            });
          }

          return experiment;
        })
      });

    case ACTIONS.SET_EXPERIMENTS_SORT:
      return _objectSpread({}, state, {
        sortMethod: action.payload.sortMethod,
        sortColumn: action.payload.sortColumn
      });

    case ACTIONS.SET_QUERY_PARAMS:
      return _objectSpread({}, state, {
        sortMethod: action.payload.sortMethod,
        sortColumn: action.payload.sortColumn,
        offset: action.payload.offset
      });

    case ACTIONS.SET_ERROR:
      return _objectSpread({}, state, {
        error: action.payload.error
      });

    default:
      return state;
  }
};

var store = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  experiments: experiments
}), {
  experiments: DEFAULT_EXPERIMENTS
}, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__());
/* harmony default export */ __webpack_exports__["default"] = (store);


/***/ }),

/***/ "./components/GroupedBarChart/index.js":
/*!*********************************************!*\
  !*** ./components/GroupedBarChart/index.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return GroupedBarChart; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_VegaLiteChart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/VegaLiteChart */ "./components/VegaLiteChart/index.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */



var chartSpec = {
  data: {
    values: []
  },
  mark: 'bar',
  encoding: {
    column: {
      field: 'name',
      type: 'ordinal'
    },
    y: {
      field: 'count',
      type: 'quantitative',
      axis: {
        title: 'Count',
        grid: false
      }
    },
    x: {
      field: 'type',
      type: 'nominal',
      axis: {
        title: ''
      }
    },
    color: {
      field: 'type',
      type: 'nominal'
    }
  },
  config: {
    view: {
      stroke: 'transparent'
    }
  }
};
function GroupedBarChart(_ref) {
  var data = _ref.data,
      _ref$customEncoding = _ref.customEncoding,
      customEncoding = _ref$customEncoding === void 0 ? {} : _ref$customEncoding,
      width = _ref.width,
      heightOffset = _ref.heightOffset,
      tooltipOptions = _ref.tooltipOptions;

  var newSpec = _objectSpread({}, chartSpec, {
    encoding: _objectSpread({}, chartSpec.encoding, {}, customEncoding)
  });

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_VegaLiteChart__WEBPACK_IMPORTED_MODULE_2__["default"], {
    spec: newSpec,
    data: data,
    className: "grouped-bar-chart",
    width: width,
    heightOffset: heightOffset,
    tooltipOptions: tooltipOptions
  });
} // TODO: Should have options to change axis style. Right now customEncoding has to provide everything.
// Might be useful if we could identify just the props that we will be changing

GroupedBarChart.propTypes = {
  data: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    name: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    count: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number
  })).isRequired,
  customEncoding: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  width: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func]),
  heightOffset: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  tooltipOptions: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
};

/***/ }),

/***/ "./components/PaginationWithTitle/PaginationWithTitle.scss":
/*!*****************************************************************!*\
  !*** ./components/PaginationWithTitle/PaginationWithTitle.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./PaginationWithTitle.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/PaginationWithTitle/PaginationWithTitle.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/PaginationWithTitle/index.js":
/*!*************************************************!*\
  !*** ./components/PaginationWithTitle/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PaginationWithTitle; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_paginate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-paginate */ "../../node_modules/react-paginate/dist/index.js");
/* harmony import */ var react_paginate__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_paginate__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




__webpack_require__(/*! ./PaginationWithTitle.scss */ "./components/PaginationWithTitle/PaginationWithTitle.scss");

var PaginationWithTitle =
/*#__PURE__*/
function (_Component) {
  _inherits(PaginationWithTitle, _Component);

  function PaginationWithTitle() {
    _classCallCheck(this, PaginationWithTitle);

    return _possibleConstructorReturn(this, _getPrototypeOf(PaginationWithTitle).apply(this, arguments));
  }

  _createClass(PaginationWithTitle, [{
    key: "renderPaginationComponent",
    value: function renderPaginationComponent() {
      if (this.props.totalPages < 2) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react_paginate__WEBPACK_IMPORTED_MODULE_1___default.a, {
        pageCount: this.props.totalPages,
        pageRangeDisplayed: 3,
        marginPagesDisplayed: 1,
        breakLabel: react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("span", null, "..."),
        breakClassName: 'ellipsis',
        previousLabel: react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("span", {
          className: "fa fa-angle-left"
        }),
        nextLabel: react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("span", {
          className: "fa fa-angle-right"
        }),
        onPageChange: this.props.handlePageChange.bind(this),
        disableInitialCallback: true,
        initialPage: this.props.currentPage - 1,
        forcePage: this.props.currentPage - 1,
        containerClassName: 'page-list',
        activeClassName: 'current-page'
      });
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("span", {
        className: "pagination-with-title"
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("ul", {
        className: "total-entities"
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("span", null, this.props.title)), this.renderPaginationComponent());
    }
  }]);

  return PaginationWithTitle;
}(react__WEBPACK_IMPORTED_MODULE_2__["Component"]);

_defineProperty(PaginationWithTitle, "propTypes", {
  currentPage: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  totalPages: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  title: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  handlePageChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
});



/***/ }),

/***/ "./components/PieChart/index.js":
/*!**************************************!*\
  !*** ./components/PieChart/index.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PieChart; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var d3__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! d3 */ "../../node_modules/d3/index.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/isNil */ "../../node_modules/lodash/isNil.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_isNil__WEBPACK_IMPORTED_MODULE_4__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var PieChart =
/*#__PURE__*/
function (_Component) {
  _inherits(PieChart, _Component);

  function PieChart() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, PieChart);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(PieChart)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      data: _this.props.data,
      id: "pie-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_3___default()())
    });

    _defineProperty(_assertThisInitialized(_this), "drawPie", function () {
      if (lodash_isNil__WEBPACK_IMPORTED_MODULE_4___default()(_this.state.data) || Array.isArray(_this.state.data) && !_this.state.data.length) {
        return;
      }

      var svg = d3__WEBPACK_IMPORTED_MODULE_2__["select"]("#".concat(_this.state.id, " svg")),
          width = +svg.attr('width'),
          height = +svg.attr('height'),
          radius = Math.min(width, height) / 2,
          translateX = _this.props.translateX || width / 2,
          translateY = _this.props.translateY || height / 2,
          g = svg.append('g').attr('transform', 'translate(' + translateX + ',' + translateY + ')');
      var pie = d3__WEBPACK_IMPORTED_MODULE_2__["pie"]().sort(null).value(function (d) {
        return d.count;
      });
      var path = d3__WEBPACK_IMPORTED_MODULE_2__["arc"]().outerRadius(radius - 10).innerRadius(0);
      var arc = g.selectAll('.arc').data(pie(_this.state.data)).enter().append('g').attr('class', 'arc');
      arc.append('title').text(function (d) {
        return "".concat(d.data.value, " (").concat(d.data.count, ")");
      });
      arc.append('path').attr('d', path).attr('fill', function (d) {
        return d.data.color;
      });
    });

    return _this;
  }

  _createClass(PieChart, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.drawPie();
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.setState({
        data: nextProps.data
      }, this.drawPie);
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        id: this.state.id
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("svg", {
        width: this.props.width || '50',
        height: this.props.height || '50'
      }));
    }
  }]);

  return PieChart;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(PieChart, "propTypes", {
  data: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    color: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    value: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
  })),
  width: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  height: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  translateX: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  translateY: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number
});



/***/ }),

/***/ "./components/VegaLiteChart/VegaLiteChart.scss":
/*!*****************************************************!*\
  !*** ./components/VegaLiteChart/VegaLiteChart.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./VegaLiteChart.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/VegaLiteChart/VegaLiteChart.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/VegaLiteChart/index.js":
/*!*******************************************!*\
  !*** ./components/VegaLiteChart/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return VegaLiteChart; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vega_lite__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vega-lite */ "../../node_modules/vega-lite/build/src/index.js");
/* harmony import */ var vega_lite__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vega_lite__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var vega__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vega */ "../../node_modules/vega/index.js");
/* harmony import */ var vega_tooltip__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vega-tooltip */ "../../node_modules/vega-tooltip/build/src/index.js");
/* harmony import */ var vega_tooltip__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(vega_tooltip__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_LoadingSVG__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/LoadingSVG */ "./components/LoadingSVG/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash/debounce */ "../../node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_7__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









__webpack_require__(/*! ./VegaLiteChart.scss */ "./components/VegaLiteChart/VegaLiteChart.scss");

var VegaLiteChart =
/*#__PURE__*/
function (_Component) {
  _inherits(VegaLiteChart, _Component);

  function VegaLiteChart() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, VegaLiteChart);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(VegaLiteChart)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      data: _this.props.data || [],
      isLoading: true,
      id: "chart-".concat(uuid_v4__WEBPACK_IMPORTED_MODULE_5___default()())
    });

    _defineProperty(_assertThisInitialized(_this), "renderChart", function (isResize) {
      if (_this.mountTimeout) {
        clearTimeout(_this.mountTimeout);
      }

      if (!isResize) {
        _this.setState({
          isLoading: true
        });
      }

      _this.mountTimeout = window.setTimeout(function () {
        _this.updateSpec();

        _this.runView();

        _this.setState({
          isLoading: false
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "updateSpec", function () {
      try {
        var el = document.getElementById(_this.state.id);
        var dimension = el.getBoundingClientRect();

        var vlSpec = _objectSpread({}, _this.props.spec, {
          width: dimension.width - (_this.props.widthOffset || 0),
          height: dimension.height - (_this.props.heightOffset || 0),
          data: {
            name: _this.state.id
          }
        });

        if (_this.props.width) {
          if (typeof _this.props.width === 'function') {
            vlSpec.width = _this.props.width(dimension, _this.state.data);
          } else {
            vlSpec.width = _this.props.width;
          }
        }

        var spec = vega_lite__WEBPACK_IMPORTED_MODULE_2__["compile"](vlSpec).spec;
        var runtime = vega__WEBPACK_IMPORTED_MODULE_3__["parse"](spec);
        _this.view = new vega__WEBPACK_IMPORTED_MODULE_3__["View"](runtime).logLevel(vega__WEBPACK_IMPORTED_MODULE_3__["Warn"]).initialize(el).renderer('svg').hover();

        if (_this.props.tooltipOptions && Object.keys(_this.props.tooltipOptions).length) {
          vega_tooltip__WEBPACK_IMPORTED_MODULE_4__["vega"](_this.view, _this.props.tooltipOptions);
        } else {
          vega_tooltip__WEBPACK_IMPORTED_MODULE_4__["vega"](_this.view);
        }

        _this.bindData();
      } catch (err) {
        console.log('ERROR: Failed to compile vega spec ', err);
      }
    });

    _defineProperty(_assertThisInitialized(_this), "bindData", function () {
      var data = _this.props.data;

      if (data) {
        _this.view.change(_this.state.id, vega__WEBPACK_IMPORTED_MODULE_3__["changeset"]().remove(function () {
          return true;
        }) // remove previous data
        .insert(data));
      }
    });

    _defineProperty(_assertThisInitialized(_this), "runView", function () {
      try {
        _this.view.run();
      } catch (err) {
        console.log('ERROR: Rendering view');
      }
    });

    return _this;
  }

  _createClass(VegaLiteChart, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.renderChart();
      document.body.onresize = lodash_debounce__WEBPACK_IMPORTED_MODULE_7___default()(this.renderChart, 1);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      document.body.onresize = null;
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.setState({
        data: nextProps.data || []
      }, this.renderChart.bind(this, true));
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "".concat(this.props.className, " vega-lite-chart")
      }, this.state.isLoading ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_LoadingSVG__WEBPACK_IMPORTED_MODULE_6__["default"], null) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        id: this.state.id
      }));
    }
  }]);

  return VegaLiteChart;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(VegaLiteChart, "propTypes", {
  spec: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object.isRequired,
  data: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object, prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.array]),
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  widthOffset: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  heightOffset: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  width: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func]),
  tooltipOptions: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
});



/***/ }),

/***/ "./services/CDAPComponentsVersions.js":
/*!********************************************!*\
  !*** ./services/CDAPComponentsVersions.js ***!
  \********************************************/
/*! exports provided: isSpark2Available */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSpark2Available", function() { return isSpark2Available; });
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var api_version__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! api/version */ "./api/version.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var versions = [];

var checkForSpark2 = function checkForSpark2(versions) {
  var sparkcompat = versions.find(function (component) {
    return component.name === 'sparkcompat';
  });
  return !sparkcompat || sparkcompat && sparkcompat.version.indexOf('spark2') !== -1;
};

function isSpark2Available() {
  return rxjs_Observable__WEBPACK_IMPORTED_MODULE_0__["Observable"].create(function (observer) {
    if (versions.length) {
      return observer.next(checkForSpark2(versions));
    }

    api_version__WEBPACK_IMPORTED_MODULE_1__["default"].getCDAPComponentVersions().subscribe(function (v) {
      versions = v;
      observer.next(checkForSpark2(v));
    });
  });
}

/***/ })

}]);
//# sourceMappingURL=Experiments.452654a8734c434f02d0.js.map