(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["SchemaModal"],{

/***/ "./components/DataPrep/TopPanel/SchemaModal.js":
/*!*****************************************************!*\
  !*** ./components/DataPrep/TopPanel/SchemaModal.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SchemaModal; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var components_SchemaEditor_SchemaStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/SchemaEditor/SchemaStore */ "./components/SchemaEditor/SchemaStore.js");
/* harmony import */ var components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/LoadingSVGCentered */ "./components/LoadingSVGCentered/index.js");
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-loadable */ "../../node_modules/react-loadable/lib/index.js");
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_loadable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/SchemaEditor/SchemaHelpers */ "./components/SchemaEditor/SchemaHelpers.js");
/* harmony import */ var api_dataprep__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! api/dataprep */ "./api/dataprep.js");
/* harmony import */ var components_DataPrep_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/DataPrep/store */ "./components/DataPrep/store/index.js");
/* harmony import */ var js_file_download__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! js-file-download */ "../../node_modules/js-file-download/file-download.js");
/* harmony import */ var js_file_download__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(js_file_download__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! components/DataPrep/helper */ "./components/DataPrep/helper.js");
/* harmony import */ var components_DataPrep_store_DataPrepActionCreator__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! components/DataPrep/store/DataPrepActionCreator */ "./components/DataPrep/store/DataPrepActionCreator.js");
/* harmony import */ var components_DataPrep_store_DataPrepActions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! components/DataPrep/store/DataPrepActions */ "./components/DataPrep/store/DataPrepActions.js");
/* harmony import */ var components_CardActionFeedback__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! components/CardActionFeedback */ "./components/CardActionFeedback/index.js");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


















var SchemaEditor = react_loadable__WEBPACK_IMPORTED_MODULE_5___default()({
  loader: function loader() {
    return __webpack_require__.e(/*! import() | SchemaEditor */ "SchemaEditor").then(__webpack_require__.bind(null, /*! components/SchemaEditor */ "./components/SchemaEditor/index.js"));
  },
  loading: components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_4__["default"]
});

var mapErrorToMessage = function mapErrorToMessage(e) {
  var message = e.message;

  if (message.indexOf('invalid field name') !== -1) {
    var splitMessage = e.message.split('field name: ');
    var fieldName = Object(services_helpers__WEBPACK_IMPORTED_MODULE_11__["objectQuery"])(splitMessage, 1) || e.message;
    return {
      message: i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate('features.DataPrep.TopPanel.invalidFieldNameMessage', {
        fieldName: fieldName
      }),
      remedies: "".concat(i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate('features.DataPrep.TopPanel.invalidFieldNameRemedies1'))
    };
  }

  return {
    message: e.message
  };
};

var SchemaModal =
/*#__PURE__*/
function (_Component) {
  _inherits(SchemaModal, _Component);

  function SchemaModal(props) {
    var _this;

    _classCallCheck(this, SchemaModal);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(SchemaModal).call(this, props));
    _this.state = {
      loading: true,
      error: null,
      schema: []
    };
    _this.download = _this.download.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(SchemaModal, [{
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      components_SchemaEditor_SchemaStore__WEBPACK_IMPORTED_MODULE_3__["default"].dispatch({
        type: 'RESET'
      });
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      this.getSchema();
    }
  }, {
    key: "getSchema",
    value: function getSchema() {
      var _this2 = this;

      var state = components_DataPrep_store__WEBPACK_IMPORTED_MODULE_8__["default"].getState().dataprep;
      var workspaceId = state.workspaceId;
      var namespace = services_NamespaceStore__WEBPACK_IMPORTED_MODULE_10__["default"].getState().selectedNamespace;
      var requestObj = {
        context: namespace,
        workspaceId: workspaceId
      };
      var directives = state.directives;
      var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_13__["directiveRequestBodyCreator"])(directives);
      api_dataprep__WEBPACK_IMPORTED_MODULE_7__["default"].getSchema(requestObj, requestBody).subscribe(function (res) {
        var tempSchema = {
          name: 'avroSchema',
          type: 'record',
          fields: res
        };

        try {
          Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_6__["getParsedSchemaForDataPrep"])(tempSchema);
        } catch (e) {
          var _mapErrorToMessage = mapErrorToMessage(e),
              message = _mapErrorToMessage.message,
              _mapErrorToMessage$re = _mapErrorToMessage.remedies,
              remedies = _mapErrorToMessage$re === void 0 ? null : _mapErrorToMessage$re;

          _this2.setState({
            error: {
              message: message,
              remedies: remedies
            },
            loading: false
          });
        }

        components_SchemaEditor_SchemaStore__WEBPACK_IMPORTED_MODULE_3__["default"].dispatch({
          type: 'FIELD_UPDATE',
          payload: {
            schema: tempSchema
          }
        });

        _this2.setState({
          loading: false,
          schema: res
        });
      }, function (err) {
        _this2.setState({
          loading: false,
          error: Object(services_helpers__WEBPACK_IMPORTED_MODULE_11__["objectQuery"])(err, 'response', 'message') || i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate('features.DataPrep.TopPanel.SchemaModal.defaultErrorMessage')
        });
      });
    }
  }, {
    key: "applyDirective",
    value: function applyDirective(directive) {
      var _this3 = this;

      Object(components_DataPrep_store_DataPrepActionCreator__WEBPACK_IMPORTED_MODULE_14__["execute"])([directive]).subscribe(function () {
        _this3.setState({
          error: null,
          loading: true,
          schema: []
        });

        setTimeout(function () {
          _this3.getSchema();
        });
      }, function (err) {
        console.log('Error', err);
        components_DataPrep_store__WEBPACK_IMPORTED_MODULE_8__["default"].dispatch({
          type: components_DataPrep_store_DataPrepActions__WEBPACK_IMPORTED_MODULE_15__["default"].setError,
          payload: {
            message: err.message || err.response.message
          }
        });
      });
    }
  }, {
    key: "download",
    value: function download() {
      var workspaceId = components_DataPrep_store__WEBPACK_IMPORTED_MODULE_8__["default"].getState().dataprep.workspaceId;
      var filename = "".concat(workspaceId, "-schema.json");
      var fields = this.state.schema; // TODO: Change this when we make UI schema consistent with backend schema (JIRA: CDAP-13010)

      var data = JSON.stringify([Object(components_SchemaEditor_SchemaHelpers__WEBPACK_IMPORTED_MODULE_6__["getSchemaObjFromFieldsArray"])(fields)], null, 4);
      js_file_download__WEBPACK_IMPORTED_MODULE_9___default()(data, filename);
    }
  }, {
    key: "render",
    value: function render() {
      var content;

      if (this.state.loading) {
        content = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "text-center"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h4", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "fa fa-spin fa-spinner"
        })));
      } else if (this.state.error) {
        content = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "remedy-message"
        }, Object(services_helpers__WEBPACK_IMPORTED_MODULE_11__["objectQuery"])(this.state, 'error', 'remedies') ? this.state.error.remedies : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate('features.DataPrep.TopPanel.invalidFieldNameRemedies2'), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "btn-link",
          onClick: this.applyDirective.bind(this, 'cleanse-column-names')
        }, i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate('features.DataPrep.TopPanel.cleanseLinkLabel')), i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate('features.DataPrep.TopPanel.invalidFieldNameRemedies3')));
      } else {
        content = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("fieldset", {
          disabled: true
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(SchemaEditor, null));
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Modal"], {
        isOpen: true,
        toggle: this.props.toggle,
        size: "lg",
        zIndex: "1061",
        className: "dataprep-schema-modal cdap-modal"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalHeader"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, "Schema"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "close-section float-right"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
        disabled: this.state.error ? 'disabled' : null,
        className: "btn btn-link",
        onClick: this.download
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-download"
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "fa fa-times",
        onClick: this.props.toggle
      }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalBody"], null, content), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_17__["default"], {
        condition: this.state.error
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_CardActionFeedback__WEBPACK_IMPORTED_MODULE_16__["default"], {
        type: "DANGER",
        message: !Object(services_helpers__WEBPACK_IMPORTED_MODULE_11__["isNilOrEmpty"])(this.state.error) ? this.state.error.message : this.state.error,
        extendedMessage: this.state.remedies
      })));
    }
  }]);

  return SchemaModal;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


SchemaModal.propTypes = {
  toggle: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/***/ }),

/***/ "./components/SchemaEditor/SchemaStore.js":
/*!************************************************!*\
  !*** ./components/SchemaEditor/SchemaStore.js ***!
  \************************************************/
/*! exports provided: createStoreInstance, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createStoreInstance", function() { return createStoreInstance; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/*
 * Copyright © 2016 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

var defaultAction = {
  type: '',
  payload: {}
};
var defaultState = {
  name: 'etlSchemabody',
  type: 'record',
  fields: [{
    name: '',
    type: {},
    displayType: 'string'
  }]
};

var schema = function schema() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultState;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : defaultAction;

  switch (action.type) {
    case 'FIELD_UPDATE':
      {
        return Object.assign({}, state, {
          fields: action.payload.schema.fields
        });
      }

    case 'RESET':
      {
        return defaultState;
      }

    default:
      return state;
  }
};

var createStoreInstance = function createStoreInstance() {
  return Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
    schema: schema
  }), window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__());
};


var SchemaStore = createStoreInstance();
/* harmony default export */ __webpack_exports__["default"] = (SchemaStore);

/***/ })

}]);
//# sourceMappingURL=SchemaModal.cfc1ab0f7169bafd5c02.js.map