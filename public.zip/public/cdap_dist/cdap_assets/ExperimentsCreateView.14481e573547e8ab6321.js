(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ExperimentsCreateView"],{

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/CreateView.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/CreateView.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2016-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.experiments-create-view {\n  height: 100%;\n  overflow-y: hidden;\n  position: relative; }\n  .experiments-create-view .experiments-toppanel {\n    margin-left: 0;\n    margin-right: 0;\n    border-bottom: 1px solid #bbbbbb; }\n    .experiments-create-view .experiments-toppanel .icon-svg.icon-close {\n      font-size: 20px;\n      cursor: pointer;\n      color: black; }\n  .experiments-create-view .dataprep-connections-container {\n    height: 100%;\n    overflow-y: auto; }\n    .experiments-create-view .dataprep-connections-container .file-browser-container {\n      height: 100%; }\n    .experiments-create-view .dataprep-connections-container .dataprep-browser-top-panel .title h5 .fa.fa-fw {\n      display: none; }\n  .experiments-create-view .dataprephome-wrapper {\n    height: calc(100vh - (53px + 50px + 50px)); }\n    .experiments-create-view .dataprephome-wrapper .dataprep-container .dataprep-error-alert-container {\n      top: 0; }\n    .experiments-create-view .dataprephome-wrapper .dataprep-container .dataprep-body {\n      height: calc(100% - 50px); }\n    .experiments-create-view .dataprephome-wrapper .dataprep-container .top-section .top-section-content .top-panel .action-buttons {\n      z-index: 998; }\n      .experiments-create-view .dataprephome-wrapper .dataprep-container .top-section .top-section-content .top-panel .action-buttons .more-dropdown .popper {\n        margin-right: 0; }\n      .experiments-create-view .dataprephome-wrapper .dataprep-container .top-section .top-section-content .top-panel .action-buttons .dataprep-plus-button {\n        display: none; }\n      .experiments-create-view .dataprephome-wrapper .dataprep-container .top-section .top-section-content .top-panel .action-buttons > .btn.btn-primary {\n        display: none; }\n  .experiments-create-view .experiments-model-panel {\n    height: 50px;\n    position: absolute;\n    right: 80px;\n    top: 59px;\n    z-index: 999; }\n    .experiments-create-view .experiments-model-panel > .btn.btn-primary {\n      padding-right: 30px;\n      padding-left: 30px; }\n  .experiments-create-view > .experiments-split-data > .experiment-metadata {\n    height: 80px; }\n    .experiments-create-view > .experiments-split-data > .experiment-metadata > div {\n      width: 25%;\n      word-break: break-word;\n      margin: 0; }\n  .experiments-create-view > :not([class*=\"experiments-\"]) {\n    height: calc(100% - 50px); }\n  .experiments-create-view.add-model .top-section .panel-toggle {\n    display: none; }\n  .experiments-create-view.add-model .top-section .top-section-content {\n    width: 100%; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/ExperimentMetadata/ExperimentMetadata.scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/ExperimentMetadata/ExperimentMetadata.scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.experiment-metadata {\n  display: -webkit-box;\n  display: flex;\n  flex-wrap: wrap;\n  padding: 20px;\n  border-bottom: 1px solid #cccccc; }\n  .experiment-metadata > div {\n    margin: 0 20px 0 0; }\n    .experiment-metadata > div.grayed {\n      color: #cccccc; }\n    .experiment-metadata > div > * {\n      margin: 0 5px; }\n    .experiment-metadata > div .model-description-wrapper {\n      display: -webkit-box;\n      display: flex; }\n      .experiment-metadata > div .model-description-wrapper .model-description {\n        margin-left: 10px;\n        max-width: 200px;\n        white-space: nowrap;\n        display: inline-block;\n        overflow: hidden;\n        text-overflow: ellipsis; }\n  .experiment-metadata .btn.btn-link {\n    padding: 0;\n    margin: 0;\n    vertical-align: top; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/MLAlgorithmSelection/HyperParamWidget/HyperParamWidget.scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/MLAlgorithmSelection/HyperParamWidget/HyperParamWidget.scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.hyper-param-widget {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr); }\n  .hyper-param-widget .param-label {\n    margin-right: 5px;\n    display: -webkit-inline-box;\n    display: inline-flex;\n    min-width: 100px;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    -webkit-box-pack: end;\n            justify-content: flex-end;\n    -webkit-box-align: center;\n            align-items: center; }\n  .hyper-param-widget .bool-widget {\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-align: center;\n            align-items: center; }\n    .hyper-param-widget .bool-widget label {\n      display: -webkit-inline-box;\n      display: inline-flex;\n      margin: 0;\n      -webkit-box-align: center;\n              align-items: center; }\n      .hyper-param-widget .bool-widget label span {\n        margin-right: 5px; }\n      .hyper-param-widget .bool-widget label input[type=\"radio\"] {\n        width: 20px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/MLAlgorithmSelection/MLAlgorithmSelection.scss":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/MLAlgorithmSelection/MLAlgorithmSelection.scss ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.ml-algorithm-selection {\n  padding: 20px;\n  height: calc(100% - (80px + 50px));\n  overflow: auto; }\n  .ml-algorithm-selection h3 {\n    margin-bottom: 20px; }\n  .ml-algorithm-selection .btn.btn-primary {\n    margin: 20px; }\n  .ml-algorithm-selection .ml-algorithm-list-details {\n    display: -webkit-box;\n    display: flex; }\n    .ml-algorithm-selection .ml-algorithm-list-details .ml-algorithm-hyper-parameters-wrapper {\n      border: 1px solid #bbbbbb;\n      height: 100%;\n      padding: 10px; }\n    .ml-algorithm-selection .ml-algorithm-list-details .ml-algorithm-hyper-parameters {\n      display: grid;\n      grid-template-columns: repeat(2, 1fr);\n      grid-auto-rows: 30px;\n      padding: 20px 50px;\n      grid-gap: 20px; }\n    @media (max-width: 1000px) {\n      .ml-algorithm-selection .ml-algorithm-list-details .ml-algorithm-hyper-parameters {\n        grid-template-columns: 1fr; } }\n    .ml-algorithm-selection .ml-algorithm-list-details .ml-algorithm-list-view {\n      margin-right: 100px;\n      min-width: 350px; }\n      .ml-algorithm-selection .ml-algorithm-list-details .ml-algorithm-list-view .ml-algorithm-category-title {\n        color: #cccccc;\n        margin-bottom: 10px; }\n      .ml-algorithm-selection .ml-algorithm-list-details .ml-algorithm-list-view .ml-algorithm-list-item {\n        border-top: 1px solid #cccccc;\n        cursor: pointer;\n        display: -webkit-box;\n        display: flex;\n        padding: 8px;\n        -webkit-box-align: center;\n                align-items: center; }\n        .ml-algorithm-selection .ml-algorithm-list-details .ml-algorithm-list-view .ml-algorithm-list-item:hover, .ml-algorithm-selection .ml-algorithm-list-details .ml-algorithm-list-view .ml-algorithm-list-item.selected {\n          background: rgba(255, 213, 0, 0.3); }\n        .ml-algorithm-selection .ml-algorithm-list-details .ml-algorithm-list-view .ml-algorithm-list-item:last-child {\n          border-bottom: 1px solid #cccccc; }\n        .ml-algorithm-selection .ml-algorithm-list-details .ml-algorithm-list-view .ml-algorithm-list-item input[type=\"radio\"] {\n          margin-right: 5px;\n          cursor: pointer; }\n        .ml-algorithm-selection .ml-algorithm-list-details .ml-algorithm-list-view .ml-algorithm-list-item .control-label {\n          cursor: pointer;\n          margin: 0; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/Popovers/ExperimentPopovers.scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/Popovers/ExperimentPopovers.scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.new-experiment-popover {\n  padding: 0;\n  min-width: 270px; }\n  .new-experiment-popover .popover-container {\n    margin: 10px;\n    border: 1px solid #cccccc;\n    padding: 0 10px 10px; }\n    .new-experiment-popover .popover-container .popover-heading {\n      padding: 10px;\n      display: block;\n      margin: 0 -10px 10px -10px;\n      background: #eeeeee;\n      font-size: 14px; }\n    .new-experiment-popover .popover-container .form-control.btn {\n      margin: 0; }\n    .new-experiment-popover .popover-container .form-group .control-label {\n      font-size: 13px;\n      font-weight: 500; }\n    .new-experiment-popover .popover-container .form-group textarea {\n      min-height: 100px;\n      max-height: 250px; }\n    .new-experiment-popover .popover-container button {\n      width: 100%; }\n\n.new-model-popover {\n  padding: 20px; }\n  .new-model-popover .form-group .control-label {\n    font-size: 13px;\n    font-weight: 500; }\n  .new-model-popover .form-group textarea {\n    min-height: 100px;\n    max-height: 250px; }\n  .new-model-popover .experiment-metadata-wrapper {\n    color: #cccccc;\n    margin: 5px 0;\n    display: -webkit-box;\n    display: flex; }\n    .new-model-popover .experiment-metadata-wrapper > div:first-child {\n      margin-right: 5px; }\n  .new-model-popover button {\n    width: 100%; }\n\n.create_new_experiment_popover .popper {\n  min-width: 270px;\n  text-align: left; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/SplitDataStep/SplitDataStep.scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/SplitDataStep/SplitDataStep.scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n.split-data-step {\n  padding: 20px;\n  height: calc(100% - (80px + 50px));\n  overflow: auto; }\n  .split-data-step .split-error-container {\n    padding-left: 10px; }\n    .split-data-step .split-error-container a {\n      text-decoration: none; }\n  .split-data-step .done-action-container {\n    display: inline-block;\n    margin: 0 10px; }\n    .split-data-step .done-action-container > :first-child {\n      margin-right: 10px; }\n  .split-data-step .btn.btn-primary .btn-inner-container {\n    display: -webkit-box;\n    display: flex;\n    -webkit-box-align: center;\n            align-items: center; }\n    .split-data-step .btn.btn-primary .btn-inner-container > svg {\n      margin-right: 10px; }\n    .split-data-step .btn.btn-primary .btn-inner-container > span {\n      line-height: 1; }\n  .split-data-step .action-button-group button {\n    margin: 0 5px 0 0; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/SplitDataStep/SplitInfo/SplitInfo.scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/SplitDataStep/SplitInfo/SplitInfo.scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.split-info {\n  padding: 15px 0; }\n  .split-info .split-info-graph-wrapper {\n    height: 300px;\n    margin-top: -10px; }\n  .split-info .active-column-container {\n    font-size: 1.2rem;\n    margin: 5px 0 0 0; }\n    .split-info .active-column-container .icon-svg.icon-star {\n      color: var(--brand-primary-color);\n      margin-right: 5px;\n      height: 12px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/SplitDataStep/SplitInfoTable/SplitInfoTable.scss":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/SplitDataStep/SplitInfoTable/SplitInfoTable.scss ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.split-info-table .split-info-collapsable-section {\n  padding: 5px 0;\n  border-bottom: 1px solid #cccccc;\n  margin: 5px 0;\n  cursor: pointer; }\n\n.split-info-table .split-info-table-container .split-table-search {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n          align-items: center; }\n  .split-info-table .split-info-table-container .split-table-search .filter-container {\n    display: -webkit-box;\n    display: flex; }\n    .split-info-table .split-info-table-container .split-table-search .filter-container > span {\n      margin: 0 5px;\n      display: -webkit-box;\n      display: flex;\n      -webkit-box-align: center;\n              align-items: center; }\n      .split-info-table .split-info-table-container .split-table-search .filter-container > span > input[type=\"checkbox\"] {\n        margin: 0 5px;\n        position: static; }\n\n.split-info-table .split-info-table-container .split-info-numerical-table .table tbody tr,\n.split-info-table .split-info-table-container .split-info-categorical-table .table tbody tr {\n  cursor: pointer; }\n  .split-info-table .split-info-table-container .split-info-numerical-table .table tbody tr:hover,\n  .split-info-table .split-info-table-container .split-info-categorical-table .table tbody tr:hover {\n    background: #f5f5f5; }\n  .split-info-table .split-info-table-container .split-info-numerical-table .table tbody tr.active,\n  .split-info-table .split-info-table-container .split-info-categorical-table .table tbody tr.active {\n    background: rgba(255, 213, 0, 0.3); }\n  .split-info-table .split-info-table-container .split-info-numerical-table .table tbody tr .outcome-field .icon-svg.icon-star,\n  .split-info-table .split-info-table-container .split-info-categorical-table .table tbody tr .outcome-field .icon-svg.icon-star {\n    color: var(--brand-primary-color);\n    margin-right: 5px;\n    height: 12px; }\n\n.split-info-table .split-info-table-container .split-info-numerical-table .split-table-header,\n.split-info-table .split-info-table-container .split-info-categorical-table .split-table-header {\n  width: 100%;\n  background: #cccccc;\n  padding: 5px;\n  border-radius: 2px;\n  color: white;\n  font-weight: 500;\n  margin: 10px 0; }\n\n.split-info-table .split-info-table-container .table-field-search {\n  width: 200px; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SortableTable/SortableTable.scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SortableTable/SortableTable.scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2017 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n.table th span {\n  cursor: pointer; }\n  .table th span .text-underline {\n    text-decoration: underline; }\n  .table th span i {\n    margin-left: 3px; }\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "../../node_modules/lodash/_arrayReduce.js":
/*!*****************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/_arrayReduce.js ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * A specialized version of `_.reduce` for arrays without support for
 * iteratee shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @param {*} [accumulator] The initial value.
 * @param {boolean} [initAccum] Specify using the first element of `array` as
 *  the initial value.
 * @returns {*} Returns the accumulated value.
 */
function arrayReduce(array, iteratee, accumulator, initAccum) {
  var index = -1,
      length = array == null ? 0 : array.length;

  if (initAccum && length) {
    accumulator = array[++index];
  }
  while (++index < length) {
    accumulator = iteratee(accumulator, array[index], index, array);
  }
  return accumulator;
}

module.exports = arrayReduce;


/***/ }),

/***/ "../../node_modules/lodash/_asciiWords.js":
/*!****************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/_asciiWords.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used to match words composed of alphanumeric characters. */
var reAsciiWord = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;

/**
 * Splits an ASCII `string` into an array of its words.
 *
 * @private
 * @param {string} The string to inspect.
 * @returns {Array} Returns the words of `string`.
 */
function asciiWords(string) {
  return string.match(reAsciiWord) || [];
}

module.exports = asciiWords;


/***/ }),

/***/ "../../node_modules/lodash/_createCompounder.js":
/*!**********************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/_createCompounder.js ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayReduce = __webpack_require__(/*! ./_arrayReduce */ "../../node_modules/lodash/_arrayReduce.js"),
    deburr = __webpack_require__(/*! ./deburr */ "../../node_modules/lodash/deburr.js"),
    words = __webpack_require__(/*! ./words */ "../../node_modules/lodash/words.js");

/** Used to compose unicode capture groups. */
var rsApos = "['\u2019]";

/** Used to match apostrophes. */
var reApos = RegExp(rsApos, 'g');

/**
 * Creates a function like `_.camelCase`.
 *
 * @private
 * @param {Function} callback The function to combine each word.
 * @returns {Function} Returns the new compounder function.
 */
function createCompounder(callback) {
  return function(string) {
    return arrayReduce(words(deburr(string).replace(reApos, '')), callback, '');
  };
}

module.exports = createCompounder;


/***/ }),

/***/ "../../node_modules/lodash/_hasUnicodeWord.js":
/*!********************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/_hasUnicodeWord.js ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used to detect strings that need a more robust regexp to match words. */
var reHasUnicodeWord = /[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;

/**
 * Checks if `string` contains a word composed of Unicode symbols.
 *
 * @private
 * @param {string} string The string to inspect.
 * @returns {boolean} Returns `true` if a word is found, else `false`.
 */
function hasUnicodeWord(string) {
  return reHasUnicodeWord.test(string);
}

module.exports = hasUnicodeWord;


/***/ }),

/***/ "../../node_modules/lodash/_unicodeWords.js":
/*!******************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/_unicodeWords.js ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used to compose unicode character classes. */
var rsAstralRange = '\\ud800-\\udfff',
    rsComboMarksRange = '\\u0300-\\u036f',
    reComboHalfMarksRange = '\\ufe20-\\ufe2f',
    rsComboSymbolsRange = '\\u20d0-\\u20ff',
    rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange,
    rsDingbatRange = '\\u2700-\\u27bf',
    rsLowerRange = 'a-z\\xdf-\\xf6\\xf8-\\xff',
    rsMathOpRange = '\\xac\\xb1\\xd7\\xf7',
    rsNonCharRange = '\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf',
    rsPunctuationRange = '\\u2000-\\u206f',
    rsSpaceRange = ' \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000',
    rsUpperRange = 'A-Z\\xc0-\\xd6\\xd8-\\xde',
    rsVarRange = '\\ufe0e\\ufe0f',
    rsBreakRange = rsMathOpRange + rsNonCharRange + rsPunctuationRange + rsSpaceRange;

/** Used to compose unicode capture groups. */
var rsApos = "['\u2019]",
    rsBreak = '[' + rsBreakRange + ']',
    rsCombo = '[' + rsComboRange + ']',
    rsDigits = '\\d+',
    rsDingbat = '[' + rsDingbatRange + ']',
    rsLower = '[' + rsLowerRange + ']',
    rsMisc = '[^' + rsAstralRange + rsBreakRange + rsDigits + rsDingbatRange + rsLowerRange + rsUpperRange + ']',
    rsFitz = '\\ud83c[\\udffb-\\udfff]',
    rsModifier = '(?:' + rsCombo + '|' + rsFitz + ')',
    rsNonAstral = '[^' + rsAstralRange + ']',
    rsRegional = '(?:\\ud83c[\\udde6-\\uddff]){2}',
    rsSurrPair = '[\\ud800-\\udbff][\\udc00-\\udfff]',
    rsUpper = '[' + rsUpperRange + ']',
    rsZWJ = '\\u200d';

/** Used to compose unicode regexes. */
var rsMiscLower = '(?:' + rsLower + '|' + rsMisc + ')',
    rsMiscUpper = '(?:' + rsUpper + '|' + rsMisc + ')',
    rsOptContrLower = '(?:' + rsApos + '(?:d|ll|m|re|s|t|ve))?',
    rsOptContrUpper = '(?:' + rsApos + '(?:D|LL|M|RE|S|T|VE))?',
    reOptMod = rsModifier + '?',
    rsOptVar = '[' + rsVarRange + ']?',
    rsOptJoin = '(?:' + rsZWJ + '(?:' + [rsNonAstral, rsRegional, rsSurrPair].join('|') + ')' + rsOptVar + reOptMod + ')*',
    rsOrdLower = '\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])',
    rsOrdUpper = '\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])',
    rsSeq = rsOptVar + reOptMod + rsOptJoin,
    rsEmoji = '(?:' + [rsDingbat, rsRegional, rsSurrPair].join('|') + ')' + rsSeq;

/** Used to match complex or compound words. */
var reUnicodeWord = RegExp([
  rsUpper + '?' + rsLower + '+' + rsOptContrLower + '(?=' + [rsBreak, rsUpper, '$'].join('|') + ')',
  rsMiscUpper + '+' + rsOptContrUpper + '(?=' + [rsBreak, rsUpper + rsMiscLower, '$'].join('|') + ')',
  rsUpper + '?' + rsMiscLower + '+' + rsOptContrLower,
  rsUpper + '+' + rsOptContrUpper,
  rsOrdUpper,
  rsOrdLower,
  rsDigits,
  rsEmoji
].join('|'), 'g');

/**
 * Splits a Unicode `string` into an array of its words.
 *
 * @private
 * @param {string} The string to inspect.
 * @returns {Array} Returns the words of `string`.
 */
function unicodeWords(string) {
  return string.match(reUnicodeWord) || [];
}

module.exports = unicodeWords;


/***/ }),

/***/ "../../node_modules/lodash/deburr.js":
/*!***********************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/deburr.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * This method returns the first argument it receives.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Util
 * @param {*} value Any value.
 * @returns {*} Returns `value`.
 * @example
 *
 * var object = { 'a': 1 };
 *
 * console.log(_.identity(object) === object);
 * // => true
 */
function identity(value) {
  return value;
}

module.exports = identity;


/***/ }),

/***/ "../../node_modules/lodash/findLast.js":
/*!*************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/findLast.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var createFind = __webpack_require__(/*! ./_createFind */ "../../node_modules/lodash/_createFind.js"),
    findLastIndex = __webpack_require__(/*! ./findLastIndex */ "../../node_modules/lodash/findLastIndex.js");

/**
 * This method is like `_.find` except that it iterates over elements of
 * `collection` from right to left.
 *
 * @static
 * @memberOf _
 * @since 2.0.0
 * @category Collection
 * @param {Array|Object} collection The collection to inspect.
 * @param {Function} [predicate=_.identity] The function invoked per iteration.
 * @param {number} [fromIndex=collection.length-1] The index to search from.
 * @returns {*} Returns the matched element, else `undefined`.
 * @example
 *
 * _.findLast([1, 2, 3, 4], function(n) {
 *   return n % 2 == 1;
 * });
 * // => 3
 */
var findLast = createFind(findLastIndex);

module.exports = findLast;


/***/ }),

/***/ "../../node_modules/lodash/findLastIndex.js":
/*!******************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/findLastIndex.js ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseFindIndex = __webpack_require__(/*! ./_baseFindIndex */ "../../node_modules/lodash/_baseFindIndex.js"),
    baseIteratee = __webpack_require__(/*! ./_baseIteratee */ "../../node_modules/lodash/_baseIteratee.js"),
    toInteger = __webpack_require__(/*! ./toInteger */ "../../node_modules/lodash/toInteger.js");

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * This method is like `_.findIndex` except that it iterates over elements
 * of `collection` from right to left.
 *
 * @static
 * @memberOf _
 * @since 2.0.0
 * @category Array
 * @param {Array} array The array to inspect.
 * @param {Function} [predicate=_.identity] The function invoked per iteration.
 * @param {number} [fromIndex=array.length-1] The index to search from.
 * @returns {number} Returns the index of the found element, else `-1`.
 * @example
 *
 * var users = [
 *   { 'user': 'barney',  'active': true },
 *   { 'user': 'fred',    'active': false },
 *   { 'user': 'pebbles', 'active': false }
 * ];
 *
 * _.findLastIndex(users, function(o) { return o.user == 'pebbles'; });
 * // => 2
 *
 * // The `_.matches` iteratee shorthand.
 * _.findLastIndex(users, { 'user': 'barney', 'active': true });
 * // => 0
 *
 * // The `_.matchesProperty` iteratee shorthand.
 * _.findLastIndex(users, ['active', false]);
 * // => 2
 *
 * // The `_.property` iteratee shorthand.
 * _.findLastIndex(users, 'active');
 * // => 0
 */
function findLastIndex(array, predicate, fromIndex) {
  var length = array == null ? 0 : array.length;
  if (!length) {
    return -1;
  }
  var index = length - 1;
  if (fromIndex !== undefined) {
    index = toInteger(fromIndex);
    index = fromIndex < 0
      ? nativeMax(length + index, 0)
      : nativeMin(index, length - 1);
  }
  return baseFindIndex(array, baseIteratee(predicate, 3), index, true);
}

module.exports = findLastIndex;


/***/ }),

/***/ "../../node_modules/lodash/startCase.js":
/*!**************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/startCase.js ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var createCompounder = __webpack_require__(/*! ./_createCompounder */ "../../node_modules/lodash/_createCompounder.js"),
    upperFirst = __webpack_require__(/*! ./upperFirst */ "../../node_modules/lodash/upperFirst.js");

/**
 * Converts `string` to
 * [start case](https://en.wikipedia.org/wiki/Letter_case#Stylistic_or_specialised_usage).
 *
 * @static
 * @memberOf _
 * @since 3.1.0
 * @category String
 * @param {string} [string=''] The string to convert.
 * @returns {string} Returns the start cased string.
 * @example
 *
 * _.startCase('--foo-bar--');
 * // => 'Foo Bar'
 *
 * _.startCase('fooBar');
 * // => 'Foo Bar'
 *
 * _.startCase('__FOO_BAR__');
 * // => 'FOO BAR'
 */
var startCase = createCompounder(function(result, word, index) {
  return result + (index ? ' ' : '') + upperFirst(word);
});

module.exports = startCase;


/***/ }),

/***/ "../../node_modules/lodash/words.js":
/*!**********************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/lodash/words.js ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var asciiWords = __webpack_require__(/*! ./_asciiWords */ "../../node_modules/lodash/_asciiWords.js"),
    hasUnicodeWord = __webpack_require__(/*! ./_hasUnicodeWord */ "../../node_modules/lodash/_hasUnicodeWord.js"),
    toString = __webpack_require__(/*! ./toString */ "../../node_modules/lodash/toString.js"),
    unicodeWords = __webpack_require__(/*! ./_unicodeWords */ "../../node_modules/lodash/_unicodeWords.js");

/**
 * Splits `string` into an array of its words.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to inspect.
 * @param {RegExp|string} [pattern] The pattern to match words.
 * @param- {Object} [guard] Enables use as an iteratee for methods like `_.map`.
 * @returns {Array} Returns the words of `string`.
 * @example
 *
 * _.words('fred, barney, & pebbles');
 * // => ['fred', 'barney', 'pebbles']
 *
 * _.words('fred, barney, & pebbles', /[^, ]+/g);
 * // => ['fred', 'barney', '&', 'pebbles']
 */
function words(string, pattern, guard) {
  string = toString(string);
  pattern = guard ? undefined : pattern;

  if (pattern === undefined) {
    return hasUnicodeWord(string) ? unicodeWords(string) : asciiWords(string);
  }
  return string.match(pattern) || [];
}

module.exports = words;


/***/ }),

/***/ "./components/Experiments/CreateView/CreateView.scss":
/*!***********************************************************!*\
  !*** ./components/Experiments/CreateView/CreateView.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./CreateView.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/CreateView.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/CreateView/ExperimentMetadata/ExperimentMetadata.scss":
/*!**************************************************************************************!*\
  !*** ./components/Experiments/CreateView/ExperimentMetadata/ExperimentMetadata.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./ExperimentMetadata.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/ExperimentMetadata/ExperimentMetadata.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/CreateView/ExperimentMetadata/index.js":
/*!***********************************************************************!*\
  !*** ./components/Experiments/CreateView/ExperimentMetadata/index.js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ExperimentMetadata; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Experiments/store/createExperimentStore */ "./components/Experiments/store/createExperimentStore.js");
/* harmony import */ var components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/store/CreateExperimentActionCreator */ "./components/Experiments/store/CreateExperimentActionCreator.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash/isNil */ "../../node_modules/lodash/isNil.js");
/* harmony import */ var lodash_isNil__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash_isNil__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_7__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








var PREFIX = 'features.Experiments.CreateView';

__webpack_require__(/*! ./ExperimentMetadata.scss */ "./components/Experiments/CreateView/ExperimentMetadata/ExperimentMetadata.scss");

var ExperimentMetadataWrapper = function ExperimentMetadataWrapper(_ref) {
  var modelName = _ref.modelName,
      modelDescription = _ref.modelDescription,
      directives = _ref.directives,
      algorithm = _ref.algorithm,
      active_step = _ref.active_step;

  var isAlgorithmEmpty = function isAlgorithmEmpty() {
    return lodash_isNil__WEBPACK_IMPORTED_MODULE_6___default()(algorithm) || !algorithm.length;
  };

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "experiment-metadata"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".modelNameWithColon"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, modelName), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "model-description-wrapper"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".modelDescriptionWithColon"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
    className: "model-description"
  }, modelDescription))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".numDirectives"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, directives.length), directives.length ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "btn btn-link",
    onClick: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["overrideCreationStep"].bind(null, components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__["CREATION_STEPS"].DATAPREP)
  }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('commons.edit')) : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".splitMethod"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".random"))), active_step === components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__["CREATION_STEPS"].ALGORITHM_SELECTION ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "btn btn-link",
    onClick: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["overrideCreationStep"].bind(null, components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__["CREATION_STEPS"].DATASPLIT)
  }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('commons.edit')) : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()({
      grayed: isAlgorithmEmpty()
    })
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".MLAlgorithm"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, isAlgorithmEmpty() ? '--' : algorithm)));
};

ExperimentMetadataWrapper.propTypes = {
  modelName: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  modelDescription: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  directives: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.array,
  algorithm: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  active_step: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    modelName: state.model_create.name,
    modelDescription: state.model_create.description,
    directives: state.model_create.directives,
    active_step: state.active_step.step_name,
    algorithm: !state.model_create.algorithm.name.length ? '' : state.model_create.validAlgorithmsList.find(function (algo) {
      return algo.name === state.model_create.algorithm.name;
    }).label
  };
};

var ConnectedExperimentMetadata = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps, null)(ExperimentMetadataWrapper);
function ExperimentMetadata() {
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_redux__WEBPACK_IMPORTED_MODULE_2__["Provider"], {
    store: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__["default"]
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ConnectedExperimentMetadata, null));
}

/***/ }),

/***/ "./components/Experiments/CreateView/MLAlgorithmSelection/HyperParamWidget/HyperParamWidget.scss":
/*!*******************************************************************************************************!*\
  !*** ./components/Experiments/CreateView/MLAlgorithmSelection/HyperParamWidget/HyperParamWidget.scss ***!
  \*******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../../node_modules/postcss-loader/src!../../../../../../../node_modules/sass-loader/dist/cjs.js!./HyperParamWidget.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/MLAlgorithmSelection/HyperParamWidget/HyperParamWidget.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/CreateView/MLAlgorithmSelection/HyperParamWidget/index.js":
/*!******************************************************************************************!*\
  !*** ./components/Experiments/CreateView/MLAlgorithmSelection/HyperParamWidget/index.js ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HyperParamWidget; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_SelectWithOptions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/SelectWithOptions */ "./components/SelectWithOptions/index.js");
function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




__webpack_require__(/*! ./HyperParamWidget.scss */ "./components/Experiments/CreateView/MLAlgorithmSelection/HyperParamWidget/HyperParamWidget.scss");

var BoolWidget = function BoolWidget(_ref) {
  var options = _ref.options,
      value = _ref.value,
      onChange = _ref.onChange;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "bool-widget"
  }, options.map(function (option) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("label", {
      key: option
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("input", {
      type: "radio",
      value: option,
      checked: option === value,
      className: "form-control",
      onChange: onChange
    }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, option));
  }));
};

BoolWidget.propTypes = {
  options: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string),
  value: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

var getComponent = function getComponent(type) {
  switch (type) {
    case 'int':
      return {
        comp: 'input',
        props: {
          type: 'number',
          step: 1,
          className: 'form-control'
        }
      };

    case 'double':
      return {
        comp: 'input',
        props: {
          type: 'number',
          step: 0.1,
          className: 'form-control'
        }
      };

    case 'bool':
      return {
        comp: BoolWidget,
        props: {}
      };

    case 'string':
      return {
        comp: components_SelectWithOptions__WEBPACK_IMPORTED_MODULE_2__["default"],
        props: {}
      };

    default:
      return {
        comp: 'input',
        props: {
          type: 'text',
          className: 'form-control'
        }
      };
  }
};

function HyperParamWidget(_ref2) {
  var type = _ref2.type,
      config = _ref2.config,
      onChange = _ref2.onChange;

  var _getComponent = getComponent(type),
      Component = _getComponent.comp,
      _getComponent$props = _getComponent.props,
      props = _getComponent$props === void 0 ? {} : _getComponent$props;

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("label", {
    className: "hyper-param-widget"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
    className: "param-label"
  }, config.label || config.name || ''), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Component, _extends({}, config, props, {
    onChange: onChange
  })));
}
HyperParamWidget.propTypes = {
  type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  config: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/***/ }),

/***/ "./components/Experiments/CreateView/MLAlgorithmSelection/MLAlgorithmSelection.scss":
/*!******************************************************************************************!*\
  !*** ./components/Experiments/CreateView/MLAlgorithmSelection/MLAlgorithmSelection.scss ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./MLAlgorithmSelection.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/MLAlgorithmSelection/MLAlgorithmSelection.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/CreateView/MLAlgorithmSelection/index.js":
/*!*************************************************************************!*\
  !*** ./components/Experiments/CreateView/MLAlgorithmSelection/index.js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MLAlgorithmSelection; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Experiments/store/createExperimentStore */ "./components/Experiments/store/createExperimentStore.js");
/* harmony import */ var components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/store/CreateExperimentActionCreator */ "./components/Experiments/store/CreateExperimentActionCreator.js");
/* harmony import */ var components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Experiments/store/SharedActionCreator */ "./components/Experiments/store/SharedActionCreator.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_Experiments_CreateView_MLAlgorithmSelection_HyperParamWidget__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/Experiments/CreateView/MLAlgorithmSelection/HyperParamWidget */ "./components/Experiments/CreateView/MLAlgorithmSelection/HyperParamWidget/index.js");
/* harmony import */ var lodash_startCase__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash/startCase */ "../../node_modules/lodash/startCase.js");
/* harmony import */ var lodash_startCase__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_startCase__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var components_Alert__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/Alert */ "./components/Alert/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_12__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */













var PREFIX = 'features.Experiments.CreateView';

__webpack_require__(/*! ./MLAlgorithmSelection.scss */ "./components/Experiments/CreateView/MLAlgorithmSelection/MLAlgorithmSelection.scss");

var MLAlgorithmsList = function MLAlgorithmsList(_ref) {
  var algorithmsList = _ref.algorithmsList,
      setModelAlgorithm = _ref.setModelAlgorithm,
      selectedAlgorithm = _ref.selectedAlgorithm,
      error = _ref.error;

  if (!Object(services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"])(algorithmsList, 'length')) {
    return null;
  }

  var getSelectedAlgorithm = function getSelectedAlgorithm(algorithm) {
    var hyperparameters = {};
    algorithm.hyperparameters.forEach(function (hp) {
      hyperparameters[hp.name] = hp.defaultVal;
    });
    return {
      name: algorithm.name,
      hyperparameters: hyperparameters
    };
  };

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "ml-algorithm-list-view"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "ml-algorithm-category-title"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate("".concat(PREFIX, ".algorithmType"), {
    type: lodash_startCase__WEBPACK_IMPORTED_MODULE_9___default()(algorithmsList[0].type || '')
  })), algorithmsList.map(function (algo, i) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
      key: i,
      className: classnames__WEBPACK_IMPORTED_MODULE_10___default()('ml-algorithm-list-item', {
        selected: selectedAlgorithm.name === algo.name
      }),
      onClick: setModelAlgorithm.bind(null, getSelectedAlgorithm(algo))
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("input", {
      type: "radio",
      name: "algo-radio",
      value: algo.name,
      checked: selectedAlgorithm.name === algo.name,
      onChange: setModelAlgorithm.bind(null, getSelectedAlgorithm(algo))
    }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_6__["Label"], {
      className: "control-label"
    }, algo.label));
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ConnectedAddModelBtn, null), error ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Alert__WEBPACK_IMPORTED_MODULE_11__["default"], {
    message: error,
    type: "error",
    showAlert: true,
    onClose: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["setModelCreateError"]
  }) : null);
};

MLAlgorithmsList.propTypes = {
  algorithmsList: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object),
  setModelAlgorithm: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  selectedAlgorithm: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  error: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.any
};

var getComponent = function getComponent(hyperParam) {
  /*
    Example of hyper parameters from backend
    {
      "type": "int|double",
      "defaultVal": "32",
      "validValues": [],
      "range": {
        "min": "2",
        "max": "1000",
        "isMinInclusive": true
      }
    },
    {
      "type": "string",
      "defaultVal": "gaussian",
      "validValues": [
        "gaussian",
        "binomial",
        "poisson",
        "gamma"
      ]
    },
    {
      "type": "bool",
      "defaultVal": "true",
      "validValues": [
        "true",
        "false"
      ]
    },
  */
  var BACKEND_PROPS_TO_REACT_PROPS = {
    "int": {
      defaultVal: 'defaultValue',
      'range,min': 'min',
      'range,max': 'max',
      name: 'name'
    },
    "double": {
      defaultVal: 'defaultValue',
      'range,min': 'min',
      'range,max': 'max',
      name: 'name'
    },
    bool: {
      defaultVal: 'defaultValue',
      validValues: 'options',
      name: 'name'
    },
    string: {
      defaultVal: 'defaultValue',
      validValues: 'options',
      name: 'name'
    }
  };
  var matchedType = BACKEND_PROPS_TO_REACT_PROPS[hyperParam.type];

  if (!matchedType) {
    return {};
  }

  var config = {};
  Object.keys(matchedType).forEach(function (hyperParamProp) {
    if (hyperParamProp.indexOf(',') !== -1) {
      config[matchedType[hyperParamProp]] = services_helpers__WEBPACK_IMPORTED_MODULE_7__["objectQuery"].apply(null, [hyperParam].concat(_toConsumableArray(hyperParamProp.split(','))));
    } else {
      config[matchedType[hyperParamProp]] = hyperParam[hyperParamProp];
    }
  });
  return config;
}; // Will be used post demo.


var MLAlgorithmDetails = function MLAlgorithmDetails(_ref2) {
  var algorithm = _ref2.algorithm,
      algorithmsList = _ref2.algorithmsList;

  if (!algorithm.name.length) {
    return null;
  }

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "ml-algorithm-hyper-parameters-wrapper"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate("".concat(PREFIX, ".configureHyperparamsFor"), {
    algorithm: Object(components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_5__["getAlgorithmLabel"])(algorithm.name)
  })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "ml-algorithm-hyper-parameters"
  }, algorithmsList.find(function (al) {
    return al.name === algorithm.name;
  }).hyperparameters.map(function (hyperParam) {
    var actualValue = algorithm.hyperparameters[hyperParam.name];

    var config = _objectSpread({}, getComponent(hyperParam), {
      label: Object(components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_5__["getHyperParamLabel"])(algorithm.name, hyperParam.name),
      value: actualValue
    });

    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_CreateView_MLAlgorithmSelection_HyperParamWidget__WEBPACK_IMPORTED_MODULE_8__["default"], {
      type: hyperParam.type,
      config: config,
      onChange: function onChange(e) {
        // FIX: as we use non-input elements this doesn't need be an "event" object
        Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["updateHyperParam"])(hyperParam.name, e.target.value);
      }
    });
  })));
};

MLAlgorithmDetails.propTypes = {
  algorithm: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  algorithmsList: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object)
};

var AddModelBtn = function AddModelBtn(_ref3) {
  var algorithm = _ref3.algorithm,
      trainModel = _ref3.trainModel;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
    className: "btn btn-primary",
    disabled: !algorithm.name.length,
    onClick: trainModel
  }, i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate("".concat(PREFIX, ".trainModel")));
};

AddModelBtn.propTypes = {
  algorithm: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  trainModel: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

var mapStateToAddModelBtnProps = function mapStateToAddModelBtnProps(state) {
  return {
    algorithm: state.model_create.algorithm
  };
};

var mapDispatchToAddModelBtnProps = function mapDispatchToAddModelBtnProps() {
  return {
    trainModel: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["trainModel"]
  };
};

var mapStateToMLAlgorithmsListProps = function mapStateToMLAlgorithmsListProps(state) {
  return {
    algorithmsList: state.model_create.validAlgorithmsList,
    selectedAlgorithm: state.model_create.algorithm,
    error: state.model_create.error
  };
};

var mapDispatchToMLAlgorithmsListProps = function mapDispatchToMLAlgorithmsListProps() {
  return {
    setModelAlgorithm: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["setModelAlgorithm"]
  };
};

var mapStateToMLAlgorithmDetailsProps = function mapStateToMLAlgorithmDetailsProps(state) {
  return {
    algorithmsList: state.model_create.algorithmsList,
    algorithm: state.model_create.algorithm
  };
};

var ConnectedMLAlgorithmsList = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToMLAlgorithmsListProps, mapDispatchToMLAlgorithmsListProps)(MLAlgorithmsList);
var ConnectedMLAlgorithmDetails = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToMLAlgorithmDetailsProps)(MLAlgorithmDetails);
var ConnectedAddModelBtn = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToAddModelBtnProps, mapDispatchToAddModelBtnProps)(AddModelBtn);
function MLAlgorithmSelection() {
  Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["setAlgorithmList"])();
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_redux__WEBPACK_IMPORTED_MODULE_2__["Provider"], {
    store: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__["default"]
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "ml-algorithm-selection"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h3", null, i18n_react__WEBPACK_IMPORTED_MODULE_12___default.a.translate("".concat(PREFIX, ".selectMLAlgorithm"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "ml-algorithm-list-details"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ConnectedMLAlgorithmsList, null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ConnectedMLAlgorithmDetails, null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null))));
}

/***/ }),

/***/ "./components/Experiments/CreateView/Popovers/ExperimentPopovers.scss":
/*!****************************************************************************!*\
  !*** ./components/Experiments/CreateView/Popovers/ExperimentPopovers.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./ExperimentPopovers.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/Popovers/ExperimentPopovers.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/CreateView/Popovers/NewExperimentPopover.js":
/*!****************************************************************************!*\
  !*** ./components/Experiments/CreateView/Popovers/NewExperimentPopover.js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/store/CreateExperimentActionCreator */ "./components/Experiments/store/CreateExperimentActionCreator.js");
/* harmony import */ var components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Experiments/store/createExperimentStore */ "./components/Experiments/store/createExperimentStore.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_7__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








var PREFIX = 'features.Experiments.CreateView';

var ExperimentName = function ExperimentName(_ref) {
  var name = _ref.name,
      onNameChange = _ref.onNameChange;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
    row: true
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
    xs: "12"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Label"], {
    className: "control-label"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".experimentName"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
    value: name,
    onChange: onNameChange,
    placeholder: i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".experimentNamePlaceholder"))
  })));
};

ExperimentName.propTypes = {
  name: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onNameChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

var ExperimentDescription = function ExperimentDescription(_ref2) {
  var description = _ref2.description,
      onDescriptionChange = _ref2.onDescriptionChange;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
    row: true
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
    xs: "12"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Label"], {
    className: "control-label"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate('commons.descriptionLabel')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
    type: "textarea",
    value: description,
    placeholder: i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".descriptionPlaceholder")),
    onChange: onDescriptionChange
  })));
};

ExperimentDescription.propTypes = {
  description: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onDescriptionChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

var ExperimentOutcome = function ExperimentOutcome(_ref3) {
  var outcome = _ref3.outcome,
      columns = _ref3.columns,
      onOutcomeChange = _ref3.onOutcomeChange;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
    row: true
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
    xs: "12"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Label"], {
    className: "control-label"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".setOutcome"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
    type: "select",
    value: outcome,
    onChange: onOutcomeChange
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("option", {
    key: "default"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".selectOutcome"))), columns.map(function (column, i) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("option", {
      key: i
    }, column);
  }))));
};

ExperimentOutcome.propTypes = {
  outcome: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  columns: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object),
  onOutcomeChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

var CreateExperimentBtn = function CreateExperimentBtn(_ref4) {
  var state = _ref4.state,
      createExperiment = _ref4.createExperiment;

  var isAddExperimentBtnEnabled = function isAddExperimentBtnEnabled() {
    return state.name.length && state.description.length && state.outcome.length;
  };

  var renderBtnContent = function renderBtnContent() {
    if (state.loading) {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
        name: "icon-spinner",
        className: "fa-spin"
      });
    }

    return i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".createExperiment"));
  };

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
    className: "btn btn-primary",
    disabled: !isAddExperimentBtnEnabled(),
    onClick: createExperiment
  }, renderBtnContent());
};

CreateExperimentBtn.propTypes = {
  state: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  createExperiment: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

var NewExperimentPopoverWrapper = function NewExperimentPopoverWrapper(_ref5) {
  var popover = _ref5.popover,
      isEdit = _ref5.isEdit;

  if (popover !== components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_5__["POPOVER_TYPES"].EXPERIMENT || isEdit) {
    return null;
  }

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "new-experiment-popover"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "popover-container"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", {
    className: "popover-heading"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate("".concat(PREFIX, ".createNewExperiment"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ExperimentOutcomeWrapper, null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("hr", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ExperimentNameWrapper, null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ExperiementDescriptionWrapper, null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ConnectedCreateExperimentBtn, null)));
};

NewExperimentPopoverWrapper.propTypes = {
  popover: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  isEdit: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
};

var mapDispatchToCreateExperimentBtnProps = function mapDispatchToCreateExperimentBtnProps() {
  return {
    createExperiment: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["createExperiment"]
  };
};

var mapStateToCreateExperimentBtnProps = function mapStateToCreateExperimentBtnProps(state) {
  return {
    state: _objectSpread({}, state.experiments_create)
  };
};

var mapStateToNameProps = function mapStateToNameProps(state) {
  return {
    name: state.experiments_create.name
  };
};

var mapDispatchToNameProps = function mapDispatchToNameProps() {
  return {
    onNameChange: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["onExperimentNameChange"]
  };
};

var mapStateToDescriptionProps = function mapStateToDescriptionProps(state) {
  return {
    description: state.experiments_create.description
  };
};

var mapDispatchToDescriptionToProps = function mapDispatchToDescriptionToProps() {
  return {
    onDescriptionChange: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["onExperimentDescriptionChange"]
  };
};

var mapStateToOutcomeProps = function mapStateToOutcomeProps(state) {
  return {
    outcome: state.experiments_create.outcome,
    columns: state.model_create.columns
  };
};

var mapDispatchToOutcomeProps = function mapDispatchToOutcomeProps() {
  return {
    onOutcomeChange: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["onExperimentOutcomeChange"]
  };
};

var mapNEPWStateToProps = function mapNEPWStateToProps(state) {
  return {
    popover: state.experiments_create.popover,
    isEdit: state.experiments_create.isEdit
  };
};

var ExperiementDescriptionWrapper = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToDescriptionProps, mapDispatchToDescriptionToProps)(ExperimentDescription);
var ExperimentNameWrapper = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToNameProps, mapDispatchToNameProps)(ExperimentName);
var ExperimentOutcomeWrapper = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToOutcomeProps, mapDispatchToOutcomeProps)(ExperimentOutcome);
var ConnectedNewExperimentPopoverWrapper = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapNEPWStateToProps)(NewExperimentPopoverWrapper);
var ConnectedCreateExperimentBtn = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToCreateExperimentBtnProps, mapDispatchToCreateExperimentBtnProps)(CreateExperimentBtn);
/* harmony default export */ __webpack_exports__["default"] = (ConnectedNewExperimentPopoverWrapper);

/***/ }),

/***/ "./components/Experiments/CreateView/Popovers/NewModelPopover.js":
/*!***********************************************************************!*\
  !*** ./components/Experiments/CreateView/Popovers/NewModelPopover.js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/store/CreateExperimentActionCreator */ "./components/Experiments/store/CreateExperimentActionCreator.js");
/* harmony import */ var components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Experiments/store/createExperimentStore */ "./components/Experiments/store/createExperimentStore.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */







var PREFIX = 'features.Experiments.CreateView';

var ModelName = function ModelName(_ref) {
  var modelName = _ref.modelName,
      onModelNameChange = _ref.onModelNameChange;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
    row: true
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
    xs: "12"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Label"], {
    className: "control-label"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".modelName")))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
    xs: "12"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
    value: modelName,
    onChange: onModelNameChange
  })));
};

ModelName.propTypes = {
  modelName: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onModelNameChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

var ModelDescription = function ModelDescription(_ref2) {
  var modelDescription = _ref2.modelDescription,
      onModelDescriptionChange = _ref2.onModelDescriptionChange;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
    row: true
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
    xs: "12"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Label"], {
    className: "control-label"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".modelDescription")))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
    xs: "12"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
    type: "textarea",
    value: modelDescription,
    onChange: onModelDescriptionChange
  })));
};

ModelDescription.propTypes = {
  modelDescription: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onModelDescriptionChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

var CreateModelBtn = function CreateModelBtn(_ref3) {
  var state = _ref3.state,
      createModel = _ref3.createModel;

  var isAddModelBtnEnabled = function isAddModelBtnEnabled() {
    return state.name.length && state.description.length;
  };

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
    className: "btn btn-primary",
    onClick: createModel,
    disabled: !isAddModelBtnEnabled()
  }, "Create Model");
};

CreateModelBtn.propTypes = {
  state: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  createModel: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

var ExperimentMetadata = function ExperimentMetadata(_ref4) {
  var experimentOutcome = _ref4.experimentOutcome;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
    xs: 12
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "experiment-metadata-wrapper"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, "Outcome:"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, experimentOutcome)));
};

ExperimentMetadata.propTypes = {
  experimentOutcome: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

var NewModelPopoverWrapper = function NewModelPopoverWrapper(_ref5) {
  var popover = _ref5.popover,
      experimentName = _ref5.experimentName;

  if (popover !== components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_5__["POPOVER_TYPES"].MODEL) {
    return null;
  }

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "new-model-popover"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
    row: true
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
    xs: "12"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Label"], {
    className: "control-label"
  }, " Create model under the experiment ")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Col"], {
    xs: "12"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
    disabled: true,
    value: experimentName
  })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ConnectedExperimentMetadata, null)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("hr", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ConnectedModelName, null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ConnectedModelDescription, null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ConnectedCreateModelBtn, null));
};

NewModelPopoverWrapper.propTypes = {
  popover: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  experimentName: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
};

var mapStateToModelNameProps = function mapStateToModelNameProps(state) {
  return {
    modelName: state.model_create.name
  };
};

var mapDispatchToModelNameProps = function mapDispatchToModelNameProps() {
  return {
    onModelNameChange: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["onModelNameChange"]
  };
};

var mapStateToModelDescriptionProps = function mapStateToModelDescriptionProps(state) {
  return {
    modelDescription: state.model_create.description
  };
};

var mapDispatchToModelDescriptionProps = function mapDispatchToModelDescriptionProps() {
  return {
    onModelDescriptionChange: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["onModelDescriptionChange"]
  };
};

var mapStateToCreateModelBtnProps = function mapStateToCreateModelBtnProps(state) {
  return {
    state: state.model_create
  };
};

var mapDispatchToCreateModelBtnProps = function mapDispatchToCreateModelBtnProps() {
  return {
    createModel: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["createModel"]
  };
};

var mapStateToExperimentMetadataProps = function mapStateToExperimentMetadataProps(state) {
  return {
    experimentOutcome: state.experiments_create.outcome
  };
};

var mapNMPWStateToProps = function mapNMPWStateToProps(state) {
  return {
    popover: state.experiments_create.popover,
    experimentName: state.experiments_create.name
  };
};

var ConnectedModelName = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToModelNameProps, mapDispatchToModelNameProps)(ModelName);
var ConnectedModelDescription = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToModelDescriptionProps, mapDispatchToModelDescriptionProps)(ModelDescription);
var ConnectedCreateModelBtn = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToCreateModelBtnProps, mapDispatchToCreateModelBtnProps)(CreateModelBtn);
var ConnectedExperimentMetadata = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToExperimentMetadataProps)(ExperimentMetadata);
var ConnectedNewModelPopoverWrapper = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapNMPWStateToProps)(NewModelPopoverWrapper);
/* harmony default export */ __webpack_exports__["default"] = (ConnectedNewModelPopoverWrapper);

/***/ }),

/***/ "./components/Experiments/CreateView/Popovers/index.js":
/*!*************************************************************!*\
  !*** ./components/Experiments/CreateView/Popovers/index.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ExperimentPopovers; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Experiments/store/createExperimentStore */ "./components/Experiments/store/createExperimentStore.js");
/* harmony import */ var components_Experiments_CreateView_Popovers_NewExperimentPopover__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Experiments/CreateView/Popovers/NewExperimentPopover */ "./components/Experiments/CreateView/Popovers/NewExperimentPopover.js");
/* harmony import */ var components_Experiments_CreateView_Popovers_NewModelPopover__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/CreateView/Popovers/NewModelPopover */ "./components/Experiments/CreateView/Popovers/NewModelPopover.js");
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./ExperimentPopovers.scss */ "./components/Experiments/CreateView/Popovers/ExperimentPopovers.scss");

function ExperimentPopovers() {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_redux__WEBPACK_IMPORTED_MODULE_1__["Provider"], {
    store: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_2__["default"]
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Experiments_CreateView_Popovers_NewExperimentPopover__WEBPACK_IMPORTED_MODULE_3__["default"], null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Experiments_CreateView_Popovers_NewModelPopover__WEBPACK_IMPORTED_MODULE_4__["default"], null)));
}

/***/ }),

/***/ "./components/Experiments/CreateView/SplitDataStep/SplitDataStep.scss":
/*!****************************************************************************!*\
  !*** ./components/Experiments/CreateView/SplitDataStep/SplitDataStep.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/postcss-loader/src!../../../../../../node_modules/sass-loader/dist/cjs.js!./SplitDataStep.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/SplitDataStep/SplitDataStep.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/CreateView/SplitDataStep/SplitInfo/SplitInfo.scss":
/*!**********************************************************************************!*\
  !*** ./components/Experiments/CreateView/SplitDataStep/SplitInfo/SplitInfo.scss ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../../node_modules/postcss-loader/src!../../../../../../../node_modules/sass-loader/dist/cjs.js!./SplitInfo.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/SplitDataStep/SplitInfo/SplitInfo.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/CreateView/SplitDataStep/SplitInfo/index.js":
/*!****************************************************************************!*\
  !*** ./components/Experiments/CreateView/SplitDataStep/SplitInfo/index.js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Experiments_CreateView_SplitDataStep_SplitInfoTable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Experiments/CreateView/SplitDataStep/SplitInfoTable */ "./components/Experiments/CreateView/SplitDataStep/SplitInfoTable/index.js");
/* harmony import */ var components_Experiments_CreateView_SplitDataStep_SplitInfoGraph__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/CreateView/SplitDataStep/SplitInfoGraph */ "./components/Experiments/CreateView/SplitDataStep/SplitInfoGraph/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */







var PREFIX = 'features.Experiments.CreateView';

__webpack_require__(/*! ./SplitInfo.scss */ "./components/Experiments/CreateView/SplitDataStep/SplitInfo/SplitInfo.scss");

var SplitInfo =
/*#__PURE__*/
function (_Component) {
  _inherits(SplitInfo, _Component);

  function SplitInfo() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SplitInfo);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SplitInfo)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      activeColumn: _this.props.outcome,
      splitInfo: _this.props.splitInfo
    });

    _defineProperty(_assertThisInitialized(_this), "onActiveColumnChange", function (activeColumn) {
      _this.setState({
        activeColumn: activeColumn
      });
    });

    return _this;
  }

  _createClass(SplitInfo, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(_ref) {
      var splitInfo = _ref.splitInfo,
          outcome = _ref.outcome;
      this.setState({
        splitInfo: splitInfo,
        activeColumn: outcome
      });
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "split-info"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h5", null, i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate("".concat(PREFIX, ".verifySample"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "active-column-container"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, "Displaying column: "), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, this.state.activeColumn === this.props.outcome ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "outcome-field"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_5__["default"], {
        name: "icon-star"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.state.activeColumn)) : this.state.activeColumn)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "split-info-graph-wrapper"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_CreateView_SplitDataStep_SplitInfoGraph__WEBPACK_IMPORTED_MODULE_4__["default"], {
        splitInfo: this.state.splitInfo,
        activeColumn: this.state.activeColumn
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_CreateView_SplitDataStep_SplitInfoTable__WEBPACK_IMPORTED_MODULE_3__["default"], {
        splitInfo: this.state.splitInfo,
        onActiveColumnChange: this.onActiveColumnChange,
        activeColumn: this.state.activeColumn,
        outcome: this.props.outcome
      }));
    }
  }]);

  return SplitInfo;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(SplitInfo, "propTypes", {
  splitInfo: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  outcome: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  activeColumn: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
});

var mapStateToSplitInfoProps = function mapStateToSplitInfoProps(state) {
  return {
    splitInfo: state.model_create.splitInfo,
    outcome: state.experiments_create.outcome
  };
};

var ConnectedSplitInfo = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToSplitInfoProps)(SplitInfo);
/* harmony default export */ __webpack_exports__["default"] = (ConnectedSplitInfo);

/***/ }),

/***/ "./components/Experiments/CreateView/SplitDataStep/SplitInfoGraph/index.js":
/*!*********************************************************************************!*\
  !*** ./components/Experiments/CreateView/SplitDataStep/SplitInfoGraph/index.js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SplitInfoGraph; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_GroupedBarChart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/GroupedBarChart */ "./components/GroupedBarChart/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var SplitInfoGraph =
/*#__PURE__*/
function (_Component) {
  _inherits(SplitInfoGraph, _Component);

  function SplitInfoGraph() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SplitInfoGraph);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SplitInfoGraph)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      splitInfo: _this.props.splitInfo,
      activeColumn: _this.props.activeColumn
    });

    _defineProperty(_assertThisInitialized(_this), "customEncoding", {
      x: {
        field: 'type',
        type: 'nominal',
        axis: null
      },
      column: {
        field: 'name',
        type: 'ordinal',
        header: {
          title: 'values'
        }
      },
      y: {
        field: 'count',
        type: 'quantitative',
        axis: {
          title: 'Count (Percent)',
          grid: false,
          format: '.0%'
        }
      }
    });

    _defineProperty(_assertThisInitialized(_this), "getFormattedData", function () {
      var matchingField = _this.state.splitInfo.stats.filter(function (stat) {
        return stat.field === _this.state.activeColumn;
      }).pop();

      if (!matchingField) {
        return [];
      }

      var getTotalValues = function getTotalValues() {
        var dataType = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'train';
        var total = matchingField.numTotal[dataType];
        var nulls = matchingField.numNull[dataType];
        return total - nulls;
      };

      return matchingField.histo.reduce(function (prev, curr) {
        prev = prev || [];
        return [].concat(_toConsumableArray(prev), [{
          name: curr.bin,
          count: curr.count.train / getTotalValues('train'),
          type: 'train'
        }, {
          name: curr.bin,
          count: curr.count.test / getTotalValues('test'),
          type: 'test'
        }]);
      }, []);
    });

    return _this;
  }

  _createClass(SplitInfoGraph, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.setState({
        activeColumn: nextProps.activeColumn,
        splitInfo: nextProps.splitInfo
      });
    }
  }, {
    key: "render",
    value: function render() {
      if (!this.state.splitInfo.stats || !this.state.activeColumn) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_GroupedBarChart__WEBPACK_IMPORTED_MODULE_2__["default"], {
        customEncoding: this.customEncoding,
        data: this.getFormattedData(),
        width: function width(dimension, data) {
          if (!data.length) {
            return dimension.width - 260;
          }

          return (dimension.width - 260) / (data.length / 2);
        },
        heightOffset: 80,
        tooltipOptions: {
          showAllFields: false,
          fields: [{
            field: 'type',
            title: 'Type'
          }, {
            field: 'count',
            title: 'Percentage',
            format: '.0%',
            formatType: 'number'
          }]
        }
      });
    }
  }]);

  return SplitInfoGraph;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(SplitInfoGraph, "propTypes", {
  splitInfo: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object.isRequired,
  activeColumn: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired
});



/***/ }),

/***/ "./components/Experiments/CreateView/SplitDataStep/SplitInfoTable/SplitInfoTable.scss":
/*!********************************************************************************************!*\
  !*** ./components/Experiments/CreateView/SplitDataStep/SplitInfoTable/SplitInfoTable.scss ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../../node_modules/postcss-loader/src!../../../../../../../node_modules/sass-loader/dist/cjs.js!./SplitInfoTable.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/Experiments/CreateView/SplitDataStep/SplitInfoTable/SplitInfoTable.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/Experiments/CreateView/SplitDataStep/SplitInfoTable/index.js":
/*!*********************************************************************************!*\
  !*** ./components/Experiments/CreateView/SplitDataStep/SplitInfoTable/index.js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SplitInfoTable; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var components_SortableTable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/SortableTable */ "./components/SortableTable/index.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var lodash_findLast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash/findLast */ "../../node_modules/lodash/findLast.js");
/* harmony import */ var lodash_findLast__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_findLast__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_9__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */










var PREFIX = 'features.Experiments.CreateView.SplitInfo';

__webpack_require__(/*! ./SplitInfoTable.scss */ "./components/Experiments/CreateView/SplitDataStep/SplitInfoTable/SplitInfoTable.scss");

var SplitInfoTable =
/*#__PURE__*/
function (_Component) {
  _inherits(SplitInfoTable, _Component);

  function SplitInfoTable() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SplitInfoTable);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SplitInfoTable)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      collapsed: false,
      splitInfo: _this.props.splitInfo,
      search: '',
      selectedTypes: ['boolean', 'double', 'float', 'int', 'long', 'string'],
      activeColumn: _this.props.activeColumn,
      outcome: _this.props.outcome
    });

    _defineProperty(_assertThisInitialized(_this), "toggleCollapse", function () {
      _this.setState({
        collapsed: !_this.state.collapsed
      });
    });

    _defineProperty(_assertThisInitialized(_this), "isFieldNumberType", function (type) {
      return services_global_constants__WEBPACK_IMPORTED_MODULE_4__["NUMBER_TYPES"].indexOf(type) !== -1;
    });

    _defineProperty(_assertThisInitialized(_this), "CATEGORICAL_FIELD_HEADERS", [{
      property: 'name',
      label: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".columnName"))
    }, {
      property: 'numTotal',
      label: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".count"))
    }, {
      property: 'numEmpty',
      label: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".missing"))
    }, {
      property: 'unique',
      label: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".unique"))
    }]);

    _defineProperty(_assertThisInitialized(_this), "NUMERICAL_FIELD_HEADERS", [{
      property: 'name',
      label: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".columnName"))
    }, {
      property: 'numTotal',
      label: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".count"))
    }, {
      property: 'numEmpty',
      label: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".missing"))
    }, {
      property: 'numZero',
      label: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".zero"))
    }, {
      property: 'mean',
      label: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".mean"))
    }, {
      property: 'stddev',
      label: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".stddev"))
    }, {
      property: 'min',
      label: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".min"))
    }, {
      property: 'max',
      label: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".max"))
    }]);

    _defineProperty(_assertThisInitialized(_this), "onSearch", function (e) {
      _this.setState({
        search: e.target.value
      });
    });

    _defineProperty(_assertThisInitialized(_this), "onToggleSelectedType", function (e) {
      if (_this.state.selectedTypes.indexOf(e.target.name) !== -1) {
        _this.setState({
          selectedTypes: _this.state.selectedTypes.filter(function (type) {
            return type !== e.target.name;
          })
        });
      } else {
        _this.setState({
          selectedTypes: [].concat(_toConsumableArray(_this.state.selectedTypes), [e.target.name])
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "renderNumericalTableBody", function (fields) {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tbody", null, fields.map(function (field) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
          key: field.name,
          className: classnames__WEBPACK_IMPORTED_MODULE_8___default()({
            active: field.name === _this.state.activeColumn
          }),
          onClick: _this.props.onActiveColumnChange.bind(null, field.name)
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, _this.state.outcome === field.name ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "outcome-field"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
          name: "icon-star"
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, " ", field.name, " ")) : field.name), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, field.numTotal), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, field.numEmpty), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, field.numZero), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["roundDecimalToNDigits"])(field.mean, 4)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["roundDecimalToNDigits"])(field.stddev, 4)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, field.min), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, field.max));
      }));
    });

    _defineProperty(_assertThisInitialized(_this), "renderCategoricalTableBody", function (fields) {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tbody", null, fields.map(function (field) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
          key: field.name,
          className: classnames__WEBPACK_IMPORTED_MODULE_8___default()({
            active: field.name === _this.state.activeColumn
          }),
          onClick: _this.props.onActiveColumnChange.bind(null, field.name)
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, _this.state.outcome === field.name ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "outcome-field"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
          name: "icon-star"
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, " ", field.name, " ")) : field.name), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, field.numTotal), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, field.numEmpty), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, field.unique));
      }));
    });

    _defineProperty(_assertThisInitialized(_this), "renderNumericalTable", function (fields) {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SortableTable__WEBPACK_IMPORTED_MODULE_5__["default"], {
        entities: fields,
        tableHeaders: _this.NUMERICAL_FIELD_HEADERS,
        renderTableBody: _this.renderNumericalTableBody,
        sortOnInitialLoad: false
      });
    });

    _defineProperty(_assertThisInitialized(_this), "renderCategoricalTable", function (fields) {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_SortableTable__WEBPACK_IMPORTED_MODULE_5__["default"], {
        entities: fields,
        tableHeaders: _this.CATEGORICAL_FIELD_HEADERS,
        renderTableBody: _this.renderCategoricalTableBody,
        sortOnInitialLoad: false
      });
    });

    _defineProperty(_assertThisInitialized(_this), "renderTable", function () {
      if (!Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(_this.state.splitInfo, 'schema', 'fields', 'length')) {
        return null;
      }

      var schema = _this.state.splitInfo.schema;

      var getFieldType = function getFieldType(field) {
        var type; // TODO: The assumption fields cannot have complex type coming from dataprep wrangler
        // Need to verify this.

        if (Array.isArray(field.type)) {
          type = field.type.filter(function (t) {
            return t !== 'null';
          }).pop();
        } else if (typeof field.type === 'string') {
          type = field.type;
        }

        return type;
      };

      var getStats = function getStats(_ref) {
        var fieldName = _ref.name;
        var stat = lodash_findLast__WEBPACK_IMPORTED_MODULE_7___default()(_this.state.splitInfo.stats, function (stat) {
          return stat.field === fieldName;
        });
        stat = {
          numTotal: Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(stat, 'numTotal', 'total') || '--',
          numNull: Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(stat, 'numNull', 'total') || '--',
          numEmpty: Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(stat, 'numEmpty', 'total') || '--',
          unique: Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(stat, 'unique', 'total') || '--',
          numZero: Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(stat, 'numZero', 'total') || '--',
          numPositive: Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(stat, 'numPositive', 'total') || '--',
          numNegative: Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(stat, 'numNegative', 'total') || '--',
          min: Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(stat, 'min', 'total') || '--',
          max: Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(stat, 'max', 'total') || '--',
          stddev: Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(stat, 'stddev', 'total') || '--',
          mean: Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(stat, 'mean', 'total') || '--'
        };
        return _objectSpread({
          name: fieldName
        }, stat);
      };

      var searchMatchFilter = function searchMatchFilter(field) {
        if (_this.state.search.length) {
          return field.name.indexOf(_this.state.search) !== -1 ? true : false;
        }

        return field;
      };

      var typeMatchFilter = function typeMatchFilter(field) {
        return _this.state.selectedTypes.indexOf(getFieldType(field)) !== -1;
      };

      var categoricalFields = schema.fields.filter(function (field) {
        return typeMatchFilter(field) && searchMatchFilter(field) && !_this.isFieldNumberType(getFieldType(field));
      }).map(getStats.bind(_assertThisInitialized(_this)));
      var numericalFields = schema.fields.filter(function (field) {
        return typeMatchFilter(field) && searchMatchFilter(field) && _this.isFieldNumberType(getFieldType(field));
      }).map(getStats.bind(_assertThisInitialized(_this)));

      var countOfType = function countOfType(type) {
        return schema.fields.filter(function (field) {
          return getFieldType(field) === type;
        }).length;
      };

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "split-info-table-container"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "split-table-search"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "filter-container"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".dataType"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
        type: "checkbox",
        checked: _this.state.selectedTypes.indexOf('boolean') !== -1,
        onChange: _this.onToggleSelectedType,
        name: "boolean"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, " Boolean (", countOfType('boolean'), ") ")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
        type: "checkbox",
        checked: _this.state.selectedTypes.indexOf('double') !== -1,
        onChange: _this.onToggleSelectedType,
        name: "double"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, " Double (", countOfType('double'), ") ")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
        type: "checkbox",
        checked: _this.state.selectedTypes.indexOf('float') !== -1,
        onChange: _this.onToggleSelectedType,
        name: "float"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, " Float (", countOfType('float'), ") ")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
        type: "checkbox",
        checked: _this.state.selectedTypes.indexOf('int') !== -1,
        onChange: _this.onToggleSelectedType,
        name: "int"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, " Integer (", countOfType('int'), ") ")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
        type: "checkbox",
        checked: _this.state.selectedTypes.indexOf('long') !== -1,
        onChange: _this.onToggleSelectedType,
        name: "long"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, " Long (", countOfType('long'), ") ")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
        type: "checkbox",
        checked: _this.state.selectedTypes.indexOf('string') !== -1,
        onChange: _this.onToggleSelectedType,
        name: "string"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, " String (", countOfType('string'), ") "))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_3__["Input"], {
        className: "table-field-search",
        placeholder: i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".searchColumn")),
        onChange: _this.onSearch
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "split-info-numerical-table"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "split-table-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".numerical"))), _this.renderNumericalTable(numericalFields)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "split-info-categorical-table"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "split-table-header"
      }, i18n_react__WEBPACK_IMPORTED_MODULE_9___default.a.translate("".concat(PREFIX, ".categorical"))), _this.renderCategoricalTable(categoricalFields)));
    });

    return _this;
  }

  _createClass(SplitInfoTable, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.setState({
        splitInfo: nextProps.splitInfo,
        activeColumn: nextProps.activeColumn,
        outcome: nextProps.outcome
      });
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "split-info-table"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "split-info-collapsable-section",
        onClick: this.toggleCollapse
      }, this.state.collapsed ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
        name: "icon-caret-right"
      }) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
        name: "icon-caret-down"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, " View Features ")), !this.state.collapsed ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "split-info-table-section"
      }, this.renderTable()) : null);
    }
  }]);

  return SplitInfoTable;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(SplitInfoTable, "propTypes", {
  splitInfo: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  onActiveColumnChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  activeColumn: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  outcome: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
});



/***/ }),

/***/ "./components/Experiments/CreateView/SplitDataStep/index.js":
/*!******************************************************************!*\
  !*** ./components/Experiments/CreateView/SplitDataStep/index.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "../../node_modules/react-redux/es/index.js");
/* harmony import */ var components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/Experiments/store/createExperimentStore */ "./components/Experiments/store/createExperimentStore.js");
/* harmony import */ var components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/Experiments/store/CreateExperimentActionCreator */ "./components/Experiments/store/CreateExperimentActionCreator.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var components_Experiments_CreateView_SplitDataStep_SplitInfo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/Experiments/CreateView/SplitDataStep/SplitInfo */ "./components/Experiments/CreateView/SplitDataStep/SplitInfo/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_Alert__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/Alert */ "./components/Alert/index.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash/isEmpty */ "../../node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_11__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */












var PREFIX = 'features.Experiments.CreateView';

__webpack_require__(/*! ./SplitDataStep.scss */ "./components/Experiments/CreateView/SplitDataStep/SplitDataStep.scss");

var getSplitLogsUrl = function getSplitLogsUrl(experimentId, splitInfo) {
  var splitId = splitInfo.id;
  var startTime = splitInfo.start;
  var endTime = splitInfo.end;
  var baseUrl = "/logviewer/view?namespace=".concat(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_5__["getCurrentNamespace"])(), "&appId=ModelManagementApp&programType=spark&programId=ModelManagerService");
  var queryParams = "&filter=".concat(encodeURIComponent("MDC:experiment=\"".concat(experimentId, "\" AND MDC:split=").concat(splitId)), "&startTime=").concat(startTime, "&endTime=").concat(endTime);
  return "".concat(baseUrl).concat(queryParams);
};

var getSplitFailedElem = function getSplitFailedElem(experimentId, splitInfo) {
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
    className: "split-error-container"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".failedToSplit"), {
    experimentId: experimentId
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
    href: getSplitLogsUrl(experimentId, splitInfo),
    target: "_blank",
    rel: "noopener noreferrer"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".logs"))), i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".moreInfo")));
};

var SplitDataStep =
/*#__PURE__*/
function (_Component) {
  _inherits(SplitDataStep, _Component);

  function SplitDataStep() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SplitDataStep);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SplitDataStep)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      splitFailed: false
    });

    _defineProperty(_assertThisInitialized(_this), "closeSplitFailedAlert", function () {
      _this.setState({
        splitFailed: false
      });
    });

    return _this;
  }

  _createClass(SplitDataStep, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      var isCurrentSplitStatusFailed = nextProps.splitInfo.status === components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__["SPLIT_STATUS"].FAILED;
      var isStartingSplitFailed = this.props.splitInfo.status === components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__["SPLIT_STATUS"].CREATING && nextProps.error;

      if (isCurrentSplitStatusFailed || isStartingSplitFailed) {
        this.setState({
          splitFailed: true
        });
      }
    }
  }, {
    key: "renderSplitBtn",
    value: function renderSplitBtn() {
      var isSplitCreated = Object.keys(this.props.splitInfo).length;
      var splitStatus = (this.props.splitInfo || {}).status;
      var isSplitComplete = [components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__["SPLIT_STATUS"].COMPLETE, components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__["SPLIT_STATUS"].FAILED].indexOf(splitStatus) !== -1;

      if (!isSplitCreated || isSplitCreated && isSplitComplete) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: classnames__WEBPACK_IMPORTED_MODULE_10___default()('btn btn-primary', {
            'btn-secondary': isSplitCreated && isSplitComplete
          }),
          onClick: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["createSplitAndUpdateStatus"]
        }, this.state.splitFailed || isSplitCreated ? i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".resplitAndVerify")) : i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".splitAndVerify"))), isSplitCreated && isSplitComplete ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "done-action-container"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
          className: "btn btn-primary",
          onClick: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["setSplitFinalized"],
          disabled: splitStatus !== components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__["SPLIT_STATUS"].COMPLETE
        }, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate('commons.doneLabel')), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".nextSelect")))) : null);
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("button", {
        className: "btn btn-primary",
        disabled: true
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "btn-inner-container"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_7__["default"], {
        name: "icon-spinner",
        className: "fa-spin"
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".splitting")))));
    }
  }, {
    key: "renderSplitInfo",
    value: function renderSplitInfo() {
      var isSplitFailed = this.props.splitInfo.status === components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__["SPLIT_STATUS"].FAILED;

      if (lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9___default()(this.props.splitInfo) || !this.props.splitInfo.id || isSplitFailed) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "action-button-group"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_CreateView_SplitDataStep_SplitInfo__WEBPACK_IMPORTED_MODULE_6__["default"], null));
    }
  }, {
    key: "renderError",
    value: function renderError() {
      var _this2 = this;

      if (!this.state.splitFailed) {
        return null;
      }
      /*
        We have 2 cases where we want to show an Alert on this page:
        1. When the split status request returns 200, but status is 'Failed'
        2. When the split request or split status request returns error code
      */


      if (this.props.splitInfo.id) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Alert__WEBPACK_IMPORTED_MODULE_8__["default"], {
          element: getSplitFailedElem(this.props.experimentId, this.props.splitInfo),
          type: "error",
          showAlert: true,
          onClose: this.closeSplitFailedAlert
        });
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Alert__WEBPACK_IMPORTED_MODULE_8__["default"], {
        message: this.props.error,
        type: "error",
        showAlert: true,
        onClose: function onClose() {
          _this2.closeSplitFailedAlert();

          Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_4__["setModelCreateError"])();
        }
      });
    }
  }, {
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "split-data-step"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h3", null, i18n_react__WEBPACK_IMPORTED_MODULE_11___default.a.translate("".concat(PREFIX, ".splitData"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), this.renderSplitBtn(), this.renderSplitInfo(), this.renderError());
    }
  }]);

  return SplitDataStep;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(SplitDataStep, "propTypes", {
  splitInfo: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  experimentId: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  error: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string
});

var mapStateToSplitDataStepProps = function mapStateToSplitDataStepProps(state) {
  var model_create = state.model_create,
      experiments_create = state.experiments_create;
  var _model_create$splitIn = model_create.splitInfo,
      splitInfo = _model_create$splitIn === void 0 ? {} : _model_create$splitIn,
      error = model_create.error;
  return {
    splitInfo: splitInfo,
    experimentId: experiments_create.name,
    error: error
  };
};

var ConnectedSplitDataStep = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToSplitDataStepProps)(SplitDataStep);

function ProvidedSplitDataStep() {
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_redux__WEBPACK_IMPORTED_MODULE_2__["Provider"], {
    store: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_3__["default"]
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ConnectedSplitDataStep, null));
}

/* harmony default export */ __webpack_exports__["default"] = (ProvidedSplitDataStep);

/***/ }),

/***/ "./components/Experiments/CreateView/index.js":
/*!****************************************************!*\
  !*** ./components/Experiments/CreateView/index.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ExperimentCreateView; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Experiments_TopPanel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Experiments/TopPanel */ "./components/Experiments/TopPanel/index.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_DataPrepConnections__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/DataPrepConnections */ "./components/DataPrepConnections/index.js");
/* harmony import */ var components_DataPrepHome__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/DataPrepHome */ "./components/DataPrepHome/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/Experiments/store/createExperimentStore */ "./components/Experiments/store/createExperimentStore.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var components_Popover__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/Popover */ "./components/Popover/index.js");
/* harmony import */ var components_Experiments_CreateView_Popovers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/Experiments/CreateView/Popovers */ "./components/Experiments/CreateView/Popovers/index.js");
/* harmony import */ var components_DataPrep_store__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/DataPrep/store */ "./components/DataPrep/store/index.js");
/* harmony import */ var components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! components/Experiments/store/CreateExperimentActionCreator */ "./components/Experiments/store/CreateExperimentActionCreator.js");
/* harmony import */ var components_Experiments_CreateView_MLAlgorithmSelection__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! components/Experiments/CreateView/MLAlgorithmSelection */ "./components/Experiments/CreateView/MLAlgorithmSelection/index.js");
/* harmony import */ var components_Experiments_CreateView_SplitDataStep__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! components/Experiments/CreateView/SplitDataStep */ "./components/Experiments/CreateView/SplitDataStep/index.js");
/* harmony import */ var components_Experiments_CreateView_ExperimentMetadata__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! components/Experiments/CreateView/ExperimentMetadata */ "./components/Experiments/CreateView/ExperimentMetadata/index.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react-helmet */ "../../node_modules/react-helmet/lib/Helmet.js");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! query-string */ "../../node_modules/query-string/index.js");
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(query_string__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! components/LoadingSVGCentered */ "./components/LoadingSVGCentered/index.js");
/* harmony import */ var components_DataPrep_store_DataPrepActions__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! components/DataPrep/store/DataPrepActions */ "./components/DataPrep/store/DataPrepActions.js");
/* harmony import */ var components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! components/DataPrep/helper */ "./components/DataPrep/helper.js");
/* harmony import */ var api_dataprep__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! api/dataprep */ "./api/dataprep.js");
/* harmony import */ var components_Alert__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! components/Alert */ "./components/Alert/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */



























var PREFIX = 'features.Experiments.CreateView';

__webpack_require__(/*! ./CreateView.scss */ "./components/Experiments/CreateView/CreateView.scss");

var ExperimentCreateView =
/*#__PURE__*/
function (_Component) {
  _inherits(ExperimentCreateView, _Component);

  function ExperimentCreateView() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ExperimentCreateView);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ExperimentCreateView)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      workspaceId: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["default"].getState().experiments_create.workspaceId,
      modelId: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["default"].getState().model_create.modelId,
      experimentId: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["default"].getState().experiments_create.name,
      isSplitFinalized: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["default"].getState().model_create.isSplitFinalized,
      loading: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["default"].getState().experiments_create.loading,
      active_step: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["default"].getState().active_step.step_name,
      redirectToExperimentDetail: false
    });

    _defineProperty(_assertThisInitialized(_this), "title", 'Create a new experiment');

    _defineProperty(_assertThisInitialized(_this), "renderTopPanel", function (title) {
      var navigateTo = "/ns/".concat(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_8__["getCurrentNamespace"])(), "/experiments");

      if (_this.state.experimentId) {
        navigateTo = "".concat(navigateTo, "/").concat(_this.state.experimentId);
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_TopPanel__WEBPACK_IMPORTED_MODULE_2__["default"], null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h4", null, title), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_6__["Link"], {
        to: navigateTo
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
        name: "icon-close"
      })));
    });

    return _this;
  }

  _createClass(ExperimentCreateView, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["setAlgorithmsListForCreateView"])();
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      this.dataprepsubscription = components_DataPrep_store__WEBPACK_IMPORTED_MODULE_11__["default"].subscribe(function () {
        var _DataPrepStore$getSta = components_DataPrep_store__WEBPACK_IMPORTED_MODULE_11__["default"].getState(),
            dataprep = _DataPrepStore$getSta.dataprep;

        var _dataprep$headers = dataprep.headers,
            headers = _dataprep$headers === void 0 ? [] : _dataprep$headers,
            directives = dataprep.directives,
            _dataprep$workspaceIn = dataprep.workspaceInfo,
            workspaceInfo = _dataprep$workspaceIn === void 0 ? {} : _dataprep$workspaceIn,
            workspaceId = dataprep.workspaceId;

        if (!headers.length) {
          return;
        }

        Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["setWorkspace"])(workspaceId);
        Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["setSrcPath"])(workspaceInfo.properties.path);
        Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["setOutcomeColumns"])(headers);
        Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["setDirectives"])(directives);
        var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_20__["directiveRequestBodyCreator"])(directives);
        api_dataprep__WEBPACK_IMPORTED_MODULE_21__["default"].getSchema({
          context: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_8__["getCurrentNamespace"])(),
          workspaceId: workspaceId
        }, requestBody).subscribe(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["updateSchema"]);
      });
      this.createExperimentStoreSubscription = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["default"].subscribe(function () {
        var _createExperimentStor = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["default"].getState(),
            model_create = _createExperimentStor.model_create,
            experiments_create = _createExperimentStor.experiments_create,
            active_step = _createExperimentStor.active_step;

        var modelId = model_create.modelId,
            isSplitFinalized = model_create.isSplitFinalized,
            isModelTrained = model_create.isModelTrained;
        var workspaceId = experiments_create.workspaceId,
            loading = experiments_create.loading,
            experimentId = experiments_create.name,
            experimentError = experiments_create.error;
        var newState = {};

        if (_this2.state.experimentId !== experimentId) {
          newState = {
            experimentId: experimentId
          };
        }

        if (_this2.state.active_step.step_name !== active_step.step_name) {
          newState = _objectSpread({}, newState, {
            active_step: active_step
          });
        }

        if (_this2.state.modelId !== modelId) {
          newState = _objectSpread({}, newState, {
            modelId: modelId
          });
        }

        if (_this2.state.workspaceId !== workspaceId) {
          newState = _objectSpread({}, newState, {
            workspaceId: workspaceId
          });
        }

        if (_this2.state.loading !== loading) {
          newState = _objectSpread({}, newState, {
            loading: loading
          });
        }

        if (isSplitFinalized !== _this2.state.isSplitFinalized) {
          newState = _objectSpread({}, newState, {
            isSplitFinalized: isSplitFinalized
          });
        }

        if (isModelTrained) {
          newState = _objectSpread({}, newState, {
            redirectToExperimentDetail: true
          });
        }

        if (_this2.state.experimentError !== experimentError) {
          newState = _objectSpread({}, newState, {
            experimentError: experimentError
          });
        }

        if (Object.keys(newState).length > 0) {
          _this2.setState(newState);
        }
      });

      var _queryString$parse = query_string__WEBPACK_IMPORTED_MODULE_17___default.a.parse(this.props.location.search),
          experimentId = _queryString$parse.experimentId,
          modelId = _queryString$parse.modelId;

      if (experimentId && !modelId) {
        Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["getExperimentForEdit"])(experimentId);
      } else if (experimentId && modelId) {
        Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["getExperimentModelSplitForCreate"])(experimentId, modelId);
      } else {
        this.setState({
          loading: false
        });
      }

      Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["fetchAlgorithmsList"])();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      var _createExperimentStor2 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["default"].getState(),
          experiments_create = _createExperimentStor2.experiments_create;

      var workspaceId = experiments_create.workspaceId;

      if (workspaceId) {
        // Every workspace created in experiments create view is temp. So don't worry about deleting it.
        api_dataprep__WEBPACK_IMPORTED_MODULE_21__["default"]["delete"]({
          context: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_8__["getCurrentNamespace"])(),
          workspaceId: workspaceId
        }).subscribe();
      }

      components_DataPrep_store__WEBPACK_IMPORTED_MODULE_11__["default"].dispatch({
        type: components_DataPrep_store_DataPrepActions__WEBPACK_IMPORTED_MODULE_19__["default"].reset
      });

      if (this.dataprepsubscription) {
        this.dataprepsubscription();
      }

      Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["resetCreateExperimentsStore"])();
    }
  }, {
    key: "renderConnections",
    value: function renderConnections() {
      var _this3 = this;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.renderTopPanel(this.title), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_DataPrepConnections__WEBPACK_IMPORTED_MODULE_4__["default"], {
        sidePanelExpanded: false,
        allowSidePanelToggle: false,
        enableRouting: false,
        singleWorkspaceMode: true,
        onWorkspaceCreate: function onWorkspaceCreate(workspaceId) {
          Object(components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["setWorkspace"])(workspaceId);

          _this3.setState({
            workspaceId: workspaceId
          });
        },
        scope: true,
        browserTitle: "Select a file to use in your experiment"
      }));
    }
  }, {
    key: "renderDataPrep",
    value: function renderDataPrep() {
      var _this4 = this;

      var updateModelBtn = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "btn btn-primary",
        onClick: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["updateModel"]
      }, "Update Model");

      var _queryString$parse2 = query_string__WEBPACK_IMPORTED_MODULE_17___default.a.parse(this.props.location.search),
          experimentId = _queryString$parse2.experimentId,
          addModel = _queryString$parse2.addModel;

      var popoverElementLabel = i18n_react__WEBPACK_IMPORTED_MODULE_23___default.a.translate("".concat(PREFIX, ".createExperiment"));

      if (addModel) {
        popoverElementLabel = i18n_react__WEBPACK_IMPORTED_MODULE_23___default.a.translate("".concat(PREFIX, ".addModel"));
      }

      var popoverElement = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "btn btn-primary"
      }, popoverElementLabel);
      var createModelBtn = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Popover__WEBPACK_IMPORTED_MODULE_9__["default"], {
        target: function target() {
          return popoverElement;
        },
        enableInteractionInPopover: true,
        targetDimension: {
          width: 'auto'
        },
        placement: "bottom",
        className: "create_new_experiment_popover",
        showPopover: !experimentId ? true : false
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_CreateView_Popovers__WEBPACK_IMPORTED_MODULE_10__["default"], null));
      var topPanelTitle = 'Create a new experiment';

      if (addModel) {
        topPanelTitle = "Add model to '".concat(experimentId, "'");
      }

      var renderAddBtn = function renderAddBtn() {
        if (!_this4.state.workspaceId) {
          return null;
        }

        return _this4.state.modelId ? updateModelBtn : createModelBtn;
      };

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, this.renderTopPanel(topPanelTitle), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "experiments-model-panel"
      }, renderAddBtn()), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_DataPrepHome__WEBPACK_IMPORTED_MODULE_5__["default"], {
        singleWorkspaceMode: true,
        enableRouting: false,
        workspaceId: this.state.workspaceId
      }));
    }
  }, {
    key: "renderSplitDataStep",
    value: function renderSplitDataStep() {
      var name = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["default"].getState().model_create.name;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "experiments-split-data-step"
      }, this.renderTopPanel("Split data for model '".concat(name, "'")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_CreateView_ExperimentMetadata__WEBPACK_IMPORTED_MODULE_15__["default"], null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_CreateView_SplitDataStep__WEBPACK_IMPORTED_MODULE_14__["default"], null));
    }
  }, {
    key: "renderAlgorithmSelectionStep",
    value: function renderAlgorithmSelectionStep() {
      var name = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["default"].getState().model_create.name;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "experiments-algorithm-selection-step"
      }, this.renderTopPanel("Select an algorithm to train model '".concat(name, "'")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_CreateView_ExperimentMetadata__WEBPACK_IMPORTED_MODULE_15__["default"], null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Experiments_CreateView_MLAlgorithmSelection__WEBPACK_IMPORTED_MODULE_13__["default"], null));
    }
  }, {
    key: "renderSteps",
    value: function renderSteps() {
      if (this.state.loading) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_18__["default"], null);
      }

      if (this.state.redirectToExperimentDetail) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_6__["Redirect"], {
          to: "/ns/".concat(Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_8__["getCurrentNamespace"])(), "/experiments/").concat(this.state.experimentId)
        });
      }

      switch (this.state.active_step.step_name) {
        case components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["CREATION_STEPS"].DATAPREP_CONNECTIONS:
          return this.renderConnections();

        case components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["CREATION_STEPS"].DATAPREP:
          return this.renderDataPrep();

        case components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["CREATION_STEPS"].DATASPLIT:
          return this.renderSplitDataStep();

        case components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_7__["CREATION_STEPS"].ALGORITHM_SELECTION:
          return this.renderAlgorithmSelectionStep();

        default:
          return null;
      }
    }
  }, {
    key: "renderError",
    value: function renderError() {
      if (!this.state.experimentError) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_Alert__WEBPACK_IMPORTED_MODULE_22__["default"], {
        message: this.state.experimentError,
        type: "error",
        showAlert: true,
        onClose: components_Experiments_store_CreateExperimentActionCreator__WEBPACK_IMPORTED_MODULE_12__["setExperimentCreateError"]
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _queryString$parse3 = query_string__WEBPACK_IMPORTED_MODULE_17___default.a.parse(this.props.location.search),
          experimentId = _queryString$parse3.experimentId,
          addModel = _queryString$parse3.addModel;

      var expId = experimentId ? "".concat(experimentId, " | ") : '';
      var labelSuffix = addModel ? 'Add model' : 'Create Experiment';
      var featureName = services_ThemeHelper__WEBPACK_IMPORTED_MODULE_26__["Theme"].featureNames.analytics;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_24___default()('experiments-create-view', {
          'add-model': !Object(services_helpers__WEBPACK_IMPORTED_MODULE_25__["isNilOrEmpty"])(this.state.experimentId)
        })
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_helmet__WEBPACK_IMPORTED_MODULE_16___default.a, {
        title: i18n_react__WEBPACK_IMPORTED_MODULE_23___default.a.translate("".concat(PREFIX, ".pageTitle"), {
          productName: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_26__["Theme"].productName,
          experimentIdWithSuffix: "".concat(expId, " ").concat(labelSuffix),
          featureName: featureName
        })
      }), this.renderSteps(), this.renderError(), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_6__["Prompt"], {
        when: !this.state.experimentId || !this.state.modelId,
        message: 'Are you sure you want to navigate away?'
      }));
    }
  }]);

  return ExperimentCreateView;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

_defineProperty(ExperimentCreateView, "propTypes", {
  match: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  location: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object
});



/***/ }),

/***/ "./components/Experiments/store/CreateExperimentActionCreator.js":
/*!***********************************************************************!*\
  !*** ./components/Experiments/store/CreateExperimentActionCreator.js ***!
  \***********************************************************************/
/*! exports provided: onExperimentNameChange, onExperimentDescriptionChange, onExperimentOutcomeChange, setSrcPath, setOutcomeColumns, setDirectives, setVisiblePopover, setExperimentCreated, setExperimentLoading, onModelNameChange, onModelDescriptionChange, setModelAlgorithm, setWorkspace, updateSchema, setSplitDetails, createExperiment, pollForSplitStatus, createSplitAndUpdateStatus, createModel, trainModel, getExperimentForEdit, getExperimentModelSplitForCreate, setAlgorithmList, setSplitFinalized, resetCreateExperimentsStore, fetchAlgorithmsList, updateHyperParam, setExperimentCreateError, setModelCreateError, setAlgorithmsListForCreateView, overrideCreationStep, updateModel, createWorkspace, applyDirectives */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onExperimentNameChange", function() { return onExperimentNameChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onExperimentDescriptionChange", function() { return onExperimentDescriptionChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onExperimentOutcomeChange", function() { return onExperimentOutcomeChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setSrcPath", function() { return setSrcPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setOutcomeColumns", function() { return setOutcomeColumns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setDirectives", function() { return setDirectives; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setVisiblePopover", function() { return setVisiblePopover; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setExperimentCreated", function() { return setExperimentCreated; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setExperimentLoading", function() { return setExperimentLoading; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onModelNameChange", function() { return onModelNameChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onModelDescriptionChange", function() { return onModelDescriptionChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setModelAlgorithm", function() { return setModelAlgorithm; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setWorkspace", function() { return setWorkspace; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateSchema", function() { return updateSchema; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setSplitDetails", function() { return setSplitDetails; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createExperiment", function() { return createExperiment; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pollForSplitStatus", function() { return pollForSplitStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createSplitAndUpdateStatus", function() { return createSplitAndUpdateStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createModel", function() { return createModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "trainModel", function() { return trainModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getExperimentForEdit", function() { return getExperimentForEdit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getExperimentModelSplitForCreate", function() { return getExperimentModelSplitForCreate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setAlgorithmList", function() { return setAlgorithmList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setSplitFinalized", function() { return setSplitFinalized; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetCreateExperimentsStore", function() { return resetCreateExperimentsStore; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchAlgorithmsList", function() { return fetchAlgorithmsList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateHyperParam", function() { return updateHyperParam; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setExperimentCreateError", function() { return setExperimentCreateError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setModelCreateError", function() { return setModelCreateError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setAlgorithmsListForCreateView", function() { return setAlgorithmsListForCreateView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "overrideCreationStep", function() { return overrideCreationStep; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateModel", function() { return updateModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createWorkspace", function() { return createWorkspace; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "applyDirectives", function() { return applyDirectives; });
/* harmony import */ var components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! components/Experiments/store/createExperimentStore */ "./components/Experiments/store/createExperimentStore.js");
/* harmony import */ var components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/Experiments/store/experimentDetailStore */ "./components/Experiments/store/experimentDetailStore.js");
/* harmony import */ var components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Experiments/store/SharedActionCreator */ "./components/Experiments/store/SharedActionCreator.js");
/* harmony import */ var api_experiments__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api/experiments */ "./api/experiments.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_dataprep__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! api/dataprep */ "./api/dataprep.js");
/* harmony import */ var components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/DataPrep/helper */ "./components/DataPrep/helper.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/Observable */ "../../node_modules/rxjs/Observable.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(rxjs_Observable__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var services_global_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! services/global-constants */ "./services/global-constants.js");
/* harmony import */ var components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/Experiments/store/ModelStatus */ "./components/Experiments/store/ModelStatus.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */











function onExperimentNameChange(e) {
  var value = e.target.value;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_NAME,
    payload: {
      name: value
    }
  });
}

function onExperimentDescriptionChange(e) {
  var value = e.target.value;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_DESCRIPTION,
    payload: {
      description: value
    }
  });
}

function onExperimentOutcomeChange(e) {
  var value = e.target.value;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_OUTCOME,
    payload: {
      outcome: value
    }
  });
}

function setSrcPath(srcpath) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_SRC_PATH,
    payload: {
      srcpath: srcpath
    }
  });
}

function setOutcomeColumns(columns) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_OUTCOME_COLUMNS,
    payload: {
      columns: columns
    }
  });
}

function setDirectives(directives) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_DIRECTIVES,
    payload: {
      directives: directives
    }
  });
}

function setVisiblePopover() {
  var popover = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["POPOVER_TYPES"].EXPERIMENT;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_VISIBLE_POPOVER,
    payload: {
      popover: popover
    }
  });
}

function setExperimentCreated(experimentId) {
  var url = "".concat(location.pathname, "?experimentId=").concat(experimentId);
  history.replaceState({
    url: url
  }, document.title, url);
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_VISIBLE_POPOVER,
    payload: {
      popover: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["POPOVER_TYPES"].MODEL
    }
  });
}

function setExperimentLoading() {
  var value = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_CREATE_EXPERIMENT_LOADING,
    payload: {
      loading: value
    }
  });
}

function onModelNameChange(e) {
  var value = e.target.value;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODEL_NAME,
    payload: {
      name: value
    }
  });
}

function onModelDescriptionChange(e) {
  var value = e.target.value;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODEL_DESCRIPTION,
    payload: {
      description: value
    }
  });
}

function setModelAlgorithm(algorithm) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODEL_ML_ALGORITHM,
    payload: {
      algorithm: algorithm
    }
  });
}

function updateHyperParam(key, value) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].UPDATE_HYPER_PARAM,
    payload: {
      key: key,
      value: value
    }
  });
}

function setWorkspace(workspaceId) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_WORKSPACE_ID,
    payload: {
      workspaceId: workspaceId
    }
  });
}

function updateSchema(fields) {
  var schema = {
    name: 'avroSchema',
    type: 'record',
    fields: fields
  };
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_SCHEMA,
    payload: {
      schema: schema
    }
  });
}

function setSplitDetails(experimentId, splitId) {
  if (splitId.id) {
    splitId = splitId.id;
  }

  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getSplitDetails({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experimentId,
    splitId: splitId
  }).subscribe(function (splitInfo) {
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_SPLIT_INFO,
      payload: {
        splitInfo: splitInfo
      }
    });
  }, function (err) {
    setModelCreateError("Failed to get split details of the experiment '".concat(experimentId, "' - ").concat(err.response || err));
  });
}

function createExperiment() {
  var _createExperimentStor = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      model_create = _createExperimentStor.model_create,
      experiments_create = _createExperimentStor.experiments_create;

  var name = experiments_create.name,
      description = experiments_create.description,
      outcome = experiments_create.outcome,
      srcpath = experiments_create.srcpath;
  var directives = model_create.directives;
  var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_6__["directiveRequestBodyCreator"])(directives);
  var experiment = {
    name: name,
    description: description,
    outcome: outcome,
    srcpath: srcpath,
    directives: directives
  };
  api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].getSchema({
    context: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    workspaceId: experiments_create.workspaceId
  }, requestBody).mergeMap(function (schema) {
    // The outcome will always be simple type. So ["null", "anything"] should give correct outcomeType at the end.
    var outcomeType = schema.map(function (field) {
      return Array.isArray(field.type) ? field : _objectSpread({}, field, {
        type: [field.type]
      });
    }).find(function (field) {
      return field.name === experiment.outcome;
    }).type.filter(function (t) {
      return t !== 'null';
    }).pop();
    experiment.outcomeType = outcomeType;
    updateSchema(schema);
    return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].createExperiment({
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
      experimentId: experiment.name
    }, experiment);
  }).subscribe(setExperimentCreated.bind(null, experiments_create.name), function (err) {
    return setExperimentCreateError("Failed to create the experiment '".concat(name, "' - ").concat(err.response || err));
  });
}

function pollForSplitStatus(experimentId, modelId) {
  var getStatusOfSplit = function getStatusOfSplit(callback, errorCallback) {
    var params = {
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
      experimentId: experimentId,
      modelId: modelId
    };
    var splitStatusPoll = api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].pollModel(params).subscribe(function (modelDetails) {
      var status = modelDetails.status,
          split = modelDetails.split;

      if (status === 'Splitting') {
        return;
      }

      if (status === 'Data Ready' || status === 'Split Failed') {
        splitStatusPoll.unsubscribe();
        return callback(split);
      } // TODO: Should this be called on split failed?


      errorCallback();
    });
  };

  return rxjs_Observable__WEBPACK_IMPORTED_MODULE_7__["Observable"].create(function (observer) {
    var successCallback = function successCallback(split) {
      observer.next(split);
    };

    var failureCallback = function failureCallback() {
      observer.error("Couldn't create split");
    };

    getStatusOfSplit(successCallback, failureCallback);
  });
}

function overrideCreationStep(step) {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].OVERRIDE_CREATION_STEP,
    payload: {
      active_step: step
    }
  });
}
/*
  This is needed when user clicks "Split Data" button in the split step

  1. Create a split under the model (POST `/models/:modelId/split`)
  2. This will create a split and assign it to the model
  3. Once the model is assigned a split poll the model for an update on its status
  4. Once the status is "Data Ready" or "Split Failed" update UI appropriately.

*/


function createSplitAndUpdateStatus() {
  var _arguments = arguments;

  var _createExperimentStor2 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      model_create = _createExperimentStor2.model_create,
      experiments_create = _createExperimentStor2.experiments_create;

  var directives = model_create.directives,
      schema = model_create.schema,
      modelId = model_create.modelId,
      modelName = model_create.name;
  var splitInfo = {
    schema: schema,
    directives: directives,
    type: 'random',
    parameters: {
      percent: '80'
    },
    description: "Default Random split created for the model '".concat(modelName, "'")
  };
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_SPLIT_INFO,
    payload: {
      splitInfo: {
        id: null,
        status: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["SPLIT_STATUS"].CREATING // INTERMEDIATE STATE TO SHOW LOADING ANIMATION FOR THE SPLIT BUTTON

      }
    }
  });
  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].createSplit({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experiments_create.name,
    modelId: modelId
  }, splitInfo).mergeMap(function () {
    return pollForSplitStatus(experiments_create.name, modelId);
  }).subscribe(setSplitDetails.bind(null, experiments_create.name), function (err) {
    setModelCreateError("Failed to create split for the model '".concat(modelName, "' - ").concat(err.response || err));
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_SPLIT_INFO,
      payload: {
        splitInfo: {
          id: null
        }
      }
    });
  }, function () {
    return console.log('Split Task complete ', _arguments);
  });
}

function updateModel() {
  var _createExperimentStor3 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      experiments_create = _createExperimentStor3.experiments_create,
      model_create = _createExperimentStor3.model_create;

  var directives = model_create.directives;
  var params = {
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experiments_create.name,
    modelId: model_create.modelId
  };
  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getModelStatus(params).flatMap(function (status) {
    if (components_Experiments_store_ModelStatus__WEBPACK_IMPORTED_MODULE_9__["MODEL_STATUS"].PREPARING === status) {
      return rxjs_Observable__WEBPACK_IMPORTED_MODULE_7__["Observable"].create(function (observer) {
        return observer.next();
      });
    }

    return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].deleteSplitInModel(params);
  }).flatMap(function () {
    return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].updateDirectivesInModel(params, {
      directives: directives
    });
  }).subscribe(function () {
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].MODEL_UPDATE
    });
  });
}

function createModel() {
  var _createExperimentStor4 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      experiments_create = _createExperimentStor4.experiments_create,
      model_create = _createExperimentStor4.model_create;

  var directives = model_create.directives;
  var model = {
    name: model_create.name,
    description: model_create.description,
    directives: directives
  };
  return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].createModelInExperiment({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experiments_create.name
  }, model).subscribe(function (_ref) {
    var modelId = _ref.id;
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODEL_ID,
      payload: {
        modelId: modelId
      }
    });
    setExperimentLoading(false);
    var url = "".concat(location.pathname).concat(location.search, "&modelId=").concat(modelId);
    history.replaceState({
      url: url
    }, document.title, url);
  }, function (err) {
    setExperimentCreateError("Failed to create the model '".concat(model_create.name, "' - ").concat(err.response || err));
    setExperimentLoading(false);
  });
}

function trainModel() {
  var _createExperimentStor5 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      experiments_create = _createExperimentStor5.experiments_create,
      model_create = _createExperimentStor5.model_create;

  var experimentId = experiments_create.name;
  var modelId = model_create.modelId,
      modelName = model_create.name;
  var formattedExperimentName = experimentId.replace(/[^\w]/g, '');
  var formattedModelName = modelName.replace(/[^\w]/g, '');
  var postBody = {
    algorithm: model_create.algorithm.name,
    hyperparameters: model_create.algorithm.hyperparameters,
    predictionsDataset: "".concat(formattedExperimentName, "_").concat(formattedModelName, "_dataset")
  };
  return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].trainModel({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experimentId,
    modelId: modelId
  }, postBody).subscribe(function () {
    components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch({
      type: components_Experiments_store_experimentDetailStore__WEBPACK_IMPORTED_MODULE_1__["ACTIONS"].SET_NEWLY_TRAINING_MODEL,
      payload: {
        model: model_create
      }
    });
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODEL_TRAINED
    });
  }, function (err) {
    setModelCreateError("Failed to train the model '".concat(modelName, "': ").concat(err.response || err));
  });
}

function createWorkspace(filePath) {
  var params = {
    context: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    path: filePath,
    lines: 10000,
    sampler: 'first',
    scope: 'mmds'
  };
  var headers = {
    'Content-Type': 'text/plain' // FIXME: THIS IS A HACK. NEED TO GET THIS FROM EXPERIMENT

  }; // FIXME: When we go to split step and create a workspace for
  // switching between steps we don't have the file content type
  // Need to store that somehow in the model/experiment
  // JIRA: CDAP-13815

  var filePathLength = filePath.length;

  if (filePathLength > 5 && filePath.substr(filePathLength - 5) === '.json') {
    headers['Content-Type'] = 'application/json';
  }

  return api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].readFile(params, null, headers);
}

function applyDirectives(workspaceId, directives) {
  return api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].getWorkspace({
    context: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    workspaceId: workspaceId
  }).mergeMap(function (res) {
    var workspaceInfo = res.values[0];
    var params = {
      workspaceId: workspaceId,
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])()
    };
    var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_6__["directiveRequestBodyCreator"])(directives);
    requestBody.properties = workspaceInfo.properties;
    return api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].execute(params, requestBody);
  });
}
/*
  This is needed when user has already created an experiment but is still in dataprep stage.
  On refresh in this state we need to go back to the same view the user left.

  1. Fetch the experiments details
  2. Get directives and srcpath from the details
  3. Create a workspace with the srcpath
  4. Once created execute it with the list of directives
  5. Once the workspace is setup and update the stores.

  After step5 CreateView will pass the workspaceid to DataPrepConnection which will render the browser.
*/


var getExperimentForEdit = function getExperimentForEdit(experimentId) {
  setExperimentLoading();
  var experiment, directives;
  var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])();
  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getExperiment({
    namespace: namespace,
    experimentId: experimentId
  }).mergeMap(function (exp) {
    experiment = exp;
    return createWorkspace(exp.srcpath);
  }).mergeMap(function (res) {
    var workspaceId = res.values[0].id;
    experiment.workspaceId = workspaceId;
    directives = experiment.directives;
    setDirectives(directives);
    return applyDirectives(workspaceId, directives);
  }).mergeMap(function () {
    // Get schema with workspaceId and directives
    var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_6__["directiveRequestBodyCreator"])(directives);
    return api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].getSchema({
      namespace: namespace,
      workspaceId: experiment.workspaceId
    }, requestBody);
  }).subscribe(function (fields) {
    var schema = {
      name: 'avroSchema',
      type: 'record',
      fields: fields
    };
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_METADATA_FOR_EDIT,
      payload: {
        experimentDetails: experiment,
        schema: schema
      }
    });
  }, function (err) {
    // The error message returned from backend for this request is at err.response.message instead of just err.response
    var error = err.response.message || err.response || err;
    setExperimentLoading(false);
    setExperimentCreateError("Failed to retrieve the experiment '".concat(experimentId, "' - ").concat(error));
  });
};
/*
  This is needed when the user has created the model but still is in the split stage.
  On refresh in this state we need to go back to the same view the user left.

  1. Fetch the experiments details
  2. Get the srcpath from the details
  3. Create a workspace with the srcpath
  4. Once created execute it with the list of directives from model
  5. Once the workspace is setup and update the stores.
  6. Check if the model already has a splitid
  7. If yes fetch split details and update the store

  After step 7 UI will land in the split stage with all the split details.
*/


var getExperimentModelSplitForCreate = function getExperimentModelSplitForCreate(experimentId, modelId) {
  setExperimentLoading();
  var experiment, model; // Get experiment

  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getExperiment({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    experimentId: experimentId
  }).mergeMap(function (exp) {
    experiment = exp;
    return createWorkspace(exp.srcpath);
  }).mergeMap(function (res) {
    var workspaceId = res.values[0].id;
    experiment.workspaceId = workspaceId;
    return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getModel({
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
      experimentId: experiment.name,
      modelId: modelId
    });
  }).mergeMap(function (m) {
    model = m; // Apply the directives from the model

    return applyDirectives(experiment.workspaceId, m.directives);
  }).mergeMap(function () {
    // Get schema with workspaceId and directives
    var _model = model,
        directives = _model.directives;
    setDirectives(directives);
    var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_6__["directiveRequestBodyCreator"])(directives);
    return api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].getSchema({
      context: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
      workspaceId: experiment.workspaceId
    }, requestBody);
  }).mergeMap(function (schema) {
    updateSchema(schema); // The user refreshed before creating the split. So no split info is present in model.

    if (!model.split) {
      return rxjs_Observable__WEBPACK_IMPORTED_MODULE_7__["Observable"].create(function (observer) {
        observer.next(false);
      });
    } // If split already created get the split info to check the status of split.


    return api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getSplitDetails({
      namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
      experimentId: experiment.name,
      splitId: model.split
    });
  }).subscribe(function (splitInfo) {
    setExperimentModelForEdit(experiment, model, splitInfo);

    if (_typeof(splitInfo) === 'object' && splitInfo.status !== 'Complete') {
      pollForSplitStatus(experiment.name, modelId).subscribe(setSplitDetails.bind(null, experiment.name));
    }
  }, function (err) {
    // The error message returned from backend for this request is at err.response.message instead of just err.response
    var error = err.response.message || err.response || err;
    setExperimentCreateError("Failed to retrieve the model '".concat(model.name, "' of the experiment '").concat(experimentId, "' - ").concat(error));
    setExperimentLoading(false);
    setExperimentModelForEdit(experiment, model);
  });
};

function setExperimentModelForEdit(experiment, model, splitInfo) {
  var payload = {
    experimentDetails: experiment,
    modelDetails: model
  };

  if (splitInfo) {
    payload.splitInfo = splitInfo;
  }

  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_MODEL_FOR_EDIT,
    payload: payload
  });
}

function setAlgorithmList() {
  var _createExperimentStor6 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      experiments_create = _createExperimentStor6.experiments_create;

  var outcome = experiments_create.outcome;

  var _createExperimentStor7 = components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].getState(),
      model_create = _createExperimentStor7.model_create;

  var directives = model_create.directives,
      algorithmsList = model_create.algorithmsList;
  var requestBody = Object(components_DataPrep_helper__WEBPACK_IMPORTED_MODULE_6__["directiveRequestBodyCreator"])(directives);
  api_dataprep__WEBPACK_IMPORTED_MODULE_5__["default"].getSchema({
    context: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])(),
    workspaceId: experiments_create.workspaceId
  }, requestBody).subscribe(function (fields) {
    updateSchema(fields);
    var outcomeType = fields.find(function (field) {
      return field.name === outcome;
    }).type.filter(function (t) {
      return t !== 'null';
    }).pop();
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_VALID_ALGORITHMS_LIST,
      payload: {
        validAlgorithmsList: services_global_constants__WEBPACK_IMPORTED_MODULE_8__["NUMBER_TYPES"].indexOf(outcomeType) !== -1 ? algorithmsList.filter(function (algo) {
          return algo.type === 'REGRESSION';
        }) : algorithmsList.filter(function (algo) {
          return algo.type === 'CLASSIFICATION';
        })
      }
    });
  }, function (err) {
    setExperimentCreateError("Failed to find algorithms for outcome: ".concat(err.response || err));
  });
}

function setSplitFinalized() {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_SPLIT_FINALIZED,
    payload: {
      isSplitFinalized: true
    }
  });
}

function resetCreateExperimentsStore() {
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].RESET
  });
}

function fetchAlgorithmsList() {
  api_experiments__WEBPACK_IMPORTED_MODULE_3__["myExperimentsApi"].getAlgorithms({
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_4__["getCurrentNamespace"])()
  }).subscribe(function (algorithmsList) {
    algorithmsList = algorithmsList.map(function (alg) {
      return _objectSpread({}, alg, {
        name: alg.algorithm
      });
    });
    components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
      type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_ALGORITHMS_LIST,
      payload: {
        algorithmsList: algorithmsList
      }
    });
  }, function (err) {
    setExperimentCreateError("Failed to fetch algorithms: ".concat(err.response || err));
  });
}

function setExperimentCreateError() {
  var error = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_EXPERIMENT_ERROR,
    payload: {
      error: error
    }
  });
}

function setModelCreateError() {
  var error = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
  components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch({
    type: components_Experiments_store_createExperimentStore__WEBPACK_IMPORTED_MODULE_0__["ACTIONS"].SET_MODEL_ERROR,
    payload: {
      error: error
    }
  });
}

function setAlgorithmsListForCreateView() {
  Object(components_Experiments_store_SharedActionCreator__WEBPACK_IMPORTED_MODULE_2__["setAlgorithmsList"])().subscribe(function () {}, function (err) {
    setExperimentCreateError("Failed to get list of algorithms: ".concat(err.response || err));
  });
}



/***/ }),

/***/ "./components/Experiments/store/ModelStatus.js":
/*!*****************************************************!*\
  !*** ./components/Experiments/store/ModelStatus.js ***!
  \*****************************************************/
/*! exports provided: MODEL_STATUS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MODEL_STATUS", function() { return MODEL_STATUS; });
/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var MODEL_STATUS = {
  PREPARING: 'Preparing',
  SPLITTING: 'Splitting',
  SPLIT_FAILED: 'Split Failed',
  DATA_READY: 'Data Ready',
  TRAINING: 'Training',
  TRAINED: 'Trained',
  TRAINING_FAILED: 'Training Failed',
  DEPLOYED: 'Deployed'
};


/***/ }),

/***/ "./components/Experiments/store/createExperimentStore.js":
/*!***************************************************************!*\
  !*** ./components/Experiments/store/createExperimentStore.js ***!
  \***************************************************************/
/*! exports provided: CREATION_STEPS, ACTIONS, POPOVER_TYPES, SPLIT_STATUS, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CREATION_STEPS", function() { return CREATION_STEPS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTIONS", function() { return ACTIONS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "POPOVER_TYPES", function() { return POPOVER_TYPES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SPLIT_STATUS", function() { return SPLIT_STATUS; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var CREATION_STEPS = {
  DATAPREP_CONNECTIONS: 'DATAPREP_CONNECTIONS',
  DATAPREP: 'DATAPREP',
  DATASPLIT: 'DATASPLIT',
  ALGORITHM_SELECTION: 'ALGORITHM_SELECTION'
};
var ACTIONS = {
  SET_EXPERIMENT_NAME: 'SET_EXPERIMENT_NAME',
  SET_EXPERIMENT_DESCRIPTION: 'SET_EXPERIMENT_DESCRIPTION',
  SET_EXPERIMENT_OUTCOME: 'SET_EXPERIMENT_OUTCOME',
  SET_EXPERIMENT_SRC_PATH: 'SET_EXPERIMENT_SRC_PATH',
  SET_CREATE_EXPERIMENT_LOADING: 'SET_CREATE_EXPERIMENT_LOADING',
  SET_EXPERIMENT_METADATA_FOR_EDIT: 'SET_EXPERIMENT_METADATA_FOR_EDIT',
  SET_VISIBLE_POPOVER: 'SET_VISIBLE_POPOVER',
  SET_EXPERIMENT_ERROR: 'SET_EXPERIMENT_ERROR',
  OVERRIDE_CREATION_STEP: 'OVERRIDE_CREATION_STEP',
  MODEL_UPDATE: 'MODEL_UPDATE',
  SET_SPLIT_INFO: 'SET_SPLIT_INFO',
  SET_SCHEMA: 'SET_SCHEMA',
  SET_OUTCOME_COLUMNS: 'SET_OUTCOME_COLUMNS',
  SET_DIRECTIVES: 'SET_DIRECTIVES',
  SET_MODEL_NAME: 'SET_MODEL_NAME',
  SET_MODEL_ID: 'SET_MODEL_ID',
  SET_EXPERIMENT_MODEL_FOR_EDIT: 'SET_EXPERIMENT_MODEL_FOR_EDIT',
  SET_MODEL_DESCRIPTION: 'SET_MODEL_DESCRIPTION',
  SET_MODEL_ML_ALGORITHM: 'SET_MODEL_ML_ALGORITHM',
  SET_VALID_ALGORITHMS_LIST: 'SET_VALID_ALGORITHMS_LIST',
  SET_ALGORITHMS_LIST: 'SET_ALGORITHMS_LIST',
  SET_WORKSPACE_ID: 'SET_WORKSPACE_ID',
  SET_SPLIT_FINALIZED: 'SET_SPLIT_FINALIZED',
  UPDATE_HYPER_PARAM: 'UPDATE_HYPER_PARAM',
  SET_MODEL_TRAINED: 'SET_MODEL_TRAINED',
  SET_MODEL_ERROR: 'SET_MODEL_ERROR',
  RESET: 'RESET'
};
var POPOVER_TYPES = {
  EXPERIMENT: 'EXPERIMENT',
  MODEL: 'MODEL'
};
var DEFAULT_EXPERIMENTS_CREATE_VALUE = {
  name: '',
  description: '',
  outcome: '',
  srcpath: '',
  loading: false,
  popover: POPOVER_TYPES.EXPERIMENT,
  isEdit: false,
  workspaceId: null,
  error: null
};
var DEFAULT_MODEL_CREATE_VALUE = {
  name: '',
  description: '',
  modelId: null,
  directives: [],
  columns: [],
  schema: null,
  splitInfo: {},
  isSplitFinalized: false,
  algorithm: {
    name: ''
  },
  validAlgorithmsList: [],
  algorithmsList: [],
  isModelTrained: false,
  error: null
};
var DEFAULT_ACTIVE_STEP = {
  override: false,
  step_name: CREATION_STEPS.DATAPREP_CONNECTIONS
};

var experiments_create = function experiments_create() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_EXPERIMENTS_CREATE_VALUE;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ACTIONS.SET_EXPERIMENT_NAME:
      return _objectSpread({}, state, {
        name: action.payload.name
      });

    case ACTIONS.SET_EXPERIMENT_DESCRIPTION:
      return _objectSpread({}, state, {
        description: action.payload.description
      });

    case ACTIONS.SET_EXPERIMENT_OUTCOME:
      return _objectSpread({}, state, {
        outcome: action.payload.outcome
      });

    case ACTIONS.SET_EXPERIMENT_SRC_PATH:
      return _objectSpread({}, state, {
        srcpath: action.payload.srcpath
      });

    case ACTIONS.SET_CREATE_EXPERIMENT_LOADING:
      return _objectSpread({}, state, {
        loading: action.payload.loading
      });

    case ACTIONS.SET_WORKSPACE_ID:
      return _objectSpread({}, state, {
        workspaceId: action.payload.workspaceId
      });

    case ACTIONS.SET_EXPERIMENT_METADATA_FOR_EDIT:
    case ACTIONS.SET_EXPERIMENT_MODEL_FOR_EDIT:
      {
        var _action$payload$exper = action.payload.experimentDetails,
            name = _action$payload$exper.name,
            description = _action$payload$exper.description,
            outcome = _action$payload$exper.outcome,
            srcpath = _action$payload$exper.srcpath,
            workspaceId = _action$payload$exper.workspaceId;
        return _objectSpread({}, state, {
          name: name,
          description: description,
          outcome: outcome,
          srcpath: srcpath,
          workspaceId: workspaceId,
          isEdit: true,
          loading: false,
          popover: POPOVER_TYPES.MODEL
        });
      }

    case ACTIONS.SET_VISIBLE_POPOVER:
      return _objectSpread({}, state, {
        popover: action.payload.popover
      });

    case ACTIONS.SET_EXPERIMENT_ERROR:
      return _objectSpread({}, state, {
        error: action.payload.error
      });

    case ACTIONS.RESET:
      return DEFAULT_EXPERIMENTS_CREATE_VALUE;

    default:
      return state;
  }
};

var model_create = function model_create() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_MODEL_CREATE_VALUE;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ACTIONS.SET_MODEL_ID:
      return _objectSpread({}, state, {
        modelId: action.payload.modelId
      });

    case ACTIONS.SET_MODEL_NAME:
      return _objectSpread({}, state, {
        name: action.payload.name
      });

    case ACTIONS.SET_MODEL_DESCRIPTION:
      return _objectSpread({}, state, {
        description: action.payload.description
      });

    case ACTIONS.SET_SPLIT_INFO:
      return _objectSpread({}, state, {
        splitInfo: action.payload.splitInfo
      });

    case ACTIONS.MODEL_UPDATE:
      return _objectSpread({}, state, {
        splitInfo: DEFAULT_MODEL_CREATE_VALUE.splitInfo
      });

    case ACTIONS.SET_SPLIT_FINALIZED:
      return _objectSpread({}, state, {
        isSplitFinalized: action.payload.isSplitFinalized
      });

    case ACTIONS.SET_OUTCOME_COLUMNS:
      return _objectSpread({}, state, {
        columns: action.payload.columns
      });

    case ACTIONS.SET_DIRECTIVES:
      return _objectSpread({}, state, {
        directives: action.payload.directives
      });

    case ACTIONS.SET_MODEL_ML_ALGORITHM:
      return _objectSpread({}, state, {
        algorithm: action.payload.algorithm
      });

    case ACTIONS.SET_ALGORITHMS_LIST:
      return _objectSpread({}, state, {
        algorithmsList: action.payload.algorithmsList
      });

    case ACTIONS.UPDATE_HYPER_PARAM:
      {
        var _action$payload = action.payload,
            key = _action$payload.key,
            value = _action$payload.value;
        return _objectSpread({}, state, {
          algorithm: _objectSpread({}, state.algorithm, {
            hyperparameters: _objectSpread({}, state.algorithm.hyperparameters, _defineProperty({}, key, value))
          })
        });
      }

    case ACTIONS.SET_EXPERIMENT_METADATA_FOR_EDIT:
    case ACTIONS.SET_SCHEMA:
      return _objectSpread({}, state, {
        schema: action.payload.schema || state.schema
      });

    case ACTIONS.SET_EXPERIMENT_MODEL_FOR_EDIT:
      {
        var _action$payload$model = action.payload.modelDetails,
            name = _action$payload$model.name,
            description = _action$payload$model.description,
            modelId = _action$payload$model.id;
        return _objectSpread({}, state, {
          name: name,
          description: description,
          modelId: modelId,
          splitInfo: action.payload.splitInfo
        });
      }

    case ACTIONS.SET_VALID_ALGORITHMS_LIST:
      return _objectSpread({}, state, {
        validAlgorithmsList: state.algorithmsList.filter(function (algo) {
          return action.payload.validAlgorithmsList.map(function (al) {
            return al.name;
          }).indexOf(algo.algorithm) !== -1;
        })
      });

    case ACTIONS.SET_MODEL_TRAINED:
      return _objectSpread({}, state, {
        isModelTrained: true
      });

    case ACTIONS.SET_MODEL_ERROR:
      return _objectSpread({}, state, {
        error: action.payload.error
      });

    case ACTIONS.RESET:
      return DEFAULT_MODEL_CREATE_VALUE;

    default:
      return state;
  }
};

var active_step = function active_step() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_ACTIVE_STEP;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  var getActiveStep = function getActiveStep(state) {
    var override = state.active_step.override;

    if (override) {
      return state.active_step;
    }

    var _state$experiments_cr = state.experiments_create,
        name = _state$experiments_cr.name,
        workspaceId = _state$experiments_cr.workspaceId;
    var _state$model_create = state.model_create,
        modelId = _state$model_create.modelId,
        isSplitFinalized = _state$model_create.isSplitFinalized,
        algorithm = _state$model_create.algorithm;

    if (!workspaceId) {
      if (name) {
        return _objectSpread({}, state.active_step, {
          step_name: CREATION_STEPS.DATAPREP
        });
      }

      return _objectSpread({}, state.active_step, {
        step_name: CREATION_STEPS.DATAPREP_CONNECTIONS
      });
    }

    if (workspaceId && !modelId) {
      return _objectSpread({}, state.active_step, {
        step_name: CREATION_STEPS.DATAPREP
      });
    }

    if (modelId && !isSplitFinalized) {
      return _objectSpread({}, state.active_step, {
        step_name: CREATION_STEPS.DATASPLIT
      });
    }

    if (modelId && !algorithm.name.length) {
      return _objectSpread({}, state.active_step, {
        step_name: CREATION_STEPS.ALGORITHM_SELECTION
      });
    }

    return state.active_step;
  };

  switch (action.type) {
    case ACTIONS.SET_WORKSPACE_ID:
      {
        var newState = _objectSpread({}, state, {
          experiments_create: _objectSpread({}, state.experiments_create, {
            workspaceId: action.payload.workspaceId
          }),
          active_step: _objectSpread({}, state.active_step, {
            step_name: state.active_step.step_name
          })
        });

        return _objectSpread({}, state.active_step, {
          step_name: getActiveStep(newState).step_name
        });
      }

    case ACTIONS.MODEL_UPDATE:
      {
        var _newState = _objectSpread({}, state, {
          active_step: {
            override: false,
            step_name: state.active_step.step_name
          }
        });

        return {
          override: false,
          step_name: getActiveStep(_newState).step_name
        };
      }

    case ACTIONS.OVERRIDE_CREATION_STEP:
      return {
        override: true,
        step_name: action.payload.active_step
      };

    case ACTIONS.SET_SPLIT_FINALIZED:
      {
        var _newState2 = _objectSpread({}, state, {
          model_create: _objectSpread({}, state.model_create, {
            isSplitFinalized: action.payload.isSplitFinalized
          }),
          active_step: _objectSpread({}, state.active_step, {
            override: false
          })
        });

        return getActiveStep(_newState2);
      }

    case ACTIONS.SET_EXPERIMENT_METADATA_FOR_EDIT:
      {
        var _action$payload$exper2 = action.payload.experimentDetails,
            name = _action$payload$exper2.name,
            description = _action$payload$exper2.description,
            outcome = _action$payload$exper2.outcome,
            srcpath = _action$payload$exper2.srcpath,
            workspaceId = _action$payload$exper2.workspaceId;
        var _newState3 = {
          experiments_create: _objectSpread({}, state.experiments_create, {
            name: name,
            description: description,
            outcome: outcome,
            srcpath: srcpath,
            workspaceId: workspaceId
          }),
          model_create: state.model_create,
          active_step: state.active_step
        };
        return getActiveStep(_newState3);
      }

    case ACTIONS.SET_EXPERIMENT_MODEL_FOR_EDIT:
      {
        var _action$payload$exper3 = action.payload.experimentDetails,
            experimentName = _action$payload$exper3.name,
            experimentDescription = _action$payload$exper3.description,
            _outcome = _action$payload$exper3.outcome,
            _srcpath = _action$payload$exper3.srcpath,
            _workspaceId = _action$payload$exper3.workspaceId;
        var _action$payload$model2 = action.payload.modelDetails,
            modelName = _action$payload$model2.name,
            modelDescription = _action$payload$model2.description,
            modelId = _action$payload$model2.id;
        var _newState4 = {
          experiments_create: _objectSpread({}, state.experiments_create, {
            name: experimentName,
            description: experimentDescription,
            outcome: _outcome,
            srcpath: _srcpath,
            workspaceId: _workspaceId
          }),
          model_create: _objectSpread({}, state.model_create, {
            name: modelName,
            description: modelDescription,
            modelId: modelId
          }),
          active_step: state.active_step
        };
        return getActiveStep(_newState4);
      }

    case ACTIONS.RESET:
      return DEFAULT_ACTIVE_STEP;

    default:
      return getActiveStep(state);
  }
};

var rootReducer = function rootReducer(state, action) {
  return {
    experiments_create: experiments_create(state.experiments_create, action),
    model_create: model_create(state.model_create, action),
    active_step: active_step(state, action)
  };
};

var createExperimentStore = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(rootReducer, {
  experiments_create: DEFAULT_EXPERIMENTS_CREATE_VALUE,
  model_create: DEFAULT_MODEL_CREATE_VALUE,
  active_step: DEFAULT_ACTIVE_STEP
}, Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["composeEnhancers"])('CreateExperimentStore')());
var SPLIT_STATUS = {
  SPLITTING: 'Splitting',
  COMPLETE: 'Complete',
  FAILED: 'Failed',
  CREATING: 'CREATING' // Purely UI state. Used when UI calls backend to create a split.

};

/* harmony default export */ __webpack_exports__["default"] = (createExperimentStore);

/***/ }),

/***/ "./components/Experiments/store/experimentDetailStore.js":
/*!***************************************************************!*\
  !*** ./components/Experiments/store/experimentDetailStore.js ***!
  \***************************************************************/
/*! exports provided: DEFAULT_EXPERIMENT_DETAILS, default, ACTIONS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_EXPERIMENT_DETAILS", function() { return DEFAULT_EXPERIMENT_DETAILS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTIONS", function() { return ACTIONS; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_Experiments_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Experiments/store */ "./components/Experiments/store/index.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017-2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */




var ACTIONS = {
  SET_EXPERIMENT_DETAILS: 'SET_EXPERIMENT_DETAILS',
  SET_MODELS: 'SET_MODELS',
  SET_MODEL_DETAILS: 'SET_MODEL_DETAILS',
  SET_ACTIVE_MODEL: 'SET_ACTIVE_MODEL',
  SET_LOADING: 'SET_LOADING',
  SET_SPLITS: 'SET_SPLITS',
  SET_MODEL_STATUS: 'SET_MODEL_STATUS',
  SET_MODEL_PAGINATION: 'SET_MODEL_PAGINATION',
  SET_MODELS_QUERY_PARAMS: 'SET_MODELS_QUERY_PARAMS',
  SET_NEWLY_TRAINING_MODEL: 'SET_NEWLY_TRAINING_MODEL',
  RESET_NEWLY_TRAINING_MODEL: 'RESET_NEWLY_TRAINING_MODEL',
  SET_MODELS_SORT: 'SET_MODELS_SORT',
  SET_ERROR: 'SET_ERROR',
  SET_MODELS_LOADING: 'SET_MODELS_LOADING',
  SET_MODELS_WITH_ERROR: 'SET_MODELS_WITH_ERROR',
  RESET: 'RESET'
};
var DEFAULT_EXPERIMENT_DETAILS = {
  name: '',
  description: '',
  srcpath: '',
  outcome: '',
  outcomeType: '',
  evaluationMetrics: {},
  algorithms: {},
  statuses: {},
  models: [],
  newlyTrainingModel: null,
  modelsOffset: 0,
  modelsLimit: 10,
  modelsTotalCount: 0,
  modelsTotalPages: 0,
  modelsSortMethod: components_Experiments_store__WEBPACK_IMPORTED_MODULE_2__["MMDS_SORT_METHODS"].ASC,
  modelsSortColumn: components_Experiments_store__WEBPACK_IMPORTED_MODULE_2__["MMDS_SORT_COLUMN"],
  modelsLoading: [],
  modelsWithError: [],
  loading: false,
  error: null
};

var experimentDetails = function experimentDetails() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_EXPERIMENT_DETAILS;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case ACTIONS.SET_EXPERIMENT_DETAILS:
      {
        var _action$payload$exper = action.payload.experimentDetails,
            _action$payload$exper2 = _action$payload$exper.name,
            name = _action$payload$exper2 === void 0 ? '' : _action$payload$exper2,
            _action$payload$exper3 = _action$payload$exper.description,
            description = _action$payload$exper3 === void 0 ? '' : _action$payload$exper3,
            _action$payload$exper4 = _action$payload$exper.srcpath,
            srcpath = _action$payload$exper4 === void 0 ? '' : _action$payload$exper4,
            _action$payload$exper5 = _action$payload$exper.outcome,
            outcome = _action$payload$exper5 === void 0 ? '' : _action$payload$exper5,
            _action$payload$exper6 = _action$payload$exper.outcomeType,
            outcomeType = _action$payload$exper6 === void 0 ? '' : _action$payload$exper6,
            _action$payload$exper7 = _action$payload$exper.evaluationMetrics,
            evaluationMetrics = _action$payload$exper7 === void 0 ? {} : _action$payload$exper7,
            _action$payload$exper8 = _action$payload$exper.algorithms,
            algorithms = _action$payload$exper8 === void 0 ? {} : _action$payload$exper8,
            _action$payload$exper9 = _action$payload$exper.statuses,
            statuses = _action$payload$exper9 === void 0 ? {} : _action$payload$exper9;
        return _objectSpread({}, state, {
          name: name,
          description: description,
          srcpath: srcpath,
          outcome: outcome,
          outcomeType: outcomeType,
          evaluationMetrics: evaluationMetrics,
          algorithms: algorithms,
          statuses: statuses
        });
      }

    case ACTIONS.SET_NEWLY_TRAINING_MODEL:
      return _objectSpread({}, state, {
        newlyTrainingModel: action.payload.model
      });

    case ACTIONS.RESET_NEWLY_TRAINING_MODEL:
      return _objectSpread({}, state, {
        newlyTrainingModel: null
      });

    case ACTIONS.SET_MODELS:
      {
        var models = action.payload.models;

        if (state.newlyTrainingModel) {
          models = models.map(function (model) {
            if (model.id === state.newlyTrainingModel.modelId) {
              return _objectSpread({}, model, {
                active: true
              });
            }

            return model;
          });
        }

        return _objectSpread({}, state, {
          models: models,
          modelsTotalCount: action.payload.totalCount,
          modelsTotalPages: Math.ceil(action.payload.totalCount / state.modelsLimit),
          loading: false
        });
      }

    case ACTIONS.SET_MODEL_PAGINATION:
      return _objectSpread({}, state, {
        modelsOffset: action.payload.modelsOffset,
        modelsLimit: action.payload.modelsLimit || state.modelsLimit
      });

    case ACTIONS.SET_MODELS_QUERY_PARAMS:
      return _objectSpread({}, state, {
        modelsOffset: action.payload.modelsOffset,
        modelsLimit: action.payload.modelsLimit || state.modelsLimit,
        modelsSortMethod: action.payload.modelsSortMethod,
        modelsSortColumn: action.payload.modelsSortColumn
      });

    case ACTIONS.SET_ACTIVE_MODEL:
      return _objectSpread({}, state, {
        models: state.models.map(function (model) {
          return _objectSpread({}, model, {
            active: !model.active ? model.id === action.payload.activeModelId : !model.active,
            loading: false
          });
        })
      });

    case ACTIONS.SET_LOADING:
      return _objectSpread({}, state, {
        loading: true
      });

    case ACTIONS.SET_SPLITS:
      return _objectSpread({}, state, {
        models: state.models.map(function (model) {
          var matchingSplit = action.payload.splits.find(function (split) {
            return split.id === model.split;
          });

          if (matchingSplit) {
            return _objectSpread({}, model, {
              splitDetails: matchingSplit
            });
          }

          return model;
        })
      });

    case ACTIONS.SET_MODEL_STATUS:
      {
        var modelsWithError = _toConsumableArray(state.modelsWithError);

        var modelIndex = modelsWithError.indexOf(action.payload.modelId);

        if (modelIndex !== -1) {
          modelsWithError.splice(modelIndex, 1);
        }

        return _objectSpread({}, state, {
          models: state.models.map(function (model) {
            if (model.id === action.payload.modelId) {
              return _objectSpread({}, model, {
                status: action.payload.modelStatus
              });
            }

            return model;
          }),
          modelsWithError: modelsWithError
        });
      }

    case ACTIONS.SET_MODELS_SORT:
      return _objectSpread({}, state, {
        modelsSortMethod: action.payload.modelsSortMethod,
        modelsSortColumn: action.payload.modelsSortColumn
      });

    case ACTIONS.SET_ERROR:
      return _objectSpread({}, state, {
        error: action.payload.error
      });

    case ACTIONS.SET_MODELS_LOADING:
      return _objectSpread({}, state, {
        modelsLoading: action.payload.modelsLoading
      });

    case ACTIONS.SET_MODELS_WITH_ERROR:
      return _objectSpread({}, state, {
        modelsWithError: action.payload.modelsWithError
      });

    default:
      return state;
  }
};

var experimentDetailsStore = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(experimentDetails, DEFAULT_EXPERIMENT_DETAILS, Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["composeEnhancers"])('ExperimentDetailStore')());
/* harmony default export */ __webpack_exports__["default"] = (experimentDetailsStore);


/***/ }),

/***/ "./components/SortableTable/SortableTable.scss":
/*!*****************************************************!*\
  !*** ./components/SortableTable/SortableTable.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./SortableTable.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SortableTable/SortableTable.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SortableTable/index.js":
/*!*******************************************!*\
  !*** ./components/SortableTable/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SortableTable; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash/orderBy */ "../../node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





__webpack_require__(/*! ./SortableTable.scss */ "./components/SortableTable/SortableTable.scss");

var SortableTable =
/*#__PURE__*/
function (_Component) {
  _inherits(SortableTable, _Component);

  function SortableTable() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SortableTable);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SortableTable)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "state", {
      entities: _this.props.entities,
      sortByHeader: '',
      sortOrder: 'asc',
      sortOnInitialLoad: typeof _this.props.sortOnInitialLoad !== 'boolean' ? true : _this.props.sortOnInitialLoad
    });

    return _this;
  }

  _createClass(SortableTable, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      if (!this.state.sortOnInitialLoad) {
        return;
      }

      var entities = this.state.entities;
      var sortByHeader = this.getDefaultSortedHeader();
      entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default()(entities, [sortByHeader], [this.state.sortOrder]);
      this.setState({
        entities: entities,
        sortByHeader: sortByHeader
      });
    }
  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      this.setState({
        entities: nextProps.entities
      });
    }
  }, {
    key: "getDefaultSortedHeader",
    value: function getDefaultSortedHeader() {
      var defaultHeader = '';

      for (var i = 0; i < this.props.tableHeaders.length; i++) {
        if (this.props.tableHeaders[i].defaultSortby) {
          defaultHeader = this.props.tableHeaders[i].property;
          break;
        }
      }

      return defaultHeader || this.props.tableHeaders[0].property;
    }
  }, {
    key: "sortBy",
    value: function sortBy(header) {
      var headerProp = header.property;
      var entities = this.state.entities;
      var sortOrder = this.state.sortOrder;
      var sortByHeader = this.state.sortByHeader;

      if (sortByHeader === headerProp) {
        if (sortOrder === 'asc') {
          // already sorting in this column, sort the other way
          sortOrder = 'desc';
        } else {
          sortOrder = 'asc';
        }
      } else {
        // a new sort, so start with ascending sort
        sortByHeader = headerProp;
        sortOrder = 'asc';
      }

      if (header.sortFunc) {
        entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default()(entities, [header.sortFunc], [sortOrder]);
      } else {
        entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default()(entities, [sortByHeader], [sortOrder]);
      }

      this.setState({
        entities: entities,
        sortOrder: sortOrder,
        sortByHeader: sortByHeader
      });
    }
  }, {
    key: "renderSortableTableHeader",
    value: function renderSortableTableHeader(header) {
      if (this.state.sortByHeader !== header.property) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          onClick: this.sortBy.bind(this, header)
        }, header.label);
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        onClick: this.sortBy.bind(this, header)
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "text-underline"
      }, header.label), this.state.sortOrder === 'asc' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
        className: "fa fa-caret-down fa-lg"
      }) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("i", {
        className: "fa fa-caret-up fa-lg"
      }));
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var tableClasses = classnames__WEBPACK_IMPORTED_MODULE_3___default()('table', this.props.className);
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("table", {
        className: tableClasses
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("thead", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, this.props.tableHeaders.map(function (tableHeader, i) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
          key: i
        }, tableHeader.property ? _this2.renderSortableTableHeader(tableHeader) : tableHeader.label);
      }))), this.props.renderTableBody(this.state.entities));
    }
  }]);

  return SortableTable;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);


SortableTable.propTypes = {
  tableHeaders: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    label: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    property: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
    defaultSortby: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
  })),
  renderTableBody: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  entities: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object),
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  sortOnInitialLoad: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
};

/***/ })

}]);
//# sourceMappingURL=ExperimentsCreateView.14481e573547e8ab6321.js.map