(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["FieldLevelLineage"],{

/***/ "../../node_modules/@material-ui/core/styles/createStyles.js":
/*!***********************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/@material-ui/core/styles/createStyles.js ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = createStyles;

var _styles = __webpack_require__(/*! @material-ui/styles */ "../../node_modules/@material-ui/styles/esm/index.js");

// import warning from 'warning';
// let warnOnce = false;
// To remove in v5
function createStyles(styles) {
  // warning(
  //   warnOnce,
  //   [
  //     'Material-UI: createStyles from @material-ui/core/styles is deprecated.',
  //     'Please use @material-ui/styles/createStyles',
  //   ].join('\n'),
  // );
  // warnOnce = true;
  return (0, _styles.createStyles)(styles);
}

/***/ }),

/***/ "../../node_modules/@material-ui/icons/KeyboardArrowDown.js":
/*!**********************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/@material-ui/icons/KeyboardArrowDown.js ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@material-ui/icons/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "../../node_modules/react/index.js"));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@material-ui/icons/utils/createSvgIcon.js"));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  d: "M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"
}), _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0V0z"
})), 'KeyboardArrowDown');

exports.default = _default;

/***/ }),

/***/ "../../node_modules/@material-ui/icons/KeyboardArrowUp.js":
/*!********************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/@material-ui/icons/KeyboardArrowUp.js ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@material-ui/icons/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "../../node_modules/react/index.js"));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@material-ui/icons/utils/createSvgIcon.js"));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  d: "M7.41 15.41L12 10.83l4.59 4.58L18 14l-6-6-6 6z"
}), _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0z"
})), 'KeyboardArrowUp');

exports.default = _default;

/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/EntityTopPanel/EntityTopPanel.scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/EntityTopPanel/EntityTopPanel.scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.entity-top-panel {\n  height: 50px;\n  background: #eeeeee;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  padding: 0 50px; }\n  .entity-top-panel .toppanel-title-container {\n    display: -webkit-box;\n    display: flex; }\n  .entity-top-panel.background {\n    background: inherit; }\n  .entity-top-panel .arrow-left {\n    margin-right: 5px; }\n  .entity-top-panel .divider {\n    margin: 0 10px; }\n  .entity-top-panel .toppanel-close-btn {\n    cursor: pointer; }\n    .entity-top-panel .toppanel-close-btn a {\n      color: black; }\n  .entity-top-panel .link-section {\n    align-self: center; }\n    .entity-top-panel .link-section span.link-container {\n      color: #0076dc;\n      cursor: pointer; }\n      .entity-top-panel .link-section span.link-container:hover {\n        text-decoration: underline; }\n  .entity-top-panel .multiline-title .overview-heading {\n    margin-bottom: 0;\n    font-weight: bold; }\n  .entity-top-panel .multiline-title .entity-type {\n    color: #999999; }\n    .entity-top-panel .multiline-title .entity-type .icon-svg {\n      margin-right: 5px; }\n    .entity-top-panel .multiline-title .entity-type .entity-type-text {\n      vertical-align: middle; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/FieldLevelLineage/OperationsModal/OperationsModal.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/FieldLevelLineage/OperationsModal/OperationsModal.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.modal .field-level-lineage-modal.modal-dialog {\n  max-width: 85vw;\n  max-height: 80vh; }\n  .modal .field-level-lineage-modal.modal-dialog .modal-header,\n  .modal .field-level-lineage-modal.modal-dialog .modal-body {\n    padding-left: 30px;\n    padding-right: 30px; }\n  .modal .field-level-lineage-modal.modal-dialog .modal-body {\n    padding-top: 0; }\n  .modal .field-level-lineage-modal.modal-dialog .operations-container .navigation {\n    -webkit-user-select: none;\n       -moz-user-select: none;\n        -ms-user-select: none;\n            user-select: none;\n    height: 27px; }\n    .modal .field-level-lineage-modal.modal-dialog .operations-container .navigation .nav-icon {\n      cursor: pointer;\n      font-size: 20px; }\n      .modal .field-level-lineage-modal.modal-dialog .operations-container .navigation .nav-icon.disabled {\n        color: #bbbbbb;\n        cursor: not-allowed; }\n    .modal .field-level-lineage-modal.modal-dialog .operations-container .navigation .separator {\n      margin-left: 5px;\n      margin-right: 5px; }\n  .modal .field-level-lineage-modal.modal-dialog .operations-container .summary-text,\n  .modal .field-level-lineage-modal.modal-dialog .operations-container .last-executed {\n    color: #666666; }\n  .modal .field-level-lineage-modal.modal-dialog .operations-container .summary-text {\n    margin-top: 30px; }\n  .modal .field-level-lineage-modal.modal-dialog .operations-container .last-executed {\n    line-height: 27px;\n    vertical-align: bottom;\n    margin-bottom: 0; }\n  .modal .field-level-lineage-modal.modal-dialog .operations-container .grid-wrapper {\n    max-height: 60vh;\n    overflow: auto;\n    margin-top: 30px; }\n  .modal .field-level-lineage-modal.modal-dialog .operations-container .grid.grid-container {\n    max-height: 55vh; }\n    .modal .field-level-lineage-modal.modal-dialog .operations-container .grid.grid-container .grid-header .grid-row,\n    .modal .field-level-lineage-modal.modal-dialog .operations-container .grid.grid-container .grid-body .grid-row {\n      grid-template-columns: 1fr 2fr 2fr 2fr 40% 2fr 2fr; }\n    .modal .field-level-lineage-modal.modal-dialog .operations-container .grid.grid-container .grid-body .grid-row > div:first-child {\n      padding-left: 15px; }\n    .modal .field-level-lineage-modal.modal-dialog .operations-container .grid.grid-container .active {\n      background-color: rgba(255, 213, 0, 0.3); }\n    .modal .field-level-lineage-modal.modal-dialog .operations-container .grid.grid-container .input-field {\n      cursor: pointer;\n      color: #0099ff; }\n      .modal .field-level-lineage-modal.modal-dialog .operations-container .grid.grid-container .input-field:hover {\n        text-decoration: underline; }\n      .modal .field-level-lineage-modal.modal-dialog .operations-container .grid.grid-container .input-field.selected {\n        color: #ffba01;\n        font-style: italic; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SortableStickyGrid/SortableStickyGrid.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/css-loader/dist/cjs.js!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/postcss-loader/src!/Users/bsjun/Documents/cdap-code/cdap/cdap-ui/node_modules/sass-loader/dist/cjs.js!./components/SortableStickyGrid/SortableStickyGrid.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n*/\n/*\n * Copyright © 2017-2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n * Copyright © 2018 Cask Data, Inc.\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n * use this file except in compliance with the License. You may obtain a copy of\n * the License at\n *\n * http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n * License for the specific language governing permissions and limitations under\n * the License.\n */\n/*\n  New start. Define colors used throughout CDAP. Use these colors from now on.\n*/\n\n.sortable-sticky-grid .grid.grid-container .grid-header .sortable-header {\n  cursor: pointer; }\n  .sortable-sticky-grid .grid.grid-container .grid-header .sortable-header.active {\n    text-decoration: underline; }\n", ""]);
// Exports
exports.locals = {
	"white01": "white",
	"green01": "#01b133",
	"green02": "#3cc801",
	"green03": "#8af302",
	"green04": "#0f9d58",
	"green05": "#0b8043",
	"blue01": "#045599",
	"blue02": "#0076dc",
	"blue03": "#0099ff",
	"blue04": "#58b7f6",
	"blue05": "#7cd2eb",
	"blue06": "#cae7ef",
	"blue07": "#3c4355",
	"bluegrey01": "#454a57",
	"bluegrey02": "#4e5568",
	"bluegrey03": "#5d6789",
	"bluegrey04": "#979fbb",
	"bluegrey05": "#bac1d8",
	"bluegrey06": "#dce0ea",
	"orange01": "#ff6600",
	"orange02": "#fa8a00",
	"orange03": "#ffa727",
	"orange04": "#ffcc80",
	"orange05": "#ffe0b2",
	"grey01": "#333333",
	"grey02": "#666666",
	"grey03": "#999999",
	"grey04": "#bbbbbb",
	"grey05": "#cccccc",
	"grey06": "#dbdbdb",
	"grey07": "#eeeeee",
	"grey08": "#f5f5f5",
	"grey09": "#e8e8e8",
	"red01": "#a40403",
	"red02": "#d40001",
	"red03": "#d15668",
	"yellow01": "#ffba01",
	"yellow02": "#ffd500",
	"yellow02lighter": "rgba(255, 213, 0, 0.3)"
};
module.exports = exports;


/***/ }),

/***/ "../../node_modules/d3/index.js":
/*!**********************************************************************************!*\
  !*** delegated ../../../node_modules/d3/index.js from dll-reference cdap_vendor ***!
  \**********************************************************************************/
/*! exports provided: version, bisect, bisectRight, bisectLeft, ascending, bisector, cross, descending, deviation, extent, histogram, thresholdFreedmanDiaconis, thresholdScott, thresholdSturges, max, mean, median, merge, min, pairs, permute, quantile, range, scan, shuffle, sum, ticks, tickIncrement, tickStep, transpose, variance, zip, axisTop, axisRight, axisBottom, axisLeft, brush, brushX, brushY, brushSelection, chord, ribbon, nest, set, map, keys, values, entries, color, rgb, hsl, lab, hcl, cubehelix, contours, contourDensity, dispatch, drag, dragDisable, dragEnable, dsvFormat, csvParse, csvParseRows, csvFormat, csvFormatRows, tsvParse, tsvParseRows, tsvFormat, tsvFormatRows, easeLinear, easeQuad, easeQuadIn, easeQuadOut, easeQuadInOut, easeCubic, easeCubicIn, easeCubicOut, easeCubicInOut, easePoly, easePolyIn, easePolyOut, easePolyInOut, easeSin, easeSinIn, easeSinOut, easeSinInOut, easeExp, easeExpIn, easeExpOut, easeExpInOut, easeCircle, easeCircleIn, easeCircleOut, easeCircleInOut, easeBounce, easeBounceIn, easeBounceOut, easeBounceInOut, easeBack, easeBackIn, easeBackOut, easeBackInOut, easeElastic, easeElasticIn, easeElasticOut, easeElasticInOut, blob, buffer, dsv, csv, tsv, image, json, text, xml, html, svg, forceCenter, forceCollide, forceLink, forceManyBody, forceRadial, forceSimulation, forceX, forceY, formatDefaultLocale, format, formatPrefix, formatLocale, formatSpecifier, precisionFixed, precisionPrefix, precisionRound, geoArea, geoBounds, geoCentroid, geoCircle, geoClipAntimeridian, geoClipCircle, geoClipExtent, geoClipRectangle, geoContains, geoDistance, geoGraticule, geoGraticule10, geoInterpolate, geoLength, geoPath, geoAlbers, geoAlbersUsa, geoAzimuthalEqualArea, geoAzimuthalEqualAreaRaw, geoAzimuthalEquidistant, geoAzimuthalEquidistantRaw, geoConicConformal, geoConicConformalRaw, geoConicEqualArea, geoConicEqualAreaRaw, geoConicEquidistant, geoConicEquidistantRaw, geoEquirectangular, geoEquirectangularRaw, geoGnomonic, geoGnomonicRaw, geoIdentity, geoProjection, geoProjectionMutator, geoMercator, geoMercatorRaw, geoNaturalEarth1, geoNaturalEarth1Raw, geoOrthographic, geoOrthographicRaw, geoStereographic, geoStereographicRaw, geoTransverseMercator, geoTransverseMercatorRaw, geoRotation, geoStream, geoTransform, cluster, hierarchy, pack, packSiblings, packEnclose, partition, stratify, tree, treemap, treemapBinary, treemapDice, treemapSlice, treemapSliceDice, treemapSquarify, treemapResquarify, interpolate, interpolateArray, interpolateBasis, interpolateBasisClosed, interpolateDate, interpolateNumber, interpolateObject, interpolateRound, interpolateString, interpolateTransformCss, interpolateTransformSvg, interpolateZoom, interpolateRgb, interpolateRgbBasis, interpolateRgbBasisClosed, interpolateHsl, interpolateHslLong, interpolateLab, interpolateHcl, interpolateHclLong, interpolateCubehelix, interpolateCubehelixLong, quantize, path, polygonArea, polygonCentroid, polygonHull, polygonContains, polygonLength, quadtree, randomUniform, randomNormal, randomLogNormal, randomBates, randomIrwinHall, randomExponential, scaleBand, scalePoint, scaleIdentity, scaleLinear, scaleLog, scaleSymlog, scaleOrdinal, scaleImplicit, scalePow, scaleSqrt, scaleQuantile, scaleQuantize, scaleThreshold, scaleTime, scaleUtc, scaleSequential, scaleSequentialLog, scaleSequentialPow, scaleSequentialSqrt, scaleSequentialSymlog, scaleSequentialQuantile, scaleDiverging, scaleDivergingLog, scaleDivergingPow, scaleDivergingSqrt, scaleDivergingSymlog, tickFormat, schemeCategory10, schemeAccent, schemeDark2, schemePaired, schemePastel1, schemePastel2, schemeSet1, schemeSet2, schemeSet3, schemeTableau10, interpolateBrBG, schemeBrBG, interpolatePRGn, schemePRGn, interpolatePiYG, schemePiYG, interpolatePuOr, schemePuOr, interpolateRdBu, schemeRdBu, interpolateRdGy, schemeRdGy, interpolateRdYlBu, schemeRdYlBu, interpolateRdYlGn, schemeRdYlGn, interpolateSpectral, schemeSpectral, interpolateBuGn, schemeBuGn, interpolateBuPu, schemeBuPu, interpolateGnBu, schemeGnBu, interpolateOrRd, schemeOrRd, interpolatePuBuGn, schemePuBuGn, interpolatePuBu, schemePuBu, interpolatePuRd, schemePuRd, interpolateRdPu, schemeRdPu, interpolateYlGnBu, schemeYlGnBu, interpolateYlGn, schemeYlGn, interpolateYlOrBr, schemeYlOrBr, interpolateYlOrRd, schemeYlOrRd, interpolateBlues, schemeBlues, interpolateGreens, schemeGreens, interpolateGreys, schemeGreys, interpolatePurples, schemePurples, interpolateReds, schemeReds, interpolateOranges, schemeOranges, interpolateCividis, interpolateCubehelixDefault, interpolateRainbow, interpolateWarm, interpolateCool, interpolateSinebow, interpolateTurbo, interpolateViridis, interpolateMagma, interpolateInferno, interpolatePlasma, creator, local, matcher, mouse, namespace, namespaces, clientPoint, select, selectAll, selection, selector, selectorAll, style, touch, touches, window, event, customEvent, arc, area, line, pie, areaRadial, radialArea, lineRadial, radialLine, pointRadial, linkHorizontal, linkVertical, linkRadial, symbol, symbols, symbolCircle, symbolCross, symbolDiamond, symbolSquare, symbolStar, symbolTriangle, symbolWye, curveBasisClosed, curveBasisOpen, curveBasis, curveBundle, curveCardinalClosed, curveCardinalOpen, curveCardinal, curveCatmullRomClosed, curveCatmullRomOpen, curveCatmullRom, curveLinearClosed, curveLinear, curveMonotoneX, curveMonotoneY, curveNatural, curveStep, curveStepAfter, curveStepBefore, stack, stackOffsetExpand, stackOffsetDiverging, stackOffsetNone, stackOffsetSilhouette, stackOffsetWiggle, stackOrderAscending, stackOrderDescending, stackOrderInsideOut, stackOrderNone, stackOrderReverse, timeInterval, timeMillisecond, timeMilliseconds, utcMillisecond, utcMilliseconds, timeSecond, timeSeconds, utcSecond, utcSeconds, timeMinute, timeMinutes, timeHour, timeHours, timeDay, timeDays, timeWeek, timeWeeks, timeSunday, timeSundays, timeMonday, timeMondays, timeTuesday, timeTuesdays, timeWednesday, timeWednesdays, timeThursday, timeThursdays, timeFriday, timeFridays, timeSaturday, timeSaturdays, timeMonth, timeMonths, timeYear, timeYears, utcMinute, utcMinutes, utcHour, utcHours, utcDay, utcDays, utcWeek, utcWeeks, utcSunday, utcSundays, utcMonday, utcMondays, utcTuesday, utcTuesdays, utcWednesday, utcWednesdays, utcThursday, utcThursdays, utcFriday, utcFridays, utcSaturday, utcSaturdays, utcMonth, utcMonths, utcYear, utcYears, timeFormatDefaultLocale, timeFormat, timeParse, utcFormat, utcParse, timeFormatLocale, isoFormat, isoParse, now, timer, timerFlush, timeout, interval, transition, active, interrupt, voronoi, zoom, zoomTransform, zoomIdentity */
/***/ (function(module, exports, __webpack_require__) {

module.exports = (__webpack_require__(/*! dll-reference cdap_vendor */ "dll-reference cdap_vendor"))("./node_modules/d3/index.js");

/***/ }),

/***/ "./api/metadata.js":
/*!*************************!*\
  !*** ./api/metadata.js ***!
  \*************************/
/*! exports provided: MyMetadataApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyMetadataApi", function() { return MyMetadataApi; });
/* harmony import */ var services_resource_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/resource-helper */ "./services/resource-helper/index.js");
/* harmony import */ var services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/datasource/DataSourceConfigurer */ "./services/datasource/DataSourceConfigurer.js");
/*
 * Copyright © 2017 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var dataSrc = services_datasource_DataSourceConfigurer__WEBPACK_IMPORTED_MODULE_1__["default"].getInstance();
var basepath = '/namespaces/:namespace/:entityType/:entityId/metadata';
var lineagePath = '/namespaces/:namespace/datasets/:entityId/lineage/fields';
var fieldLineagePath = '/namespaces/:namespace/datasets/:entityId/lineage/allfieldlineage';
var MyMetadataApi = {
  getMetadata: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', basepath),
  getProperties: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/properties?responseFormat=v6")),
  addProperties: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/properties")),
  deleteProperty: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(basepath, "/properties/:key")),
  getTags: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(basepath, "/tags?responseFormat=v6")),
  addTags: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'POST', 'REQUEST', "".concat(basepath, "/tags")),
  deleteTags: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'DELETE', 'REQUEST', "".concat(basepath, "/tags/:key")),
  // Field Level Lineage
  getFields: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', lineagePath),
  getFieldLineage: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(lineagePath, "/:fieldName")),
  getFieldOperations: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', "".concat(lineagePath, "/:fieldName/operations")),
  getAllFieldLineage: Object(services_resource_helper__WEBPACK_IMPORTED_MODULE_0__["apiCreator"])(dataSrc, 'GET', 'REQUEST', fieldLineagePath)
};

/***/ }),

/***/ "./components/EntityTopPanel/EntityTopPanel.scss":
/*!*******************************************************!*\
  !*** ./components/EntityTopPanel/EntityTopPanel.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./EntityTopPanel.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/EntityTopPanel/EntityTopPanel.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/EntityTopPanel/index.js":
/*!********************************************!*\
  !*** ./components/EntityTopPanel/index.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EntityTopPanel; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






__webpack_require__(/*! ./EntityTopPanel.scss */ "./components/EntityTopPanel/EntityTopPanel.scss");

var EntityTopPanel =
/*#__PURE__*/
function (_PureComponent) {
  _inherits(EntityTopPanel, _PureComponent);

  function EntityTopPanel() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, EntityTopPanel);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(EntityTopPanel)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_this), "renderBreadCrumnAnchorLink", function () {
      if (!_this.props.breadCrumbAnchorLink && !_this.props.historyBack) {
        return null;
      }

      var Tag = react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Link"];

      if (_this.props.historyBack) {
        Tag = 'span';
      }

      var onClickHandler = function onClickHandler() {
        if (!_this.props.historyBack) {
          return;
        }

        history.back();
      };

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "link-section"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Tag, {
        to: _this.props.breadCrumbAnchorLink,
        onClick: onClickHandler,
        className: "link-container"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "arrow-left"
      }, "\xAB"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "breadcrumb-label"
      }, _this.props.breadCrumbAnchorLabel)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
        className: "divider"
      }, " | "));
    });

    _defineProperty(_assertThisInitialized(_this), "renderTitle", function () {
      if (_this.props.entityIcon && _this.props.entityType) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "multiline-title"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h5", {
          className: "overview-heading"
        }, _this.props.title), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
          className: "entity-type"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
          name: _this.props.entityIcon
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
          className: "entity-type-text"
        }, _this.props.entityType)));
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h5", {
        className: "overview-heading"
      }, _this.props.title);
    });

    _defineProperty(_assertThisInitialized(_this), "renderCloseBtn", function () {
      if (!_this.props.closeBtnAnchorLink) {
        return null;
      }

      if (typeof _this.props.closeBtnAnchorLink === 'function') {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h5", {
          className: "toppanel-close-btn"
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
          name: "icon-close",
          onClick: _this.props.closeBtnAnchorLink
        }));
      }

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("h5", {
        className: "toppanel-close-btn"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Link"], {
        to: _this.props.closeBtnAnchorLink
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_3__["default"], {
        name: "icon-close"
      })));
    });

    return _this;
  }

  _createClass(EntityTopPanel, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()('entity-top-panel', {
          background: this.props.inheritBackground
        })
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "toppanel-title-container"
      }, this.renderBreadCrumnAnchorLink(), this.renderTitle()), this.renderCloseBtn());
    }
  }]);

  return EntityTopPanel;
}(react__WEBPACK_IMPORTED_MODULE_1__["PureComponent"]);

_defineProperty(EntityTopPanel, "propTypes", {
  breadCrumbAnchorLink: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  breadCrumbAnchorLabel: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  title: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  entityIcon: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  entityType: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  closeBtnAnchorLink: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func]),
  historyBack: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  inheritBackground: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool
});



/***/ }),

/***/ "./components/FieldLevelLineage/OperationsModal/OperationsModal.scss":
/*!***************************************************************************!*\
  !*** ./components/FieldLevelLineage/OperationsModal/OperationsModal.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js!../../../../../node_modules/postcss-loader/src!../../../../../node_modules/sass-loader/dist/cjs.js!./OperationsModal.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/FieldLevelLineage/OperationsModal/OperationsModal.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/FieldLevelLineage/store/ActionCreator.js":
/*!*************************************************************!*\
  !*** ./components/FieldLevelLineage/store/ActionCreator.js ***!
  \*************************************************************/
/*! exports provided: TIME_OPTIONS_MAP, init, getFields, getLineageSummary, search, getOperations, setCustomTimeRange, setTimeRange, getTimeQueryParams, replaceHistory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TIME_OPTIONS_MAP", function() { return TIME_OPTIONS_MAP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "init", function() { return init; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFields", function() { return getFields; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLineageSummary", function() { return getLineageSummary; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "search", function() { return search; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getOperations", function() { return getOperations; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setCustomTimeRange", function() { return setCustomTimeRange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setTimeRange", function() { return setTimeRange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTimeQueryParams", function() { return getTimeQueryParams; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "replaceHistory", function() { return replaceHistory; });
/* harmony import */ var api_metadata__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! api/metadata */ "./api/metadata.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/FieldLevelLineage/store/Store */ "./components/FieldLevelLineage/store/Store.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/debounce */ "../../node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
var _TIME_OPTIONS_MAP;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var TIME_OPTIONS_MAP = (_TIME_OPTIONS_MAP = {}, _defineProperty(_TIME_OPTIONS_MAP, components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["TIME_OPTIONS"][1], {
  start: 'now-7d',
  end: 'now'
}), _defineProperty(_TIME_OPTIONS_MAP, components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["TIME_OPTIONS"][2], {
  start: 'now-14d',
  end: 'now'
}), _defineProperty(_TIME_OPTIONS_MAP, components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["TIME_OPTIONS"][3], {
  start: 'now-30d',
  end: 'now'
}), _defineProperty(_TIME_OPTIONS_MAP, components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["TIME_OPTIONS"][4], {
  start: 'now-180d',
  end: 'now'
}), _defineProperty(_TIME_OPTIONS_MAP, components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["TIME_OPTIONS"][5], {
  start: 'now-365d',
  end: 'now'
}), _TIME_OPTIONS_MAP);

function getTimeRange() {
  var store = components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].getState();
  var selection = store.lineage.timeSelection;

  if (selection === components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["TIME_OPTIONS"][0]) {
    return {
      start: store.customTime.start || 'now-7d',
      end: store.customTime.end || 'now'
    };
  }

  return TIME_OPTIONS_MAP[selection];
}

function getFirstFieldLineage(fields) {
  var chosenField;

  for (var i = 0; i < fields.length; i++) {
    if (fields[i].lineage) {
      chosenField = fields[i].name;
      break;
    }
  }

  if (chosenField) {
    getLineageSummary(chosenField);
  } else {
    replaceHistory();
  }
}

function init(datasetId) {
  var queryParams = Object(services_helpers__WEBPACK_IMPORTED_MODULE_4__["parseQueryString"])() || {};
  var timeObj = TIME_OPTIONS_MAP[components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["TIME_OPTIONS"][1]];

  if (queryParams.time && components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["TIME_OPTIONS"].indexOf(queryParams.time) !== -1) {
    components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
      type: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setTimeSelection,
      payload: {
        timeSelection: queryParams.time
      }
    });
    timeObj = TIME_OPTIONS_MAP[queryParams.time];
  }

  if (queryParams.time === components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["TIME_OPTIONS"][0]) {
    timeObj = {
      start: parseInt(queryParams.start, 10),
      end: parseInt(queryParams.end, 10)
    };
    components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
      type: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setCustomTime,
      payload: {
        start: timeObj.start,
        end: timeObj.end
      }
    });
  }

  var params = {
    namespace: Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__["getCurrentNamespace"])(),
    entityId: datasetId,
    start: timeObj.start,
    end: timeObj.end,
    includeCurrent: true
  };
  api_metadata__WEBPACK_IMPORTED_MODULE_0__["MyMetadataApi"].getFields(params).subscribe(function (fields) {
    components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
      type: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setFields,
      payload: {
        datasetId: datasetId,
        fields: fields
      }
    });

    if (queryParams.field) {
      getLineageSummary(queryParams.field);
      return;
    } // If there is no query parameter for selected field, choose first field that have lineage


    getFirstFieldLineage(fields);
  });
}
function getFields(datasetId, prefix) {
  var start = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'now-7d';
  var end = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 'now';
  components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
    type: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["Actions"].closeSummary
  });
  var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__["getCurrentNamespace"])();
  var params = {
    namespace: namespace,
    entityId: datasetId,
    start: start,
    end: end,
    includeCurrent: true
  };

  if (prefix && prefix.length > 0) {
    params.prefix = prefix;
  }

  api_metadata__WEBPACK_IMPORTED_MODULE_0__["MyMetadataApi"].getFields(params).subscribe(function (res) {
    components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
      type: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setFields,
      payload: {
        datasetId: datasetId,
        fields: res
      }
    });
    getFirstFieldLineage(res);
  });
}
function getLineageSummary(fieldName) {
  var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__["getCurrentNamespace"])();
  var datasetId = components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().lineage.datasetId;

  var _getTimeRange = getTimeRange(),
      start = _getTimeRange.start,
      end = _getTimeRange.end;

  var params = {
    namespace: namespace,
    entityId: datasetId,
    fieldName: fieldName,
    direction: 'both',
    start: start,
    end: end
  };
  api_metadata__WEBPACK_IMPORTED_MODULE_0__["MyMetadataApi"].getFieldLineage(params).subscribe(function (res) {
    components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
      type: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setLineageSummary,
      payload: {
        incoming: res.incoming,
        outgoing: res.outgoing,
        activeField: fieldName
      }
    });
    replaceHistory();
  });
}
var debouncedGetFields = lodash_debounce__WEBPACK_IMPORTED_MODULE_3___default()(getFields, 500);
function search(e) {
  var datasetId = components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().lineage.datasetId;
  var searchText = e.target.value;
  components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
    type: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setSearch,
    payload: {
      search: searchText
    }
  });
  debouncedGetFields(datasetId, searchText);
}
function getOperations(direction) {
  components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
    type: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["Actions"].operationsLoading,
    payload: {
      direction: direction
    }
  });
  var state = components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().lineage;
  var entityId = state.datasetId;
  var fieldName = state.activeField;
  var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_1__["getCurrentNamespace"])();

  var _getTimeRange2 = getTimeRange(),
      start = _getTimeRange2.start,
      end = _getTimeRange2.end;

  var params = {
    namespace: namespace,
    entityId: entityId,
    fieldName: fieldName,
    start: start,
    end: end,
    direction: direction
  };
  api_metadata__WEBPACK_IMPORTED_MODULE_0__["MyMetadataApi"].getFieldOperations(params).subscribe(function (res) {
    components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
      type: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setOperations,
      payload: {
        operations: res[direction],
        direction: direction
      }
    });
  });
}
function setCustomTimeRange(_ref) {
  var start = _ref.start,
      end = _ref.end;
  components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
    type: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setCustomTime,
    payload: {
      start: start,
      end: end
    }
  });
  var state = components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().lineage;
  getFields(state.datasetId, state.search, start, end);
  replaceHistory();
}
function setTimeRange(option) {
  if (components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["TIME_OPTIONS"].indexOf(option) === -1) {
    return;
  }

  components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch({
    type: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["Actions"].setTimeSelection,
    payload: {
      timeSelection: option
    }
  });

  if (option === components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["TIME_OPTIONS"][0]) {
    return;
  }

  var _TIME_OPTIONS_MAP$opt = TIME_OPTIONS_MAP[option],
      start = _TIME_OPTIONS_MAP$opt.start,
      end = _TIME_OPTIONS_MAP$opt.end;
  var state = components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].getState().lineage;
  getFields(state.datasetId, state.search, start, end);
  replaceHistory();
}
function getTimeQueryParams() {
  var state = components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].getState();
  var url = "time=".concat(state.lineage.timeSelection);

  if (state.lineage.timeSelection === components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["TIME_OPTIONS"][0]) {
    url += "&start=".concat(state.customTime.start, "&end=").concat(state.customTime.end);
  }

  return url;
}
function replaceHistory() {
  var url = constructQueryParamsURL();
  var currentLocation = location.pathname + location.search;

  if (url === currentLocation) {
    return;
  }

  var stateObj = {
    title: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_5__["Theme"].productName,
    url: url
  }; // This timeout is to make sure rendering by store update is finished before changing the state.
  // Otherwise, some fonts will not render because it is referencing wrong path.

  setTimeout(function () {
    history.replaceState(stateObj, stateObj.title, stateObj.url);
  });
}

function constructQueryParamsURL() {
  var state = components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_2__["default"].getState();
  var url = location.pathname;
  url += "?".concat(getTimeQueryParams());

  if (state.lineage.activeField) {
    url += "&field=".concat(state.lineage.activeField);
  }

  return url;
}

/***/ }),

/***/ "./components/FieldLevelLineage/store/Store.js":
/*!*****************************************************!*\
  !*** ./components/FieldLevelLineage/store/Store.js ***!
  \*****************************************************/
/*! exports provided: TIME_OPTIONS, default, Actions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TIME_OPTIONS", function() { return TIME_OPTIONS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Actions", function() { return Actions; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "../../node_modules/redux/es/redux.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */


var TIME_OPTIONS = ['CUSTOM', 'last7d', 'last14d', 'lastMonth', 'last6M', 'lastYear'];
var Actions = {
  setFields: 'FLL_SET_FIELDS',
  setLineageSummary: 'FLL_SET_LINEAGE_SUMMARY',
  closeSummary: 'FLL_CLOSE_SUMMARY',
  setSearch: 'FLL_SET_SEARCH',
  setOperations: 'FLL_SET_OPERATIONS',
  closeOperations: 'FLL_CLOSE_OPERATIONS',
  operationsLoading: 'FLL_OPERATIONS_LOADING',
  nextOperation: 'FLL_NEXT_OPERATION',
  prevOperation: 'FLL_PREV_OPERATION',
  setTimeSelection: 'FLL_SET_TIME_SELECTION',
  setCustomTime: 'FLL_SET_CUSTOM_TIME',
  reset: 'FLL_RESET'
};
var defaultInitialState = {
  datasetId: '',
  fields: [],
  incoming: [],
  outgoing: [],
  activeField: null,
  search: '',
  timeSelection: TIME_OPTIONS[1]
};
var customTimeInitialState = {
  start: null,
  end: null
};
var operationsInitialState = {
  operations: [],
  showOperations: false,
  activeIndex: 0,
  direction: null,
  loading: false
};

var lineage = function lineage() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultInitialState;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case Actions.setFields:
      return _objectSpread({}, state, {
        datasetId: action.payload.datasetId,
        fields: action.payload.fields,
        incoming: state.search.length === 0 ? [] : state.incoming,
        outgoing: state.search.length === 0 ? [] : state.outgoing,
        activeField: null
      });

    case Actions.setLineageSummary:
      return _objectSpread({}, state, {
        incoming: action.payload.incoming,
        outgoing: action.payload.outgoing,
        activeField: action.payload.activeField
      });

    case Actions.closeSummary:
      return _objectSpread({}, state, {
        activeField: null
      });

    case Actions.setSearch:
      return _objectSpread({}, state, {
        search: action.payload.search
      });

    case Actions.setTimeSelection:
      return _objectSpread({}, state, {
        timeSelection: action.payload.timeSelection
      });

    case Actions.reset:
      return defaultInitialState;

    default:
      return state;
  }
};

var customTime = function customTime() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : customTimeInitialState;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case Actions.setCustomTime:
      return _objectSpread({}, state, {
        start: action.payload.start,
        end: action.payload.end
      });

    case Actions.reset:
      return customTimeInitialState;

    default:
      return state;
  }
};

var operations = function operations() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : operationsInitialState;
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : services_helpers__WEBPACK_IMPORTED_MODULE_1__["defaultAction"];

  switch (action.type) {
    case Actions.operationsLoading:
      return _objectSpread({}, state, {
        loading: true,
        showOperations: true,
        direction: action.payload.direction
      });

    case Actions.setOperations:
      return _objectSpread({}, state, {
        operations: action.payload.operations,
        direction: action.payload.direction,
        activeIndex: 0,
        showOperations: true,
        loading: false
      });

    case Actions.setLineageSummary:
    case Actions.closeOperations:
      return _objectSpread({}, state, {
        operations: [],
        direction: null,
        showOperations: false
      });

    case Actions.nextOperation:
      return _objectSpread({}, state, {
        activeIndex: state.activeIndex + 1
      });

    case Actions.prevOperation:
      return _objectSpread({}, state, {
        activeIndex: state.activeIndex - 1
      });

    case Actions.reset:
      return defaultInitialState;

    default:
      return state;
  }
};

var Store = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  lineage: lineage,
  operations: operations,
  customTime: customTime
}), {
  lineage: defaultInitialState,
  operations: operationsInitialState,
  customTime: customTimeInitialState
}, Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["composeEnhancers"])('FieldLevelLineageStore')());
/* harmony default export */ __webpack_exports__["default"] = (Store);


/***/ }),

/***/ "./components/FieldLevelLineage/v2/Context/FllContext.tsx":
/*!****************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/Context/FllContext.tsx ***!
  \****************************************************************/
/*! exports provided: FllContext, Provider, Consumer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FllContext", function() { return FllContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Provider", function() { return Provider; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Consumer", function() { return Consumer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContextHelper */ "./components/FieldLevelLineage/v2/Context/FllContextHelper.ts");
/* harmony import */ var d3__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! d3 */ "../../node_modules/d3/index.js");
/* harmony import */ var components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/FieldLevelLineage/store/Store */ "./components/FieldLevelLineage/store/Store.js");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
    }

    return t;
  };

  return __assign.apply(this, arguments);
};








var defaultContext = {
  target: '',
  targetFields: {},
  links: Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["getDefaultLinks"])(),
  causeSets: {},
  impactSets: {},
  showingOneField: false,
  start: null,
  end: null,
  selection: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_5__["TIME_OPTIONS"][1],
  showOperations: false,
  activeOpsIndex: 0,
  loadingOps: false,
  loadingLineage: true
};
var FllContext = react__WEBPACK_IMPORTED_MODULE_0___default.a.createContext(defaultContext);

var Provider =
/** @class */
function (_super) {
  __extends(Provider, _super);

  function Provider() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.handleFieldClick = function (e) {
      var activeFieldId = e.target.id; // casting because EventTarget lacks target and name

      if (!activeFieldId) {
        return;
      }

      if (_this.state.activeField.id) {
        d3__WEBPACK_IMPORTED_MODULE_4__["select"]("#" + _this.state.activeField.id).classed('selected', false);
      }

      var newField = {
        id: activeFieldId,
        name: e.target.dataset.fieldname
      };

      var activeLinks = _this.getActiveLinks(activeFieldId);

      var activeSets = _this.getActiveSets(activeLinks);

      _this.setState({
        activeField: newField,
        activeLinks: activeLinks,
        activeCauseSets: activeSets.activeCauseSets,
        activeImpactSets: activeSets.activeImpactSets
      }, function () {
        d3__WEBPACK_IMPORTED_MODULE_4__["select"]("#" + activeFieldId).classed('selected', true);
        Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["replaceHistory"])(_this.state.selection, _this.state.activeField, _this.state.start, _this.state.end);
      });
    };

    _this.getActiveLinks = function (newTargetId, newLinks) {
      var activeFieldId = newTargetId || _this.state.activeField.id;
      var activeLinks = Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["getDefaultLinks"])();
      var links = newLinks ? newLinks.incoming.concat(newLinks.outgoing) : _this.state.links.incoming.concat(_this.state.links.outgoing);
      links.forEach(function (link) {
        if (link.destination.id === activeFieldId) {
          activeLinks.incoming.push(link);
        }

        if (link.source.id === activeFieldId) {
          activeLinks.outgoing.push(link);
        }
      });
      return activeLinks;
    };

    _this.getActiveSets = function (activeLinks) {
      if (activeLinks === void 0) {
        activeLinks = _this.state.activeLinks;
      }

      var activeCauseSets = {};
      var activeImpactSets = {};

      if (!activeLinks) {
        activeLinks = _this.getActiveLinks();
      }

      for (var _i = 0, _a = Object.values(activeLinks); _i < _a.length; _i++) {
        var links = _a[_i];
        links.forEach(function (link) {
          var nonTargetFd = link.source.type !== 'target' ? link.source : link.destination;
          var tableId = Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["getTableId"])(nonTargetFd.dataset, nonTargetFd.namespace, nonTargetFd.type);

          if (nonTargetFd.type === 'cause') {
            if (!(tableId in activeCauseSets)) {
              activeCauseSets[tableId] = {
                fields: []
              };
            }

            activeCauseSets[tableId].fields.push(nonTargetFd);
          } else {
            if (!(tableId in activeImpactSets)) {
              activeImpactSets[tableId] = {
                fields: []
              };
            }

            activeImpactSets[tableId].fields.push(nonTargetFd);
          }
        });
      }

      return {
        activeCauseSets: activeCauseSets,
        activeImpactSets: activeImpactSets
      };
    };

    _this.handleViewCauseImpact = function () {
      _this.setState({
        showingOneField: true
      });
    };

    _this.handleReset = function () {
      _this.setState({
        showingOneField: false
      });
    };

    _this.setCustomTimeRange = function (_a) {
      var start = _a.start,
          end = _a.end;

      _this.updateLineageFromRange(components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_5__["TIME_OPTIONS"][0], start, end);
    };

    _this.setTimeRange = function (selection) {
      if (components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_5__["TIME_OPTIONS"].indexOf(selection) === -1) {
        return;
      }

      var _a = Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["getTimeRange"])(selection),
          start = _a.start,
          end = _a.end; // If CUSTOM, don't update lineage or url until date is picked


      if (selection === components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_5__["TIME_OPTIONS"][0]) {
        _this.setState({
          selection: selection,
          start: null,
          end: null
        });

        return;
      }

      _this.updateLineageFromRange(selection, start, end);
    };

    _this.toggleOperations = function (direction) {
      _this.setState({
        showOperations: !_this.state.showOperations,
        loadingOps: true,
        direction: direction
      }, function () {
        if (_this.state.showOperations && direction) {
          var timeParams = {
            start: _this.state.start,
            end: _this.state.end
          };

          var cb = function cb(operations) {
            _this.setState({
              operations: operations,
              loadingOps: false,
              activeOpsIndex: 0
            });
          };

          Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["getOperations"])(_this.state.target, timeParams, _this.state.activeField.name, direction, cb);
        }
      });
    };

    _this.nextOperation = function () {
      _this.setState({
        activeOpsIndex: _this.state.activeOpsIndex + 1
      });
    };

    _this.prevOperation = function () {
      _this.setState({
        activeOpsIndex: _this.state.activeOpsIndex - 1
      });
    };

    _this.handleExpandFields = function (namespace, tablename, type) {
      var entityId = Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["getTableId"])(tablename, namespace, type);
      var relatedFields = type === 'cause' ? _this.state.causeSets[entityId].fields : _this.state.impactSets[entityId].fields;
      var allSets = type === 'cause' ? _this.state.causeSets : _this.state.impactSets;

      var updatedSets = __assign({}, allSets); // If we already the unrelated fields for this table, no need to fetch again - just update expansion state for that table


      if (allSets[entityId].hasOwnProperty('unrelatedFields')) {
        updatedSets[entityId].isExpanded = !updatedSets[entityId].isExpanded;

        _this.setState(updatedSets);

        return;
      }

      Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["fetchUnrelatedFields"])(namespace, tablename, type, relatedFields, _this.state.start, _this.state.end).subscribe(function (unrelatedFields) {
        // Look up the sets to update (cause or impact)
        // Add unrelated fields to the appropriate entity in the cause or impact sets
        updatedSets[entityId].unrelatedFields = unrelatedFields;
        updatedSets[entityId].isExpanded = true;

        _this.setState(updatedSets);
      }, function (err) {
        // tslint:disable-next-line: no-console
        console.error('Error getting unrelated fields', err);
      });
    };

    _this.state = {
      target: '',
      targetFields: {},
      links: Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["getDefaultLinks"])(),
      causeSets: {},
      impactSets: {},
      activeField: {
        id: null,
        name: null
      },
      showingOneField: false,
      start: null,
      end: null,
      selection: components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_5__["TIME_OPTIONS"][1],
      activeCauseSets: {},
      activeImpactSets: {},
      activeLinks: null,
      loadingOps: false,
      loadingLineage: true,
      direction: null,
      // for handling pagination
      numTables: 4,
      firstCause: 1,
      firstImpact: 1,
      firstField: 1,
      showOperations: false,
      activeOpsIndex: 0,
      handleFieldClick: _this.handleFieldClick,
      handleViewCauseImpact: _this.handleViewCauseImpact,
      handleReset: _this.handleReset,
      handleExpandFields: _this.handleExpandFields,
      setTimeRange: _this.setTimeRange,
      setCustomTimeRange: _this.setCustomTimeRange,
      toggleOperations: _this.toggleOperations,
      nextOperation: _this.nextOperation,
      prevOperation: _this.prevOperation
    };
    return _this;
  }

  Provider.prototype.fetchFieldLineage = function (qParams, timeParams, dataset) {
    var _this = this;

    if (dataset === void 0) {
      dataset = this.state.target;
    }

    this.setState({
      loadingLineage: true
    });
    var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_2__["getCurrentNamespace"])();

    var updateState = function updateState(newState) {
      // If no field selected, grab the first field with lineage
      if (!newState.activeField.id && newState.targetFields.fields.length > 0) {
        newState.activeField = {
          id: newState.targetFields.fields[0].id,
          name: newState.targetFields.fields[0].name
        };
      }

      var activeLinks = _this.getActiveLinks(newState.activeField.id, newState.links);

      var activeSets = _this.getActiveSets(activeLinks);

      newState.activeLinks = activeLinks;
      newState.activeCauseSets = activeSets.activeCauseSets;
      newState.activeImpactSets = activeSets.activeImpactSets;
      newState.loadingLineage = false;

      _this.setState(newState);
    };

    Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["getFieldLineage"])(namespace, dataset, qParams, timeParams, updateState);
  };

  Provider.prototype.updateLineageFromRange = function (selection, start, end) {
    var _this = this;

    var newState = {
      selection: selection,
      start: null,
      end: null,
      loadingLineage: true
    }; // start and end are only set for custom date range

    if (selection === components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_5__["TIME_OPTIONS"][0]) {
      newState.start = start;
      newState.end = end;
    }

    this.setState(newState, function () {
      var qParams = Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["parseQueryString"])();
      var timeParams = {
        selection: selection,
        range: {
          start: start,
          end: end
        }
      };

      _this.fetchFieldLineage(qParams, timeParams);

      Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["replaceHistory"])(_this.state.selection, _this.state.activeField, _this.state.start, _this.state.end);
    });
  };

  Provider.prototype.initialize = function () {
    var dataset = Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["objectQuery"])(this.props, 'match', 'params', 'datasetId');
    var queryParams = Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["parseQueryString"])();
    var timeParams = Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["getTimeRangeFromUrl"])();
    this.fetchFieldLineage(queryParams, timeParams, dataset);
  };

  Provider.prototype.componentDidUpdate = function (prevProps) {
    var existingDataset = Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["objectQuery"])(prevProps, 'match', 'params', 'datasetId');
    var newDataset = Object(services_helpers__WEBPACK_IMPORTED_MODULE_1__["objectQuery"])(this.props, 'match', 'params', 'datasetId');

    if (existingDataset !== newDataset) {
      this.initialize();
    }
  };

  Provider.prototype.componentDidMount = function () {
    this.initialize();
  };

  Provider.prototype.render = function () {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(FllContext.Provider, {
      value: this.state
    }, this.props.children);
  };

  return Provider;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);


function Consumer(_a) {
  var children = _a.children;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(FllContext.Consumer, null, children);
}

/***/ }),

/***/ "./components/FieldLevelLineage/v2/Context/FllContextHelper.ts":
/*!*********************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/Context/FllContextHelper.ts ***!
  \*********************************************************************/
/*! exports provided: getDefaultLinks, getLinks, getFieldsAndLinks, makeTargetFields, getFieldId, getTableId, getTimeRangeFromUrl, getFieldLineage, getTimeRange, replaceHistory, getTimeQueryParams, getOperations, fetchUnrelatedFields */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDefaultLinks", function() { return getDefaultLinks; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLinks", function() { return getLinks; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFieldsAndLinks", function() { return getFieldsAndLinks; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeTargetFields", function() { return makeTargetFields; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFieldId", function() { return getFieldId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTableId", function() { return getTableId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTimeRangeFromUrl", function() { return getTimeRangeFromUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFieldLineage", function() { return getFieldLineage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTimeRange", function() { return getTimeRange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "replaceHistory", function() { return replaceHistory; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTimeQueryParams", function() { return getTimeQueryParams; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getOperations", function() { return getOperations; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchUnrelatedFields", function() { return fetchUnrelatedFields; });
/* harmony import */ var components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! components/FieldLevelLineage/store/Store */ "./components/FieldLevelLineage/store/Store.js");
/* harmony import */ var components_FieldLevelLineage_store_ActionCreator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/FieldLevelLineage/store/ActionCreator */ "./components/FieldLevelLineage/store/ActionCreator.js");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! services/NamespaceStore */ "./services/NamespaceStore/index.ts");
/* harmony import */ var api_metadata__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! api/metadata */ "./api/metadata.js");
/* harmony import */ var services_ThemeHelper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! services/ThemeHelper */ "./services/ThemeHelper.ts");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var getDefaultLinks = function getDefaultLinks() {
  return {
    incoming: [],
    outgoing: []
  };
};
/** Parses an incoming or outgoing entity object from backend response
 * to get array of edges and an object with fields keyed by dataset.
 * namespace and target are the target namespace and dataset name
 */

function getLinks(namespace, target, ents, isCause) {
  if (isCause === void 0) {
    isCause = true;
  }

  var tables = {};
  var links = [];
  var targetFieldsWithOps = new Set(); // Keep track of all target fields with operations/lineage

  ents.forEach(function (ent) {
    // Assumes that all tableNames are unique within a namespace
    // Check if entity should not be rendered (i.e. from dropped or added field)
    if (!ent.hasOwnProperty('entityId')) {
      // Just mark the target field(s) as having operations, for the dangling links
      ent.relations.map(function (rel) {
        var targetField = isCause ? rel.destination : rel.source; // Grab the target field

        targetFieldsWithOps.add(targetField);
      });
      return;
    }

    var type = isCause ? 'cause' : 'impact';
    var tableId = getTableId(ent.entityId.dataset, ent.entityId.namespace, type); // tables keeps track of datasets and fields that need to be rendered.

    tables[tableId] = {
      fieldCount: ent.fieldCount,
      fields: [],
      dataset: ent.entityId.dataset,
      namespace: ent.entityId.namespace
    }; // fieldIds keeps track of fields to prevent duplication, since a single field can have multiple connections

    var fieldIds = new Map(); // Go through all the entity's relations to grab fields to be rendered and the target fields (which have ops)

    ent.relations.map(function (rel) {
      /** backend response assumes connection goes from left to right
       * i.e. an incoming connection's destination = target field,
       * and outgoing connection's source = target field.
       */
      var fieldName = isCause ? rel.source : rel.destination;
      var id = fieldIds.get(fieldName);
      var field = {
        id: id,
        type: type,
        name: fieldName,
        dataset: ent.entityId.dataset,
        namespace: ent.entityId.namespace
      }; // if we haven't seen this field yet, add it to the table's list of fields

      if (!fieldIds.has(fieldName)) {
        id = getFieldId(fieldName, ent.entityId.dataset, ent.entityId.namespace, type);
        field.id = id;
        fieldIds.set(fieldName, id);
        tables[tableId].fields.push(field);
      }

      var targetName = isCause ? rel.destination : rel.source;
      targetFieldsWithOps.add(targetName);
      var targetField = {
        id: getFieldId(targetName, target, namespace, 'target'),
        type: 'target',
        dataset: target,
        namespace: namespace,
        name: isCause ? rel.destination : rel.source
      };
      var link = {
        source: isCause ? field : targetField,
        destination: isCause ? targetField : field
      };
      links.push(link);
    });
  });
  return {
    tables: tables,
    links: links,
    targetFieldsWithOps: targetFieldsWithOps
  };
}
function getFieldsAndLinks(d) {
  var incomingLineage = getLinks(d.entityId.namespace, d.entityId.dataset, d.incoming);
  var outgoingLineage = getLinks(d.entityId.namespace, d.entityId.dataset, d.outgoing, false);
  var causeTables = incomingLineage.tables;
  var impactTables = outgoingLineage.tables;
  var targetFieldsWithOps = {
    incoming: incomingLineage.targetFieldsWithOps,
    outgoing: outgoingLineage.targetFieldsWithOps
  };
  var links = {
    incoming: incomingLineage.links,
    outgoing: outgoingLineage.links
  };
  return {
    causeTables: causeTables,
    impactTables: impactTables,
    links: links,
    targetFieldsWithOps: targetFieldsWithOps
  };
}
function makeTargetFields(_a, fields, fieldsWithOps) {
  var namespace = _a.namespace,
      dataset = _a.dataset;
  var targetFields = fields.map(function (fieldname) {
    var id = "target_ns-" + namespace + "_ds-" + dataset + "_fd-" + fieldname;
    var hasIncomingOps = fieldsWithOps.incoming.has(fieldname);
    var hasOutgoingOps = fieldsWithOps.outgoing.has(fieldname);
    var field = {
      id: id,
      type: 'target',
      name: fieldname,
      dataset: dataset,
      namespace: namespace,
      hasIncomingOps: hasIncomingOps,
      hasOutgoingOps: hasOutgoingOps
    };
    return field;
  });
  return {
    fields: targetFields
  };
}
function getFieldId(fieldname, dataset, namespace, type) {
  return type + "_ns-" + namespace + "_ds-" + dataset + "_fd-" + fieldname;
}
function getTableId(dataset, namespace, type) {
  return type + "_ns-" + namespace + "_ds-" + dataset;
}
function getTimeRangeFromUrl() {
  var queryString = Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["parseQueryString"])();
  var selection = queryString ? queryString.time : components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_0__["TIME_OPTIONS"][1]; // default is last 7 days

  if (selection === components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_0__["TIME_OPTIONS"][0]) {
    return {
      selection: selection,
      range: {
        start: queryString.start || 'now-7d',
        end: queryString.end || 'now'
      }
    };
  }

  return {
    selection: selection,
    range: components_FieldLevelLineage_store_ActionCreator__WEBPACK_IMPORTED_MODULE_1__["TIME_OPTIONS_MAP"][selection]
  };
}
function getFieldLineage(namespace, dataset, qParams, timeParams, cb) {
  var fieldname;
  var activeField;

  if (!qParams || !qParams.field) {
    fieldname = null;
    activeField = {
      id: null,
      name: null
    };
  } else {
    fieldname = qParams.field;
    activeField = {
      name: fieldname,
      id: getFieldId(fieldname, dataset, namespace, 'target')
    };
  }

  var start = timeParams.range.start;
  var end = timeParams.range.end;
  var params = {
    namespace: namespace,
    entityId: dataset,
    direction: 'both',
    start: start,
    end: end
  };
  api_metadata__WEBPACK_IMPORTED_MODULE_4__["MyMetadataApi"].getAllFieldLineage(params).subscribe(function (res) {
    var parsedRes = getFieldsAndLinks(res);
    var targetInfo = {
      target: res.entityId.dataset,
      targetFields: makeTargetFields(res.entityId, res.fields, parsedRes.targetFieldsWithOps),
      links: parsedRes.links,
      causeSets: parsedRes.causeTables,
      impactSets: parsedRes.impactTables,
      selection: timeParams.selection,
      start: start,
      end: end,
      activeField: activeField,
      showingOneField: false,
      showOperations: false,
      activeOpsIndex: 0,
      loadingOps: false
    };
    cb(targetInfo);
  });
}

function constructQueryParams(selection, activeField, start, end) {
  var pathname = location.pathname;
  var timeParams = getTimeParamsFromSelection(selection, start, end);
  var url = "" + pathname + timeParams;

  if (activeField.id) {
    url = url + "&field=" + activeField.name;
  }

  return url;
}

function getTimeRange(selection) {
  var _a;

  if (components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_0__["TIME_OPTIONS"].indexOf(selection) === -1) {
    return;
  }

  var start = null;
  var end = null; // set start and end times if not CUSTOM

  if (selection !== components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_0__["TIME_OPTIONS"][0]) {
    _a = components_FieldLevelLineage_store_ActionCreator__WEBPACK_IMPORTED_MODULE_1__["TIME_OPTIONS_MAP"][selection], start = _a.start, end = _a.end;
  }

  return {
    start: start,
    end: end
  };
}

function getTimeParamsFromSelection(selection, start, end) {
  var queryParams = "?time=" + selection;

  if (selection === components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_0__["TIME_OPTIONS"][0]) {
    queryParams = queryParams + "&start=" + start + "&end=" + end;
  }

  return queryParams;
}

function replaceHistory(selection, activeField, start, end) {
  var url = constructQueryParams(selection, activeField, start, end);
  var currentLocation = location.pathname + location.search;

  if (url === currentLocation) {
    return;
  }

  var stateObj = {
    title: services_ThemeHelper__WEBPACK_IMPORTED_MODULE_5__["Theme"].productName,
    url: url
  };
  history.replaceState(stateObj, stateObj.title, stateObj.url);
}
function getTimeQueryParams(selection, start, end) {
  var timeRange = selection ? selection : components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_0__["TIME_OPTIONS"][1];
  var params = "?time=" + timeRange;

  if (start && selection === components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_0__["TIME_OPTIONS"][0]) {
    params = params + "&start=" + start + "&end=" + end;
  }

  return params;
}
function getOperations(dataset, timeParams, fieldName, direction, cb) {
  var namespace = Object(services_NamespaceStore__WEBPACK_IMPORTED_MODULE_3__["getCurrentNamespace"])();
  var params = {
    namespace: namespace,
    entityId: dataset,
    fieldName: fieldName,
    start: timeParams.start,
    end: timeParams.end,
    direction: direction
  };
  api_metadata__WEBPACK_IMPORTED_MODULE_4__["MyMetadataApi"].getFieldOperations(params).subscribe(function (res) {
    var operations = res[direction];
    cb(operations);
  });
}
function fetchUnrelatedFields(namespace, tablename, type, relatedFields, start, end) {
  var isUnrelatedField = function isUnrelatedField(fieldname, fields) {
    var fieldId = getFieldId(fieldname, tablename, namespace, type);
    return fields.filter(function (field) {
      return field.id === fieldId;
    }).length === 0;
  };

  var getFieldProperties = function getFieldProperties(fieldname) {
    var fieldProperties = {
      type: type,
      namespace: namespace,
      name: fieldname,
      dataset: tablename,
      id: getFieldId(fieldname, tablename, namespace, type)
    };
    return fieldProperties;
  };

  var params = {
    namespace: namespace,
    entityId: tablename,
    start: start,
    end: end
  };
  var fieldsObservable = api_metadata__WEBPACK_IMPORTED_MODULE_4__["MyMetadataApi"].getFields(params).map(function (res) {
    // Filter out fields that are already being rendered (to keep field order) and add field properties
    return res.filter(function (fieldname) {
      return isUnrelatedField(fieldname, relatedFields);
    }).map(function (fieldname) {
      return getFieldProperties(fieldname);
    });
  });
  return fieldsObservable;
}

/***/ }),

/***/ "./components/FieldLevelLineage/v2/FllHeader/index.tsx":
/*!*************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/FllHeader/index.tsx ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContext */ "./components/FieldLevelLineage/v2/Context/FllContext.tsx");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var styles = function styles(theme) {
  return {
    root: {
      color: "" + theme.palette.grey[50],
      height: 70,
      '& .target': {
        fontSize: '14px',
        fontWeight: 'bold'
      }
    },
    header: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    },
    subHeader: {
      borderBottom: "2px solid " + theme.palette.grey[200]
    }
  };
};

function FllHeader(_a) {
  var type = _a.type,
      total = _a.total,
      classes = _a.classes;

  var _b = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_4__["FllContext"]),
      firstCause = _b.firstCause,
      firstImpact = _b.firstImpact,
      firstField = _b.firstField,
      target = _b.target,
      numTables = _b.numTables;

  var last;
  var first;
  var header;
  var isTarget = type === 'target';

  if (type === 'impact') {
    first = firstImpact;
    header = i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate('features.FieldLevelLineage.v2.FllHeader.OutputHeader', {
      target: target
    });
  } else {
    first = firstCause;
    header = isTarget ? i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate('features.FieldLevelLineage.v2.FllHeader.TargetHeader') : i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate('features.FieldLevelLineage.v2.FllHeader.InputHeader', {
      target: target
    });
  }

  last = first + numTables - 1 <= total ? first + numTables - 1 : total;

  if (isTarget) {
    last = total;
  }

  var options = {
    first: first,
    last: last,
    total: total,
    context: total
  };
  var subHeader;

  if (total === 0) {
    subHeader = i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate('features.FieldLevelLineage.v2.FllHeader.NoRelatedSubheader');
  } else {
    subHeader = isTarget && total > 0 ? i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate('features.FieldLevelLineage.v2.FllHeader.TargetSubheader', options) : i18n_react__WEBPACK_IMPORTED_MODULE_1___default.a.translate('features.FieldLevelLineage.v2.FllHeader.RelatedSubheader', options);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classes.root
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(classes.header, {
      target: isTarget
    })
  }, header), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classes.subHeader
  }, subHeader));
}

var StyledFllHeader = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_3___default()(styles)(FllHeader);
/* harmony default export */ __webpack_exports__["default"] = (StyledFllHeader);

/***/ }),

/***/ "./components/FieldLevelLineage/v2/FllTable/FllExpandableField.tsx":
/*!*************************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/FllTable/FllExpandableField.tsx ***!
  \*************************************************************************/
/*! exports provided: styles, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "styles", function() { return styles; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/icons/KeyboardArrowDown */ "../../node_modules/@material-ui/icons/KeyboardArrowDown.js");
/* harmony import */ var _material_ui_icons_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_icons_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/icons/KeyboardArrowUp */ "../../node_modules/@material-ui/icons/KeyboardArrowUp.js");
/* harmony import */ var _material_ui_icons_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
/*
 * Copyright © 2020 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var styles = function styles(theme) {
  return {
    root: {
      color: theme.palette.blue[200],
      fontSize: '0.92em',
      cursor: 'pointer'
    }
  };
};
var I18N_PREFIX = 'features.FieldLevelLineage.v2.FllTable.FllExpandableField';

function ExpandableField(_a) {
  var isExpanded = _a.isExpanded,
      handleClick = _a.handleClick,
      tablename = _a.tablename,
      classes = _a.classes;
  var message = isExpanded ? i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate(I18N_PREFIX + ".hideFields") : i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate(I18N_PREFIX + ".showFields");
  var arrowIcon = isExpanded ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_icons_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_4___default.a, null) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_icons_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_3___default.a, null);
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()('grid-row', 'grid-link', classes.root),
    "data-cy": (isExpanded ? 'hide' : 'show') + "-fields-panel-" + tablename,
    onClick: handleClick
  }, message, arrowIcon);
}

var StyledExpandableField = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(ExpandableField);
/* harmony default export */ __webpack_exports__["default"] = (StyledExpandableField);

/***/ }),

/***/ "./components/FieldLevelLineage/v2/FllTable/FllField.tsx":
/*!***************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/FllTable/FllField.tsx ***!
  \***************************************************************/
/*! exports provided: styles, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "styles", function() { return styles; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContextHelper */ "./components/FieldLevelLineage/v2/Context/FllContextHelper.ts");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContext */ "./components/FieldLevelLineage/v2/Context/FllContext.tsx");
/* harmony import */ var components_FieldLevelLineage_v2_FllTable_FllMenu__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/FieldLevelLineage/v2/FllTable/FllMenu */ "./components/FieldLevelLineage/v2/FllTable/FllMenu/index.tsx");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









var styles = function styles(theme) {
  return {
    root: {
      '&.grid-row.activeField': {
        backgroundColor: theme.palette.yellow[200]
      }
    },
    hoverText: {
      color: theme.palette.blue[200],
      paddingLeft: '28px'
    },
    targetView: {
      paddingLeft: '55px',
      color: theme.palette.blue[200],
      cursor: 'pointer',
      height: '20px'
    },
    fieldname: {
      pointerEvents: 'none',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  };
};

function FllField(_a) {
  var field = _a.field,
      isActive = _a.isActive,
      classes = _a.classes;

  var _b = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false),
      isHovering = _b[0],
      setHoverState = _b[1];

  var _c = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_7__["FllContext"]),
      activeField = _c.activeField,
      showingOneField = _c.showingOneField,
      handleFieldClick = _c.handleFieldClick,
      handleReset = _c.handleReset,
      selection = _c.selection,
      start = _c.start,
      end = _c.end;

  var timeParams = Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_1__["getTimeQueryParams"])(selection, start, end);
  var linkPath = "/ns/" + field.namespace + "/datasets/" + field.dataset + "/fields" + timeParams + "&field=" + field.name;

  var toggleHoverState = function toggleHoverState(nextState) {
    setHoverState(nextState);
  };

  var isTarget = field.type === 'target';
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    onClick: isTarget && !showingOneField ? handleFieldClick : undefined,
    onMouseEnter: toggleHoverState.bind(this, true),
    onMouseLeave: toggleHoverState.bind(this, false),
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()('grid-row', 'grid-link', classes.root, {
      activeField: isActive
    }),
    id: field.id,
    "data-fieldname": field.name,
    "data-hovering": isHovering,
    "data-target": isTarget,
    "data-cy": field.type + "-" + field.name
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: classes.fieldname
  }, field.name), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_5__["default"], {
    condition: isHovering && !isTarget
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    "data-cy": "view-lineage"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_6__["Link"], {
    to: linkPath,
    className: classes.hoverText,
    title: field.name
  }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate('features.FieldLevelLineage.v2.FllTable.FllField.viewLineage')))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_5__["default"], {
    condition: activeField.id && field.id === activeField.id && isTarget && !showingOneField
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_FllTable_FllMenu__WEBPACK_IMPORTED_MODULE_8__["default"], {
    hasIncomingOps: field.hasIncomingOps,
    hasOutgoingOps: field.hasOutgoingOps
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_5__["default"], {
    condition: activeField.id && field.id === activeField.id && isTarget && showingOneField
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: classes.targetView,
    onClick: handleReset,
    "data-cy": "reset-lineage"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate('features.FieldLevelLineage.v2.FllTable.FllField.resetLineage'))));
}

var StyledFllField = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_2___default()(styles)(FllField);
/* harmony default export */ __webpack_exports__["default"] = (StyledFllField);

/***/ }),

/***/ "./components/FieldLevelLineage/v2/FllTable/FllMenu/index.tsx":
/*!********************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/FllTable/FllMenu/index.tsx ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_MenuItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/MenuItem */ "../../node_modules/@material-ui/core/esm/MenuItem/index.js");
/* harmony import */ var _material_ui_core_Menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/Menu */ "../../node_modules/@material-ui/core/esm/Menu/index.js");
/* harmony import */ var _material_ui_icons_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/icons/KeyboardArrowDown */ "../../node_modules/@material-ui/icons/KeyboardArrowDown.js");
/* harmony import */ var _material_ui_icons_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_Divider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Divider */ "../../node_modules/@material-ui/core/esm/Divider/index.js");
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/Button */ "../../node_modules/@material-ui/core/esm/Button/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContext */ "./components/FieldLevelLineage/v2/Context/FllContext.tsx");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









var PREFIX = 'features.FieldLevelLineage.v2.FllTable';

var styles = function styles(theme) {
  return {
    root: {
      paddingLeft: '47px'
    },
    targetView: {
      padding: 0,
      color: theme.palette.blue[200],
      minWidth: '60px',
      textAlign: 'right',
      textTransform: 'none',
      fontSize: 'inherit'
    },
    menu: {
      border: "1px solid " + theme.palette.grey[200],
      borderRadius: '1px',
      color: theme.palette.blue[200],
      '& .MuiListItem-root': {
        minHeight: 0
      },
      '& .Mui-disabled': {
        color: theme.palette.grey[200]
      }
    }
  };
};

function FllMenu(_a) {
  var hasIncomingOps = _a.hasIncomingOps,
      hasOutgoingOps = _a.hasOutgoingOps,
      classes = _a.classes;

  var _b = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null),
      anchorEl = _b[0],
      setAnchorEl = _b[1];

  var _c = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_8__["FllContext"]),
      handleViewCauseImpact = _c.handleViewCauseImpact,
      toggleOperations = _c.toggleOperations;

  function handleViewClick(e) {
    setAnchorEl(e.currentTarget);
  }

  function handleCloseMenu() {
    setAnchorEl(null);
  }

  function handleShowOperations(direction) {
    toggleOperations(direction);
    handleCloseMenu();
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: classes.root
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_6__["default"], {
    onClick: handleViewClick,
    className: classes.targetView,
    "data-cy": "fll-view-dropdown"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate(PREFIX + ".FllField.viewDropdown"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_icons_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_4___default.a, null)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Menu__WEBPACK_IMPORTED_MODULE_3__["default"], {
    classes: {
      paper: classes.menu
    },
    anchorEl: anchorEl,
    open: Boolean(anchorEl),
    onClose: handleCloseMenu,
    getContentAnchorEl: null,
    anchorOrigin: {
      vertical: 'bottom',
      horizontal: 'center'
    },
    transformOrigin: {
      vertical: 'top',
      horizontal: 'center'
    },
    "data-cy": "fll-field-menu"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_MenuItem__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onClick: handleViewCauseImpact,
    "data-cy": "fll-cause-impact"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate(PREFIX + ".FllMenu.causeImpact")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Divider__WEBPACK_IMPORTED_MODULE_5__["default"], {
    variant: "middle"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_MenuItem__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onClick: hasIncomingOps ? handleShowOperations.bind(this, 'incoming') : undefined,
    disabled: !hasIncomingOps,
    "data-cy": "fll-view-incoming"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate(PREFIX + ".FllMenu.viewIncoming")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_MenuItem__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onClick: hasOutgoingOps ? handleShowOperations.bind(this, 'outgoing') : undefined,
    disabled: !hasOutgoingOps,
    "data-cy": "fll-view-outgoing"
  }, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate(PREFIX + ".FllMenu.viewOutgoing"))));
}

var StyledFllMenu = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(FllMenu);
/* harmony default export */ __webpack_exports__["default"] = (StyledFllMenu);

/***/ }),

/***/ "./components/FieldLevelLineage/v2/FllTable/FllTableHeader.tsx":
/*!*********************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/FllTable/FllTableHeader.tsx ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContextHelper */ "./components/FieldLevelLineage/v2/Context/FllContextHelper.ts");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-router-dom */ "../../node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContext */ "./components/FieldLevelLineage/v2/Context/FllContext.tsx");
/*
 * Copyright © 2020 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









var styles = function styles(theme) {
  return {
    tableHeader: {
      borderBottom: "2px solid " + theme.palette.grey[300],
      height: '40px',
      paddingLeft: '10px',
      fontWeight: 'bold',
      fontSize: '1rem',
      overflow: 'hidden',
      ' & .table-name': {
        overflow: 'hidden',
        whiteSpace: 'nowrap',
        textOverflow: 'ellipsis'
      },
      ' &.hovering': {
        backgroundColor: theme.palette.grey[700]
      }
    },
    tableSubheader: {
      color: theme.palette.grey[100],
      fontWeight: 'normal'
    }
  };
};

function FllTableHeader(_a) {
  var tableInfo = _a.tableInfo,
      fields = _a.fields,
      isTarget = _a.isTarget,
      _b = _a.isExpanded,
      isExpanded = _b === void 0 ? false : _b,
      classes = _a.classes;

  var _c = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false),
      isHovering = _c[0],
      setHoverState = _c[1];

  var _d = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_7__["FllContext"]),
      selection = _d.selection,
      start = _d.start,
      end = _d.end;

  var timeParams = Object(components_FieldLevelLineage_v2_Context_FllContextHelper__WEBPACK_IMPORTED_MODULE_3__["getTimeQueryParams"])(selection, start, end);

  var toggleHoverState = function toggleHoverState(nextState) {
    setHoverState(nextState);
  };

  var count = fields.length;
  var tableName = fields[0].dataset;
  var i18nOptions = {
    context: count
  };
  var linkPath = "/ns/" + tableInfo.namespace + "/datasets/" + tableInfo.dataset + "/fields" + timeParams;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(classes.tableHeader, {
      hovering: isHovering && !isTarget
    }),
    onMouseEnter: toggleHoverState.bind(this, true),
    onMouseLeave: toggleHoverState.bind(this, false)
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "table-name"
  }, tableName), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_6__["default"], {
    condition: !isHovering || isTarget
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classes.tableSubheader
  }, isTarget || isExpanded ? i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate('features.FieldLevelLineage.v2.FllTable.fieldsCount', i18nOptions) : i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate('features.FieldLevelLineage.v2.FllTable.relatedFieldsCount', i18nOptions))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_6__["default"], {
    condition: isHovering
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    "data-cy": "view-lineage",
    className: classes.tableSubheader
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Link"], {
    to: linkPath,
    className: classes.hoverText,
    title: tableName
  }, i18n_react__WEBPACK_IMPORTED_MODULE_5___default.a.translate('features.FieldLevelLineage.v2.FllTable.FllTableHeader.viewLineage')))));
}

var StyledTableHeader = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(FllTableHeader);
/* harmony default export */ __webpack_exports__["default"] = (StyledTableHeader);

/***/ }),

/***/ "./components/FieldLevelLineage/v2/FllTable/index.tsx":
/*!************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/FllTable/index.tsx ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_SortableStickyGrid_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/SortableStickyGrid/index.js */ "./components/SortableStickyGrid/index.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_styles_createStyles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/styles/createStyles */ "../../node_modules/@material-ui/core/styles/createStyles.js");
/* harmony import */ var _material_ui_core_styles_createStyles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_createStyles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_FieldLevelLineage_v2_FllTable_FllField__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/FieldLevelLineage/v2/FllTable/FllField */ "./components/FieldLevelLineage/v2/FllTable/FllField.tsx");
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContext */ "./components/FieldLevelLineage/v2/Context/FllContext.tsx");
/* harmony import */ var components_FieldLevelLineage_v2_FllTable_FllExpandableField__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/FieldLevelLineage/v2/FllTable/FllExpandableField */ "./components/FieldLevelLineage/v2/FllTable/FllExpandableField.tsx");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var components_FieldLevelLineage_v2_FllTable_FllTableHeader__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/FieldLevelLineage/v2/FllTable/FllTableHeader */ "./components/FieldLevelLineage/v2/FllTable/FllTableHeader.tsx");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */










 // TO DO: Consolidate different fontsizes in ThemeWrapper

var styles = function styles(theme) {
  return _material_ui_core_styles_createStyles__WEBPACK_IMPORTED_MODULE_3___default()({
    table: {
      width: '225px',
      border: "1px solid " + theme.palette.grey[300],
      fontSize: '0.92rem',
      marginBottom: '10px',
      '& .grid.grid-container': {
        maxHeight: 'none',
        background: theme.palette.white[50]
      }
    },
    targetTable: {
      border: "2px solid " + theme.palette.green[100]
    },
    activeTable: {
      border: "2px solid " + theme.palette.grey[100]
    },
    // had to add this in to fix styling after adding custom renderGridBody method...
    gridBody: {
      '& .grid-row': {
        paddingLeft: '10px',
        paddingRight: '10px',
        borderTop: "1px solid " + theme.palette.grey[500],
        height: '21px',
        alignItems: 'center',
        padding: '0',
        gridTemplateColumns: '1fr auto !important'
      },
      ' & .grid-row:hover': {
        backgroundColor: theme.palette.grey[700]
      },
      ' & .grid-row.selected': {
        backgroundColor: theme.palette.yellow[200],
        color: theme.palette.orange[50],
        fontWeight: 'bold',
        cursor: 'unset'
      }
    },
    viewLineage: {
      visibility: 'hidden',
      color: theme.palette.blue[300]
    }
  });
};

function renderGridHeader(tableInfo, fields, isTarget, isExpanded) {
  if (isExpanded === void 0) {
    isExpanded = false;
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_FllTable_FllTableHeader__WEBPACK_IMPORTED_MODULE_10__["default"], {
    tableInfo: tableInfo,
    fields: fields,
    isTarget: isTarget,
    isExpanded: isExpanded
  });
}

function renderGridBody(fields, tableId, activeFields, hasUnrelatedFields, isExpanded, handleClick, classes) {
  if (activeFields === void 0) {
    activeFields = new Set();
  }

  if (hasUnrelatedFields === void 0) {
    hasUnrelatedFields = false;
  }

  if (isExpanded === void 0) {
    isExpanded = false;
  }

  var namespace = fields[0].namespace;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classes.gridBody,
    id: tableId,
    "data-tablename": tableId,
    "data-namespace": namespace
  }, fields.map(function (field) {
    var isActiveField = activeFields.has(field.id);
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_FllTable_FllField__WEBPACK_IMPORTED_MODULE_6__["default"], {
      key: field.id,
      field: field,
      isActive: isActiveField
    });
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_9__["default"], {
    condition: hasUnrelatedFields
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_FllTable_FllExpandableField__WEBPACK_IMPORTED_MODULE_8__["default"], {
    isExpanded: isExpanded,
    handleClick: handleClick,
    tablename: fields[0].dataset
  })));
}

function FllTable(_a) {
  var _b, _c;

  var tableId = _a.tableId,
      tableInfo = _a.tableInfo,
      type = _a.type,
      isActive = _a.isActive,
      classes = _a.classes;
  var GRID_HEADERS = [{
    property: 'name',
    label: tableId
  }];

  var _d = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_7__["FllContext"]),
      target = _d.target,
      activeCauseSets = _d.activeCauseSets,
      activeImpactSets = _d.activeImpactSets,
      handleExpandFields = _d.handleExpandFields;

  var fields = tableInfo ? tableInfo.fields : [];

  if (!fields || fields.length === 0) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate('features.FieldLevelLineage.v2.FllTable.noRelatedTables', {
      type: type,
      target: target
    }));
  }

  var unrelatedFields = tableInfo.unrelatedFields;
  var fieldCount = tableInfo.fieldCount;
  var isExpanded = tableInfo.isExpanded || false;
  var isTarget = type === 'target';
  var hasUnrelatedFields = fields.length < fieldCount; // If there are unrelated fields AND the user has expanded to see all fields
  // render the unrelated fields

  if (unrelatedFields && isExpanded) {
    fields = fields.concat(unrelatedFields);
  } // get fields that are a direct cause or impact to selected field


  var getActiveFields = function getActiveFields() {
    var activeFields = [];

    if (isActive && !isTarget) {
      if (type === 'cause' && Object.keys(activeCauseSets).length > 0) {
        activeFields = activeCauseSets[tableId].fields;
      } else if (type === 'impact' && Object.keys(activeImpactSets).length > 0) {
        activeFields = activeImpactSets[tableId].fields;
      }
    }

    return activeFields;
  };

  var activeFieldIds = new Set(getActiveFields().map(function (field) {
    return field.id;
  }));

  var handleClick = function handleClick() {
    var namespace = fields[0].namespace;
    var tablename = fields[0].dataset;
    handleExpandFields(namespace, tablename, type);
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_SortableStickyGrid_index_js__WEBPACK_IMPORTED_MODULE_1__["default"], {
    key: "cause " + tableId,
    entities: fields,
    gridHeaders: GRID_HEADERS,
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()(classes.table, (_b = {}, _b[classes.targetTable] = isTarget, _b), (_c = {}, _c[classes.activeTable] = isActive, _c)),
    renderGridHeader: renderGridHeader.bind(null, tableInfo, fields, isTarget, isExpanded, classes),
    renderGridBody: renderGridBody.bind(this, fields, tableId, activeFieldIds, hasUnrelatedFields, isExpanded, handleClick, classes)
  });
}

var StyledFllTable = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_2___default()(styles)(FllTable);
/* harmony default export */ __webpack_exports__["default"] = (StyledFllTable);

/***/ }),

/***/ "./components/FieldLevelLineage/v2/LineageSummary/index.tsx":
/*!******************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/LineageSummary/index.tsx ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "../../node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_FieldLevelLineage_v2_FllHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/FieldLevelLineage/v2/FllHeader */ "./components/FieldLevelLineage/v2/FllHeader/index.tsx");
/* harmony import */ var components_FieldLevelLineage_v2_FllTable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/FieldLevelLineage/v2/FllTable */ "./components/FieldLevelLineage/v2/FllTable/index.tsx");
/* harmony import */ var components_FieldLevelLineage_v2_OperationsModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/FieldLevelLineage/v2/OperationsModal */ "./components/FieldLevelLineage/v2/OperationsModal/index.tsx");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContext */ "./components/FieldLevelLineage/v2/Context/FllContext.tsx");
/* harmony import */ var d3__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! d3 */ "../../node_modules/d3/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash/debounce */ "../../node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var components_ThemeWrapper_colors__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/ThemeWrapper/colors */ "./components/ThemeWrapper/colors.ts");
/* harmony import */ var components_If__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! components/If */ "./components/If/index.tsx");
/* harmony import */ var components_FieldLevelLineage_v2_TopPanel__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/FieldLevelLineage/v2/TopPanel */ "./components/FieldLevelLineage/v2/TopPanel/index.tsx");
/* harmony import */ var components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! components/LoadingSVGCentered */ "./components/LoadingSVGCentered/index.js");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();















var styles = function styles(theme) {
  return {
    wrapper: {
      overflowY: 'scroll',
      background: theme.palette.grey[700],
      height: '100%',
      minHeight: '480px',
      width: '100%',
      overflowX: 'hidden'
    },
    root: {
      paddingLeft: '100px',
      paddingRight: '100px',
      paddingTop: '5px',
      display: 'flex',
      justifyContent: 'space-between',
      position: 'relative',
      overflow: 'hidden'
    },
    container: {
      position: 'absolute',
      height: '100%',
      width: '100%',
      pointerEvents: 'none',
      overflow: 'visible'
    },
    summaryCol: {
      maxWidth: '30%'
    }
  };
};

var LineageSummary =
/** @class */
function (_super) {
  __extends(LineageSummary, _super);

  function LineageSummary() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.drawLinks = function () {
      if (_this.context.loadingLineage) {
        return;
      }

      var allLinks = _this.context.links;
      var activeField = _this.context.activeField;
      var activeFieldId = activeField ? activeField.id : undefined;
      var comboLinks = allLinks.incoming.concat(allLinks.outgoing);

      if (comboLinks.length === 0) {
        return;
      }

      _this.clearCanvas();

      comboLinks.forEach(function (link) {
        var isSelected = link.source.id === activeFieldId || link.destination.id === activeFieldId;

        _this.drawLineFromLink(link, isSelected);
      });
    };

    _this.debounceRedrawLinks = lodash_debounce__WEBPACK_IMPORTED_MODULE_8___default()(_this.drawLinks, 200);
    return _this;
  }

  LineageSummary.prototype.drawLineFromLink = function (_a, isSelected) {
    var source = _a.source,
        destination = _a.destination;

    if (isSelected === void 0) {
      isSelected = false;
    } // get source and destination elements and their coordinates


    var sourceId = source.id.replace(/\./g, '\\.');
    var destId = destination.id.replace(/\./g, '\\.');
    var sourceEl = d3__WEBPACK_IMPORTED_MODULE_7__["select"]("#" + sourceId);
    var destEl = d3__WEBPACK_IMPORTED_MODULE_7__["select"]("#" + destId);
    var offsetX = -100; // From the padding on the LineageSummary

    var offsetY = -this.myRef.getBoundingClientRect().top - 65 + this.myRef.scrollTop; // From TopPanel, FllHeader, and scroll

    var sourceXY = sourceEl.node().getBoundingClientRect();
    var destXY = destEl.node().getBoundingClientRect();
    var sourceX1 = sourceXY.right + offsetX;
    var sourceY1 = sourceXY.top + 0.5 * sourceXY.height + offsetY;
    var sourceX2 = destXY.left + offsetX;
    var sourceY2 = destXY.top + 0.5 * sourceXY.height + offsetY; // draw an edge from line start to line end

    var linkContainer = isSelected ? d3__WEBPACK_IMPORTED_MODULE_7__["select"]('#selected-links') : d3__WEBPACK_IMPORTED_MODULE_7__["select"]("#" + sourceId + "_" + destId);
    var third = (sourceX2 - sourceX1) / 3; // Draw a line with a bit of curve between the straight parts

    var lineGenerator = d3__WEBPACK_IMPORTED_MODULE_7__["line"]().curve(d3__WEBPACK_IMPORTED_MODULE_7__["curveMonotoneX"]);
    var points = [[sourceX1, sourceY1], [sourceX1 + third, sourceY1], [sourceX2 - third, sourceY2], [sourceX2, sourceY2]];
    var edgeColor = isSelected ? components_ThemeWrapper_colors__WEBPACK_IMPORTED_MODULE_9__["orange"][50] : components_ThemeWrapper_colors__WEBPACK_IMPORTED_MODULE_9__["grey"][300];
    linkContainer.append('path').style('stroke', edgeColor).style('stroke-width', '1').style('fill', 'none').attr('d', lineGenerator(points)); // draw left anchor

    var anchorHeight = 8;
    var anchorRx = 1.8;
    linkContainer.append('rect').attr('x', sourceX1 - anchorHeight * 0.5).attr('y', sourceY1 - anchorHeight * 0.5).attr('width', anchorHeight).attr('height', anchorHeight).attr('rx', anchorRx).attr('pointer-events', 'fill') // To make rect clickable
    .style('fill', edgeColor); // draw right anchor

    linkContainer.append('rect').attr('x', sourceX2 - anchorHeight * 0.5).attr('y', sourceY2 - anchorHeight * 0.5).attr('width', anchorHeight).attr('height', anchorHeight).attr('rx', anchorRx).attr('pointer-events', 'fill') // To make rect clickable
    .style('fill', edgeColor);
  };

  LineageSummary.prototype.clearCanvas = function () {
    // clear any existing links and anchors
    d3__WEBPACK_IMPORTED_MODULE_7__["select"]('#links-container').selectAll('path,rect').remove();
  }; // Draws only active links


  LineageSummary.prototype.drawActiveLinks = function (activeLinks) {
    var _this = this;

    this.clearCanvas();
    var allLinks = activeLinks.incoming.concat(activeLinks.outgoing);
    allLinks.forEach(function (link) {
      _this.drawLineFromLink(link, true);
    });
  };

  LineageSummary.prototype.componentDidUpdate = function () {
    var _a = this.context,
        showingOneField = _a.showingOneField,
        activeLinks = _a.activeLinks,
        activeField = _a.activeField; // if user has just clicked "View Cause and Impact"

    if (showingOneField) {
      this.clearCanvas();
      this.drawActiveLinks(activeLinks);
      return;
    }

    if (activeField) {
      d3__WEBPACK_IMPORTED_MODULE_7__["select"]("#" + activeField.id).classed('selected', true);
    }

    this.clearCanvas();
    this.drawLinks();
  };

  LineageSummary.prototype.componentWillUnmount = function () {
    window.removeEventListener('resize', this.debounceRedrawLinks);
  };

  LineageSummary.prototype.componentDidMount = function () {
    this.drawLinks();
    this.myRef = react_dom__WEBPACK_IMPORTED_MODULE_1___default.a.findDOMNode(this);
    window.addEventListener('resize', this.debounceRedrawLinks);
  };

  LineageSummary.prototype.render = function () {
    var _this = this;

    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_6__["Consumer"], null, function (_a) {
      var causeSets = _a.causeSets,
          target = _a.target,
          targetFields = _a.targetFields,
          impactSets = _a.impactSets,
          links = _a.links,
          activeLinks = _a.activeLinks,
          activeCauseSets = _a.activeCauseSets,
          activeImpactSets = _a.activeImpactSets,
          showingOneField = _a.showingOneField,
          loadingLineage = _a.loadingLineage;
      var visibleLinks = links;
      var visibleCauseSets = causeSets;
      var visibleImpactSets = impactSets;

      if (showingOneField) {
        visibleLinks = activeLinks;
        visibleCauseSets = activeCauseSets;
        visibleImpactSets = activeImpactSets;
      }

      var allLinks = visibleLinks.incoming.concat(visibleLinks.outgoing);
      var loadingIndicator = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "loading-container text-center"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_LoadingSVGCentered__WEBPACK_IMPORTED_MODULE_12__["default"], null));

      if (loadingLineage) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: _this.props.classes.wrapper
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_TopPanel__WEBPACK_IMPORTED_MODULE_11__["default"], {
          datasetId: target
        }), loadingIndicator);
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: _this.props.classes.wrapper
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_TopPanel__WEBPACK_IMPORTED_MODULE_11__["default"], {
        datasetId: target
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_10__["default"], {
        condition: !loadingLineage
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: _this.props.classes.root,
        id: "fll-container"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("svg", {
        id: "links-container",
        className: _this.props.classes.container
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("g", null, allLinks.map(function (link) {
        var id = link.source.id + "_" + link.destination.id;
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("svg", {
          id: id,
          key: id,
          className: "fll-link"
        });
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("g", {
        id: "selected-links"
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        "data-cy": "cause-fields",
        className: _this.props.classes.summaryCol
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_FllHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
        type: "cause",
        total: Object.keys(visibleCauseSets).length
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_10__["default"], {
        condition: Object.keys(visibleCauseSets).length === 0
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_FllTable__WEBPACK_IMPORTED_MODULE_3__["default"], {
        type: "cause"
      })), Object.entries(visibleCauseSets).map(function (_a) {
        var tableId = _a[0],
            tableInfo = _a[1];
        var isActive = tableId in activeCauseSets;
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_FllTable__WEBPACK_IMPORTED_MODULE_3__["default"], {
          key: tableId,
          tableId: tableId,
          tableInfo: tableInfo,
          type: "cause",
          isActive: isActive
        });
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        "data-cy": "target-fields",
        className: _this.props.classes.summaryCol
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_FllHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
        type: "target",
        total: targetFields.fields.length
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_FllTable__WEBPACK_IMPORTED_MODULE_3__["default"], {
        tableId: target,
        tableInfo: targetFields,
        type: "target"
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        "data-cy": "impact-fields",
        className: _this.props.classes.summaryCol
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_FllHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
        type: "impact",
        total: Object.keys(visibleImpactSets).length
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_If__WEBPACK_IMPORTED_MODULE_10__["default"], {
        condition: Object.keys(visibleImpactSets).length === 0
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_FllTable__WEBPACK_IMPORTED_MODULE_3__["default"], {
        type: "impact"
      })), Object.entries(visibleImpactSets).map(function (_a) {
        var tableId = _a[0],
            tableInfo = _a[1];
        var isActive = tableId in activeImpactSets;
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_FllTable__WEBPACK_IMPORTED_MODULE_3__["default"], {
          key: tableId,
          tableId: tableId,
          tableInfo: tableInfo,
          type: "impact",
          isActive: isActive
        });
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_OperationsModal__WEBPACK_IMPORTED_MODULE_4__["default"], null))));
    });
  };

  return LineageSummary;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

LineageSummary.contextType = components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_6__["FllContext"];
var StyledLineageSummary = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_5___default()(styles)(LineageSummary);
/* harmony default export */ __webpack_exports__["default"] = (StyledLineageSummary);

/***/ }),

/***/ "./components/FieldLevelLineage/v2/OperationsModal/ModalContent.tsx":
/*!**************************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/OperationsModal/ModalContent.tsx ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContext */ "./components/FieldLevelLineage/v2/Context/FllContext.tsx");
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var components_FieldLevelLineage_v2_OperationsModal_Navigation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/FieldLevelLineage/v2/OperationsModal/Navigation */ "./components/FieldLevelLineage/v2/OperationsModal/Navigation.tsx");
/* harmony import */ var components_FieldLevelLineage_v2_OperationsModal_OperationsTable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/FieldLevelLineage/v2/OperationsModal/OperationsTable */ "./components/FieldLevelLineage/v2/OperationsModal/OperationsTable.tsx");
/* harmony import */ var components_Heading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/Heading */ "./components/Heading/index.tsx");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_6__);
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */







var PREFIX = 'features.FieldLevelLineage.OperationsModal';

function formatDatasets(datasets) {
  // return in form 'dataset1, dataset2, and dataset3'
  switch (datasets.length) {
    case 0:
      return '';

    case 1:
      return "'" + datasets[0] + "'";

    case 2:
      return "'" + datasets[0] + "' and " + datasets[1];

    default:
      {
        var last = datasets[-1];
        var rest = datasets.slice(0, -1);
        return rest.map(function (dataset) {
          return "'" + dataset + "'";
        }).join(', ') + ", and '" + last + "'";
      }
  }
}

function getDatasets(operations) {
  var inputs = new Set(); // to prevent duplicate datasets in header

  var outputs = new Set();
  operations.forEach(function (operation) {
    var input = Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(operation, 'inputs', 'endPoint', 'name');
    var output = Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(operation, 'outputs', 'endPoint', 'name');

    if (input) {
      inputs.add(input);
    }

    if (output) {
      outputs.add(output);
    }
  });
  return {
    sources: formatDatasets(Array.from(inputs)),
    targets: formatDatasets(Array.from(outputs))
  };
}

var ModalContentView = function ModalContentView() {
  var _a = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_1__["FllContext"]),
      operations = _a.operations,
      activeOpsIndex = _a.activeOpsIndex;

  var activeSet = operations[activeOpsIndex];
  var lastApp = Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(activeSet, 'programs', 0);
  var application = Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(lastApp, 'program', 'application');
  var lastExecutedTime = Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["objectQuery"])(lastApp, 'lastExecutedTimeInSeconds');
  var activeOperations = activeSet.operations;

  var _b = getDatasets(activeOperations),
      sources = _b.sources,
      targets = _b.targets;

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "operations-container"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Heading__WEBPACK_IMPORTED_MODULE_5__["default"], {
    type: components_Heading__WEBPACK_IMPORTED_MODULE_5__["HeadingTypes"].h5,
    label: i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate(PREFIX + ".summaryText", {
      sources: sources,
      targets: targets
    }),
    className: "summary-text"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_OperationsModal_Navigation__WEBPACK_IMPORTED_MODULE_3__["default"], null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Heading__WEBPACK_IMPORTED_MODULE_5__["default"], {
    type: components_Heading__WEBPACK_IMPORTED_MODULE_5__["HeadingTypes"].h6,
    label: i18n_react__WEBPACK_IMPORTED_MODULE_6___default.a.translate(PREFIX + ".lastExecution", {
      app: application,
      time: Object(services_helpers__WEBPACK_IMPORTED_MODULE_2__["humanReadableDate"])(lastExecutedTime)
    }),
    className: "last-executed"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_OperationsModal_OperationsTable__WEBPACK_IMPORTED_MODULE_4__["default"], null));
};

/* harmony default export */ __webpack_exports__["default"] = (ModalContentView);

/***/ }),

/***/ "./components/FieldLevelLineage/v2/OperationsModal/Navigation.tsx":
/*!************************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/OperationsModal/Navigation.tsx ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContext */ "./components/FieldLevelLineage/v2/Context/FllContext.tsx");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */





var NavigationView = function NavigationView() {
  var _a = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_3__["FllContext"]),
      activeOpsIndex = _a.activeOpsIndex,
      operations = _a.operations,
      prevOperation = _a.prevOperation,
      nextOperation = _a.nextOperation;

  var limit = operations.length;
  var prevDisabled = activeOpsIndex === 0;
  var nextDisabled = activeOpsIndex === limit - 1;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "navigation"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('nav-icon', {
      disabled: prevDisabled
    }),
    onClick: !prevDisabled ? prevOperation : undefined
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
    name: "icon-caret-left"
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, activeOpsIndex + 1), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "separator"
  }, "of"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, limit), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('nav-icon', {
      disabled: nextDisabled
    }),
    onClick: !nextDisabled ? nextOperation : undefined
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_2__["default"], {
    name: "icon-caret-right"
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (NavigationView);

/***/ }),

/***/ "./components/FieldLevelLineage/v2/OperationsModal/OperationsTable.tsx":
/*!*****************************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/OperationsModal/OperationsTable.tsx ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContext */ "./components/FieldLevelLineage/v2/Context/FllContext.tsx");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_3__);
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();





var PREFIX = 'features.FieldLevelLineage.OperationsModal.Table';

var OperationsTable =
/** @class */
function (_super) {
  __extends(OperationsTable, _super);

  function OperationsTable() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.state = {
      activeOrigin: null,
      activeField: {
        operation: null,
        name: null
      }
    };
    return _this;
  }

  OperationsTable.prototype.componentWillReceiveProps = function () {
    this.setState({
      activeOrigin: null,
      activeField: {
        operation: null,
        name: null
      }
    });
  };

  OperationsTable.prototype.handleInputClick = function (field, operation) {
    this.setState({
      activeOrigin: field.origin,
      activeField: {
        operation: operation.name,
        name: field.name
      }
    });
  };

  OperationsTable.prototype.joinEndpoints = function (endpoints) {
    if (!endpoints || !endpoints.endPoint) {
      return '--';
    }

    return endpoints.endPoint.name;
  };

  OperationsTable.prototype.renderInput = function (operation) {
    return this.joinEndpoints(operation.inputs);
  };

  OperationsTable.prototype.renderOutput = function (operation) {
    return this.joinEndpoints(operation.outputs);
  };

  OperationsTable.prototype.renderInputFields = function (operation) {
    var _this = this;

    var fields = operation.inputs.fields;

    if (!fields) {
      return '--';
    }

    return fields.map(function (field, i) {
      var activeField = _this.state.activeField;
      var isSelected = activeField.operation === operation.name && activeField.name === field.name && _this.state.activeOrigin === field.origin;
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        key: field.name + "-" + i
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()('input-field', {
          selected: isSelected
        }),
        onClick: _this.handleInputClick.bind(_this, field, operation)
      }, "[", field.name, "]"), i !== fields.length - 1 ? ', ' : null);
    });
  };

  OperationsTable.prototype.renderOutputFields = function (operation) {
    if (!operation.outputs.fields) {
      return '--';
    }

    return operation.outputs.fields.join(', ');
  };

  OperationsTable.prototype.renderHeader = function () {
    var headers = ['input', 'inputFields', 'pluginName', 'description', 'outputFields', 'output'];
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "grid-header"
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "grid-row"
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null), headers.map(function (head) {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        key: head
      }, i18n_react__WEBPACK_IMPORTED_MODULE_3___default.a.translate(PREFIX + "." + head));
    })));
  };

  OperationsTable.prototype.renderBody = function (operations) {
    var _this = this;

    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "grid-body"
    }, operations.map(function (operation, i) {
      var description = null;
      var pluginName = operation.name.split('.')[0];

      if (operation.description) {
        var descriptionSplit_1 = operation.description.split('\n');
        description = descriptionSplit_1.map(function (line, index) {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, {
            key: index
          }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, line), descriptionSplit_1.length - 1 !== index ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null) : null);
        });
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        key: operation.name + "-" + i,
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()('grid-row', {
          active: operation.name === _this.state.activeOrigin
        })
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, i + 1), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, _this.renderInput(operation)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, _this.renderInputFields(operation)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        title: pluginName
      }, pluginName), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        title: operation.description
      }, description), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, _this.renderOutputFields(operation)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, _this.renderOutput(operation)));
    }));
  };

  OperationsTable.prototype.render = function () {
    var _a = this.context,
        operations = _a.operations,
        activeOpsIndex = _a.activeOpsIndex;
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "grid-wrapper"
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "grid grid-container grid-compact"
    }, this.renderHeader(), this.renderBody(operations[activeOpsIndex].operations)));
  };

  return OperationsTable;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (OperationsTable);
OperationsTable.contextType = components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_1__["FllContext"];

/***/ }),

/***/ "./components/FieldLevelLineage/v2/OperationsModal/index.tsx":
/*!*******************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/OperationsModal/index.tsx ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContext */ "./components/FieldLevelLineage/v2/Context/FllContext.tsx");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "../../node_modules/reactstrap/es/index.js");
/* harmony import */ var components_LoadingSVG__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/LoadingSVG */ "./components/LoadingSVG/index.js");
/* harmony import */ var components_FieldLevelLineage_v2_OperationsModal_ModalContent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/FieldLevelLineage/v2/OperationsModal/ModalContent */ "./components/FieldLevelLineage/v2/OperationsModal/ModalContent.tsx");
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_7__);
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








var PREFIX = 'features.FieldLevelLineage.OperationsModal';

__webpack_require__(/*! ../../OperationsModal/OperationsModal.scss */ "./components/FieldLevelLineage/OperationsModal/OperationsModal.scss");

var styles = function styles() {
  return {
    root: {
      maxWidth: '85vw',
      maxHeight: '80vh'
    }
  };
};

function OperationsModalView() {
  var _a = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_1__["FllContext"]),
      showOperations = _a.showOperations,
      toggleOperations = _a.toggleOperations,
      activeField = _a.activeField,
      direction = _a.direction,
      loadingOps = _a.loadingOps;

  if (!showOperations) {
    return null;
  }

  var loadingIndicator = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "loading-container text-center"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_LoadingSVG__WEBPACK_IMPORTED_MODULE_3__["default"], null));

  var closeModal = function closeModal(e) {
    toggleOperations();
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Modal"], {
    isOpen: true,
    toggle: toggleOperations,
    size: "lg",
    backdrop: "static",
    zIndex: "1061",
    className: "field-level-lineage-modal cdap-modal"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalHeader"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.translate(PREFIX + ".Title." + direction, {
    fieldName: activeField.name
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "close-section float-right",
    onClick: closeModal
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_5__["default"], {
    name: "icon-close"
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reactstrap__WEBPACK_IMPORTED_MODULE_2__["ModalBody"], null, loadingOps ? loadingIndicator : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_OperationsModal_ModalContent__WEBPACK_IMPORTED_MODULE_4__["default"], null)));
}

var OperationsModal = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_6___default()(styles)(OperationsModalView);
/* harmony default export */ __webpack_exports__["default"] = (OperationsModal);

/***/ }),

/***/ "./components/FieldLevelLineage/v2/TimeRangePicker/index.tsx":
/*!*******************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/TimeRangePicker/index.tsx ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_Select__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Select */ "../../node_modules/@material-ui/core/esm/Select/index.js");
/* harmony import */ var _material_ui_core_MenuItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/MenuItem */ "../../node_modules/@material-ui/core/esm/MenuItem/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/FieldLevelLineage/store/Store */ "./components/FieldLevelLineage/store/Store.js");
/* harmony import */ var components_TimeRangePicker_ExpandableTimeRange__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/TimeRangePicker/ExpandableTimeRange */ "./components/TimeRangePicker/ExpandableTimeRange.js");
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContext */ "./components/FieldLevelLineage/v2/Context/FllContext.tsx");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */








var PREFIX = 'features.FieldLevelLineage.v2.TimeRangePicker'; // These styles came from components/TimeRangePicker/TimeRangePicker.scss

var styles = function styles() {
  return {
    view: {
      padding: 10
    },
    timeRangeContainer: {
      display: 'inline-block',
      position: 'relative',
      marginLeft: 10,
      width: 400,
      '& .expandable-time-range-picker': {
        width: '330px'
      }
    }
  };
};

function TimeRangePicker(_a) {
  var classes = _a.classes;

  var _b = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_7__["FllContext"]),
      start = _b.start,
      end = _b.end,
      selection = _b.selection,
      setTimeRange = _b.setTimeRange,
      setCustomTimeRange = _b.setCustomTimeRange;

  var onSelect = function onSelect(e) {
    var range = e.target.value;
    setTimeRange(range);
  };

  var renderCustomTimeRange = function renderCustomTimeRange() {
    if (selection !== components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_5__["TIME_OPTIONS"][0]) {
      return null;
    }

    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: classes.timeRangeContainer,
      "data-cy": "time-range-selector"
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_TimeRangePicker_ExpandableTimeRange__WEBPACK_IMPORTED_MODULE_6__["default"], {
      onDone: setCustomTimeRange,
      inSeconds: true,
      start: start,
      end: end
    }));
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    "data-cy": "fll-time-picker"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: classes.view
  }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate(PREFIX + ".view")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Select__WEBPACK_IMPORTED_MODULE_2__["default"], {
    value: selection,
    onChange: onSelect,
    MenuProps: {
      anchorOrigin: {
        vertical: 'bottom',
        horizontal: 'left'
      },
      getContentAnchorEl: null
    },
    "data-cy": "time-picker-dropdown"
  }, components_FieldLevelLineage_store_Store__WEBPACK_IMPORTED_MODULE_5__["TIME_OPTIONS"].map(function (option) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_MenuItem__WEBPACK_IMPORTED_MODULE_3__["default"], {
      value: option,
      key: option,
      "data-cy": option
    }, i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate(PREFIX + ".TimeRangeOptions." + option));
  })), renderCustomTimeRange());
}

var StyledTimePicker = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(TimeRangePicker);
/* harmony default export */ __webpack_exports__["default"] = (StyledTimePicker);

/***/ }),

/***/ "./components/FieldLevelLineage/v2/TopPanel/index.tsx":
/*!************************************************************!*\
  !*** ./components/FieldLevelLineage/v2/TopPanel/index.tsx ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles/withStyles */ "../../node_modules/@material-ui/core/styles/withStyles.js");
/* harmony import */ var _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_FieldLevelLineage_v2_TimeRangePicker__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/FieldLevelLineage/v2/TimeRangePicker */ "./components/FieldLevelLineage/v2/TimeRangePicker/index.tsx");
/* harmony import */ var components_EntityTopPanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/EntityTopPanel */ "./components/EntityTopPanel/index.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! i18n-react */ "../../node_modules/i18n-react/dist/i18n-react.js");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_4__);
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */






var styles = function styles(theme) {
  return {
    root: {
      height: 60,
      background: theme.palette.white[50],
      display: 'grid',
      gridTemplateColumns: 'auto 342px'
    },
    picker: {
      marginTop: '2px'
    }
  };
};

var FllTopPanel = function FllTopPanel(_a) {
  var datasetId = _a.datasetId,
      classes = _a.classes;
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", {
    className: classes.root
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_EntityTopPanel__WEBPACK_IMPORTED_MODULE_3__["default"], {
    breadCrumbAnchorLabel: "Results",
    title: datasetId,
    entityType: i18n_react__WEBPACK_IMPORTED_MODULE_4___default.a.translate("commons.entity.dataset.singular"),
    entityIcon: "icon-datasets",
    historyBack: true,
    inheritBackground: true
  })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", {
    className: classes.picker
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_FieldLevelLineage_v2_TimeRangePicker__WEBPACK_IMPORTED_MODULE_2__["default"], null)));
};

var StyledTopPanel = _material_ui_core_styles_withStyles__WEBPACK_IMPORTED_MODULE_1___default()(styles)(FllTopPanel);
/* harmony default export */ __webpack_exports__["default"] = (StyledTopPanel);

/***/ }),

/***/ "./components/FieldLevelLineage/v2/index.tsx":
/*!***************************************************!*\
  !*** ./components/FieldLevelLineage/v2/index.tsx ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FllExpt; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_FieldLevelLineage_v2_LineageSummary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/FieldLevelLineage/v2/LineageSummary */ "./components/FieldLevelLineage/v2/LineageSummary/index.tsx");
/* harmony import */ var components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/FieldLevelLineage/v2/Context/FllContext */ "./components/FieldLevelLineage/v2/Context/FllContext.tsx");
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
    }

    return t;
  };

  return __assign.apply(this, arguments);
};




function FllExpt(props) {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_Context_FllContext__WEBPACK_IMPORTED_MODULE_2__["Provider"], __assign({}, props), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_FieldLevelLineage_v2_LineageSummary__WEBPACK_IMPORTED_MODULE_1__["default"], null));
}

/***/ }),

/***/ "./components/SortableStickyGrid/SortableStickyGrid.scss":
/*!***************************************************************!*\
  !*** ./components/SortableStickyGrid/SortableStickyGrid.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./SortableStickyGrid.scss */ "../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/src/index.js!../../node_modules/sass-loader/dist/cjs.js!./components/SortableStickyGrid/SortableStickyGrid.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(module.i, content, options);

var exported = content.locals ? content.locals : {};



module.exports = exported;

/***/ }),

/***/ "./components/SortableStickyGrid/index.js":
/*!************************************************!*\
  !*** ./components/SortableStickyGrid/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SortableStickyGrid; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! uuid/v4 */ "../../node_modules/uuid/v4.js");
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_IconSVG__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/IconSVG */ "./components/IconSVG/index.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash/orderBy */ "../../node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var services_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! services/helpers */ "./services/helpers.js");
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash/isEqual */ "../../node_modules/lodash/isEqual.js");
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_isEqual__WEBPACK_IMPORTED_MODULE_7__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright © 2018 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */









__webpack_require__(/*! ./SortableStickyGrid.scss */ "./components/SortableStickyGrid/SortableStickyGrid.scss");

var SORT_ORDERS = {
  asc: 'asc',
  desc: 'desc'
};

var SortableStickyGrid =
/*#__PURE__*/
function (_Component) {
  _inherits(SortableStickyGrid, _Component);

  function SortableStickyGrid(props) {
    var _this;

    _classCallCheck(this, SortableStickyGrid);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(SortableStickyGrid).call(this, props));

    _defineProperty(_assertThisInitialized(_this), "handleSort", function (property) {
      var newSortProperty, newSortOrder;

      if (_this.state.sortProperty === property) {
        newSortProperty = _this.state.sortProperty;
        newSortOrder = _this.state.sortOrder === SORT_ORDERS.asc ? SORT_ORDERS.desc : SORT_ORDERS.asc;
      } else {
        newSortProperty = property;
        newSortOrder = SORT_ORDERS.asc;
      }

      _this.setState({
        sortProperty: newSortProperty,
        sortOrder: newSortOrder,
        entities: lodash_orderBy__WEBPACK_IMPORTED_MODULE_5___default()(_this.state.entities, [newSortProperty], [newSortOrder])
      });
    });

    var sortProperty = props.defaultSortProperty || Object(services_helpers__WEBPACK_IMPORTED_MODULE_6__["objectQuery"])(props.gridHeaders, 0, 'property');
    var sortOrder = SORT_ORDERS.asc;
    _this.state = {
      entities: lodash_orderBy__WEBPACK_IMPORTED_MODULE_5___default()(props.entities, [sortProperty], [sortOrder]),
      sortProperty: sortProperty,
      sortOrder: sortOrder
    };
    return _this;
  }

  _createClass(SortableStickyGrid, [{
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(nextProps) {
      if (!lodash_isEqual__WEBPACK_IMPORTED_MODULE_7___default()(this.props.entities, nextProps.entities)) {
        this.setState({
          entities: lodash_orderBy__WEBPACK_IMPORTED_MODULE_5___default()(nextProps.entities, [this.state.sortProperty], [this.state.sortOrder])
        });
      }
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      var highlightedElems = document.getElementsByClassName('highlighted');

      if (highlightedElems.length) {
        highlightedElems[0].scrollIntoView();
      }
    }
  }, {
    key: "renderSortIcon",
    value: function renderSortIcon(property) {
      if (property !== this.state.sortProperty) {
        return null;
      }

      return this.state.sortOrder === SORT_ORDERS.asc ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-caret-down"
      }) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_IconSVG__WEBPACK_IMPORTED_MODULE_4__["default"], {
        name: "icon-caret-up"
      });
    }
  }, {
    key: "renderGridHeader",
    value: function renderGridHeader() {
      var _this2 = this;

      if (this.props.renderGridHeader) {
        return this.props.renderGridHeader();
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-header"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-row"
      }, this.props.gridHeaders.map(function (header) {
        if (header.property) {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", {
            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('sortable-header', {
              active: _this2.state.sortProperty === header.property
            }),
            key: uuid_v4__WEBPACK_IMPORTED_MODULE_3___default()(),
            onClick: _this2.handleSort.bind(_this2, header.property)
          }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, header.label), _this2.renderSortIcon(header.property));
        }

        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", {
          key: uuid_v4__WEBPACK_IMPORTED_MODULE_3___default()()
        }, header.label);
      })));
    }
  }, {
    key: "renderGridBody",
    value: function renderGridBody() {
      var _this3 = this;

      if (this.props.renderGridBody) {
        return this.props.renderGridBody(this.state.entities);
      }

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "grid-body"
      }, this.state.entities.map(function (entity) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('grid-row', {
            'grid-link': _this3.props.cellIsClickable,
            highlighted: entity.highlighted
          }),
          key: uuid_v4__WEBPACK_IMPORTED_MODULE_3___default()()
        }, _this3.props.gridHeaders.map(function (header) {
          return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
            key: uuid_v4__WEBPACK_IMPORTED_MODULE_3___default()()
          }, entity[header.property]);
        }));
      }));
    }
  }, {
    key: "render",
    value: function render() {
      var gridClasses = classnames__WEBPACK_IMPORTED_MODULE_1___default()('grid-wrapper sortable-sticky-grid', this.props.className);
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: gridClasses
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('grid grid-container', {
          'grid-sm': this.props.size === 'small'
        })
      }, this.renderGridHeader(), this.renderGridBody()));
    }
  }]);

  return SortableStickyGrid;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

_defineProperty(SortableStickyGrid, "propTypes", {
  entities: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.object).isRequired,
  gridHeaders: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.shape({
    label: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    property: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string
  })),
  renderGridHeader: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func,
  renderGridBody: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func,
  className: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  cellIsClickable: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool,
  defaultSortProperty: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  size: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string
});

_defineProperty(SortableStickyGrid, "defaultProps", {
  cellIsClickable: false
});



/***/ })

}]);
//# sourceMappingURL=FieldLevelLineage.170ad83234ea3ebf9647.js.map