(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["LabExperimentTest"],{

/***/ "./components/Lab/LabExperimentTest/index.tsx":
/*!****************************************************!*\
  !*** ./components/Lab/LabExperimentTest/index.tsx ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_Lab_ExperimentalFeature__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/Lab/ExperimentalFeature */ "./components/Lab/ExperimentalFeature/index.tsx");
/* harmony import */ var components_Lab_ToggleExperiment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/Lab/ToggleExperiment */ "./components/Lab/ToggleExperiment/index.tsx");
/*
 * Copyright © 2020 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */



var DEFAULT_EXPERIMENT = 'cdap-common-experiment';

var LabExperimentTest = function LabExperimentTest() {
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Lab_ExperimentalFeature__WEBPACK_IMPORTED_MODULE_1__["default"], {
    name: DEFAULT_EXPERIMENT
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("p", {
    "data-cy": "experimental-feature-selector"
  }, "This is an experimental component.")), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_Lab_ToggleExperiment__WEBPACK_IMPORTED_MODULE_2__["default"], {
    name: DEFAULT_EXPERIMENT,
    defaultComponent: react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("p", {
      "data-cy": "default-feature-toggle-selector"
    }, "This is default component for the toggle."),
    experimentalComponent: react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("p", {
      "data-cy": "experimental-feature-toggle-selector"
    }, "This is experimental component for the toggle.")
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (LabExperimentTest);

/***/ })

}]);
//# sourceMappingURL=LabExperimentTest.e70154600d80fd662073.js.map